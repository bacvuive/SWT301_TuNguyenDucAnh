# Prompt Log — Unit Testing & Integration cho Toàn Dự Án **BLOODLINK**

**Model:** ChatGPT — GPT-5 Thinking  
**Tech stack:** Java 17/22 · Maven · Tomcat 10.1 · Hibernate 6.5 · SQL Server · JUnit 5 · Mockito · Testcontainers (tuỳ chọn) · JaCoCo (LINE & BRANCH ≥ 80%)

> Tài liệu này là **nhật ký prompt** (prompts + output mong đợi) để bạn có thể **tái lập toàn bộ quy trình** kiểm thử (unit, web, integration) cho dự án BLOODLINK. Bạn có thể chạy từng prompt trong ChatGPT để sinh phân tích/test/patch tương ứng, hoặc dùng chúng như checklist review test hiện có.

---

## 0) Mục tiêu & Điều kiện Hoàn Thành (Definition of Done)

- **≥ 60 test cases** (unit + web + integration) bao phủ các module:
  - **Domain/Service:** Appointment, Donation, BloodInventory, TransferRequest, **BloodRequest**, Notification
  - **Auth & Admin:** Login/Session, Role guard, Audit
  - **Web:** `AppointmentServlet`, `BloodInventoryServlet`, `TransferRequestServlet`, REST API liên quan
  - **Repository/DAO:** CRUD & truy vấn đặc thù (mock/in-memory)
- **Coverage:** LINE & BRANCH ≥ **80%** (JaCoCo enforce tại `mvn verify`).
- **Mock đúng:** Repo/DAO + EmailService + NotificationService + External Gateways.
- **Integration:** 1–2 flow end-to-end (happy & lỗi) với DB thực (**Testcontainers SQL Server**) hoặc profile test **SQLServer**.
- **Deliverables:** `README`, `/prompts/log.md`, test suite xanh, `target/site/jacoco/index.html`, scripts DB test.

---

## 1) Giai đoạn 1 — PHÂN TÍCH (Toàn dự án)

### Prompt 1.1 — **Lập bản đồ chức năng & điểm test theo module**
```
Role: Senior SDET (Java). Hãy đọc kiến trúc BLOODLINK và liệt kê tính năng chính theo module:
- AppointmentService (create/update/cancel/complete, getByDonor/Hospital, rule trùng lịch)
- DonationService (create, updateTestResult, rule sàng lọc)
- BloodInventoryService (getInventory, add/remove/update, low stock alert)
- TransferRequestService (create/accept/reject/cancel, allocation)
- BloodRequestService (create/approve/reject/fulfill/notify)  ← BỔ SUNG
- Notifications (email + push), Audit & Login (session/role)
- Web layer (Servlets + endpoints + tham số bắt buộc)

YÊU CẦU XUẤT RA:
A) Bảng feature → Inputs/Outputs/Side-effects/Edge cases/Must-mock
B) Hai luồng nghiệp vụ end-to-end tiêu biểu (1 happy, 1 lỗi) + điều kiện tiền đề
C) Ràng buộc dữ liệu & rule đặc thù (VD: ABO/Rh phù hợp, stock không âm)
- BÁM THEO SOURCE; không suy đoán vượt phạm vi.
```
### Output 1 — **Bảng feature & luồng E2E**

**A) Feature per module (rút gọn định dạng; bổ sung theo code thực tế)**

| Module | Function | Inputs (ràng buộc) | Output/Effects | Edge/Branch quan trọng | Must‑mock |
|---|---|---|---|---|---|
| AppointmentService | create | donorId, hospitalId, slot (ISO), note? | return boolean; save PENDING | donor/hospital !exists; **conflict** slot; slot in past; boundary first-of-day | AppointmentRepo, DonorRepo, HospitalRepo |
|  | cancel | appointmentId | update status → CANCELED | not found; status !∈ {PENDING,CONFIRMED} | AppointmentRepo |
|  | complete | appointmentId | update status → COMPLETED | status != ATTENDED; not found | AppointmentRepo |
| DonationService | create | donorId, hospitalId, bagId (unique), type (ABO±), qty>0 | save PENDING_TEST | duplicate bagId; invalid type; qty≤0 | DonationRepo, InventoryGateway? |
|  | updateTestResult | donationId, result (NEG/POS) | NEG → add to inventory; POS → REJECTED | not found; double update; notify | DonationRepo, InventoryService, EmailService |
| BloodInventoryService | add | bagId, bloodType, qty | increase stock | duplicate bagId | InventoryRepo |
|  | remove | type, qty | decrease stock | **avail < qty → throw**; boundary avail==qty | InventoryRepo |
|  | getLow | threshold | list nhóm thiếu | none | InventoryRepo, NotificationService |
| TransferRequestService | create | fromHospital, toHospital, type, qty | save PENDING | qty≤0; hospital !exists | TransferRepo, HospitalRepo |
|  | accept | requestId, approverId | if stock≥qty → deduct & COMPLETED; else throw | **insufficient**; not found; status≠PENDING | TransferRepo, InventoryService |
|  | cancel | requestId | CANCELED | status≠PENDING; not found | TransferRepo |
| **BloodRequestService** | **create** | hospitalId, bloodType, qty>0 | save PENDING | hospital !exists; invalid type; duplicate pending; qty≤0; boundary qty=1 | HospitalRepo, BloodRequestRepo |
|  | **approve** | requestId, adminId | APPROVED | admin !exists; not found; status≠PENDING | AdminRepo, BloodRequestRepo |
|  | **reject** | requestId, reason !blank | REJECTED(reason) | reason null/blank; not found; status≠PENDING | BloodRequestRepo |
|  | **fulfill** | requestId | if stock≥qty → deduct & COMPLETED; else **throw** | not found; status≠APPROVED; stock<qty; boundary avail==qty | BloodRequestRepo, InventoryRepo |
|  | **notify** | requestId | email+push khi status∈{APPROVED,REJECTED,COMPLETED} | not found; PENDING; missing email; **partial fail** | BloodRequestRepo, HospitalRepo, EmailSvc, NotifSvc |
| Notifications | sendEmail/push | to, subject/body | boolean | email fail / push fail (partial) | EmailService, NotificationService |
| Auth/Admin | login, guard | username, pass, role | session, 401/403 | bad creds; role mismatch | UserRepo, Session |
| Web Servlets | POST/GET | param mapping | status code + JSON/JSP | **422** invalid param; 400 missing; 401/403 | Services, Jackson/JSP |

**B) Luồng nghiệp vụ E2E tiêu biểu**  
- **Happy:** Tạo lịch hẹn → hiến máu **NEGATIVE** → **Inventory.add** → bệnh viện tạo **BloodRequest** → **approve** → **fulfill** (deduct) → **notify** OK.  
- **Lỗi:** Bệnh viện tạo **BloodRequest** → **approve** nhưng **stock < qty** → **fulfill throw** → **audit** + **notify** lỗi.

**C) Ràng buộc dữ liệu & rule**  
- ABO/Rh hợp lệ: {A±, B±, AB±, O±}.  
- **Stock không âm**; mọi thao tác deduct phải kiểm tra `available ≥ qty`.  
- Trạng thái **PENDING → APPROVED/REJECTED → COMPLETED** (đơn BloodRequest/TransferRequest).  
- **Email subject:** `"Blood Request " + STATUS"`, **push:** `"Request <id> is <STATUS>"`.

---

## 2) Giai đoạn 2 — THIẾT KẾ TEST (đa module)

### Prompt 2.1 — **Sinh TEST MATRIX (đa module + BloodRequest)**
```
Role: Senior SDET. Sinh TEST MATRIX toàn dự án (kể cả BloodRequest). Cột bắt buộc:
| Module | Function | Case ID | Case Name | Given | When | Then | Notes (mock/verify) |
- Mỗi module ≥ 8 case (web: 4–6). Bao phủ: happy, edge, error, boundary, state-based.
- Ưu tiên nhánh ảnh hưởng BRANCH: not found, invalid input/status, race, duplicate, permission denied, partial fail.
- Web layer: map tham số request, status code, JSON/JSP render, error mapping.
- BÁM SOURCE; không suy đoán quá phạm vi.
```
### Output 2.1 — **Test Matrix (tóm tắt mức “đầy đủ” để triển khai)**

> *Gợi ý: bạn có thể mang bảng này vào CSV để import sang test management tool.*

#### **AppointmentService (8+)**
| Module | Function | Case ID | Case Name | Given | When | Then | Notes |
|---|---|---|---|---|---|---|---|
| Appointment | create | AP-C1 | create_ok_no_conflict_true | donor & hospital exist; slot free | create | true; save PENDING | verify(save(PENDING)) |
|  |  | AP-C2 | create_conflict_false | slot already taken | create | false | verify(save, never()) |
|  |  | AP-C3 | create_past_slot_false | slot < now | create | false | never(save) |
|  | cancel | AP-X1 | cancel_pending_true | status=PENDING | cancel | true; CANCELED | updateStatus(CANCELED) |
|  |  | AP-X2 | cancel_not_found_false | not found | cancel | false | never(update) |
|  | complete | AP-X3 | complete_only_when_attended_true | status=ATTENDED | complete | true; COMPLETED | updateStatus(COMPLETED) |
|  | complete | AP-X4 | complete_wrong_status_false | status!=ATTENDED | complete | false | never(update) |
|  | getByDonor | AP-G1 | get_by_donor_paged_ok | donor has appts | getByDonor | list | verify(repo.query) |

#### **DonationService (8+)**
| Module | Function | Case ID | Case Name | Given | When | Then | Notes |
|---|---|---|---|---|---|---|---|
| Donation | create | DN-C1 | create_ok_screening_pending | donor ok, bag unique | create | PENDING_TEST | save() |
|  |  | DN-C2 | create_duplicate_bag_false | bagId exists | create | false | never(save) |
|  | updateResult | DN-U1 | result_positive_reject | result=POS | update | REJECTED | audit.log, notify |
|  |  | DN-U2 | result_negative_add_inventory | result=NEG | update | added to inventory | inventory.add(...), email |
|  |  | DN-U3 | update_not_found_false | donationId empty | update | false | never(inventory.add) |
|  |  | DN-U4 | update_duplicate_call_idempotent | already final | update | false | no side-effects |
|  | getByHospital | DN-G1 | get_by_hospital_ok | rows exist | get | list | verify(repo.query) |
|  | getByDonor | DN-G2 | get_by_donor_ok | rows exist | get | list | verify(repo.query) |

#### **BloodInventoryService (10+)**
| Module | Function | Case ID | Case Name | Given | When | Then | Notes |
|---|---|---|---|---|---|---|---|
| Inventory | add | IV-A1 | add_valid_increase_stock | new bag | add | ok | save |
|  |  | IV-A2 | add_duplicate_bag_false | bag exists | add | false | never(save) |
|  | remove | IV-R1 | remove_over_stock_throw | avail<qty | remove | throws ISE | never(save) |
|  |  | IV-R2 | remove_exact_boundary_ok | avail==qty | remove | ok | save(deduct qty) |
|  | update | IV-U1 | update_qty_increase_ok | record exists | update | ok | save |
|  |  | IV-U2 | update_zero_qty_noop_false | qty==0 | update | false | never(save) |
|  | getLow | IV-L1 | low_stock_threshold_trigger | avail<threshold | getLow | list+notify | verify(notification) |
|  | find | IV-F1 | find_by_type_ok | type valid | find | list | repo.query |
|  | find | IV-F2 | find_invalid_type_false | type invalid | find | false | never(query) |
|  | audit | IV-AU1 | audit_on_deduct_ok | any deduct | remove | audit appended | verify(audit) |

#### **TransferRequestService (10+)**
| Module | Function | Case ID | Case Name | Given | When | Then | Notes |
|---|---|---|---|---|---|---|---|
| Transfer | create | TR-C1 | create_ok_pending | hospitals ok, qty>0 | create | PENDING | save |
|  |  | TR-C2 | create_qty_zero_422 | qty≤0 | create | false | never(save) |
|  | accept | TR-A1 | accept_pending_ok | status=PENDING, stock≥qty | accept | COMPLETED | inventory.deduct; updateStatus |
|  |  | TR-A2 | accept_insufficient_stock_throw | stock<qty | accept | throw ISE | never(COMPLETED) |
|  |  | TR-A3 | accept_not_found_false | not found | accept | false | never(deduct) |
|  | reject | TR-R1 | reject_pending_ok | status=PENDING | reject | REJECTED | updateStatus |
|  | cancel | TR-X1 | cancel_pending_true | status=PENDING | cancel | CANCELED | updateStatus |
|  | cancel | TR-X2 | cancel_approved_false | status=APPROVED | cancel | false | never(update) |
|  | list | TR-L1 | list_by_hospital_ok | rows exist | list | list | repo.query |
|  | list | TR-L2 | list_empty_ok | none | list | empty | ok |

#### **BloodRequestService (10+)**
| Module | Function | Case ID | Case Name | Given | When | Then | Notes |
|---|---|---|---|---|---|---|---|
| BloodRequest | create | BR-C1 | create_ok_pending | hospital exists; bt valid; qty=3 | create | true; PENDING | verify(save(PENDING)) |
|  |  | BR-C2 | create_invalid_bt_false | bt="X0" | create | false | never(save) |
|  |  | BR-C3 | create_qty_le_0_false | qty=0 | create | false | never(save) |
|  |  | BR-C4 | create_duplicate_pending_false | existsPending=true | create | false | never(save) |
|  | approve | BR-A1 | approve_pending_admin_ok | admin exists; status=PENDING | approve | APPROVED | updateStatus(APPROVED) |
|  |  | BR-A2 | approve_admin_invalid_false | admin !exists | approve | false | never(update) |
|  | reject | BR-R1 | reject_reason_ok | status=PENDING; reason="dup" | reject | REJECTED | updateStatus(REJECTED,"dup") |
|  |  | BR-R2 | reject_reason_blank_false | reason="  " | reject | false | never(update) |
|  | fulfill | BR-F1 | fulfill_approved_stock_ok | APPROVED; avail≥qty | fulfill | COMPLETED | inventory.deduct; updateStatus |
|  |  | BR-F2 | fulfill_insufficient_throw | avail<qty | fulfill | throw ISE | never(update COMPLETED) |
|  |  | BR-F3 | fulfill_not_found_false | missing | fulfill | false | never(deduct) |
|  | notify | BR-N1 | notify_completed_both_ok | status=COMPLETED; email exists; send&push=OK | notify | true | verify(subject "Blood Request COMPLETED"; push "Request <id> is COMPLETED") |
|  |  | BR-N2 | notify_missing_email_false | email empty | notify | false | never(send/push) |
|  |  | BR-N3 | notify_partial_email_ok_push_fail_false | send=true, push=false | notify | false | partial fail |

#### **Notifications (6+)**
| Module | Function | Case ID | Case Name | Given | When | Then | Notes |
|---|---|---|---|---|---|---|---|
| Notify | send | NT-S1 | email_subject_body_format_ok | status=COMPLETED | send | true | subject equals; body contains |
|  |  | NT-S2 | push_format_ok | message template | push | true | eq("Request <id> is <STATUS>") |
|  |  | NT-S3 | email_fail_false | provider down | send | false | handle false |
|  |  | NT-S4 | push_fail_false | provider down | push | false | handle false |
|  |  | NT-S5 | partial_email_ok_push_fail_false | send ok, push fail | notify | false | return false |
|  |  | NT-S6 | partial_email_fail_push_ok_false | send fail, push ok | notify | false | return false |

#### **Web/Servlets (12+)**
| Module | Endpoint | Case ID | Case Name | Given | When | Then | Notes |
|---|---|---|---|---|---|---|---|
| AppointmentServlet | POST /appointments | WS-A1 | post_create_missing_param_400 | thiếu donorId | POST | 400 | map lỗi param |
|  |  | WS-A2 | post_create_ok_201 | body hợp lệ | POST | 201 | verify(service.create) |
| BloodInventoryServlet | GET /blood-inventory | WS-I1 | get_inventory_ok_200_json | hospitalId hợp lệ | GET | 200 JSON | verify(service.getHospitalInventory) |
|  |  | WS-I2 | get_inventory_missing_400 | thiếu hospitalId | GET | 400 | |
| TransferRequestServlet | POST /transfer-requests | WS-T1 | post_create_ok_201 | body hợp lệ | POST | 201 | verify(create) |
|  |  | WS-T2 | post_create_invalid_422 | qty≤0 | POST | 422 | never(create) |
| BloodRequest REST | POST /bloodrequests | WS-BR1 | post_bloodrequest_ok_201 | body hợp lệ | POST | 201 | verify(BR.create) |
|  |  | WS-BR2 | post_bloodrequest_invalid_422 | invalid bt/qty | POST | 422 | never(create) |
|  | PUT /bloodrequests/{id}/approve | WS-BR3 | put_approve_ok_200 | admin ok | PUT | 200 | verify(BR.approve) |
|  | PUT /bloodrequests/{id}/reject | WS-BR4 | put_reject_blank_422 | reason blank | PUT | 422 | never(reject) |
|  | PUT /bloodrequests/{id}/fulfill | WS-BR5 | put_fulfill_insufficient_409 | stock<qty | PUT | 409 | assert msg |
|  | POST /bloodrequests/{id}/notify | WS-BR6 | post_notify_partial_fail_500 | push fail | POST | 500 | return false |

---

### Prompt 2.2 — **Coverage-by-Design (toàn dự án + BloodRequest)**
```
Role: Senior SDET. Đánh giá coverage-by-design cho từng module dựa trên Test Matrix & source hiện tại.
YÊU CẦU:
A) Checklist nhánh/điều kiện (Covered ✅/❌) + Case ID.
B) Bảng Missing Branches → đề xuất case mới (Given/When/Then + verify/never).
C) Bảng Estimated Branch % per module + mini‑plan 12 test để vượt 80%.
```
### Output 2.2 — **Tóm tắt đánh giá**
- Thiếu phổ biến: **not found** ở nhiều service, **permission denied (401/403)** ở web, **partial failures** trong Notifications, boundary **stock==qty**.
- **Mini‑plan 12 test mới** (mỗi module 2–3 case) ưu tiên đóng các nhánh trên, riêng BloodRequest thêm BR-F3 (not found), BR-N3 (partial).

---

## 3) Giai đoạn 3 — SINH TEST CODE

### Prompt 3.1 — **Sinh skeleton test theo module & package**
```
Role: Senior SDET. Hãy sinh 8 lớp test và test methods skeleton theo Test Matrix (kể cả BloodRequest).
Yêu cầu chung:
- JUnit 5 + Mockito; @ExtendWith(MockitoExtension).
- @InjectMocks cho service; @Mock cho dependencies (Repo/DAO/Email/Notif).
- Tên test: action_condition_expectedResult.
- Mỗi test có Given–When–Then + verify() cần thiết, nhánh fail phải có verify(..., never()).
- Web test: dùng MockHttpServletRequest/Response (javax.servlet-api test util) hoặc wrapper tương đương.
```

**Output 3.1 — Cấu trúc & số lượng đề xuất**
- `AppointmentServiceTest.java` — **≥ 8** tests  
- `DonationServiceTest.java` — **≥ 8** tests  
- `BloodInventoryServiceTest.java` — **≥ 10** tests  
- `TransferRequestServiceTest.java` — **≥ 10** tests  
- `BloodRequestServiceTest.java` — **≥ 10** tests  ← **BỔ SUNG**  
- `NotificationServiceTest.java` — **≥ 6** tests  
- `AppointmentServletTest.java` — **≥ 4** tests  
- `BloodInventoryServletTest.java` — **≥ 4** tests  
- `TransferRequestServletTest.java` — **≥ 4** tests  
- `BloodRequestApiTest.java` — **≥ 6** tests  ← **BỔ SUNG (web)**

> **Matcher chặt chẽ:** ưu tiên `eq/contains/argThat`, tránh mix matchers trong cùng call; nhánh âm dùng `never()`.

---

### Prompt 3.2 — **JaCoCo & Surefire enforce**
```
Role: Build Engineer. Hãy bổ sung cấu hình Maven để enforce coverage.
YÊU CẦU:
- maven-surefire-plugin 3.2.x
- jacoco-maven-plugin: prepare-agent + report + check
- check: line & branch ≥ 0.80 (nếu branch-threshold riêng, document)
- profile test-db: H2 hoặc Testcontainers (MSSQL) cho integration
- Lệnh chạy: mvn -q clean verify
```
**Output 3.2 — Phần `pom.xml` (mẫu rút gọn)**
```xml
<build>
  <plugins>
    <plugin>
      <groupId>org.jacoco</groupId>
      <artifactId>jacoco-maven-plugin</artifactId>
      <version>0.8.12</version>
      <executions>
        <execution>
          <goals><goal>prepare-agent</goal></goals>
        </execution>
        <execution>
          <id>report</id>
          <phase>verify</phase>
          <goals><goal>report</goal><goal>check</goal></goals>
          <configuration>
            <rules>
              <rule>
                <element>BUNDLE</element>
                <limits>
                  <limit>
                    <counter>LINE</counter>
                    <value>COVEREDRATIO</value>
                    <minimum>0.80</minimum>
                  </limit>
                  <limit>
                    <counter>BRANCH</counter>
                    <value>COVEREDRATIO</value>
                    <minimum>0.80</minimum>
                  </limit>
                </limits>
              </rule>
            </rules>
          </configuration>
        </execution>
      </executions>
    </plugin>

    <plugin>
      <groupId>org.apache.maven.plugins</groupId>
      <artifactId>maven-surefire-plugin</artifactId>
      <version>3.2.5</version>
      <configuration>
        <argLine>-XX:+EnableDynamicAgentLoading</argLine>
      </configuration>
    </plugin>
  </plugins>
</build>

<profiles>
  <profile>
    <id>test-h2</id>
    <properties>
      <spring.profiles.active>test-h2</spring.profiles.active>
    </properties>
    <!-- deps H2 + Flyway/Liquibase nếu dùng -->
  </profile>
</profiles>
```

---

## 4) Giai đoạn 4 — CHẠY & DEBUG

### Prompt 4.1 — **Template chẩn đoán lỗi test (copy/paste stacktrace)**
```
Vai trò: Senior SDET. Hãy chẩn đoán và sửa test fail.

ĐẦU VÀO (bắt buộc):
1) Môi trường: OS, JDK, Maven, JUnit, Mockito, JaCoCo (version); command chạy (mvn/IntelliJ).
2) Lỗi: Mô tả ngắn “expected vs actual”.
3) Stacktrace đầy đủ (copy nguyên văn).
4) Test code liên quan (@Test, @BeforeEach).
5) Source code liên quan (method trong service).
6) Bước tái hiện (command hoặc config IDE).

YÊU CẦU ĐẦU RA:
A) Root cause (thiếu stubbing, mix matchers, verify sai tham số, …).
B) Vị trí & nhánh (if/else/throw) dẫn đến lỗi.
C) Patch tối thiểu (unified diff) — ưu tiên sửa TEST trước; chỉ sửa CODE khi rule sai.
D) Cách kiểm chứng (rerun mvn/IDE), kỳ vọng pass.
```
**Output 4 — Mẫu lỗi phổ biến & patch**

- **Email subject/body lệch format (BloodRequest.notify):** test verify subject chứa “Request #id” trong khi **subject** thực tế là `"Blood Request " + STATUS` (id nằm ở **body**). → Sửa verify: `eq("Blood Request COMPLETED")` cho subject; body dùng `argThat` contains `#<id>`.

- **verifyNoMoreInteractions gãy:** service gọi `findById()` ngoài `updateStatus()`. → Hoặc verify thêm `findById`, hoặc bỏ `verifyNoMoreInteractions()`.

- **Servlet 400/422 do thiếu mapping:** thêm test map param & thông điệp.

---

## 5) Giai đoạn 5 — TỐI ƯU & TĂNG COVERAGE

### Prompt 5.1 — **Liệt kê nhánh thiếu & test bù (mỗi module, gồm BloodRequest)**
```
Role: Senior SDET. Đọc báo cáo JaCoCo + source, liệt kê nhánh chưa cover per module.
Đề xuất @Test mới: Given/When/Then, stubbing when(...).thenReturn(...),
assert/verify (eq/contains/argThat), never()/times(n). Nếu exception → assertThrows + message contains "<keyword>".
Ưu tiên: not found, invalid status, boundary stock==qty, partial fail notifications, permission denied (web).
```
**Output 5.1 — Ví dụ đề xuất (đã map nhánh)**

- **Inventory:** `remove_over_stock_throw`, `update_zero_qty_noop_false`, `add_duplicate_bag_id_false`  
- **Transfer:** `accept_not_found_false`, `cancel_approved_false`, `create_qty_zero_422`  
- **Web:** `auth_required_401`, `role_forbidden_403` (nếu có filter/guard)  
- **Notify:** `send_ok_push_fail_false`, `email_fail_push_ok_false`  
- **BloodRequest:**  
  - `fulfill_not_found_false` → if `findById(id).isEmpty()` return false  
  - `reject_reason_null_false` → if `reason==null` early return  
  - `notify_not_found_false` → if request not found, `never(send/push)`

### Prompt 5.2 — **Siết verify & tránh mix matchers**
```
Role: Senior SDET. Rà soát verify toàn bộ test:
- Dùng eq()/contains()/argThat() đúng từng tham số.
- Nhánh âm: verify(..., never()) + (tùy chọn) verifyNoInteractions/verifyNoMoreInteractions.
- Tránh mix matchers: nếu một tham số dùng matcher thì tất cả tham số khác cũng dùng matcher.
- Exception: assertThrows + assert message contains "<keyword>".
Xuất patch kiểu unified diff (chỉ chạm file test).
```

---

## 6) Giai đoạn 6 — DOCUMENTATION & DEMO

### Prompt 6.1 — **README chạy dự án & test**
```
Role: Tech Writer. Hãy soạn README cho BLOODLINK:
- Cài đặt: JDK 17/22, Maven, Tomcat 10.1, SQL Server (hoặc H2 profile test).
- Chạy local (IntelliJ/Tomcat), build (mvn package).
- Chạy test & coverage: mvn -q clean verify; báo cáo: target/site/jacoco/index.html.
- Troubleshoot Tomcat: cổng 8080/8005 bận (java.net.BindException), chỉnh server.xml Connector & Server.
- DBCP2 warning: dùng maxTotal, maxWaitMillis thay cho maxActive/maxWait.
- Mockito/ByteBuddy: thêm `-XX:+EnableDynamicAgentLoading` để ẩn cảnh báo.
```
**Output 6.1 — Lệnh tiêu chuẩn**
```bash
mvn -q clean verify
# Open coverage at: target/site/jacoco/index.html

mvn -q clean package
# Deploy WAR → $CATALINA_BASE/webapps

# (Tuỳ chọn) Profile DB test H2:
mvn -q clean verify -Ptest-h2
```

### Prompt 6.2 — **Slide + demo script**
```
Role: Presenter. Soạn 10–12 slide: Kiến trúc, modules, Test Matrix, Mocking, Coverage, 2 demo flows (happy + lỗi),
bài học & mở rộng (contract test, mutation testing). Kèm speaker notes ngắn.
```

---

## 7) Giai đoạn 7 — INTEGRATION TEST (khuyến nghị)

### Prompt 7.1 — **Thiết kế Integration flow & Testcontainers 
```
Role: Senior SDET. Thiết kế 2 bài IT:
1) Flow happy: create appointment → donation NEGATIVE → add bag → hospital tạo BloodRequest → approve → fulfill → notify OK.
2) Flow lỗi: BloodRequest approve nhưng stock<qty → fulfill throw → audit + notify lỗi.

Dùng Testcontainers (SQL Server) với schema test.
Sinh base class: @Testcontainers, @Container (MSSQLServerContainer), Flyway/Liquibase migration test.
```
**Output 7.1 — Dàn ý lớp *IT.java***
- `BloodlinkHappyFlowIT` — dựng dữ liệu seed (donor, hospital, inventory with NEG bag), gọi services tuần tự, assert cuối: request COMPLETED, email+push OK.  
- `BloodlinkInsufficientStockIT` — thiếu stock, assert `IllegalStateException("Insufficient stock")`, audit log có entry, notify trả false.

---

## Phụ lục A — **Snippet verify quan trọng (BloodRequest.notify)**

```java
verify(emailService).send(
  eq("hos@mail.com"),
  eq("Blood Request COMPLETED"),
  argThat(b -> b.contains("Request #"+id) &&
               b.contains(" for "+bloodType+" ("+qty+" units)") &&
               b.contains("COMPLETED"))
);
verify(notificationService).pushToHospital(
  eq(hospitalId), eq("Request "+id+" is COMPLETED")
);
```

## Phụ lục B — **Mẫu xương sống lớp test (Mockito/JUnit5)**

```java
@ExtendWith(MockitoExtension.class)
class BloodRequestServiceTest {

  @Mock HospitalRepository hospitals;
  @Mock BloodRequestRepository requests;
  @Mock BloodInventoryRepository inventory;
  @Mock AdminRepository admins;
  @Mock EmailService email;
  @Mock NotificationService notif;

  @InjectMocks BloodRequestService svc;

  @Test
  void create_invalid_bt_false() {
    // Given
    when(hospitals.existsById(9)).thenReturn(true);

    // When
    boolean ok = svc.createBloodRequest(9, "X0", 3);

    // Then
    assertFalse(ok);
    verify(requests, never()).save(any());
  }
}
```

---



