# Tổng quan System Test

## Công nghệ sử dụng cho System Test
- **JUnit 5 (JUnit Jupiter):** Khung chạy test chính cho các lớp `AuthTests`, `DonorScheduleTests`, `HospitalRequestTests`.
- **Selenium WebDriver 4:** Tương tác trình duyệt ở mức DOM, xử lý luồng UI end-to-end.
- **ChromeDriver + WebDriverManager:** Tự động quản lý binary và điều khiển trình duyệt Chrome.
- **Selenium Support (WebDriverWait, ExpectedConditions):** Đồng bộ hoá chờ phần tử, tránh test flaky.
- **Java 17:** Ngôn ngữ triển khai test suite và page object.

## AuthTests
- **Register donor (success):** Gửi thông tin hợp lệ và mong đợi thông báo thành công hoặc điều hướng về trang đăng nhập.
- **Register donor (password mismatch):** Nhập mật khẩu và xác nhận không khớp, form phải hiển thị lỗi.
- **Login donor (success):** Đăng nhập với tài khoản hợp lệ và kiểm tra được chuyển vào dashboard/chào mừng.
- **Login donor (wrong password):** Dùng mật khẩu sai, vẫn ở trang đăng nhập và thấy thông báo lỗi.
- **Login hospital (success):** Đăng nhập bằng tài khoản bệnh viện và xác nhận được chuyển tới khu vực hospital.

## DonorScheduleTests
- **Create appointment (success):** Donor đăng nhập, tạo lịch hẹn và kiểm tra trạng thái thành công.
- **Create appointment (missing datetime):** Gửi form thiếu datetime, UI/browser phải báo lỗi.
- **Schedule unauthorized access:** Truy cập `/donor/schedule` khi chưa đăng nhập sẽ bị chuyển hướng về trang login.

## HospitalRequestTests
- **Create targeted request (success):** Bệnh viện tạo yêu cầu gửi tới bệnh viện khác và nhận thông báo thành công.
- **Create broadcast request (success):** Gửi yêu cầu broadcast và xác nhận UI thông báo thành công.
- **Create request with zero quantity:** Nhập số lượng `0` để kiểm chứng lỗi validation phía server.
- **Create request missing blood group:** Để trống nhóm máu và xác nhận trình duyệt hiển thị cảnh báo.
- **Unauthorized request creation access:** Truy cập `/hospital/requests/create` không đăng nhập sẽ bị chuyển tới trang login.


