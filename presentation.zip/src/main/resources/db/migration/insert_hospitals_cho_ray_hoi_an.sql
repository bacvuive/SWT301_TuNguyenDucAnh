-- ================================================================
-- INSERT DATA CHO 2 BỆNH VIỆN: CHỢ RẪY VÀ HỘI AN
-- ================================================================
USE bloodlink;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRAN;

-- ================================================================
-- 1. TẠO USERS CHO 2 BỆNH VIỆN
-- ================================================================

DECLARE @user_choray_id INT;
DECLARE @user_hoian_id INT;

-- User cho Bệnh viện Chợ Rẫy
IF NOT EXISTS (SELECT 1 FROM dbo.[users] WHERE email = N'choray@bloodlink.vn')
BEGIN
    INSERT INTO dbo.[users](username, password_hash, email, role_code, [status])
    VALUES (
        N'choray',
        N'$2a$12$V.mBFpm7R5l.vbXdsraIFeUlYJt5xscnyC8MEzYesxFYJ1fc.D67S', -- password: password123
        N'choray@bloodlink.vn',
        N'hospital',
        N'active'
    );
    SET @user_choray_id = SCOPE_IDENTITY();
    PRINT 'Created user for Chợ Rẫy: ' + CAST(@user_choray_id AS VARCHAR(10));
END
ELSE
BEGIN
    SELECT @user_choray_id = user_id FROM dbo.[users] WHERE email = N'choray@bloodlink.vn';
    PRINT 'User Chợ Rẫy already exists: ' + CAST(@user_choray_id AS VARCHAR(10));
END

-- User cho Bệnh viện Hội An
IF NOT EXISTS (SELECT 1 FROM dbo.[users] WHERE email = N'hoian@bloodlink.vn')
BEGIN
    INSERT INTO dbo.[users](username, password_hash, email, role_code, [status])
    VALUES (
        N'hoian',
        N'$2a$12$V.mBFpm7R5l.vbXdsraIFeUlYJt5xscnyC8MEzYesxFYJ1fc.D67S', -- password: password123
        N'hoian@bloodlink.vn',
        N'hospital',
        N'active'
    );
    SET @user_hoian_id = SCOPE_IDENTITY();
    PRINT 'Created user for Hội An: ' + CAST(@user_hoian_id AS VARCHAR(10));
END
ELSE
BEGIN
    SELECT @user_hoian_id = user_id FROM dbo.[users] WHERE email = N'hoian@bloodlink.vn';
    PRINT 'User Hội An already exists: ' + CAST(@user_hoian_id AS VARCHAR(10));
END

-- ================================================================
-- 2. TẠO HOSPITAL RECORDS VỚI TỌA ĐỘ
-- ================================================================

DECLARE @hospital_choray_id INT;
DECLARE @hospital_hoian_id INT;

-- Bệnh viện Chợ Rẫy - TP.HCM
IF NOT EXISTS (SELECT 1 FROM dbo.hospital WHERE user_id = @user_choray_id)
BEGIN
    INSERT INTO dbo.hospital(user_id, [name], [address], contact, region, latitude, longitude, created_at)
    VALUES (
        @user_choray_id,
        N'Bệnh viện Chợ Rẫy',
        N'201B Nguyễn Chí Thanh, Phường 12, Quận 5, TP.HCM',
        N'028 3855 4137',
        N'TP.HCM',
        10.75994,  -- Latitude
        106.66186, -- Longitude
        SYSUTCDATETIME()
    );
    SET @hospital_choray_id = SCOPE_IDENTITY();
    PRINT 'Created hospital Chợ Rẫy: ' + CAST(@hospital_choray_id AS VARCHAR(10));
END
ELSE
BEGIN
    -- Update tọa độ nếu chưa có
    UPDATE dbo.hospital
    SET latitude = 10.75994,
        longitude = 106.66186,
        [name] = N'Bệnh viện Chợ Rẫy',
        [address] = N'201B Nguyễn Chí Thanh, Phường 12, Quận 5, TP.HCM',
        contact = N'028 3855 4137',
        region = N'TP.HCM'
    WHERE user_id = @user_choray_id;
    
    SELECT @hospital_choray_id = hospital_id FROM dbo.hospital WHERE user_id = @user_choray_id;
    PRINT 'Updated hospital Chợ Rẫy: ' + CAST(@hospital_choray_id AS VARCHAR(10));
END

-- Bệnh viện Hội An - Quảng Nam
IF NOT EXISTS (SELECT 1 FROM dbo.hospital WHERE user_id = @user_hoian_id)
BEGIN
    INSERT INTO dbo.hospital(user_id, [name], [address], contact, region, latitude, longitude, created_at)
    VALUES (
        @user_hoian_id,
        N'Bệnh viện Đa khoa Hội An',
        N'Nguyễn Du, Cẩm Châu, Hội An, Quảng Nam',
        N'0235 3861 234',
        N'Quảng Nam',
        15.57364,  -- Latitude
        108.47403, -- Longitude
        SYSUTCDATETIME()
    );
    SET @hospital_hoian_id = SCOPE_IDENTITY();
    PRINT 'Created hospital Hội An: ' + CAST(@hospital_hoian_id AS VARCHAR(10));
END
ELSE
BEGIN
    -- Update tọa độ nếu chưa có
    UPDATE dbo.hospital
    SET latitude = 15.57364,
        longitude = 108.47403,
        [name] = N'Bệnh viện Đa khoa Hội An',
        [address] = N'Nguyễn Du, Cẩm Châu, Hội An, Quảng Nam',
        contact = N'0235 3861 234',
        region = N'Quảng Nam'
    WHERE user_id = @user_hoian_id;
    
    SELECT @hospital_hoian_id = hospital_id FROM dbo.hospital WHERE user_id = @user_hoian_id;
    PRINT 'Updated hospital Hội An: ' + CAST(@hospital_hoian_id AS VARCHAR(10));
END

-- ================================================================
-- 3. THÊM BLOOD BAGS MẪU CHO 2 BỆNH VIỆN
-- ================================================================

-- Blood bags cho Chợ Rẫy
IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'CR001_O+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'CR001_O+_WB',
        @hospital_id = @hospital_choray_id,
        @record_id = NULL,
        @blood_group = N'O+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -5, GETDATE()));
    PRINT 'Added bag CR001_O+_WB for Chợ Rẫy';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'CR002_A+_RBC')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'CR002_A+_RBC',
        @hospital_id = @hospital_choray_id,
        @record_id = NULL,
        @blood_group = N'A+',
        @component = N'RBC',
        @volume_ml = 300,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -10, GETDATE()));
    PRINT 'Added bag CR002_A+_RBC for Chợ Rẫy';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'CR003_B+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'CR003_B+_WB',
        @hospital_id = @hospital_choray_id,
        @record_id = NULL,
        @blood_group = N'B+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -3, GETDATE()));
    PRINT 'Added bag CR003_B+_WB for Chợ Rẫy';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'CR004_AB+_PLT')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'CR004_AB+_PLT',
        @hospital_id = @hospital_choray_id,
        @record_id = NULL,
        @blood_group = N'AB+',
        @component = N'PLT',
        @volume_ml = 50,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -1, GETDATE()));
    PRINT 'Added bag CR004_AB+_PLT for Chợ Rẫy';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'CR005_O-_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'CR005_O-_WB',
        @hospital_id = @hospital_choray_id,
        @record_id = NULL,
        @blood_group = N'O-',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -7, GETDATE()));
    PRINT 'Added bag CR005_O-_WB for Chợ Rẫy';
END

-- Blood bags cho Hội An
IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HA001_O+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HA001_O+_WB',
        @hospital_id = @hospital_hoian_id,
        @record_id = NULL,
        @blood_group = N'O+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -8, GETDATE()));
    PRINT 'Added bag HA001_O+_WB for Hội An';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HA002_A+_RBC')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HA002_A+_RBC',
        @hospital_id = @hospital_hoian_id,
        @record_id = NULL,
        @blood_group = N'A+',
        @component = N'RBC',
        @volume_ml = 300,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -12, GETDATE()));
    PRINT 'Added bag HA002_A+_RBC for Hội An';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HA003_B+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HA003_B+_WB',
        @hospital_id = @hospital_hoian_id,
        @record_id = NULL,
        @blood_group = N'B+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -4, GETDATE()));
    PRINT 'Added bag HA003_B+_WB for Hội An';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HA004_AB+_FFP')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HA004_AB+_FFP',
        @hospital_id = @hospital_hoian_id,
        @record_id = NULL,
        @blood_group = N'AB+',
        @component = N'FFP',
        @volume_ml = 200,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -15, GETDATE()));
    PRINT 'Added bag HA004_AB+_FFP for Hội An';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HA005_A-_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HA005_A-_WB',
        @hospital_id = @hospital_hoian_id,
        @record_id = NULL,
        @blood_group = N'A-',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -6, GETDATE()));
    PRINT 'Added bag HA005_A-_WB for Hội An';
END

-- ================================================================
-- 4. KIỂM TRA KẾT QUẢ
-- ================================================================

PRINT '';
PRINT '=== KẾT QUẢ INSERT ===';
PRINT '';

SELECT 
    h.hospital_id,
    h.[name] AS hospital_name,
    h.region,
    h.latitude,
    h.longitude,
    u.email,
    (SELECT COUNT(*) FROM dbo.blood_bag b WHERE b.hospital_id = h.hospital_id) AS total_bags,
    (SELECT COUNT(*) FROM dbo.blood_bag b WHERE b.hospital_id = h.hospital_id AND b.[status] = N'AVAILABLE') AS available_bags
FROM dbo.hospital h
INNER JOIN dbo.[users] u ON u.user_id = h.user_id
WHERE h.hospital_id IN (@hospital_choray_id, @hospital_hoian_id)
ORDER BY h.hospital_id;

PRINT '';
PRINT '=== CHI TIẾT BLOOD BAGS ===';
PRINT '';

SELECT 
    b.bag_code,
    h.[name] AS hospital_name,
    b.blood_group,
    b.component,
    b.volume_ml,
    b.[status],
    b.collection_date,
    b.expiry_date
FROM dbo.blood_bag b
INNER JOIN dbo.hospital h ON h.hospital_id = b.hospital_id
WHERE b.hospital_id IN (@hospital_choray_id, @hospital_hoian_id)
ORDER BY b.hospital_id, b.bag_code;

COMMIT TRAN;

PRINT '';
PRINT '=== HOÀN TẤT ===';
PRINT 'Đã insert thành công 2 bệnh viện: Chợ Rẫy và Hội An';
PRINT 'Với tọa độ và blood bags mẫu';
GO

