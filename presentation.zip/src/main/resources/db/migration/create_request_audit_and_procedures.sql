-- ============================================
-- Migration: Create request_audit table and stored procedures
-- ============================================

-- 1. Create request_audit table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[request_audit]') AND type in (N'U'))
BEGIN
    CREATE TABLE request_audit (
        audit_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        request_id INT NOT NULL,
        actor_user_id INT NULL,
        old_status NVARCHAR(50) NULL,
        new_status NVARCHAR(50) NOT NULL,
        note NVARCHAR(MAX) NULL,
        created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT FK_request_audit_request FOREIGN KEY (request_id) REFERENCES blood_request(request_id) ON DELETE CASCADE,
        CONSTRAINT FK_request_audit_user FOREIGN KEY (actor_user_id) REFERENCES [user](user_id) ON DELETE SET NULL
    );
    
    CREATE INDEX IX_request_audit_request_id ON request_audit(request_id);
    CREATE INDEX IX_request_audit_created_at ON request_audit(created_at);
END
GO

-- 2. Add CHECK constraint for from_hospital_id != to_hospital_id (if not exists)
IF NOT EXISTS (SELECT * FROM sys.check_constraints WHERE name = 'CK_blood_request_hospitals_different')
BEGIN
    ALTER TABLE blood_request
    ADD CONSTRAINT CK_blood_request_hospitals_different
    CHECK (to_hospital_id IS NULL OR from_hospital_id != to_hospital_id);
END
GO

-- 3. Stored Procedure: sp_update_request_status
-- Updates request status and logs audit trail
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_update_request_status]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_update_request_status];
GO

CREATE PROCEDURE [dbo].[sp_update_request_status]
    @request_id INT,
    @new_status NVARCHAR(50),
    @by_user_id INT = NULL,
    @note NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    
    BEGIN TRANSACTION;
    
    BEGIN TRY
        -- Lock the request row for update
        DECLARE @old_status NVARCHAR(50);
        DECLARE @current_status NVARCHAR(50);
        
        SELECT @old_status = status, @current_status = status
        FROM blood_request WITH (UPDLOCK, ROWLOCK)
        WHERE request_id = @request_id;
        
        IF @old_status IS NULL
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50001, 'Request not found', 1;
        END
        
        -- Validate status transition
        IF @current_status = 'COMPLETED' OR @current_status = 'CANCELLED'
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50002, 'Cannot update request that is already COMPLETED or CANCELLED', 1;
        END
        
        -- Validate specific transitions
        IF @new_status = 'ACCEPTED' AND @current_status != 'PENDING'
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50003, 'Can only ACCEPT requests with PENDING status', 1;
        END
        
        IF @new_status = 'REJECTED' AND @current_status != 'PENDING'
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50004, 'Can only REJECT requests with PENDING status', 1;
        END
        
        IF @new_status = 'COMPLETED' AND @current_status != 'ACCEPTED'
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50005, 'Can only COMPLETE requests with ACCEPTED status', 1;
        END
        
        -- Update request status
        UPDATE blood_request
        SET status = @new_status,
            updated_at = GETDATE()
        WHERE request_id = @request_id;
        
        -- Insert audit record
        INSERT INTO request_audit (request_id, actor_user_id, old_status, new_status, note, created_at)
        VALUES (@request_id, @by_user_id, @old_status, @new_status, @note, GETDATE());
        
        COMMIT TRANSACTION;
        
        SELECT @request_id AS request_id, @new_status AS status, @old_status AS old_status;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        THROW @ErrorSeverity, @ErrorMessage, @ErrorState;
    END CATCH
END
GO

-- 4. Stored Procedure: sp_allocate_transfer
-- Allocates bags for transfer using FIFO (expiry_date) with row-level locking
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_allocate_transfer]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_allocate_transfer];
GO

CREATE PROCEDURE [dbo].[sp_allocate_transfer]
    @transfer_id INT,
    @from_hospital_id INT,
    @blood_group NVARCHAR(10),
    @component NVARCHAR(10),
    @units INT
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    
    BEGIN TRANSACTION;
    
    BEGIN TRY
        -- Select and lock available bags using FIFO (expiry_date ASC)
        -- Use ROWLOCK, UPDLOCK to lock rows and skip locked rows if needed
        DECLARE @BagIds TABLE (bag_id INT);
        
        INSERT INTO @BagIds (bag_id)
        SELECT TOP (@units) bag_id
        FROM blood_bag WITH (ROWLOCK, UPDLOCK, READPAST)
        WHERE hospital_id = @from_hospital_id
          AND blood_group = @blood_group
          AND component = @component
          AND status = 'AVAILABLE'
          AND expiry_date >= CAST(GETDATE() AS DATE)
        ORDER BY expiry_date ASC, bag_id ASC;
        
        -- Check if we have enough bags
        DECLARE @bag_count INT;
        SELECT @bag_count = COUNT(*) FROM @BagIds;
        
        IF @bag_count < @units
        BEGIN
            ROLLBACK TRANSACTION;
            DECLARE @error_msg NVARCHAR(500) = FORMATMESSAGE('Insufficient bags. Required: %d, Available: %d', @units, @bag_count);
            THROW 50010, @error_msg, 1;
        END
        
        -- Insert into transfer_request_bags
        INSERT INTO transfer_request_bags (transfer_id, bag_id)
        SELECT @transfer_id, bag_id
        FROM @BagIds;
        
        -- Update bag status to RESERVED
        UPDATE blood_bag
        SET status = 'RESERVED',
            updated_at = GETDATE()
        WHERE bag_id IN (SELECT bag_id FROM @BagIds);
        
        -- Update transfer status to ACCEPTED
        UPDATE transfer_requests
        SET status = 'ACCEPTED',
            updated_at = GETDATE()
        WHERE transfer_id = @transfer_id;
        
        COMMIT TRANSACTION;
        
        -- Return allocated bag IDs
        SELECT bag_id FROM @BagIds ORDER BY bag_id;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        THROW @ErrorSeverity, @ErrorMessage, @ErrorState;
    END CATCH
END
GO

-- 5. Stored Procedure: sp_complete_transfer
-- Completes transfer: moves bags to to_hospital and sets status to AVAILABLE
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_complete_transfer]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_complete_transfer];
GO

CREATE PROCEDURE [dbo].[sp_complete_transfer]
    @transfer_id INT,
    @actor_user_id INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    
    BEGIN TRANSACTION;
    
    BEGIN TRY
        -- Get transfer details
        DECLARE @to_hospital_id INT;
        DECLARE @request_id INT;
        DECLARE @current_status NVARCHAR(50);
        
        SELECT @to_hospital_id = to_hospital_id,
               @request_id = request_id,
               @current_status = status
        FROM transfer_requests WITH (UPDLOCK, ROWLOCK)
        WHERE transfer_id = @transfer_id;
        
        IF @to_hospital_id IS NULL
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50020, 'Transfer not found', 1;
        END
        
        IF @current_status != 'IN_TRANSIT'
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50021, 'Can only complete transfers with IN_TRANSIT status', 1;
        END
        
        -- Get bag IDs from transfer_request_bags
        DECLARE @BagIds TABLE (bag_id INT);
        INSERT INTO @BagIds (bag_id)
        SELECT bag_id
        FROM transfer_request_bags
        WHERE transfer_id = @transfer_id;
        
        -- Update bags: change hospital_id and set status to AVAILABLE
        UPDATE blood_bag
        SET hospital_id = @to_hospital_id,
            status = 'AVAILABLE',
            updated_at = GETDATE()
        WHERE bag_id IN (SELECT bag_id FROM @BagIds);
        
        -- Update transfer status to COMPLETED
        UPDATE transfer_requests
        SET status = 'COMPLETED',
            updated_at = GETDATE()
        WHERE transfer_id = @transfer_id;
        
        -- If transfer has request_id, auto-complete the request
        IF @request_id IS NOT NULL
        BEGIN
            DECLARE @request_status NVARCHAR(50);
            SELECT @request_status = status
            FROM blood_request
            WHERE request_id = @request_id;
            
            -- Only complete if request is still ACCEPTED
            IF @request_status = 'ACCEPTED'
            BEGIN
                EXEC sp_update_request_status @request_id, 'COMPLETED', @actor_user_id, 
                    'Auto-completed when transfer delivered';
            END
        END
        
        COMMIT TRANSACTION;
        
        SELECT @transfer_id AS transfer_id, 'COMPLETED' AS status;
        
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        DECLARE @ErrorSeverity INT = ERROR_SEVERITY();
        DECLARE @ErrorState INT = ERROR_STATE();
        
        THROW @ErrorSeverity, @ErrorMessage, @ErrorState;
    END CATCH
END
GO

PRINT 'Migration completed: request_audit table and stored procedures created successfully';
GO

