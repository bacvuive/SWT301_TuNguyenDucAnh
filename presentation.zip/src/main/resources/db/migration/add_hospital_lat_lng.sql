-- Migration: Add latitude and longitude columns to hospital table
-- Run this script to add location support for hospitals

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'hospital') AND name = 'latitude')
BEGIN
    ALTER TABLE hospital ADD latitude DECIMAL(10, 8) NULL;
    PRINT 'Added latitude column to hospital table';
END
ELSE
BEGIN
    PRINT 'Column latitude already exists in hospital table';
END
GO

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'hospital') AND name = 'longitude')
BEGIN
    ALTER TABLE hospital ADD longitude DECIMAL(11, 8) NULL;
    PRINT 'Added longitude column to hospital table';
END
ELSE
BEGIN
    PRINT 'Column longitude already exists in hospital table';
END
GO

-- Optional: Update existing hospitals with coordinates (Vietnam major cities)
-- Uncomment and modify as needed

/*
UPDATE hospital SET latitude = 21.00072, longitude = 105.83952 WHERE region LIKE '%Hà Nội%' AND latitude IS NULL;
UPDATE hospital SET latitude = 10.78004, longitude = 106.69504 WHERE region LIKE '%TP.HCM%' OR region LIKE '%Hồ Chí Minh%' AND latitude IS NULL;
UPDATE hospital SET latitude = 16.047079, longitude = 108.206230 WHERE region LIKE '%Đà Nẵng%' AND latitude IS NULL;
UPDATE hospital SET latitude = 20.85606, longitude = 106.68212 WHERE region LIKE '%Hải Phòng%' AND latitude IS NULL;
*/

PRINT 'Migration completed successfully';
GO

