-- ================================================================
-- INSERT DATA CHO 2 BỆNH VIỆN: ĐÀ NẴNG VÀ HUẾ
-- ================================================================
USE bloodlink;
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRAN;

-- ================================================================
-- 1. TẠO USERS CHO 2 BỆNH VIỆN
-- ================================================================

DECLARE @user_danang_id INT;
DECLARE @user_hue_id INT;

-- User cho Bệnh viện Đà Nẵng
IF NOT EXISTS (SELECT 1 FROM dbo.[users] WHERE email = N'danang@bloodlink.vn')
BEGIN
    INSERT INTO dbo.[users](username, password_hash, email, role_code, [status])
    VALUES (
        N'danang',
        N'$2a$12$V.mBFpm7R5l.vbXdsraIFeUlYJt5xscnyC8MEzYesxFYJ1fc.D67S', -- password: password123
        N'danang@bloodlink.vn',
        N'hospital',
        N'active'
    );
    SET @user_danang_id = SCOPE_IDENTITY();
    PRINT 'Created user for Đà Nẵng: ' + CAST(@user_danang_id AS VARCHAR(10));
END
ELSE
BEGIN
    SELECT @user_danang_id = user_id FROM dbo.[users] WHERE email = N'danang@bloodlink.vn';
    PRINT 'User Đà Nẵng already exists: ' + CAST(@user_danang_id AS VARCHAR(10));
END

-- User cho Bệnh viện Huế
IF NOT EXISTS (SELECT 1 FROM dbo.[users] WHERE email = N'hue@bloodlink.vn')
BEGIN
    INSERT INTO dbo.[users](username, password_hash, email, role_code, [status])
    VALUES (
        N'hue',
        N'$2a$12$V.mBFpm7R5l.vbXdsraIFeUlYJt5xscnyC8MEzYesxFYJ1fc.D67S', -- password: password123
        N'hue@bloodlink.vn',
        N'hospital',
        N'active'
    );
    SET @user_hue_id = SCOPE_IDENTITY();
    PRINT 'Created user for Huế: ' + CAST(@user_hue_id AS VARCHAR(10));
END
ELSE
BEGIN
    SELECT @user_hue_id = user_id FROM dbo.[users] WHERE email = N'hue@bloodlink.vn';
    PRINT 'User Huế already exists: ' + CAST(@user_hue_id AS VARCHAR(10));
END

-- ================================================================
-- 2. TẠO HOSPITAL RECORDS VỚI TỌA ĐỘ
-- ================================================================

DECLARE @hospital_danang_id INT;
DECLARE @hospital_hue_id INT;

-- Bệnh viện Đà Nẵng
IF NOT EXISTS (SELECT 1 FROM dbo.hospital WHERE user_id = @user_danang_id)
BEGIN
    INSERT INTO dbo.hospital(user_id, [name], [address], contact, region, latitude, longitude, created_at)
    VALUES (
        @user_danang_id,
        N'Trung tâm Hiến máu Đà Nẵng',
        N'789 Trần Phú, Hải Châu, Đà Nẵng',
        N'0236 3654 987',
        N'Đà Nẵng',
        16.047079,  -- Latitude
        108.206230, -- Longitude
        SYSUTCDATETIME()
    );
    SET @hospital_danang_id = SCOPE_IDENTITY();
    PRINT 'Created hospital Đà Nẵng: ' + CAST(@hospital_danang_id AS VARCHAR(10));
END
ELSE
BEGIN
    -- Update tọa độ nếu chưa có
    UPDATE dbo.hospital
    SET latitude = 16.047079,
        longitude = 108.206230,
        [name] = N'Trung tâm Hiến máu Đà Nẵng',
        [address] = N'789 Trần Phú, Hải Châu, Đà Nẵng',
        contact = N'0236 3654 987',
        region = N'Đà Nẵng'
    WHERE user_id = @user_danang_id;
    
    SELECT @hospital_danang_id = hospital_id FROM dbo.hospital WHERE user_id = @user_danang_id;
    PRINT 'Updated hospital Đà Nẵng: ' + CAST(@hospital_danang_id AS VARCHAR(10));
END

-- Bệnh viện Huế
IF NOT EXISTS (SELECT 1 FROM dbo.hospital WHERE user_id = @user_hue_id)
BEGIN
    INSERT INTO dbo.hospital(user_id, [name], [address], contact, region, latitude, longitude, created_at)
    VALUES (
        @user_hue_id,
        N'Bệnh viện TW Huế - Trung tâm huyết học',
        N'3 Lê Lợi, Phú Hội, Thành phố Huế, Thừa Thiên Huế',
        N'0234 3822 325',
        N'Thừa Thiên Huế',
        16.46371,  -- Latitude
        107.59087, -- Longitude
        SYSUTCDATETIME()
    );
    SET @hospital_hue_id = SCOPE_IDENTITY();
    PRINT 'Created hospital Huế: ' + CAST(@hospital_hue_id AS VARCHAR(10));
END
ELSE
BEGIN
    -- Update tọa độ nếu chưa có
    UPDATE dbo.hospital
    SET latitude = 16.46371,
        longitude = 107.59087,
        [name] = N'Bệnh viện TW Huế - Trung tâm huyết học',
        [address] = N'3 Lê Lợi, Phú Hội, Thành phố Huế, Thừa Thiên Huế',
        contact = N'0234 3822 325',
        region = N'Thừa Thiên Huế'
    WHERE user_id = @user_hue_id;
    
    SELECT @hospital_hue_id = hospital_id FROM dbo.hospital WHERE user_id = @user_hue_id;
    PRINT 'Updated hospital Huế: ' + CAST(@hospital_hue_id AS VARCHAR(10));
END

-- ================================================================
-- 3. THÊM BLOOD BAGS MẪU CHO 2 BỆNH VIỆN
-- ================================================================

-- Blood bags cho Đà Nẵng
IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'DN001_O+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'DN001_O+_WB',
        @hospital_id = @hospital_danang_id,
        @record_id = NULL,
        @blood_group = N'O+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -6, GETDATE()));
    PRINT 'Added bag DN001_O+_WB for Đà Nẵng';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'DN002_A+_RBC')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'DN002_A+_RBC',
        @hospital_id = @hospital_danang_id,
        @record_id = NULL,
        @blood_group = N'A+',
        @component = N'RBC',
        @volume_ml = 300,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -11, GETDATE()));
    PRINT 'Added bag DN002_A+_RBC for Đà Nẵng';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'DN003_B+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'DN003_B+_WB',
        @hospital_id = @hospital_danang_id,
        @record_id = NULL,
        @blood_group = N'B+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -4, GETDATE()));
    PRINT 'Added bag DN003_B+_WB for Đà Nẵng';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'DN004_AB+_PLT')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'DN004_AB+_PLT',
        @hospital_id = @hospital_danang_id,
        @record_id = NULL,
        @blood_group = N'AB+',
        @component = N'PLT',
        @volume_ml = 50,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -2, GETDATE()));
    PRINT 'Added bag DN004_AB+_PLT for Đà Nẵng';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'DN005_O-_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'DN005_O-_WB',
        @hospital_id = @hospital_danang_id,
        @record_id = NULL,
        @blood_group = N'O-',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -8, GETDATE()));
    PRINT 'Added bag DN005_O-_WB for Đà Nẵng';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'DN006_A+_FFP')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'DN006_A+_FFP',
        @hospital_id = @hospital_danang_id,
        @record_id = NULL,
        @blood_group = N'A+',
        @component = N'FFP',
        @volume_ml = 200,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -13, GETDATE()));
    PRINT 'Added bag DN006_A+_FFP for Đà Nẵng';
END

-- Blood bags cho Huế
IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HUE001_O+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HUE001_O+_WB',
        @hospital_id = @hospital_hue_id,
        @record_id = NULL,
        @blood_group = N'O+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -7, GETDATE()));
    PRINT 'Added bag HUE001_O+_WB for Huế';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HUE002_A+_RBC')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HUE002_A+_RBC',
        @hospital_id = @hospital_hue_id,
        @record_id = NULL,
        @blood_group = N'A+',
        @component = N'RBC',
        @volume_ml = 300,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -9, GETDATE()));
    PRINT 'Added bag HUE002_A+_RBC for Huế';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HUE003_B+_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HUE003_B+_WB',
        @hospital_id = @hospital_hue_id,
        @record_id = NULL,
        @blood_group = N'B+',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -5, GETDATE()));
    PRINT 'Added bag HUE003_B+_WB for Huế';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HUE004_AB+_PLT')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HUE004_AB+_PLT',
        @hospital_id = @hospital_hue_id,
        @record_id = NULL,
        @blood_group = N'AB+',
        @component = N'PLT',
        @volume_ml = 50,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -1, GETDATE()));
    PRINT 'Added bag HUE004_AB+_PLT for Huế';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HUE005_A-_WB')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HUE005_A-_WB',
        @hospital_id = @hospital_hue_id,
        @record_id = NULL,
        @blood_group = N'A-',
        @component = N'WB',
        @volume_ml = 450,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -10, GETDATE()));
    PRINT 'Added bag HUE005_A-_WB for Huế';
END

IF NOT EXISTS (SELECT 1 FROM dbo.blood_bag WHERE bag_code = N'HUE006_B+_RBC')
BEGIN
    EXEC dbo.sp_add_blood_bag 
        @bag_code = N'HUE006_B+_RBC',
        @hospital_id = @hospital_hue_id,
        @record_id = NULL,
        @blood_group = N'B+',
        @component = N'RBC',
        @volume_ml = 300,
        @collection_date = CONVERT(DATE, DATEADD(DAY, -14, GETDATE()));
    PRINT 'Added bag HUE006_B+_RBC for Huế';
END

-- ================================================================
-- 4. KIỂM TRA KẾT QUẢ
-- ================================================================

PRINT '';
PRINT '=== KẾT QUẢ INSERT ===';
PRINT '';

SELECT 
    h.hospital_id,
    h.[name] AS hospital_name,
    h.region,
    h.latitude,
    h.longitude,
    u.email,
    (SELECT COUNT(*) FROM dbo.blood_bag b WHERE b.hospital_id = h.hospital_id) AS total_bags,
    (SELECT COUNT(*) FROM dbo.blood_bag b WHERE b.hospital_id = h.hospital_id AND b.[status] = N'AVAILABLE') AS available_bags
FROM dbo.hospital h
INNER JOIN dbo.[users] u ON u.user_id = h.user_id
WHERE h.hospital_id IN (@hospital_danang_id, @hospital_hue_id)
ORDER BY h.hospital_id;

PRINT '';
PRINT '=== CHI TIẾT BLOOD BAGS ===';
PRINT '';

SELECT 
    b.bag_code,
    h.[name] AS hospital_name,
    b.blood_group,
    b.component,
    b.volume_ml,
    b.[status],
    b.collection_date,
    b.expiry_date
FROM dbo.blood_bag b
INNER JOIN dbo.hospital h ON h.hospital_id = b.hospital_id
WHERE b.hospital_id IN (@hospital_danang_id, @hospital_hue_id)
ORDER BY b.hospital_id, b.bag_code;

COMMIT TRAN;

PRINT '';
PRINT '=== HOÀN TẤT ===';
PRINT 'Đã insert thành công 2 bệnh viện: Đà Nẵng và Huế';
PRINT 'Với tọa độ và blood bags mẫu';
GO

