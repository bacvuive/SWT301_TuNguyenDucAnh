-- Migration script: Thêm cột subject và link vào bảng notification
-- Chạy script này để mở rộng cấu trúc notification table

USE bloodlink;
GO

-- Kiểm tra và thêm cột subject nếu chưa có
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'notification' AND COLUMN_NAME = 'subject'
)
BEGIN
    ALTER TABLE notification 
    ADD subject NVARCHAR(255) NULL;
    PRINT 'Added column: subject';
END
ELSE
BEGIN
    PRINT 'Column subject already exists';
END
GO

-- Kiểm tra và thêm cột link nếu chưa có
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_NAME = 'notification' AND COLUMN_NAME = 'link'
)
BEGIN
    ALTER TABLE notification 
    ADD [link] NVARCHAR(500) NULL;
    PRINT 'Added column: link';
END
ELSE
BEGIN
    PRINT 'Column link already exists';
END
GO

-- Cập nhật type để hỗ trợ các loại mới (nếu cần)
-- Type hiện tại: info, warning, success, error
-- Type mới: REQUEST_ACCEPTED, REQUEST_REJECTED, REQUEST_COMPLETED,
--           TRANSFER_CREATED, TRANSFER_PICKED_UP, TRANSFER_IN_TRANSIT,
--           TRANSFER_DELIVERED, TRANSFER_CANCELLED, BAG_EXPIRED
-- Note: Nếu có CHECK constraint, cần DROP và tạo lại
GO

PRINT 'Migration completed successfully!';
GO

