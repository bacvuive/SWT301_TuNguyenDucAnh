<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Đăng ký nhận tin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="header.jsp" %>

<style>
  .section{padding:72px 0}
  .section-title{font-weight:800;margin-bottom:12px}
  .muted{color:#64748b}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
  .bg-blush{background:#fff5f6}
</style>

<!-- =================== HERO =================== -->
<section class="bg-blush">
  <div class="container py-5">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold mb-3">
          Đăng ký <span class="text-danger">Nhận tin</span>
        </h1>
        <p class="lead text-muted mb-4">
          Nhận thông tin mới nhất về hoạt động hiến máu, sự kiện và kiến thức sức khỏe 
          qua email. Hoàn toàn miễn phí và có thể hủy đăng ký bất cứ lúc nào.
        </p>
      </div>
      <div class="col-lg-6 text-center">
        <div class="card card-soft p-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-danger">100%</div>
                <div class="small text-muted">Miễn phí</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-success">2-3</div>
                <div class="small text-muted">Tin/tuần</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-primary">10K+</div>
                <div class="small text-muted">Người đăng ký</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-warning">95%</div>
                <div class="small text-muted">Hài lòng</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== FORM ĐĂNG KÝ =================== -->
<section class="section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card card-soft">
          <div class="card-body p-4 p-md-5">
            <h3 class="fw-bold mb-2 text-center">Đăng ký nhận tin</h3>
            <p class="text-muted mb-4 text-center">Điền thông tin bên dưới để nhận tin tức mới nhất</p>
            
            <c:if test="${not empty error}">
              <div class="alert alert-danger" role="alert">${error}</div>
            </c:if>
            <c:if test="${not empty success}">
              <div class="alert alert-success" role="alert">${success}</div>
            </c:if>
            
            <form method="post" action="${pageContext.request.contextPath}/newsletter" class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Họ và tên</label>
                <input name="fullName" class="form-control" placeholder="Nhập họ và tên">
              </div>
              <div class="col-md-6">
                <label class="form-label">Email *</label>
                <input type="email" name="email" class="form-control" placeholder="Nhập email của bạn" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Số điện thoại</label>
                <input name="phone" class="form-control" placeholder="Nhập số điện thoại">
              </div>
              <div class="col-md-6">
                <label class="form-label">Nhóm máu</label>
                <select name="bloodType" class="form-select">
                  <option value="">Chọn nhóm máu</option>
                  <option>O-</option><option>O+</option>
                  <option>A-</option><option>A+</option>
                  <option>B-</option><option>B+</option>
                  <option>AB-</option><option>AB+</option>
                </select>
              </div>
              <div class="col-12">
                <label class="form-label">Loại tin bạn quan tâm</label>
                <div class="row g-2">
                  <div class="col-md-4">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="interests" value="events" id="events">
                      <label class="form-check-label" for="events">Sự kiện hiến máu</label>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="interests" value="health" id="health">
                      <label class="form-check-label" for="health">Kiến thức sức khỏe</label>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="interests" value="news" id="news">
                      <label class="form-check-label" for="news">Tin tức</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-12">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="agree" value="1" required>
                  <label class="form-check-label">
                    Tôi đồng ý nhận email từ BloodLink và có thể hủy đăng ký bất cứ lúc nào
                  </label>
                </div>
              </div>
              <div class="col-12 pt-2">
                <button class="btn btn-danger pill w-100 py-2" type="submit">
                  <i class="bi bi-envelope me-2"></i>Đăng ký nhận tin
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== LỢI ÍCH =================== -->
<section class="section bg-blush">
  <div class="container">
    <h2 class="text-center section-title">Lợi ích khi đăng ký nhận tin</h2>
    <p class="text-center muted mb-4">Những gì bạn sẽ nhận được khi đăng ký</p>
    
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-danger mb-3"><i class="bi bi-calendar-event"></i></div>
            <h6 class="fw-bold mb-2">Sự kiện hiến máu</h6>
            <p class="text-muted small">Thông báo về các sự kiện hiến máu gần bạn</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-primary mb-3"><i class="bi bi-heart-pulse"></i></div>
            <h6 class="fw-bold mb-2">Kiến thức sức khỏe</h6>
            <p class="text-muted small">Mẹo chăm sóc sức khỏe và dinh dưỡng</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-success mb-3"><i class="bi bi-newspaper"></i></div>
            <h6 class="fw-bold mb-2">Tin tức mới nhất</h6>
            <p class="text-muted small">Cập nhật về hoạt động của BloodLink</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== CTA =================== -->
<section class="section">
  <div class="container text-center">
    <h2 class="section-title">Sẵn sàng tham gia?</h2>
    <p class="muted mb-4">Đăng ký ngay để không bỏ lỡ thông tin quan trọng</p>
    <div class="d-flex gap-3 justify-content-center">
      <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
        <i class="bi bi-heart-fill me-2"></i>Đăng ký hiến máu
      </a>
      <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger pill px-4">
        <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
      </a>
    </div>
  </div>
</section>

<%@ include file="footer.jsp" %>
</body>
</html>
