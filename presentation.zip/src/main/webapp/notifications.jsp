<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Thông báo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .notifications-section{padding:40px 0}
  .page-container{max-width:900px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .page-header h1{font-weight:800;margin-bottom:8px}
  .page-header p{opacity:.9;margin-bottom:0}
  
  .notif-card{background:#fff;border-radius:16px;padding:20px;border:1px solid var(--bl-border);margin-bottom:16px;transition:all .2s ease}
  .notif-card:hover{box-shadow:0 8px 20px rgba(2,8,23,.08);transform:translateY(-2px)}
  .notif-card.unread{background:#fef3c7;border-left:4px solid #f59e0b}
  .notif-card.read{opacity:.8}
  
  .notif-header{display:flex;align-items:start;gap:16px;margin-bottom:12px}
  .notif-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
  .notif-icon.success{background:#dcfce7;color:#16a34a}
  .notif-icon.warning{background:#fef3c7;color:#d97706}
  .notif-icon.info{background:#dbeafe;color:#2563eb}
  .notif-icon.danger{background:#fee2e2;color:#dc2626}
  
  .notif-content{flex:1}
  .notif-subject{font-weight:700;font-size:16px;margin-bottom:6px;color:var(--bl-dark)}
  .notif-subject a{color:inherit;text-decoration:none}
  .notif-subject a:hover{color:var(--bl-red)}
  .notif-message{color:var(--bl-muted);font-size:14px;line-height:1.6;margin-bottom:8px}
  .notif-time{color:var(--bl-muted);font-size:12px}
  .notif-badge{display:inline-block;background:#dc2626;color:#fff;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;margin-left:8px}
  
  .notif-actions{display:flex;gap:8px;align-items:center}
  .btn-mark-read{background:transparent;border:1px solid var(--bl-border);color:var(--bl-muted);padding:4px 12px;border-radius:8px;font-size:12px;cursor:pointer;transition:all .2s}
  .btn-mark-read:hover{background:var(--bl-border);color:var(--bl-dark)}
  
  .filter-tabs{display:flex;gap:12px;margin-bottom:24px}
  .filter-tab{background:#fff;border:1px solid var(--bl-border);padding:8px 20px;border-radius:10px;text-decoration:none;color:var(--bl-muted);font-weight:600;transition:all .2s}
  .filter-tab:hover{background:var(--bl-border);color:var(--bl-dark)}
  .filter-tab.active{background:var(--bl-red);color:#fff;border-color:var(--bl-red)}
  
  .empty-state{text-align:center;padding:60px 20px;color:var(--bl-muted)}
  .empty-state i{font-size:64px;margin-bottom:16px;opacity:.3}
  .empty-state h4{font-weight:600;margin-bottom:8px}
  .empty-state p{margin-bottom:0}
</style>

<div class="notifications-section">
  <div class="page-container">
    
    <!-- Page Header -->
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1><i class="bi bi-bell-fill me-2"></i>Thông báo</h1>
          <p>Quản lý và xem tất cả thông báo của bạn</p>
        </div>
        <c:if test="${unreadCount > 0}">
          <div class="text-end">
            <button class="btn btn-light btn-sm" id="markAllReadBtn">
              <i class="bi bi-check-all me-1"></i>Đánh dấu tất cả đã đọc
            </button>
          </div>
        </c:if>
      </div>
    </div>

    <!-- Filter Tabs -->
    <div class="filter-tabs">
      <a href="${pageContext.request.contextPath}/notifications?filter=all" 
         class="filter-tab ${filter == 'all' ? 'active' : ''}">
        <i class="bi bi-list-ul me-1"></i>Tất cả
      </a>
      <a href="${pageContext.request.contextPath}/notifications?filter=unread" 
         class="filter-tab ${filter == 'unread' ? 'active' : ''}">
        <i class="bi bi-envelope me-1"></i>Chưa đọc
        <c:if test="${unreadCount > 0}">
          <span class="badge bg-danger ms-2">${unreadCount}</span>
        </c:if>
      </a>
    </div>

    <!-- Error Message -->
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>${fn:escapeXml(error)}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Notifications List -->
    <c:choose>
      <c:when test="${not empty notifications}">
        <div class="notifications-list">
          <c:forEach var="notif" items="${notifications}">
            <c:set var="isRead" value="${notif.isRead}" />
            <c:set var="notifType" value="${notif.type}" />
            <c:set var="notifLink" value="${notif.link}" />
            <c:set var="notifSubject" value="${notif.subject}" />
            <c:set var="notifMessage" value="${notif.message}" />
            <c:set var="notifCreatedAt" value="${notif.createdAt}" />
            <c:set var="notifId" value="${notif.notificationId}" />
            
            <div class="notif-card ${not isRead ? 'unread' : 'read'}" data-notif-id="${notifId}">
              <div class="notif-header">
                <div class="notif-icon ${notifType == 'APPOINTMENT_CONFIRMED' ? 'success' : (notifType == 'APPOINTMENT_CANCELLED' ? 'warning' : (notifType == 'DONATION_COMPLETED' ? 'success' : (notifType == 'REQUEST_ACCEPTED' ? 'success' : (notifType == 'REQUEST_REJECTED' ? 'danger' : 'info'))))}">
                  <c:choose>
                    <c:when test="${notifType == 'APPOINTMENT_CONFIRMED'}">
                      <i class="bi bi-check-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'APPOINTMENT_CANCELLED'}">
                      <i class="bi bi-x-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'REQUEST_ACCEPTED'}">
                      <i class="bi bi-check-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'REQUEST_REJECTED'}">
                      <i class="bi bi-x-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'TRANSFER_CREATED' || notifType == 'TRANSFER_DELIVERED'}">
                      <i class="bi bi-truck"></i>
                    </c:when>
                    <c:when test="${notifType == 'BAG_EXPIRED'}">
                      <i class="bi bi-exclamation-triangle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'DONATION_COMPLETED'}">
                      <i class="bi bi-heart-fill"></i>
                    </c:when>
                    <c:otherwise>
                      <i class="bi bi-info-circle-fill"></i>
                    </c:otherwise>
                  </c:choose>
                </div>
                <div class="notif-content">
                  <div class="notif-subject">
                    <c:choose>
                      <c:when test="${not empty notifLink}">
                        <a href="${pageContext.request.contextPath}${notifLink}">
                          ${fn:escapeXml(not empty notifSubject ? notifSubject : 'Thông báo')}
                        </a>
                      </c:when>
                      <c:otherwise>
                        ${fn:escapeXml(not empty notifSubject ? notifSubject : 'Thông báo')}
                      </c:otherwise>
                    </c:choose>
                    <c:if test="${not isRead}">
                      <span class="notif-badge">Mới</span>
                    </c:if>
                  </div>
                  <div class="notif-message">${fn:escapeXml(notifMessage)}</div>
                  <div class="notif-time">
                    <i class="bi bi-clock me-1"></i>
                    <c:if test="${notifCreatedAt != null}">
                      <fmt:formatDate value="${notifCreatedAt}" type="both" dateStyle="medium" timeStyle="short" />
                    </c:if>
                  </div>
                </div>
                <div class="notif-actions">
                  <c:if test="${not isRead}">
                    <button class="btn-mark-read" onclick="markAsRead(${notifId})">
                      <i class="bi bi-check me-1"></i>Đánh dấu đã đọc
                    </button>
                  </c:if>
                </div>
              </div>
            </div>
          </c:forEach>
        </div>
      </c:when>
      <c:otherwise>
        <div class="empty-state">
          <i class="bi bi-bell-slash"></i>
          <h4>Không có thông báo</h4>
          <p>
            <c:choose>
              <c:when test="${filter == 'unread'}">
                Bạn không có thông báo chưa đọc nào.
              </c:when>
              <c:otherwise>
                Bạn chưa có thông báo nào.
              </c:otherwise>
            </c:choose>
          </p>
        </div>
      </c:otherwise>
    </c:choose>

  </div>
</div>

<%@ include file="/footer.jsp" %>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  function markAsRead(notificationId) {
    fetch('${pageContext.request.contextPath}/notifications/' + notificationId + '/read', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Remove unread styling
        const card = document.querySelector(`[data-notif-id="${notificationId}"]`);
        if (card) {
          card.classList.remove('unread');
          card.classList.add('read');
          // Remove badge and button
          const badge = card.querySelector('.notif-badge');
          if (badge) badge.remove();
          const actions = card.querySelector('.notif-actions');
          if (actions) actions.remove();
        }
        // Reload page after short delay to update count
        setTimeout(() => {
          window.location.reload();
        }, 500);
      } else {
        alert('Lỗi: ' + (data.error || 'Không thể đánh dấu thông báo'));
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Lỗi khi đánh dấu thông báo');
    });
  }

  // Mark all as read
  document.getElementById('markAllReadBtn')?.addEventListener('click', function() {
    if (!confirm('Bạn có chắc chắn muốn đánh dấu tất cả thông báo là đã đọc?')) {
      return;
    }
    
    fetch('${pageContext.request.contextPath}/notifications/mark-all-read', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        window.location.reload();
      } else {
        alert('Lỗi: ' + (data.error || 'Không thể đánh dấu tất cả thông báo'));
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Lỗi khi đánh dấu tất cả thông báo');
    });
  });
</script>

</body>
</html>

