<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<style>
  .footer-bl{
    background:#0f172a; color:#94a3b8; padding:48px 0 24px;
  }
  .footer-bl h6{ color:#fff; font-weight:800; margin-bottom:16px }
  .footer-bl a{ color:#94a3b8; text-decoration:none; transition:color .15s ease }
  .footer-bl a:hover{ color:#fff }
  .footer-bl .social a{
    width:40px; height:40px; border-radius:50%; background:#1e293b;
    display:inline-flex; align-items:center; justify-content:center;
    margin-right:8px; transition:all .15s ease;
  }
  .footer-bl .social a:hover{ background:#e11d48; color:#fff }
  .footer-bl .newsletter{
    background:linear-gradient(135deg,#e11d48,#dc2626); color:#fff; padding:24px; border-radius:12px;
  }
  .footer-bl .newsletter input{
    background:rgba(255,255,255,.1); border:1px solid rgba(255,255,255,.2); color:#fff;
    border-radius:8px; padding:10px 12px;
  }
  .footer-bl .newsletter input::placeholder{ color:rgba(255,255,255,.7) }
  .footer-bl .newsletter button{
    background:#fff; color:#e11d48; border:0; border-radius:8px; padding:10px 16px; font-weight:700;
  }

  /* Chatbot Styles */
  .chatbot-container {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 9999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  }

  .chatbot-button {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e11d48 0%, #dc2626 100%);
    border: none;
    box-shadow: 0 4px 20px rgba(225, 29, 72, 0.4);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    color: #fff;
    font-size: 24px;
  }

  .chatbot-button:hover {
    transform: scale(1.1);
    box-shadow: 0 6px 25px rgba(225, 29, 72, 0.5);
  }

  .chatbot-button:active {
    transform: scale(0.95);
  }

  .chatbot-button .bi-heart-fill {
    animation: heartbeat 2s ease-in-out infinite;
  }

  @keyframes heartbeat {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
  }

  .chatbot-window {
    position: absolute;
    bottom: 80px;
    right: 0;
    width: 380px;
    height: 500px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
    display: none;
    flex-direction: column;
    overflow: hidden;
    animation: slideUp 0.3s ease-out;
  }

  @keyframes slideUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  .chatbot-window.active {
    display: flex;
  }

  .chatbot-header {
    background: linear-gradient(135deg, #e11d48 0%, #dc2626 100%);
    color: #fff;
    padding: 16px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .chatbot-header h6 {
    margin: 0;
    font-weight: 700;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .chatbot-header .status {
    width: 8px;
    height: 8px;
    background: #10b981;
    border-radius: 50%;
    animation: pulse 2s ease-in-out infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }

  .chatbot-close {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: #fff;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s;
  }

  .chatbot-close:hover {
    background: rgba(255, 255, 255, 0.3);
  }

  .chatbot-messages {
    flex: 1;
    overflow-y: auto;
    padding: 20px;
    background: #f8fafc;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .chatbot-messages::-webkit-scrollbar {
    width: 6px;
  }

  .chatbot-messages::-webkit-scrollbar-track {
    background: #f1f5f9;
  }

  .chatbot-messages::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 3px;
  }

  .message {
    max-width: 75%;
    padding: 12px 16px;
    border-radius: 12px;
    line-height: 1.5;
    word-wrap: break-word;
    animation: fadeIn 0.3s ease;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  .message.bot {
    background: #fff;
    border: 1px solid #e2e8f0;
    align-self: flex-start;
    border-bottom-left-radius: 4px;
  }

  .message.user {
    background: linear-gradient(135deg, #e11d48 0%, #dc2626 100%);
    color: #fff;
    align-self: flex-end;
    border-bottom-right-radius: 4px;
  }

  .chatbot-input-container {
    padding: 16px;
    background: #fff;
    border-top: 1px solid #e2e8f0;
    display: flex;
    gap: 8px;
  }

  .chatbot-input {
    flex: 1;
    border: 1px solid #e2e8f0;
    border-radius: 24px;
    padding: 10px 16px;
    font-size: 14px;
    outline: none;
    transition: border-color 0.2s;
  }

  .chatbot-input:focus {
    border-color: #e11d48;
  }

  .chatbot-send {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e11d48 0%, #dc2626 100%);
    border: none;
    color: #fff;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform 0.2s;
  }

  .chatbot-send:hover {
    transform: scale(1.1);
  }

  .chatbot-send:active {
    transform: scale(0.95);
  }

  @media (max-width: 576px) {
    .chatbot-window {
      width: calc(100vw - 40px);
      height: calc(100vh - 120px);
      bottom: 80px;
      right: 20px;
    }
  }
</style>

<footer class="footer-bl">
  <div class="container">
    <div class="row g-4">
      <!-- Brand -->
      <div class="col-lg-4">
        <div class="d-flex align-items-center gap-2 mb-3">
          <img src="${pageContext.request.contextPath}/assets/images/logo-bloodlink.png" alt="BloodLink" style="height:32px">
          <span style="font-weight:800; font-size:20px; color:#fff">BloodLink</span>
        </div>
        <p class="mb-3">Nền tảng kết nối người hiến máu và người cần máu khẩn cấp. Mỗi giọt máu đều có thể cứu sống một con người.</p>
        <div class="social">
          <a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
          <a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
          <a href="#" aria-label="YouTube"><i class="bi bi-youtube"></i></a>
          <a href="#" aria-label="Twitter"><i class="bi bi-twitter"></i></a>
        </div>
      </div>

      <!-- Quick Links -->
      <div class="col-lg-2 col-md-4">
        <h6>Liên kết nhanh</h6>
        <ul class="list-unstyled">
          <li class="mb-2"><a href="${pageContext.request.contextPath}/">Trang chủ</a></li>
          <li class="mb-2"><a href="${pageContext.request.contextPath}/requests">Yêu cầu máu</a></li>
          <li class="mb-2"><a href="${pageContext.request.contextPath}/donors">Đăng ký hiến máu</a></li>
          <li class="mb-2"><a href="${pageContext.request.contextPath}/centers">Bản đồ máu</a></li>
          <li class="mb-2"><a href="${pageContext.request.contextPath}/about">Về chúng tôi</a></li>
        </ul>
      </div>

      <!-- Support -->
      <div class="col-lg-2 col-md-4">
        <h6>Hỗ trợ</h6>
        <ul class="list-unstyled">
          <li class="mb-2"><a href="#">Điều kiện hiến máu</a></li>
          <li class="mb-2"><a href="#">Quy trình hiến máu</a></li>
          <li class="mb-2"><a href="#">Câu hỏi thường gặp</a></li>
          <li class="mb-2"><a href="#">Liên hệ</a></li>
          <li class="mb-2"><a href="#">Báo cáo sự cố</a></li>
        </ul>
      </div>

      <!-- Newsletter -->
      <div class="col-lg-4">
        <h6>Đăng ký nhận tin</h6>
        <div class="newsletter">
          <h6 class="mb-2">Nhận thông tin mới nhất</h6>
          <p class="mb-3 small">Đăng ký để nhận tin tức về hoạt động hiến máu và kiến thức sức khỏe</p>
          <form class="d-flex gap-2">
            <input type="email" placeholder="Nhập email của bạn" class="flex-fill">
            <button type="submit">Đăng ký</button>
          </form>
        </div>
      </div>
    </div>

    <hr style="border-color:#374151; margin:32px 0 24px">
    
    <div class="row align-items-center">
      <div class="col-md-6">
        <p class="mb-0 small">© <%= java.time.Year.now() %> BloodLink. Tất cả quyền được bảo lưu.</p>
      </div>
      <div class="col-md-6 text-md-end">
        <a href="#" class="small me-3">Điều khoản sử dụng</a>
        <a href="#" class="small me-3">Chính sách bảo mật</a>
        <a href="#" class="small">Chính sách cookie</a>
      </div>
    </div>
  </div>
</footer>

<!-- Chatbot Widget -->
<div class="chatbot-container">
  <!-- Chat Window -->
  <div class="chatbot-window" id="chatbotWindow">
    <div class="chatbot-header">
      <h6>
        <i class="bi bi-heart-fill"></i>
        BloodLink Chat
        <span class="status"></span>
      </h6>
      <button class="chatbot-close" id="chatbotClose" aria-label="Đóng chat">
        <i class="bi bi-x-lg"></i>
      </button>
    </div>
    <div class="chatbot-messages" id="chatbotMessages">
      <div class="message bot">
        <strong>Xin chào! 👋</strong><br>
        Tôi là chatbot hỗ trợ của BloodLink. Tôi có thể giúp bạn:
        <br>• Tìm hiểu về quy trình hiến máu
        <br>• Kiểm tra điều kiện hiến máu
        <br>• Tìm địa điểm hiến máu gần nhất
        <br>• Trả lời các câu hỏi thường gặp
        <br><br>
        Bạn cần hỗ trợ gì hôm nay?
      </div>
    </div>
    <div class="chatbot-input-container">
      <input type="text" class="chatbot-input" id="chatbotInput" 
             placeholder="Nhập câu hỏi của bạn..." 
             autocomplete="off">
      <button class="chatbot-send" id="chatbotSend" aria-label="Gửi tin nhắn">
        <i class="bi bi-send-fill"></i>
      </button>
    </div>
  </div>

  <!-- Chat Button -->
  <button class="chatbot-button" id="chatbotButton" aria-label="Mở chat">
    <i class="bi bi-heart-fill"></i>
  </button>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
(function() {
  const chatbotButton = document.getElementById('chatbotButton');
  const chatbotWindow = document.getElementById('chatbotWindow');
  const chatbotClose = document.getElementById('chatbotClose');
  const chatbotInput = document.getElementById('chatbotInput');
  const chatbotSend = document.getElementById('chatbotSend');
  const chatbotMessages = document.getElementById('chatbotMessages');

  // Toggle chat window
  function toggleChat() {
    chatbotWindow.classList.toggle('active');
    if (chatbotWindow.classList.contains('active')) {
      chatbotInput.focus();
    }
  }

  chatbotButton.addEventListener('click', toggleChat);
  chatbotClose.addEventListener('click', toggleChat);

  // Send message
  async function sendMessage() {
    const message = chatbotInput.value.trim();
    if (!message) return;

    // Add user message
    addMessage(message, 'user');
    chatbotInput.value = '';
    chatbotInput.disabled = true;
    chatbotSend.disabled = true;

    // Show typing indicator
    showTypingIndicator();

    try {
      // Call chatbot API
      const response = await fetch('${pageContext.request.contextPath}/api/chatbot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: message })
      });

      const data = await response.json();
      
      // Hide typing indicator
      hideTypingIndicator();
      
      // Add bot response
      if (data.message) {
        addMessage(data.message, 'bot');
        
        // If success action, show additional info
        if (data.type === 'success') {
          if (data.requestId) {
            setTimeout(() => {
              addMessage('Bạn có thể xem chi tiết yêu cầu trong phần "Quản lý yêu cầu máu".', 'bot');
            }, 1000);
          }
          if (data.appointmentId) {
            setTimeout(() => {
              addMessage('Bạn có thể xem chi tiết đăng ký trong phần "Lịch sử hiến máu".', 'bot');
            }, 1000);
          }
        }
      } else {
        addMessage('Xin lỗi, có lỗi xảy ra. Vui lòng thử lại sau.', 'bot');
      }
    } catch (error) {
      console.error('Chatbot error:', error);
      hideTypingIndicator();
      addMessage('Xin lỗi, không thể kết nối đến server. Vui lòng thử lại sau.', 'bot');
    } finally {
      chatbotInput.disabled = false;
      chatbotSend.disabled = false;
      chatbotInput.focus();
    }
  }

  function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.id = 'typingIndicator';
    typingDiv.className = 'message bot';
    typingDiv.innerHTML = '<em>Đang soạn tin nhắn...</em>';
    chatbotMessages.appendChild(typingDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
  }

  function hideTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
      typingIndicator.remove();
    }
  }

  chatbotSend.addEventListener('click', sendMessage);
  chatbotInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });

  function addMessage(text, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    
    if (type === 'bot') {
      // Bot messages can have HTML formatting (from API response)
      messageDiv.innerHTML = text.replace(/\n/g, '<br>');
    } else {
      // User messages: escape HTML for security
      const escapedText = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
      messageDiv.textContent = escapedText;
    }
    
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
  }

  // Close chat when clicking outside (optional)
  document.addEventListener('click', function(e) {
    if (chatbotWindow.classList.contains('active') && 
        !chatbotWindow.contains(e.target) && 
        !chatbotButton.contains(e.target)) {
      // Uncomment to enable click outside to close
      // toggleChat();
    }
  });
})();
</script>