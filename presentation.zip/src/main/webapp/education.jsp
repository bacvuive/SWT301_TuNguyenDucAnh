<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Giáo dục</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="header.jsp" %>

<style>
  .section{padding:72px 0}
  .section-title{font-weight:800;margin-bottom:12px}
  .muted{color:#64748b}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
  .bg-blush{background:#fff5f6}
  .bg-ice{background:linear-gradient(180deg,#f1f5ff 0%,#f8fbff 100%)}
</style>

<!-- =================== HERO =================== -->
<section class="bg-blush">
  <div class="container py-5">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold mb-3">
          Giáo dục <span class="text-danger">Hiến máu</span>
        </h1>
        <p class="lead text-muted mb-4">
          Tìm hiểu về hiến máu, các nhóm máu, quy trình và lợi ích. 
          Kiến thức là nền tảng để hiến máu an toàn và hiệu quả.
        </p>
        <div class="d-flex gap-3">
          <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
            <i class="bi bi-heart-fill me-2"></i>Đăng ký hiến máu
          </a>
          <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger pill px-4">
            <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
          </a>
        </div>
      </div>
      <div class="col-lg-6 text-center">
        <div class="card card-soft p-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-danger">50+</div>
                <div class="small text-muted">Bài viết</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-success">1000+</div>
                <div class="small text-muted">Lượt đọc</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-primary">24/7</div>
                <div class="small text-muted">Cập nhật</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-warning">100%</div>
                <div class="small text-muted">Miễn phí</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== DANH MỤC BÀI VIẾT =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Danh mục bài viết</h2>
    <p class="text-center muted mb-4">Chọn chủ đề bạn quan tâm để tìm hiểu thêm</p>
    
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-danger mb-3"><i class="bi bi-heart-pulse"></i></div>
            <h5 class="fw-bold mb-3">Kiến thức cơ bản</h5>
            <p class="text-muted mb-3">Tìm hiểu về máu, các nhóm máu và tầm quan trọng của việc hiến máu</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/basics" class="btn btn-outline-danger pill">Xem bài viết</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-primary mb-3"><i class="bi bi-clipboard2-pulse"></i></div>
            <h5 class="fw-bold mb-3">Điều kiện hiến máu</h5>
            <p class="text-muted mb-3">Kiểm tra xem bạn có đủ điều kiện để hiến máu không</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/eligibility" class="btn btn-outline-danger pill">Xem bài viết</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-success mb-3"><i class="bi bi-list-check"></i></div>
            <h5 class="fw-bold mb-3">Quy trình hiến máu</h5>
            <p class="text-muted mb-3">Hướng dẫn chi tiết từng bước trong quy trình hiến máu</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/process" class="btn btn-outline-danger pill">Xem bài viết</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-warning mb-3"><i class="bi bi-shield-check"></i></div>
            <h5 class="fw-bold mb-3">An toàn & Sức khỏe</h5>
            <p class="text-muted mb-3">Lợi ích sức khỏe và các biện pháp an toàn khi hiến máu</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/safety" class="btn btn-outline-danger pill">Xem bài viết</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-info mb-3"><i class="bi bi-question-circle"></i></div>
            <h5 class="fw-bold mb-3">Câu hỏi thường gặp</h5>
            <p class="text-muted mb-3">Giải đáp những thắc mắc phổ biến về hiến máu</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/faq" class="btn btn-outline-danger pill">Xem bài viết</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-purple mb-3"><i class="bi bi-book"></i></div>
            <h5 class="fw-bold mb-3">Tài liệu tham khảo</h5>
            <p class="text-muted mb-3">Các tài liệu khoa học và nghiên cứu về hiến máu</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/resources" class="btn btn-outline-danger pill">Xem bài viết</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== BÀI VIẾT NỔI BẬT =================== -->
<section class="section bg-ice">
  <div class="container">
    <h2 class="text-center section-title">Bài viết nổi bật</h2>
    <p class="text-center muted mb-4">Những bài viết được đọc nhiều nhất</p>
    
    <div class="row g-4">
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3">
              <div class="flex-shrink-0">
                <div class="bg-danger text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                  <i class="bi bi-heart-pulse"></i>
                </div>
              </div>
              <div class="flex-grow-1">
                <h6 class="fw-bold mb-2">Tại sao hiến máu lại quan trọng?</h6>
                <p class="text-muted small mb-2">Tìm hiểu về tầm quan trọng của việc hiến máu và tác động tích cực đến cộng đồng...</p>
                <div class="d-flex justify-content-between align-items-center">
                  <small class="text-muted">5 phút đọc</small>
                  <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/importance" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3">
              <div class="flex-shrink-0">
                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                  <i class="bi bi-clipboard2-pulse"></i>
                </div>
              </div>
              <div class="flex-grow-1">
                <h6 class="fw-bold mb-2">Kiểm tra điều kiện hiến máu</h6>
                <p class="text-muted small mb-2">Hướng dẫn chi tiết về các điều kiện cần thiết để có thể hiến máu an toàn...</p>
                <div class="d-flex justify-content-between align-items-center">
                  <small class="text-muted">3 phút đọc</small>
                  <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/check-eligibility" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3">
              <div class="flex-shrink-0">
                <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                  <i class="bi bi-list-check"></i>
                </div>
              </div>
              <div class="flex-grow-1">
                <h6 class="fw-bold mb-2">Quy trình hiến máu từ A-Z</h6>
                <p class="text-muted small mb-2">Từ đăng ký đến hoàn thành, tất cả các bước trong quy trình hiến máu...</p>
                <div class="d-flex justify-content-between align-items-center">
                  <small class="text-muted">7 phút đọc</small>
                  <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/complete-process" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3">
              <div class="flex-shrink-0">
                <div class="bg-warning text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                  <i class="bi bi-shield-check"></i>
                </div>
              </div>
              <div class="flex-grow-1">
                <h6 class="fw-bold mb-2">Lợi ích sức khỏe của hiến máu</h6>
                <p class="text-muted small mb-2">Khám phá những lợi ích tuyệt vời mà hiến máu mang lại cho sức khỏe...</p>
                <div class="d-flex justify-content-between align-items-center">
                  <small class="text-muted">4 phút đọc</small>
                  <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/health-benefits" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== VIDEO HƯỚNG DẪN =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Video hướng dẫn</h2>
    <p class="text-center muted mb-4">Xem video để hiểu rõ hơn về quy trình hiến máu</p>
    
    <div class="row g-4">
      <div class="col-md-6">
        <div class="card card-soft">
          <div class="card-body text-center">
            <div class="bg-danger text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 80px; height: 80px;">
              <i class="bi bi-play-fill fs-2"></i>
            </div>
            <h6 class="fw-bold mb-2">Quy trình hiến máu</h6>
            <p class="text-muted small mb-3">Video hướng dẫn chi tiết từng bước trong quy trình hiến máu</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/video-process" class="btn btn-danger pill">Xem video</a>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft">
          <div class="card-body text-center">
            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 80px; height: 80px;">
              <i class="bi bi-play-fill fs-2"></i>
            </div>
            <h6 class="fw-bold mb-2">Chuẩn bị trước khi hiến máu</h6>
            <p class="text-muted small mb-3">Những điều cần chuẩn bị để có một buổi hiến máu thành công</p>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/education/video-preparation" class="btn btn-danger pill">Xem video</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== CTA =================== -->
<section class="section bg-blush">
  <div class="container text-center">
    <h2 class="section-title">Sẵn sàng hiến máu?</h2>
    <p class="muted mb-4">Sau khi đã tìm hiểu về hiến máu, hãy đăng ký để trở thành người hiến máu</p>
    <div class="d-flex gap-3 justify-content-center">
      <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
        <i class="bi bi-heart-fill me-2"></i>Đăng ký hiến máu
      </a>
      <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger pill px-4">
        <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
      </a>
    </div>
  </div>
</section>

<%@ include file="footer.jsp" %>
</body>
</html>
