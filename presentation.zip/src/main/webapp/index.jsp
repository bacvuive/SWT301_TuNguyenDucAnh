<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Trang chủ</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
</head>
<body>
<%@ include file="header.jsp" %>
<link rel="preload" as="image" href="<c:url value='/assets/images/hero-hospital.jpg'/>">

<c:set var="dashboardUrl" value="${pageContext.request.contextPath}/" />
<c:choose>
  <c:when test="${sessionScope.role == 'DONOR'}">
    <c:set var="dashboardUrl" value="${pageContext.request.contextPath}/donor" />
  </c:when>
  <c:when test="${sessionScope.role == 'RECIPIENT'}">
    <c:set var="dashboardUrl" value="${pageContext.request.contextPath}/recipient" />
  </c:when>
  <c:when test="${sessionScope.role == 'HOSPITAL'}">
    <c:set var="dashboardUrl" value="${pageContext.request.contextPath}/hospital" />
  </c:when>
  <c:when test="${sessionScope.role == 'ADMIN'}">
    <c:set var="dashboardUrl" value="${pageContext.request.contextPath}/admin" />
  </c:when>
</c:choose>

<style>
  /* ============ TONE & SPACING ============ */
  :root{
    --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b;
  }
  .section{padding:72px 0}
  .section-title{font-weight:800;margin-bottom:12px}
  .muted{color:var(--bl-muted)}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
  .progress-slim{height:6px;border-radius:999px}
  .bg-blush{background:#fff5f6}
  .bg-ice{background:linear-gradient(180deg,#f1f5ff 0%,#f8fbff 100%)}
  #vnMap{width:100%;height:360px;border-radius:14px}

  /* ============ HERO ============ */
  .hero{
    position:relative;min-height:82vh;display:flex;align-items:center;
    color:var(--bl-dark);
    background:url('<c:url value="/assets/images/hero-hospital.jpg"/>') center/cover no-repeat;
    /* FIX: tăng độ nét cảm nhận */
    filter: contrast(1.05) saturate(1.05);
    image-rendering: -webkit-optimize-contrast;
  }
  /* phủ nhẹ để chữ nổi rõ nhưng vẫn thấy nền (giảm opacity + bỏ blur) */
  .hero::before{
    content:"";position:absolute;inset:0;
    /* FIX: giảm che phủ để ảnh nền rõ hơn */
    background:linear-gradient(90deg,rgba(255,255,255,.78) 0%,rgba(255,255,255,.66) 45%,rgba(255,255,255,.28) 70%,rgba(255,255,255,.18) 100%);
    /* backdrop-filter: blur(1.2px);  -- FIX: bỏ blur gây mờ ảnh nền */
  }
  .hero-inner{position:relative;z-index:2;width:100%}
  .hero h1{font-weight:800;line-height:1.06;margin-bottom:.5rem}
  .hero h1 .accent{color:var(--bl-red)}
  .hero .lead{color:#334155}

  /* khung ảnh bên phải (giữ chip & stamp, nhưng ẩn <img> bên trong để tránh ảnh lỗi) */
  .hero-figure{
    position:relative;border-radius:22px;overflow:hidden;background:#fff;
    box-shadow:0 18px 55px rgba(2,8,23,.18);border:1px solid rgba(2,8,23,.06);
  }
  .hero-figure img{display:none;} /* FIX: ẩn ảnh bị lỗi, giữ layout & badges */

  .hero-chip{
    position:absolute;left:12px;top:12px;
    background:#fff;border:1px solid #fee2e2;border-radius:14px;padding:8px 12px;display:flex;gap:8px;align-items:center;
    box-shadow:0 6px 18px rgba(2,8,23,.08)
  }
  .hero-chip .dot{width:26px;height:26px;border-radius:999px;background:#fee2e2;display:inline-flex;align-items:center;justify-content:center}
  .hero-chip i{color:#ef4444}
  .hero-stamp{
    position:absolute;right:12px;bottom:12px;
    background:#10b981;color:#fff;border-radius:14px;padding:8px 12px;display:flex;gap:8px;align-items:center;
    box-shadow:0 6px 18px rgba(2,8,23,.10)
  }
  .cta-card{border:0;border-radius:18px;padding:18px;display:flex;align-items:center;gap:10px;font-weight:700;color:#fff}
  .cta-1{background:#e11d48}.cta-2{background:#f97316}.cta-3{background:#3b82f6}
  .cta-card i{font-size:1.1rem}

  /* STAT CARDS */
  .stat-card{border:1px solid #eef2f7;border-radius:18px;padding:18px 22px;background:#fff}
  .stat-card h4{margin:0;font-weight:800}
  .stat-card small{color:var(--bl-muted)}

  /* GROUPS GRID hover */
  .group-blood .card{transition:transform .18s ease,box-shadow .18s ease}
  .group-blood .card:hover{transform:translateY(-6px);box-shadow:0 16px 40px rgba(2,8,23,.10)}

  /* TIMELINE */
  .timeline .dot{width:44px;height:44px;border-radius:999px;background:#ef4444;color:#fff;display:inline-flex;align-items:center;justify-content:center;font-weight:700}
  .timeline .bar{height:4px;background:#fee2e2;border-radius:999px;position:relative;margin:12px 0}
  .timeline .bar::after{content:"";position:absolute;left:0;top:0;height:100%;width:60%;background:#ef4444;border-radius:999px}

  /* RESPONSIVE */
  @media (max-width: 991.98px){
    .hero{min-height:auto;padding-top:28px;padding-bottom:28px}
    .hero-figure{margin-top:18px}
  }
</style>

<!-- =================== HERO =================== -->
<section class="hero">
  <div class="container hero-inner py-4">
    <div class="row align-items-center g-4">
      <!-- LEFT: Headline + CTA -->
      <div class="col-lg-6" data-aos="fade-up" data-aos-duration="700">
        <h1 class="display-5 mb-2">
          Kết nối <span class="accent">Hiến máu</span><br/>Cứu sống
        </h1>
        <p class="lead mb-4">
          Nền tảng kết nối nhanh giữa người cần máu khẩn cấp, người hiến máu tình nguyện và đội ngũ y tế.
          Mỗi giọt máu đều có thể cứu sống một con người.
        </p>

        <!-- CTA row -->
        <div class="row g-3">
          <div class="col-12 col-sm-6 col-md-4">
            <a href="${pageContext.request.contextPath}/register" class="text-decoration-none">
              <div class="cta-card cta-1 shadow-soft"><i class="bi bi-heart-fill"></i><span>Đăng ký hiến máu</span></div>
            </a>
          </div>
          <div class="col-12 col-sm-6 col-md-4">
            <c:url var="urgentUrl" value="${pageContext.request.contextPath}/login"><c:param name="next" value="${pageContext.request.contextPath}/recipient/requests/create"/></c:url>
            <a href="${urgentUrl}" class="text-decoration-none">
              <div class="cta-card cta-2 shadow-soft"><i class="bi bi-exclamation-triangle-fill"></i><span>Cần máu khẩn cấp</span></div>
            </a>
          </div>
          <div class="col-12 col-sm-6 col-md-4">
            <c:url var="hospitalUrl" value="${pageContext.request.contextPath}/login"><c:param name="next" value="${pageContext.request.contextPath}/hospital"/></c:url>
            <a href="${hospitalUrl}" class="text-decoration-none">
              <div class="cta-card cta-3 shadow-soft"><i class="bi bi-hospital-fill"></i><span>Bác sĩ/Bệnh viện</span></div>
            </a>
          </div>
        </div>

        <!-- Stats -->
        <div class="row g-3 mt-3">
          <div class="col-6 col-sm-3"><div class="stat-card text-center"><h4 class="counter" data-target="15247">0</h4><small>Người hiến máu</small></div></div>
          <div class="col-6 col-sm-3"><div class="stat-card text-center"><h4 class="counter" data-target="45891">0</h4><small>Đơn vị máu</small></div></div>
          <div class="col-6 col-sm-3"><div class="stat-card text-center"><h4 class="counter" data-target="137673">0</h4><small>Người được cứu</small></div></div>
          <div class="col-6 col-sm-3"><div class="stat-card text-center"><h4 class="counter" data-target="156">0</h4><small>Bệnh viện</small></div></div>
        </div>
      </div>

      <!-- RIGHT: Figure card + badges -->
      <div class="col-lg-6" data-aos="fade-left" data-aos-duration="700">
        <div class="hero-figure">
          <!-- badge trái trên -->
          <div class="hero-chip">
            <div class="dot"><i class="bi bi-heart-fill"></i></div>
            <div>
              <div class="fw-bold small">Kết nối nhanh</div>
              <div class="small text-muted">Trong 15 phút</div>
            </div>
          </div>

          <!-- FIX: Bỏ ảnh bên trong (nguyên nhân overlay lỗi) -->
          <!-- <img src="https://images.unsplash.com/photo-1631815588490-4b4a3fb9a2b7?q=80&w=1400&auto=format&fit=crop" alt="Medical team"/> -->

          <!-- badge phải dưới -->
          <div class="hero-stamp">
            <i class="bi bi-shield-check"></i><span class="small fw-bold">An toàn 100%</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== VỀ BLOODLINK =================== -->
<section class="section bg-light">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Về BloodLink</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">
      Chúng tôi là tổ chức phi lợi nhuận hàng đầu trong việc kết nối người hiến máu với những người cần giúp đỡ.
    </p>
    <div class="row g-4 justify-content-center">
      <div class="col-lg-5" data-aos="zoom-in">
        <img class="img-fluid rounded-4 shadow-soft"
             src="<c:url value='/assets/images/about-bloodlink.jpg'/>"
             onerror="this.src='https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=1200&auto=format&fit=crop';"
             alt="About BloodLink">
      </div>
      <div class="col-lg-5" data-aos="fade-left">
        <div class="d-flex gap-3 mb-3">
          <div class="text-danger fs-4"><i class="bi bi-shield-check"></i></div>
          <div><h6 class="mb-1">An toàn tuyệt đối</h6>
            <div class="muted">Quy trình kiểm soát nghiêm ngặt theo chuẩn y tế quốc tế; đội ngũ y tế trực ca 24/7.</div>
          </div>
        </div>
        <div class="d-flex gap-3 mb-3">
          <div class="text-primary fs-4"><i class="bi bi-people"></i></div>
          <div><h6 class="mb-1">Cộng đồng lớn mạnh</h6>
            <div class="muted">Hơn 50.000 người hiến máu tình nguyện trên cả nước, tạo thành mạng lưới phản ứng nhanh.</div>
          </div>
        </div>
        <div class="d-flex gap-3">
          <div class="text-warning fs-4"><i class="bi bi-headset"></i></div>
          <div><h6 class="mb-1">Phục vụ 24/7</h6>
            <div class="muted">Tổng đài cứu trợ, đối soát bệnh viện và logistics luôn sẵn sàng.</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== THÀNH TỰU + TIẾN ĐỘ =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Thành tựu của chúng tôi</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">Những con số ấn tượng thể hiện sự đóng góp tích cực</p>

    <div class="row g-3 mb-4" data-aos="fade-up" data-aos-delay="150">
      <div class="col-6 col-md-3"><div class="stat-card text-center"><h4 class="counter" data-target="15247">0</h4><small>Người hiến máu</small></div></div>
      <div class="col-6 col-md-3"><div class="stat-card text-center"><h4 class="counter" data-target="45891">0</h4><small>Đơn vị máu</small></div></div>
      <div class="col-6 col-md-3"><div class="stat-card text-center"><h4 class="counter" data-target="137673">0</h4><small>Người được cứu</small></div></div>
      <div class="col-6 col-md-3"><div class="stat-card text-center"><h4 class="counter" data-target="156">0</h4><small>Bệnh viện</small></div></div>
    </div>

    <div class="p-4 rounded-4 bg-blush shadow-soft" data-aos="fade-up" data-aos-delay="200">
      <h5 class="text-center fw-bold mb-1">Tiến độ hiến máu theo tháng</h5>
      <p class="text-center muted mb-4">Thống kê 6 tháng gần đây</p>
      <div class="row g-3">
        <%
          String[] months = {"T7","T8","T9","T10","T11","T12"};
          int[] values = {1245,1567,1432,1789,1654,1897};
          int[] pct = {70,85,75,95,88,98};
          for(int i=0;i<months.length;i++){
        %>
        <div class="col-6 col-md-2">
          <div class="card card-soft text-center">
            <div class="card-body">
              <div class="h5 mb-0"><%=values[i]%></div>
              <small class="muted d-block mb-2">người hiến</small>
              <div class="progress progress-slim mb-2">
                <div class="progress-bar bg-danger" role="progressbar" style="width:<%=pct[i]%>%"></div>
              </div>
              <small class="muted"><%=months[i]%></small>
            </div>
          </div>
        </div>
        <% } %>
      </div>
    </div>

    <div class="newsletter mt-4 p-4 text-center" data-aos="zoom-in">
      <div class="fw-bold fs-5 mb-2">Bạn có muốn trở thành một phần của những con số này?</div>
      <div class="text-white-50 mb-3">Mỗi lần hiến máu có thể cứu sống tới 3 người</div>
      <a href="${pageContext.request.contextPath}/register" class="btn btn-light pill px-4"><i class="bi bi-heart-fill me-2"></i>Tham gia ngay hôm nay</a>
    </div>
  </div>
</section>

<!-- =================== CÁC NHÓM MÁU =================== -->
<section class="section group-blood">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Các nhóm máu</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">Tìm hiểu nhóm máu và khả năng tương thích để giúp đỡ đúng người cần</p>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3" data-aos="fade-up" data-aos-delay="150">
      <%
        String[][] groups = {
          {"O-","Người hiến máu vạn năng","Rất cần thiết"},
          {"O+","Nhóm phổ biến nhất","Cần thiết"},
          {"A-","Nhóm hiếm","Rất cần thiết"},
          {"A+","Thường gặp","Cần thiết"},
          {"B-","Nhóm hiếm","Rất cần thiết"},
          {"B+","Thường gặp","Cần thiết"},
          {"AB-","Rất hiếm","Cực kỳ cần thiết"},
          {"AB+","Người nhận vạn năng","Cần thiết"}
        };
        String[] colors = {"danger","warning","danger","warning","danger","warning","danger","success"};
        for(int i=0;i<groups.length;i++){
      %>
      <div class="col">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 fw-bold text-<%=colors[i]%>"><%=groups[i][0]%></div>
            <div class="muted mb-2"><%=groups[i][1]%></div>
            <div class="small mb-3">Mức độ cần: <span class="text-<%=colors[i]%> fw-bold"><%=groups[i][2]%></span></div>
            <a href="${pageContext.request.contextPath}/register" class="btn btn-outline-secondary w-100 pill">Hiến nhóm máu này</a>
          </div>
        </div>
      </div>
      <% } %>
    </div>
  </div>
</section>

<!-- =================== LỢI ÍCH & ĐIỀU KIỆN =================== -->
<section class="section bg-ice">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Lợi ích của việc hiến máu</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">Hiến máu tốt cho cộng đồng và cả sức khỏe của bạn</p>

    <div class="row g-3 mb-4" data-aos="fade-up" data-aos-delay="150">
      <div class="col-sm-6 col-lg-4"><div class="card card-soft h-100"><div class="card-body"><div class="mb-2"><i class="bi bi-heart-pulse text-danger me-2"></i><strong>Cải thiện sức khỏe tim mạch</strong></div><div class="muted">Giảm sắt dư thừa, giảm nguy cơ bệnh tim mạch và đột quỵ.</div></div></div></div>
      <div class="col-sm-6 col-lg-4"><div class="card card-soft h-100"><div class="card-body"><div class="mb-2"><i class="bi bi-droplet text-primary me-2"></i><strong>Tái tạo tế bào máu mới</strong></div><div class="muted">Cơ thể tái tạo lượng máu tươi trong 24–72 giờ giúp khoẻ hơn.</div></div></div></div>
      <div class="col-sm-6 col-lg-4"><div class="card card-soft h-100"><div class="card-body"><div class="mb-2"><i class="bi bi-clipboard2-pulse text-success me-2"></i><strong>Kiểm tra sức khoẻ miễn phí</strong></div><div class="muted">Được kiểm tra các chỉ số cơ bản và xét nghiệm miễn phí.</div></div></div></div>
      <div class="col-sm-6 col-lg-4"><div class="card card-soft h-100"><div class="card-body"><div class="mb-2"><i class="bi bi-fire text-warning me-2"></i><strong>Hỗ trợ cân nặng</strong></div><div class="muted">Mỗi lần hiến có thể đốt ~650 calories.</div></div></div></div>
      <div class="col-sm-6 col-lg-4"><div class="card card-soft h-100"><div class="card-body"><div class="mb-2"><i class="bi bi-emoji-smile text-info me-2"></i><strong>Giảm stress</strong></div><div class="muted">Cảm giác tích cực khi giúp đỡ người khác.</div></div></div></div>
      <div class="col-sm-6 col-lg-4"><div class="card card-soft h-100"><div class="card-body"><div class="mb-2"><i class="bi bi-award text-purple me-2"></i><strong>Ưu tiên hỗ trợ</strong></div><div class="muted">Thẻ ưu tiên khi bạn hoặc người thân cần máu.</div></div></div></div>
    </div>

    <div class="row g-4 align-items-center">
      <div class="col-lg-6" data-aos="fade-right">
        <div class="card card-soft">
          <div class="card-body">
            <h5 class="fw-bold mb-3">Điều kiện hiến máu an toàn</h5>
            <ul class="list-unstyled m-0">
              <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Tuổi 18–60 (lần đầu), đến 65 (tái hiến)</li>
              <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Cân nặng ≥45kg (nữ), ≥50kg (nam)</li>
              <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Khoảng cách tối thiểu 12 tuần giữa 2 lần hiến</li>
              <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Không mắc bệnh truyền nhiễm qua đường máu</li>
              <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i>Sức khoẻ tốt, không dùng thuốc kháng sinh</li>
            </ul>
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/donor/eligibility" class="btn btn-outline-danger mt-3 pill"><i class="bi bi-list-check me-2"></i>Kiểm tra điều kiện</a>
          </div>
        </div>
      </div>
      <div class="col-lg-6" data-aos="zoom-in">
        <img class="img-fluid rounded-4 shadow-soft"
             src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=1200&auto=format&fit=crop" alt="">
      </div>
    </div>
  </div>
</section>

<!-- =================== QUY TRÌNH =================== -->
<section class="section bg-light">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Quy trình hiến máu</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">Đơn giản, an toàn, bởi đội ngũ y tế chuyên nghiệp</p>
    <div class="row row-cols-2 row-cols-md-4 g-4 timeline" data-aos="fade-up" data-aos-delay="150">
      <div class="col text-center"><div class="dot">01</div><div class="bar"></div><h6>Đăng ký</h6><div class="muted small">Điền thông tin & chọn lịch</div></div>
      <div class="col text-center"><div class="dot">02</div><div class="bar"></div><h6>Khám sàng lọc</h6><div class="muted small">Bác sĩ thăm khám</div></div>
      <div class="col text-center"><div class="dot">03</div><div class="bar"></div><h6>Hiến máu</h6><div class="muted small">8–10 phút, vô trùng</div></div>
      <div class="col text-center"><div class="dot">04</div><div class="bar"></div><h6>Nghỉ ngơi</h6><div class="muted small">Bồi dưỡng & chăm sóc</div></div>
    </div>
    <div class="text-center mt-4" data-aos="zoom-in"><a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/donor/schedule" class="btn btn-danger pill px-4"><i class="bi bi-calendar-check me-2"></i>Đặt lịch hiến máu</a></div>
  </div>
</section>

<!-- =================== CÂU CHUYỆN =================== -->
<section class="section bg-blush">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Câu chuyện từ những người hiến máu</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">Chia sẻ chân thực từ cộng đồng</p>
    <div class="row g-4" data-aos="fade-up" data-aos-delay="150">
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center p-3">
          <img class="rounded-circle mx-auto mb-2" style="width:56px;height:56px;object-fit:cover"
               src="<c:url value='/assets/images/story-nam.jpg'/>"
               onerror="this.src='https://randomuser.me/api/portraits/men/32.jpg'">
          <h6 class="mb-1">Nguyễn Văn Nam</h6><div class="muted small mb-2">28 tuổi · Hà Nội</div>
          <div class="muted">“Tôi đã hiến 15 lần trong 3 năm. Cảm giác được giúp đỡ người cần máu thật tuyệt vời.”</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center p-3">
          <img class="rounded-circle mx-auto mb-2" style="width:56px;height:56px;object-fit:cover"
               src="<c:url value='/assets/images/story-huong.jpg'/>"
               onerror="this.src='https://randomuser.me/api/portraits/women/65.jpg'">
          <h6 class="mb-1">Trần Thị Hương</h6><div class="muted small mb-2">35 tuổi · TP.HCM</div>
          <div class="muted">“Hiến máu giúp mình sống tích cực, lại được kiểm tra sức khoẻ định kỳ.”</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center p-3">
          <img class="rounded-circle mx-auto mb-2" style="width:56px;height:56px;object-fit:cover"
               src="<c:url value='/assets/images/story-tuan.jpg'/>"
               onerror="this.src='https://randomuser.me/api/portraits/men/83.jpg'">
          <h6 class="mb-1">Lê Minh Tuấn</h6><div class="muted small mb-2">24 tuổi · Đà Nẵng</div>
          <div class="muted">“Tôi bắt đầu từ năm nhất và duy trì đến nay. Việc nhỏ mà ý nghĩa lớn.”</div>
        </div>
      </div>
    </div>
    <div class="text-center mt-4" data-aos="zoom-in"><a href="${pageContext.request.contextPath}/community" class="btn btn-outline-danger pill">Tham gia cộng đồng hiến máu</a></div>
  </div>
</section>

<!-- =================== ĐỊA ĐIỂM + MAP (VN ONLY) =================== -->
<section class="section" id="dia-diem">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Địa điểm hiến máu</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">
      Tìm trung tâm gần nhất để tham gia hoạt động ý nghĩa
    </p>

    <!-- Bộ lọc -->
    <div class="card card-soft mb-3" data-aos="fade-up" data-aos-delay="120">
      <div class="card-body">
        <div class="row g-2 align-items-end">
          <div class="col-md-4">
            <label class="form-label mb-1">Tỉnh/Thành</label>
            <select id="provinceFilter" class="form-select">
              <option value="">Tất cả</option>
              <option>Hà Nội</option><option>Hải Phòng</option><option>Quảng Ninh</option>
              <option>Thừa Thiên Huế</option><option>Đà Nẵng</option><option>Quảng Nam</option>
              <option>Khánh Hòa</option><option>Bình Định</option><option>Gia Lai</option>
              <option>Đăk Lăk</option><option>Đồng Nai</option><option>Bình Dương</option>
              <option>TP.HCM</option><option>Cần Thơ</option><option>An Giang</option>
              <option>Kiên Giang</option><option>Nghệ An</option><option>Thanh Hóa</option>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label mb-1">Tìm kiếm (tên, địa chỉ, BV…)</label>
            <input id="keywordFilter" class="form-control" placeholder="Ví dụ: Chợ Rẫy, Nguyễn Thị Minh Khai, trung tâm hiến máu...">
          </div>
          <div class="col-md-2 d-grid d-md-block">
            <button id="btnClearFilter" class="btn btn-outline-secondary pill mt-3 mt-md-0 w-100">
              Xóa lọc
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-lg-6">
        <div id="centerList" class="row g-3"></div>
      </div>
      <div class="col-lg-6">
        <div id="vnMap" class="shadow-soft" aria-label="Bản đồ Việt Nam"></div>
        <div id="vnMapFallback" class="mt-2 d-none">
          <iframe
            src="https://www.openstreetmap.org/export/embed.html?bbox=102.14441%2C8.179066%2C109.46966%2C23.392694&layer=mapnik"
            style="border:0;width:100%;height:360px;border-radius:14px"></iframe>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== TIN TỨC & SỰ KIỆN =================== -->
<section class="section bg-light">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Tin tức & Sự kiện</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">Cập nhật hoạt động hiến máu & kiến thức sức khoẻ</p>

    <div class="row g-3" data-aos="fade-up" data-aos-delay="150">
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <img class="card-img-top" src="<c:url value='/assets/images/news-1.jpg'/>"
               onerror="this.src='https://images.unsplash.com/photo-1580281657527-47d4d1cfb3ae?q=80&w=1200&auto=format&fit=crop'">
          <div class="card-body"><span class="badge bg-danger-subtle text-danger pill">Sự kiện</span>
            <h6 class="mt-2">Chiến dịch hiến máu cứu người tại Bách Khoa</h6>
            <p class="muted small">Hơn 500 sinh viên tham gia trong tuần lễ nhân đạo.</p>
            <a href="${pageContext.request.contextPath}/education" class="small">Đọc thêm →</a></div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <img class="card-img-top" src="<c:url value='/assets/images/news-2.jpg'/>"
               onerror="this.src='https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=1200&auto=format&fit=crop'">
          <div class="card-body"><span class="badge bg-primary-subtle text-primary pill">Tin mới</span>
            <h6 class="mt-2">1.000 đơn vị máu thu thập tháng 12</h6>
            <p class="muted small">Nhờ mạng lưới tình nguyện viên khắp cả nước.</p>
            <a href="${pageContext.request.contextPath}/education" class="small">Đọc thêm →</a></div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <img class="card-img-top" src="<c:url value='/assets/images/news-3.jpg'/>"
               onerror="this.src='https://images.unsplash.com/photo-1581091014534-8988e0a6d45d?q=80&w=1200&auto=format&fit=crop'">
          <div class="card-body"><span class="badge bg-warning-subtle text-warning pill">Hướng dẫn</span>
            <h6 class="mt-2">Chăm sóc sau hiến máu đúng cách</h6>
            <p class="muted small">Mẹo dinh dưỡng & nghỉ ngơi để hồi phục nhanh.</p>
            <a href="${pageContext.request.contextPath}/education" class="small">Đọc thêm →</a></div>
        </div>
      </div>
    </div>

    <div class="newsletter mt-4 p-4" data-aos="zoom-in">
      <div class="row align-items-center g-2">
        <div class="col-lg-6">
          <div class="fw-bold fs-5">Đăng ký nhận thông tin mới nhất</div>
          <div class="text-white-50">Nhận tin tức, sự kiện hiến máu và kiến thức sức khoẻ qua email</div>
        </div>
        <div class="col-lg-6">
          <form method="post" action="${pageContext.request.contextPath}/newsletter" class="d-flex gap-2">
            <input type="email" class="form-control pill" placeholder="Nhập email của bạn">
            <button class="btn btn-light pill">Đăng ký</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== LIÊN HỆ =================== -->
<section class="section" id="lien-he">
  <div class="container">
    <h2 class="text-center section-title" data-aos="fade-up">Liên hệ với chúng tôi</h2>
    <p class="text-center muted mb-4" data-aos="fade-up" data-aos-delay="100">Có thắc mắc về hiến máu? Hãy để chúng tôi tư vấn miễn phí</p>
    <div class="row g-4">
      <div class="col-lg-5" data-aos="fade-right">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="mb-3"><i class="bi bi-telephone me-2"></i><strong>Hotline 24/7:</strong> 0917849617</div>
            <div class="mb-3"><i class="bi bi-envelope me-2"></i><strong>Email:</strong> bacmtp1104@gmail.com</div>
            <div class="mb-3"><i class="bi bi-geo-alt me-2"></i><strong>Trụ sở:</strong> Đại Học FPT, Ngũ Hành Sơn, Đà Nẵng</div>
            <div class="mb-3"><i class="bi bi-clock me-2"></i><strong>Giờ làm việc:</strong> T2–T7: 7:00–17:00</div>
            <div class="d-flex gap-2 fs-5">
              <a href="https://facebook.com/bloodlink" target="_blank" rel="noopener"><i class="bi bi-facebook"></i></a>
              <a href="https://instagram.com/bloodlink" target="_blank" rel="noopener"><i class="bi bi-instagram"></i></a>
              <a href="https://youtube.com/bloodlink" target="_blank" rel="noopener"><i class="bi bi-youtube"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-7" data-aos="fade-left">
        <div class="card card-soft">
          <div class="card-body">
            <form method="post" action="${pageContext.request.contextPath}/contact" class="row g-3">
              <div class="col-md-6"><label class="form-label">Họ và tên*</label><input class="form-control" required></div>
              <div class="col-md-6"><label class="form-label">Email*</label><input type="email" class="form-control" required></div>
              <div class="col-md-6"><label class="form-label">Số điện thoại*</label><input class="form-control" required></div>
              <div class="col-md-6"><label class="form-label">Nhóm máu</label>
                <select class="form-select"><option>Chọn nhóm máu</option><option>O</option><option>A</option><option>B</option><option>AB</option></select>
              </div>
              <div class="col-12"><label class="form-label">Tin nhắn</label><textarea class="form-control" rows="4"></textarea></div>
              <div class="col-12"><button class="btn btn-danger pill"><i class="bi bi-send me-2"></i>Gửi tin nhắn</button></div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- JS: Counter + Map -->
<script>
/* Counter animation */
(function(){
  var counters = document.querySelectorAll('.counter');
  if (!('IntersectionObserver' in window)) {
    counters.forEach(function(c){ c.textContent = Number(c.dataset.target).toLocaleString('vi-VN'); });
    return;
  }
  var obs = new IntersectionObserver(function(entries,observer){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        var el = entry.target, target = +el.dataset.target, dur = 1200, t0 = performance.now();
        (function tick(t){
          var p = Math.min((t - t0)/dur, 1);
          el.textContent = Math.floor(target * p).toLocaleString('vi-VN');
          if(p<1) requestAnimationFrame(tick);
        })(t0);
        observer.unobserve(el);
      }
    });
  }, {threshold: .6});
  counters.forEach(function(c){ obs.observe(c); });
})();

/* DỮ LIỆU & MAP */
var BLOOD_CENTERS = [
  {name:'Viện Huyết học – Truyền máu TW', addr:'78 Giải Phóng, Đống Đa', city:'Hà Nội', phone:'024 3868 9364', hours:'T2–CN: 7:30–17:00', lat:21.00072, lng:105.83952},
  {name:'Trung tâm Hiến máu Hà Nội', addr:'123 Đống Đa', city:'Hà Nội', phone:'024 3456 7890', hours:'T2–T7: 7:00–17:00; CN: 8:00–12:00', lat:21.0278, lng:105.8342},
  {name:'Bệnh viện Việt Tiệp – Ngân hàng máu', addr:'Hồng Bàng', city:'Hải Phòng', phone:'0225 3732 243', hours:'T2–T7: 7:00–16:30', lat:20.85606, lng:106.68212},
  {name:'BV Bãi Cháy – Đơn vị máu', addr:'Trần Hưng Đạo', city:'Quảng Ninh', phone:'0203 3846 119', hours:'T2–T7: 7:00–16:30', lat:20.95578, lng:107.04478},
  {name:'BV Đa khoa Thanh Hóa – Khoa huyết học', addr:'Quang Trung', city:'Thanh Hóa', phone:'0237 3852 205', hours:'T2–T7: 7:30–16:30', lat:19.80839, lng:105.77639},
  {name:'BV Hữu nghị ĐK Nghệ An – Ngân hàng máu', addr:'QL1A, Nghi Phú', city:'Nghệ An', phone:'0238 3859 979', hours:'T2–T7: 7:00–17:00', lat:18.69934, lng:105.68134},
  {name:'BV TW Huế – Trung tâm huyết học', addr:'3 Lê Lợi', city:'Thừa Thiên Huế', phone:'0234 3822 325', hours:'T2–T7: 7:30–16:30', lat:16.46371, lng:107.59087},
  {name:'Trung tâm Hiến máu Đà Nẵng', addr:'789 Trần Phú, Hải Châu', city:'Đà Nẵng', phone:'0236 3654 987', hours:'T2–T6: 7:00–16:30; T7: 7:00–12:00', lat:16.047079, lng:108.206230},
  {name:'BV ĐK Quảng Nam – Ngân hàng máu', addr:'Nguyễn Du, Tam Kỳ', city:'Quảng Nam', phone:'0235 3822 468', hours:'T2–T7: 7:00–16:30', lat:15.57364, lng:108.47403},
  {name:'Trung tâm Hiến máu Nha Trang', addr:'19 Yersin', city:'Khánh Hòa', phone:'0258 3825 765', hours:'T2–T7: 7:00–16:30', lat:12.23879, lng:109.19675},
  {name:'BV ĐK Bình Định – Khoa huyết học', addr:'Nguyễn Huệ, Quy Nhơn', city:'Bình Định', phone:'0256 3825 555', hours:'T2–T7: 7:00–16:30', lat:13.77366, lng:109.22309},
  {name:'BV ĐK Gia Lai – Đơn vị truyền máu', addr:'Anh Hùng Núp, Pleiku', city:'Gia Lai', phone:'0269 3822 245', hours:'T2–T7: 7:00–16:30', lat:13.98333, lng:108.00000},
  {name:'BV ĐK Đăk Lăk – Khoa huyết học', addr:'Khai Nguyên, Buôn Ma Thuột', city:'Đăk Lăk', phone:'0262 3869 999', hours:'T2–T7: 7:00–16:30', lat:12.66819, lng:108.03775},
  {name:'Trung tâm Hiến máu TP.HCM', addr:'456 Nguyễn Thị Minh Khai, Q1', city:'TP.HCM', phone:'028 3897 6543', hours:'T2–T7: 7:30–17:30; CN: 8:00–12:00', lat:10.78004, lng:106.69504},
  {name:'BV Chợ Rẫy – Ngân hàng máu', addr:'201B Nguyễn Chí Thanh, Q5', city:'TP.HCM', phone:'028 3855 4137', hours:'T2–CN: 7:00–20:00', lat:10.75994, lng:106.66186},
  {name:'BV Bệnh Nhiệt đới – Huyết học', addr:'764 Võ Văn Kiệt, Q5', city:'TP.HCM', phone:'028 3923 5804', hours:'T2–T7: 7:00–16:30', lat:10.75544, lng:106.66737},
  {name:'BV ĐK Bình Dương – Ngân hàng máu', addr:'Hiệp Thành, Thủ Dầu Một', city:'Bình Dương', phone:'0274 3822 555', hours:'T2–T7: 7:00–16:30', lat:10.98040, lng:106.65996},
  {name:'BV ĐK Đồng Nai – Khoa huyết học', addr:'Đồng Khởi, Biên Hòa', city:'Đồng Nai', phone:'0251 3821 115', hours:'T2–T7: 7:00–16:30', lat:10.95066, lng:106.82718},
  {name:'Trung tâm Hiến máu Cần Thơ', addr:'121 Nguyễn Văn Cừ, Ninh Kiều', city:'Cần Thơ', phone:'0292 3789 4560', hours:'T2–T6: 7:30–16:00; T7: 8:00–11:30', lat:10.045162, lng:105.746857},
  {name:'BV ĐK An Giang – Ngân hàng máu', addr:'Ung Văn Khiêm, Long Xuyên', city:'An Giang', phone:'0296 3841 234', hours:'T2–T7: 7:00–16:30', lat:10.38647, lng:105.43509},
  {name:'BV ĐK Kiên Giang – Khoa huyết học', addr:'Lạc Hồng, Rạch Giá', city:'Kiên Giang', phone:'0297 3862 222', hours:'T2–T7: 7:00–16:30', lat:10.01245, lng:105.08089}
];

(function(){
  var listEl = document.getElementById('centerList');
  var provinceEl = document.getElementById('provinceFilter');
  var keywordEl  = document.getElementById('keywordFilter');
  var clearBtn   = document.getElementById('btnClearFilter');

  var mapEl = document.getElementById('vnMap');
  var fbEl  = document.getElementById('vnMapFallback');
  var vnBounds = [[8.179066,102.14441],[23.392694,109.46966]];
  var map, markerLayer;

  function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,"\\'");}
  function gmapsLink(lat,lng){return 'https://www.google.com/maps/dir/?api=1&destination='+lat+','+lng+'&travelmode=driving&dir_action=navigate';}

  function ensureMap(){
    if (!window.L){ fbEl.classList.remove('d-none'); mapEl.classList.add('d-none'); return null; }
    if (!map){
      map = L.map('vnMap',{maxBounds:L.latLngBounds(vnBounds),maxBoundsViscosity:1.0,minZoom:5,maxZoom:18,zoomControl:true})
            .fitBounds(L.latLngBounds(vnBounds).pad(-0.25));
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap'}).addTo(map);
      markerLayer = L.layerGroup().addTo(map);
      setTimeout(function(){ map.invalidateSize(); }, 300);
      map.on('tileerror', function(){ mapEl.classList.add('d-none'); fbEl.classList.remove('d-none'); });
    }
    return map;
  }

  function renderList(items){
    var html = '';
    for (var i=0;i<items.length;i++){
      var c = items[i], badge = (i<3)?'danger':'secondary';
      html += ''
      + '<div class="col-12"><div class="card card-soft h-100"><div class="card-body">'
      +   '<div class="d-flex justify-content-between align-items-start">'
      +     '<div>'
      +       '<h6 class="mb-1">'+esc(c.name)+'</h6>'
      +       '<div class="small muted mb-1"><i class="bi bi-geo-alt me-1"></i>'+esc(c.addr)+', '+esc(c.city)+'</div>'
      +       '<div class="small muted mb-2"><i class="bi bi-telephone me-1"></i>'+(c.phone?esc(c.phone):'—')+' · <i class="bi bi-clock me-1"></i>'+(c.hours?esc(c.hours):'—')+'</div>'
      +     '</div>'
      +     '<span class="badge bg-'+badge+'-subtle text-'+badge+' pill">'+(i<3?'Cần gấp':'Hoạt động')+'</span>'
      +   '</div>'
      +   '<div class="d-flex gap-2 mt-2">'
      +     '<a href="'+gmapsLink(c.lat,c.lng)+'" target="_blank" rel="noopener" class="btn btn-outline-secondary pill"><i class="bi bi-geo me-1"></i>Chỉ đường</a>'
      +     '<button class="btn btn-danger pill" onclick="window.scrollTo({top:document.getElementById(\'vnMap\').offsetTop-120,behavior:\'smooth\'}); _focusMarker('+c.lat+','+c.lng+',\''+esc(c.name)+'\')"><i class="bi bi-pin-map me-1"></i>Hiển thị trên bản đồ</button>'
      +   '</div>'
      + '</div></div></div>';
    }
    listEl.innerHTML = html;
  }

  function renderMarkers(items){
    var m = ensureMap(); if(!m) return;
    markerLayer.clearLayers(); var bounds=[];
    for (var i=0;i<items.length;i++){
      var c=items[i];
      L.marker([c.lat,c.lng]).addTo(markerLayer)
        .bindPopup('<strong>'+esc(c.name)+'</strong><br>'+esc(c.addr)+', '+esc(c.city)+'<br>'+(c.hours?esc(c.hours):''));
      bounds.push([c.lat,c.lng]);
    }
    if (bounds.length){ m.fitBounds(bounds,{padding:[20,20]}); }
  }

  function filterData(){
    var kw = (keywordEl.value||'').toLowerCase().trim();
    var pv = (provinceEl.value||'').trim();
    var out = [];
    for (var i=0;i<BLOOD_CENTERS.length;i++){
      var c = BLOOD_CENTERS[i];
      var byPv = !pv || c.city === pv;
      var byKw = !kw || ((c.name+' '+c.addr+' '+c.city).toLowerCase().indexOf(kw)!==-1);
      if (byPv && byKw) out.push(c);
    }
    return out;
  }

  function update(){ var items = filterData(); renderList(items); renderMarkers(items); }

  window._focusMarker = function(lat,lng,name){
    var m = ensureMap(); if(!m) return;
    m.setView([lat,lng], 15, {animate:true});
    L.popup().setLatLng([lat,lng]).setContent('<strong>'+esc(name)+'</strong>').openOn(m);
  };

  ensureMap(); update();
  provinceEl.addEventListener('change', update);
  keywordEl.addEventListener('input', function(){ clearTimeout(keywordEl._t); keywordEl._t = setTimeout(update, 200); });
  clearBtn.addEventListener('click', function(){ provinceEl.value=''; keywordEl.value=''; update(); });
})();
</script>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<%@ include file="footer.jsp" %>
</body>
</html>
