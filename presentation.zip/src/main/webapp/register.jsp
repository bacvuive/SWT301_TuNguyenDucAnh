<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Đăng ký</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="header.jsp" %>

<style>
  .auth-section{padding:56px 0}
  .card-soft{border:1px solid #eef2f7;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .form-label{font-weight:600}
  .pill{border-radius:999px}
  
  /* Styling cho các trường donor và hospital */
  .donor-specific-fields, .hospital-specific-fields {
    transition: all 0.3s ease;
    border-top: 1px solid #eef2f7;
    padding-top: 1rem;
    margin-top: 1rem;
    display: none;
  }
  
  .donor-specific-fields.show, .hospital-specific-fields.show {
    display: block;
  }
  
  .medical-condition-fields {
    transition: all 0.3s ease;
    margin-top: 1rem;
  }
  
  /* Styling cho checkbox */
  .form-check-input:checked {
    background-color: #e11d48;
    border-color: #e11d48;
  }
  
  .form-check-input:focus {
    box-shadow: 0 0 0 0.25rem rgba(225, 29, 72, 0.25);
  }
  
  /* Styling cho alert cảnh báo */
  .alert-danger {
    border-left: 4px solid #e11d48;
    background-color: #fef2f2;
    border-color: #fecaca;
  }
</style>

<section class="auth-section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-8 col-lg-9">
        <div class="card card-soft">
          <div class="card-body p-4 p-md-5">

            <!-- Nút quay lại -->
            <div class="mb-3">
              <a href="${pageContext.request.contextPath}/" class="btn btn-outline-danger pill d-inline-flex align-items-center gap-2">
                <i class="bi bi-arrow-left"></i>
                Quay lại trang chủ
              </a>
            </div>

            <h3 class="fw-bold mb-2">Đăng ký tài khoản</h3>
            <p class="text-muted mb-4">Điền đầy đủ thông tin bên dưới để tham gia BloodLink.</p>

            <c:if test="${not empty error}">
              <div class="alert alert-danger" role="alert">${error}</div>
            </c:if>
            <c:if test="${not empty success}">
              <div class="alert alert-success" role="alert">${success}</div>
            </c:if>

            <form method="post" action="${pageContext.request.contextPath}/register" class="row g-3" autocomplete="on" id="registerForm">
              <div class="col-md-6">
                <label class="form-label" for="fullName">Họ và tên *</label>
                <input id="fullName" name="fullName" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="email">Email *</label>
                <input id="email" type="email" name="email" class="form-control" required>
              </div>

              <div class="col-md-6">
                <label class="form-label" for="password">Mật khẩu *</label>
                <input id="password" type="password" name="password" class="form-control" minlength="6" required>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="confirmPassword">Xác nhận mật khẩu *</label>
                <input id="confirmPassword" type="password" name="confirmPassword" class="form-control" minlength="6" required>
              </div>

              <div class="col-md-6">
                <label class="form-label" for="phone">Số điện thoại *</label>
                <input id="phone" name="phone" class="form-control" placeholder="VD: 0912345678" required>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="role">Vai trò *</label>
                <select id="role" name="role" class="form-select" required>
                  <option value="">Chọn vai trò</option>
                  <option value="donor">Người hiến máu</option>
                  <option value="hospital">Bệnh viện/Bác sĩ</option>
                </select>
              </div>

              <!-- Field nhóm máu - chỉ hiện khi chọn DONOR -->
              <div class="col-md-6 donor-specific-fields" id="bloodTypeField">
                <label class="form-label" for="bloodType">Nhóm máu *</label>
                <select id="bloodType" name="bloodType" class="form-select">
                  <option value="">Chọn nhóm máu</option>
                  <option>O-</option><option>O+</option>
                  <option>A-</option><option>A+</option>
                  <option>B-</option><option>B+</option>
                  <option>AB-</option><option>AB+</option>
                </select>
              </div>

              <!-- Hospital Fields - chỉ hiện khi chọn HOSPITAL -->
              <div class="col-md-6 hospital-specific-fields" id="hospitalField" style="display: none;">
                <label class="form-label" for="hospitalName">Tên bệnh viện *</label>
                <input id="hospitalName" name="hospitalName" class="form-control" 
                       placeholder="VD: Bệnh viện Đa khoa Đà Nẵng">
              </div>
              
              <div class="col-md-6 hospital-specific-fields" id="hospitalContactField" style="display: none;">
                <label class="form-label" for="hospitalContact">Số điện thoại</label>
                <input id="hospitalContact" name="hospitalContact" class="form-control" 
                       placeholder="VD: 0236-1234567">
              </div>
              
              <div class="col-md-6 hospital-specific-fields" id="hospitalRegionField" style="display: none;">
                <label class="form-label" for="hospitalRegion">Khu vực</label>
                <select id="hospitalRegion" name="hospitalRegion" class="form-select">
                  <option value="">Chọn khu vực</option>
                  <option value="Miền Bắc">Miền Bắc</option>
                  <option value="Miền Trung">Miền Trung</option>
                  <option value="Miền Nam">Miền Nam</option>
                </select>
              </div>

              <div class="col-md-6">
                <label class="form-label" for="address">Địa chỉ *</label>
                <input id="address" name="address" class="form-control" placeholder="VD: Đại học FPT, Đà Nẵng" required>
              </div>

              <!-- Các trường chỉ hiển thị cho DONOR -->
              <div id="donorFields" class="donor-specific-fields">
                <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="hasMedicalCondition" name="hasMedicalCondition" value="1">
                    <label class="form-check-label" for="hasMedicalCondition">
                      Bạn có bệnh nền? *
                    </label>
                  </div>
                </div>

                <div id="medicalConditionFields" class="medical-condition-fields" style="display: none;">
                  <div class="col-12">
                    <label class="form-label" for="medicalCondition">Chọn bệnh nền</label>
                    <select id="medicalCondition" name="medicalCondition" class="form-select">
                      <option value="">Chọn bệnh nền</option>
                      <option value="diabetes">Tiểu đường</option>
                      <option value="hypertension">Cao huyết áp</option>
                      <option value="heart_disease">Bệnh tim mạch</option>
                      <option value="liver_disease">Bệnh gan</option>
                      <option value="kidney_disease">Bệnh thận</option>
                      <option value="thyroid">Bệnh tuyến giáp</option>
                      <option value="asthma">Hen suyễn</option>
                      <option value="epilepsy">Động kinh</option>
                      <option value="cancer">Ung thư</option>
                      <option value="hiv">HIV/AIDS</option>
                      <option value="hepatitis">Viêm gan</option>
                      <option value="other">Khác</option>
                    </select>
                  </div>
                  
                  <div class="col-12">
                    <div class="alert alert-danger" role="alert">
                      <strong><i class="bi bi-exclamation-triangle-fill me-2"></i>Cảnh báo:</strong>
                      Nếu có bệnh nền, nên đến bệnh viện để kiểm tra trước khi hiến máu.
                    </div>
                  </div>
                </div>
              </div>

              <!-- Giữ tham số next nếu có -->
              <c:if test="${not empty param.next}">
                <input type="hidden" name="next" value="${fn:escapeXml(param.next)}">
              </c:if>

              <div class="col-12">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="agree" name="agree" value="1" required>
                  <label class="form-check-label" for="agree">
                    Tôi đồng ý với điều khoản sử dụng và chính sách bảo mật
                  </label>
                </div>
              </div>

              <div class="col-12 pt-2">
                <button class="btn btn-danger pill w-100 py-2" type="submit">
                  Đăng ký tài khoản
                </button>
              </div>

              <div class="col-12 text-center">
                <small class="text-muted">Đã có tài khoản?
                  <a href="${pageContext.request.contextPath}/login">Đăng nhập ngay</a>
                </small>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<%@ include file="footer.jsp" %>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const roleSelect = document.getElementById('role');
  const donorFields = document.getElementById('donorFields');
  const bloodTypeField = document.getElementById('bloodTypeField');
  const hospitalField = document.getElementById('hospitalField');
  const bloodTypeSelect = document.getElementById('bloodType');
  const hasMedicalConditionCheckbox = document.getElementById('hasMedicalCondition');
  const medicalConditionFields = document.getElementById('medicalConditionFields');
  const medicalConditionSelect = document.getElementById('medicalCondition');
  const registerForm = document.getElementById('registerForm');

  // Hiển thị/ẩn các trường theo role
  function toggleRoleFields() {
    const role = roleSelect.value;
    const hospitalNameField = document.getElementById('hospitalName');
    const hospitalContactField = document.getElementById('hospitalContactField');
    const hospitalRegionField = document.getElementById('hospitalRegionField');
    
    // Reset tất cả fields
    donorFields.classList.remove('show');
    bloodTypeField.classList.remove('show');
    hospitalField.classList.remove('show');
    if (hospitalContactField) hospitalContactField.style.display = 'none';
    if (hospitalRegionField) hospitalRegionField.style.display = 'none';
    
    // Bỏ required cho các fields này
    bloodTypeSelect.required = false;
    if (hospitalNameField) hospitalNameField.required = false;
    bloodTypeSelect.value = '';
    if (hospitalNameField) hospitalNameField.value = '';
    if (hospitalContactField) {
      const hospitalContact = document.getElementById('hospitalContact');
      if (hospitalContact) hospitalContact.value = '';
    }
    if (hospitalRegionField) {
      const hospitalRegion = document.getElementById('hospitalRegion');
      if (hospitalRegion) hospitalRegion.value = '';
    }
    
    // Reset các trường bệnh nền
    hasMedicalConditionCheckbox.checked = false;
    medicalConditionFields.style.display = 'none';
    medicalConditionSelect.required = false;
    medicalConditionSelect.value = '';
    
    if (role === 'donor') {
      // Hiển thị fields cho donor
      donorFields.classList.add('show');
      bloodTypeField.classList.add('show');
      bloodTypeSelect.required = true;
    } else if (role === 'hospital') {
      // Hiển thị fields nhập thông tin bệnh viện
      hospitalField.style.display = 'block';
      if (hospitalContactField) hospitalContactField.style.display = 'block';
      if (hospitalRegionField) hospitalRegionField.style.display = 'block';
      if (hospitalNameField) hospitalNameField.required = true;
    }
  }

  // Hiển thị/ẩn các trường bệnh nền khi tick checkbox
  function toggleMedicalConditionFields() {
    if (hasMedicalConditionCheckbox.checked) {
      medicalConditionFields.style.display = 'block';
      medicalConditionSelect.required = true;
    } else {
      medicalConditionFields.style.display = 'none';
      medicalConditionSelect.required = false;
      medicalConditionSelect.value = '';
    }
  }

  // Validate form trước khi submit
  registerForm.addEventListener('submit', function(e) {
    const role = roleSelect.value;
    const hospitalNameField = document.getElementById('hospitalName');
    const addressField = document.getElementById('address');
    
    // Đảm bảo role đã được chọn
    if (!role || role === '') {
      e.preventDefault();
      alert('Vui lòng chọn vai trò!');
      roleSelect.focus();
      return false;
    }
    
    if (role === 'donor') {
      if (!bloodTypeSelect.value) {
        e.preventDefault();
        alert('Vui lòng chọn nhóm máu!');
        bloodTypeSelect.focus();
        return false;
      }
    } else if (role === 'hospital') {
      if (!hospitalNameField || !hospitalNameField.value || !hospitalNameField.value.trim()) {
        e.preventDefault();
        alert('Vui lòng nhập tên bệnh viện!');
        if (hospitalNameField) hospitalNameField.focus();
        return false;
      }
      if (!addressField || !addressField.value || !addressField.value.trim()) {
        e.preventDefault();
        alert('Vui lòng nhập địa chỉ bệnh viện!');
        if (addressField) addressField.focus();
        return false;
      }
    }
    
    // Nếu không có lỗi, form sẽ được submit bình thường
    return true;
  });

  // Thêm event listeners
  roleSelect.addEventListener('change', toggleRoleFields);
  hasMedicalConditionCheckbox.addEventListener('change', toggleMedicalConditionFields);

  // Khởi tạo trạng thái ban đầu
  toggleRoleFields();
});
</script>

</body>
</html>
