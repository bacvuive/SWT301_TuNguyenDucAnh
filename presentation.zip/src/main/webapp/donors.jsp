<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Đăng ký hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="header.jsp" %>

<style>
  .section{padding:72px 0}
  .section-title{font-weight:800;margin-bottom:12px}
  .muted{color:#64748b}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
  .bg-blush{background:#fff5f6}
  .bg-ice{background:linear-gradient(180deg,#f1f5ff 0%,#f8fbff 100%)}
  .step-card{border-left:4px solid #e11d48;background:#fff5f6}
  .step-number{width:40px;height:40px;border-radius:50%;background:#e11d48;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800}
</style>

<!-- =================== HERO =================== -->
<section class="bg-blush">
  <div class="container py-5">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold mb-3">
          Đăng ký <span class="text-danger">Hiến máu</span>
        </h1>
        <p class="lead text-muted mb-4">
          Tham gia cộng đồng hiến máu để cứu sống những người cần máu khẩn cấp.
          Mỗi giọt máu của bạn đều có ý nghĩa.
        </p>
        <div class="d-flex gap-3">
          <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
            <i class="bi bi-heart-fill me-2"></i>Đăng ký ngay
          </a>
          <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger pill px-4">
            <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
          </a>
        </div>
      </div>
      <div class="col-lg-6 text-center">
        <div class="card card-soft p-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-danger">15,247</div>
                <div class="small text-muted">Người hiến máu</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-success">45,891</div>
                <div class="small text-muted">Đơn vị máu</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-primary">137,673</div>
                <div class="small text-muted">Người được cứu</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-warning">156</div>
                <div class="small text-muted">Bệnh viện</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== ĐIỀU KIỆN HIẾN MÁU =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Điều kiện hiến máu</h2>
    <p class="text-center muted mb-4">Kiểm tra xem bạn có đủ điều kiện để hiến máu không</p>

    <div class="row g-4">
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <h5 class="fw-bold mb-3 text-success">
              <i class="bi bi-check-circle-fill me-2"></i>Điều kiện cần có
            </h5>
            <ul class="list-unstyled">
              <li class="mb-2"><i class="bi bi-check text-success me-2"></i>Tuổi từ 18-60 (lần đầu), đến 65 (tái hiến)</li>
              <li class="mb-2"><i class="bi bi-check text-success me-2"></i>Cân nặng ≥45kg (nữ), ≥50kg (nam)</li>
              <li class="mb-2"><i class="bi bi-check text-success me-2"></i>Khoảng cách tối thiểu 12 tuần giữa 2 lần hiến</li>
              <li class="mb-2"><i class="bi bi-check text-success me-2"></i>Không mắc bệnh truyền nhiễm qua đường máu</li>
              <li class="mb-2"><i class="bi bi-check text-success me-2"></i>Sức khoẻ tốt, không dùng thuốc kháng sinh</li>
              <li class="mb-2"><i class="bi bi-check text-success me-2"></i>Không có tiền sử nghiện ma túy</li>
              <li class="mb-2"><i class="bi bi-check text-success me-2"></i>Không có quan hệ tình dục không an toàn</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <h5 class="fw-bold mb-3 text-danger">
              <i class="bi bi-x-circle-fill me-2"></i>Không được hiến máu nếu
            </h5>
            <ul class="list-unstyled">
              <li class="mb-2"><i class="bi bi-x text-danger me-2"></i>Đang mang thai hoặc cho con bú</li>
              <li class="mb-2"><i class="bi bi-x text-danger me-2"></i>Đang trong chu kỳ kinh nguyệt</li>
              <li class="mb-2"><i class="bi bi-x text-danger me-2"></i>Đang bị cảm cúm, sốt</li>
              <li class="mb-2"><i class="bi bi-x text-danger me-2"></i>Đã uống rượu bia trong 24h</li>
              <li class="mb-2"><i class="bi bi-x text-danger me-2"></i>Đã xăm mình trong 6 tháng</li>
              <li class="mb-2"><i class="bi bi-x text-danger me-2"></i>Đã phẫu thuật trong 6 tháng</li>
              <li class="mb-2"><i class="bi bi-x text-danger me-2"></i>Đang dùng thuốc điều trị</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== QUY TRÌNH HIẾN MÁU =================== -->
<section class="section bg-ice">
  <div class="container">
    <h2 class="text-center section-title">Quy trình hiến máu</h2>
    <p class="text-center muted mb-4">Đơn giản, an toàn, bởi đội ngũ y tế chuyên nghiệp</p>

    <div class="row g-4">
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="step-number mx-auto mb-3">01</div>
            <h6 class="fw-bold mb-2">Đăng ký</h6>
            <p class="small text-muted">Điền thông tin cá nhân và chọn lịch hiến máu phù hợp</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="step-number mx-auto mb-3">02</div>
            <h6 class="fw-bold mb-2">Khám sàng lọc</h6>
            <p class="small text-muted">Bác sĩ thăm khám và kiểm tra các chỉ số sức khỏe</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="step-number mx-auto mb-3">03</div>
            <h6 class="fw-bold mb-2">Hiến máu</h6>
            <p class="small text-muted">Quá trình hiến máu diễn ra trong 8-10 phút, hoàn toàn vô trùng</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="step-number mx-auto mb-3">04</div>
            <h6 class="fw-bold mb-2">Nghỉ ngơi</h6>
            <p class="small text-muted">Được bồi dưỡng và chăm sóc tại chỗ trong 15-20 phút</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== LỢI ÍCH HIẾN MÁU =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Lợi ích của việc hiến máu</h2>
    <p class="text-center muted mb-4">Hiến máu tốt cho cộng đồng và cả sức khỏe của bạn</p>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 text-danger mb-3"><i class="bi bi-heart-pulse"></i></div>
            <h6 class="fw-bold mb-2">Cải thiện sức khỏe tim mạch</h6>
            <p class="small text-muted">Giảm sắt dư thừa, giảm nguy cơ bệnh tim mạch và đột quỵ</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 text-primary mb-3"><i class="bi bi-droplet"></i></div>
            <h6 class="fw-bold mb-2">Tái tạo tế bào máu mới</h6>
            <p class="small text-muted">Cơ thể tái tạo lượng máu tươi trong 24-72 giờ giúp khỏe hơn</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 text-success mb-3"><i class="bi bi-clipboard2-pulse"></i></div>
            <h6 class="fw-bold mb-2">Kiểm tra sức khỏe miễn phí</h6>
            <p class="small text-muted">Được kiểm tra các chỉ số cơ bản và xét nghiệm miễn phí</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 text-warning mb-3"><i class="bi bi-fire"></i></div>
            <h6 class="fw-bold mb-2">Hỗ trợ cân nặng</h6>
            <p class="small text-muted">Mỗi lần hiến có thể đốt ~650 calories</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 text-info mb-3"><i class="bi bi-emoji-smile"></i></div>
            <h6 class="fw-bold mb-2">Giảm stress</h6>
            <p class="small text-muted">Cảm giác tích cực khi giúp đỡ người khác</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 text-purple mb-3"><i class="bi bi-award"></i></div>
            <h6 class="fw-bold mb-2">Ưu tiên hỗ trợ</h6>
            <p class="small text-muted">Thẻ ưu tiên khi bạn hoặc người thân cần máu</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== CÁC NHÓM MÁU =================== -->
<section class="section bg-blush">
  <div class="container">
    <h2 class="text-center section-title">Các nhóm máu</h2>
    <p class="text-center muted mb-4">Tìm hiểu nhóm máu và khả năng tương thích để giúp đỡ đúng người cần</p>

    <div class="row row-cols-2 row-cols-md-4 g-3">
      <%
        String[][] groups = {
          {"O-","Người hiến máu vạn năng","Rất cần thiết"},
          {"O+","Nhóm phổ biến nhất","Cần thiết"},
          {"A-","Nhóm hiếm","Rất cần thiết"},
          {"A+","Thường gặp","Cần thiết"},
          {"B-","Nhóm hiếm","Rất cần thiết"},
          {"B+","Thường gặp","Cần thiết"},
          {"AB-","Rất hiếm","Cực kỳ cần thiết"},
          {"AB+","Người nhận vạn năng","Cần thiết"}
        };
        String[] colors = {"danger","warning","danger","warning","danger","warning","danger","success"};
        for(int i=0;i<groups.length;i++){
      %>
      <div class="col">
        <div class="card card-soft h-100">
          <div class="card-body text-center">
            <div class="display-6 fw-bold text-<%=colors[i]%>"><%=groups[i][0]%></div>
            <div class="muted mb-2"><%=groups[i][1]%></div>
            <div class="small mb-3">Mức độ cần: <span class="text-<%=colors[i]%> fw-bold"><%=groups[i][2]%></span></div>
            <a href="${pageContext.request.contextPath}/register" class="btn btn-outline-secondary w-100 pill">Hiến nhóm máu này</a>
          </div>
        </div>
      </div>
      <% } %>
    </div>
  </div>
</section>

<!-- =================== CÂU CHUYỆN =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Câu chuyện từ những người hiến máu</h2>
    <p class="text-center muted mb-4">Chia sẻ chân thực từ cộng đồng</p>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center p-3">
          <img class="rounded-circle mx-auto mb-2" style="width:56px;height:56px;object-fit:cover"
               src="<c:url value='/assets/images/story-nam.jpg'/>"
               onerror="this.src='https://randomuser.me/api/portraits/men/32.jpg'">
          <h6 class="mb-1">Nguyễn Văn Nam</h6>
          <div class="muted small mb-2">28 tuổi · Hà Nội</div>
          <div class="muted">"Tôi đã hiến 15 lần trong 3 năm. Cảm giác được giúp đỡ người cần máu thật tuyệt vời."</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center p-3">
          <img class="rounded-circle mx-auto mb-2" style="width:56px;height:56px;object-fit:cover"
               src="<c:url value='/assets/images/story-huong.jpg'/>"
               onerror="this.src='https://randomuser.me/api/portraits/women/65.jpg'">
          <h6 class="mb-1">Trần Thị Hương</h6>
          <div class="muted small mb-2">35 tuổi · TP.HCM</div>
          <div class="muted">"Hiến máu giúp mình sống tích cực, lại được kiểm tra sức khoẻ định kỳ."</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center p-3">
          <img class="rounded-circle mx-auto mb-2" style="width:56px;height:56px;object-fit:cover"
               src="<c:url value='/assets/images/story-tuan.jpg'/>"
               onerror="this.src='https://randomuser.me/api/portraits/men/83.jpg'">
          <h6 class="mb-1">Lê Minh Tuấn</h6>
          <div class="muted small mb-2">24 tuổi · Đà Nẵng</div>
          <div class="muted">"Tôi bắt đầu từ năm nhất và duy trì đến nay. Việc nhỏ mà ý nghĩa lớn."</div>
        </div>
      </div>
    </div>

    <div class="text-center mt-4">
      <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
        <i class="bi bi-heart-fill me-2"></i>Tham gia cộng đồng hiến máu
      </a>
    </div>
  </div>
</section>

<!-- =================== CTA =================== -->
<section class="section bg-ice">
  <div class="container text-center">
    <h2 class="section-title">Sẵn sàng hiến máu?</h2>
    <p class="muted mb-4">Đăng ký ngay để trở thành một phần của cộng đồng hiến máu</p>
    <div class="d-flex gap-3 justify-content-center">
      <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
        <i class="bi bi-heart-fill me-2"></i>Đăng ký hiến máu
      </a>
      <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger pill px-4">
        <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
      </a>
    </div>
  </div>
</section>

<%@ include file="footer.jsp" %>
</body>
</html>
