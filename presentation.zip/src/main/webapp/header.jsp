<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c"  uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>

<!-- Bootstrap & Icons (chỉ cho header) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>
  :root{
    --bl-red:#e11d48; --bl-dark:#0f172a; --bl-text:#0b1220; --bl-border:#eef2f7; --bl-muted:#6b7280;
  }
  /* Chỉ style bên trong header */
  .navbar-bl{ --bs-navbar-padding-y:.6rem; background:#fff; border-bottom:1px solid var(--bl-border); transition:box-shadow .18s }
  .navbar-bl.stuck{ box-shadow:0 8px 24px rgba(2,8,23,.06) }
  .navbar-brand{ font-weight:900; letter-spacing:.2px; display:flex; align-items:center; gap:.55rem; color:var(--bl-dark); text-decoration:none }
  .navbar-brand .mark{ color:var(--bl-red); }
  .navbar-brand img{ height:30px; width:auto }
  .navbar-nav{ align-items:center; gap:.25rem }
  .navbar-nav .nav-link{ padding:.5rem .85rem; color:var(--bl-text); font-weight:600; border-radius:.55rem }
  .navbar-nav .nav-link:hover{ color:var(--bl-red); background:rgba(225,29,72,.06) }
  .navbar-nav .nav-link.active{ color:#fff; background:var(--bl-red) }

  /* Account chip */
  .avatar{
    width:32px;height:32px;border-radius:999px;display:inline-grid;place-items:center;
    background:#fee2e2; color:#dc2626;
  }
  .avatar.hospital{
    background:#dbeafe; color:#2563eb;
  }
  .avatar.admin{
    background:#f3e8ff; color:#9333ea;
  }
  .user-chip{ display:flex; align-items:center; gap:.5rem; }
  .user-meta{ line-height:1; }
  .user-meta .name{ font-weight:800; color:#b91c1c; }
  .user-meta .bt{ font-size:.8rem; color:var(--bl-muted); }

  /* User dropdown button */
  .user-dropdown-btn {
    background: #fff;
    border: 1px solid var(--bl-border);
    border-radius: 10px;
    padding: 0.5rem 0.75rem;
    transition: all 0.2s ease;
    cursor: pointer;
    position: relative;
    z-index: 1000;
  }
  .user-dropdown-btn:hover {
    background: #f8fafc;
    border-color: #e2e8f0;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  }
  .user-dropdown-btn:focus {
    box-shadow: 0 0 0 3px rgba(225,29,72,0.1);
  }
  .user-dropdown-btn[aria-expanded="true"] {
    background: #f8fafc;
    border-color: var(--bl-red);
  }

  /* Dropdown menu styling */
  .dropdown {
    position: relative;
    z-index: 1050;
  }
  .dropdown-menu {
    border: 1px solid var(--bl-border) !important;
    border-radius: 12px !important;
    padding: 0.5rem 0 !important;
    margin-top: 0.5rem !important;
    z-index: 1051 !important;
    box-shadow: 0 10px 40px rgba(0,0,0,0.15) !important;
    display: none;
  }
  .dropdown-menu.show {
    display: block !important;
  }
  .dropdown-item {
    padding: 0.65rem 1.25rem;
    transition: all 0.15s ease;
    display: flex;
    align-items: center;
  }
  .dropdown-item:hover {
    background: #f8fafc;
    color: var(--bl-red);
  }
  .dropdown-item i {
    width: 20px;
    text-align: center;
  }
  .dropdown-item.text-danger:hover {
    background: #fee2e2;
    color: #dc2626;
  }

  /* Bell badge */
  .btn-icon{ position:relative; border:1px solid #e5e7eb; background:#fff; }
  .btn-icon .badge-dot{
    position:absolute; top:-6px; right:-6px; min-width:18px; height:18px; border-radius:999px;
    background:#ef4444; color:#fff; font-size:.7rem; display:grid; place-items:center;
  }

  /* Notifications dropdown */
  .dropdown-menu-notif{ width:min(92vw, 360px); }
  .notif-item{ border-left:4px solid transparent; padding-top:.6rem; padding-bottom:.6rem; }
  .notif-item.unread{ background:#f8fafc; border-left-color:#ef4444; }
  .notif-icon{
    width:36px;height:36px;border-radius:10px;display:grid;place-items:center;
    background:#fee2e2; color:#ef4444;
  }
  .notif-time{ color:#64748b; font-size:.8rem; }
  .dropdown-menu .divider { margin:.25rem 0; }

  .btn-donate{ background:var(--bl-red); color:#fff; border:0; padding:.45rem .95rem; border-radius:999px; font-weight:800 }
  .btn-donate:hover{ color:#fff; opacity:.92 }
  
  /* Login button styling to match site design */
  .btn-outline-danger.pill{ 
    border-color:var(--bl-red); 
    color:var(--bl-red); 
    font-weight:600;
    transition:all .18s ease;
  }
  .btn-outline-danger.pill:hover{ 
    background:var(--bl-red); 
    color:#fff; 
    border-color:var(--bl-red);
    transform:translateY(-1px);
    box-shadow:0 4px 12px rgba(225,29,72,.25);
  }
  .navbar-toggler { border-color:#e5e7eb; }
  .navbar-toggler-icon{
    background-image:url("data:image/svg+xml,%3csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3e%3cpath stroke='rgba(15,23,42,.9)' stroke-width='2' stroke-linecap='round' d='M5 7h20M5 15h20M5 23h20'/%3e%3c/svg%3e");
  }
</style>

<c:set var="ctx" value="${pageContext.request.contextPath}" />
<c:set var="uri" value="${pageContext.request.requestURI}" />

<%-- Paths để highlight active --%>
<c:set var="homePath"    value="${ctx}/" />
<c:set var="reqPath"     value="${ctx}/requests" />
<c:set var="donorsPath"  value="${ctx}/donors" />
<c:set var="centersPath" value="${ctx}/centers" />
<c:set var="eduPath"     value="${ctx}/education" />
<c:set var="comPath"     value="${ctx}/community" />

<%-- Notifications (đã set bởi BaseHeaderDataFilter) --%>
<c:set var="headerNotifs" value="${requestScope.headerNotifications}" />
<c:set var="unreadCount"  value="${requestScope.unreadNotificationsCount}" />

<nav class="navbar navbar-expand-lg navbar-light navbar-bl sticky-top" role="navigation" aria-label="Main navigation">
  <div class="container">
    <a class="navbar-brand" href="${ctx}/" aria-label="BloodLink Home">
      <img src="${ctx}/assets/images/logo-bloodlink.png" alt="BloodLink">
      <span class="mark">BloodLink</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain"
            aria-controls="navMain" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div id="navMain" class="collapse navbar-collapse">
      <!-- LEFT -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link ${uri == homePath ? 'active' : ''}" href="${homePath}">Trang chủ</a></li>
        <c:choose>
          <c:when test="${empty sessionScope.authUser}">
            <!-- Guest: chuyển đến trang đăng ký/đăng nhập -->
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, reqPath) ? 'active' : ''}" href="${ctx}/login?next=${reqPath}">Yêu cầu máu</a></li>
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, donorsPath) ? 'active' : ''}" href="${ctx}/login?next=${donorsPath}">Tìm người hiến</a></li>
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, centersPath) ? 'active' : ''}" href="${ctx}/login?next=${centersPath}">Bản đồ máu</a></li>
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, eduPath) ? 'active' : ''}" href="${ctx}/login?next=${eduPath}">Giáo dục</a></li>
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, comPath) ? 'active' : ''}" href="${ctx}/login?next=${comPath}">Cộng đồng</a></li>
          </c:when>
          <c:otherwise>
            <!-- Đã đăng nhập: hiển thị theo role -->
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, reqPath) ? 'active' : ''}" href="${reqPath}">Yêu cầu máu</a></li>
            <!-- Ẩn "Tìm người hiến" cho role DONOR -->
            <c:if test="${sessionScope.role != 'DONOR'}">
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, donorsPath) ? 'active' : ''}" href="${donorsPath}">Tìm người hiến</a></li>
            </c:if>
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, centersPath) ? 'active' : ''}" href="${centersPath}">Bản đồ máu</a></li>
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, eduPath) ? 'active' : ''}" href="${eduPath}">Giáo dục</a></li>
            <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, comPath) ? 'active' : ''}" href="${comPath}">Cộng đồng</a></li>
          </c:otherwise>
        </c:choose>

        <!-- Quick links theo role -->
        <c:if test="${not empty sessionScope.role}">
          <c:choose>
            <c:when test="${sessionScope.role == 'DONOR'}">
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/donor/schedule')) ? 'active' : ''}" href="${ctx}/donor/schedule">Đặt lịch hiến</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/donor/eligibility')) ? 'active' : ''}" href="${ctx}/donor/eligibility">Kiểm tra điều kiện</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/donor/history')) ? 'active' : ''}" href="${ctx}/donor/history">Lịch sử hiến</a></li>
            </c:when>
            <c:when test="${sessionScope.role == 'RECIPIENT'}">
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/recipient/requests/create')) ? 'active' : ''}" href="${ctx}/recipient/requests/create">Tạo yêu cầu</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/recipient/requests')) ? 'active' : ''}" href="${ctx}/recipient/requests">Yêu cầu của tôi</a></li>
            </c:when>
            <c:when test="${sessionScope.role == 'HOSPITAL'}">
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/hospital/requests/create')) ? 'active' : ''}" href="${ctx}/hospital/requests/create">Tạo yêu cầu</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/hospital/requests')) ? 'active' : ''}" href="${ctx}/hospital/requests">Quản lý yêu cầu</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/hospital/donors')) ? 'active' : ''}" href="${ctx}/hospital/donors">Người hiến</a></li>
            </c:when>
            <c:when test="${sessionScope.role == 'ADMIN'}">
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/admin/users')) ? 'active' : ''}" href="${ctx}/admin/manage-user">Người dùng</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/admin/requests')) ? 'active' : ''}" href="${ctx}/admin/manage-request">Yêu cầu</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/admin/verification')) ? 'active' : ''}" href="${ctx}/admin/verification-requests">Xác minh BV</a></li>
              <li class="nav-item"><a class="nav-link ${fn:startsWith(uri, ctx.concat('/admin/settings')) ? 'active' : ''}" href="${ctx}/admin/settings">Cấu hình</a></li>
            </c:when>
          </c:choose>
        </c:if>
      </ul>

      <!-- RIGHT -->
      <div class="d-flex align-items-center gap-2">
        <!-- Khách -->
        <c:if test="${empty sessionScope.authUser}">
          <a class="btn btn-sm btn-outline-danger pill px-3" href="${ctx}/login">Đăng nhập</a>
          <a class="btn btn-sm btn-donate" href="${ctx}/register">Đăng ký</a>
        </c:if>

        <!-- Đã đăng nhập: chuông + tài khoản -->
        <c:if test="${not empty sessionScope.authUser}">
          <!-- Notifications -->
          <div class="dropdown me-1">
            <button class="btn btn-light btn-icon rounded-3" data-bs-toggle="dropdown" aria-expanded="false" id="notifBtn" aria-label="Thông báo">
              <i class="bi bi-bell"></i>
              <c:if test="${unreadCount gt 0}">
                <span class="badge-dot">${unreadCount}</span>
              </c:if>
            </button>
            <div class="dropdown-menu dropdown-menu-end dropdown-menu-notif p-0 shadow" aria-labelledby="notifBtn">
              <div class="p-3 pb-2 d-flex justify-content-between align-items-center">
                <strong>Thông báo</strong>
                <a href="${ctx}/notifications" class="small">Xem tất cả</a>
              </div>
              <div class="dropdown-divider"></div>

              <c:choose>
                <c:when test="${not empty headerNotifs}">
                  <c:forEach var="n" items="${headerNotifs}" varStatus="s" begin="0" end="4">
                    <a class="dropdown-item notif-item ${n.read ? '' : 'unread'}" href="${ctx}/notifications#${n.id}">
                      <div class="d-flex align-items-start gap-2">
                        <div class="notif-icon">
                          <c:choose>
                            <c:when test="${n.type == 'ALERT'}"><i class="bi bi-exclamation-triangle-fill"></i></c:when>
                            <c:when test="${n.type == 'REMINDER'}"><i class="bi bi-calendar2-week"></i></c:when>
                            <c:otherwise><i class="bi bi-trophy-fill"></i></c:otherwise>
                          </c:choose>
                        </div>
                        <div>
                          <div class="fw-semibold">${fn:escapeXml(n.title)}</div>
                          <div class="text-muted small">${fn:escapeXml(n.content)}</div>
                          <div class="notif-time">${n.relativeTime}</div>
                        </div>
                      </div>
                    </a>
                    <c:if test="${!s.last}">
                      <div class="dropdown-divider divider"></div>
                    </c:if>
                  </c:forEach>
                </c:when>
                <c:otherwise>
                  <div class="px-3 py-4 text-center text-muted small">Không có thông báo mới</div>
                </c:otherwise>
              </c:choose>

              <div class="dropdown-divider"></div>
              <div class="p-2 text-center">
                <button class="btn btn-sm btn-outline-secondary" id="markAllReadBtn">Đánh dấu đã đọc</button>
              </div>
            </div>
          </div>

          <!-- Account dropdown -->
          <c:set var="dashUrl" value="${ctx}/" />
          <c:if test="${sessionScope.role == 'DONOR'}"><c:set var="dashUrl" value="${ctx}/donor/dashboard"/></c:if>
          <c:if test="${sessionScope.role == 'RECIPIENT'}"><c:set var="dashUrl" value="${ctx}/recipient/dashboard"/></c:if>
          <c:if test="${sessionScope.role == 'HOSPITAL'}"><c:set var="dashUrl" value="${ctx}/hospital/dashboard"/></c:if>
          <c:if test="${sessionScope.role == 'ADMIN'}"><c:set var="dashUrl" value="${ctx}/admin/dashboard"/></c:if>

          <div class="dropdown">
            <button class="btn user-dropdown-btn d-flex align-items-center gap-2" 
                    type="button" 
                    id="userMenuBtn"
                    aria-expanded="false" 
                    aria-haspopup="true"
                    aria-label="Menu tài khoản">
              <span class="avatar ${sessionScope.role == 'HOSPITAL' ? 'hospital' : sessionScope.role == 'ADMIN' ? 'admin' : ''}">
                <c:choose>
                  <c:when test="${sessionScope.role == 'HOSPITAL'}">
                    <i class="bi bi-hospital"></i>
                  </c:when>
                  <c:when test="${sessionScope.role == 'ADMIN'}">
                    <i class="bi bi-shield-check"></i>
                  </c:when>
                  <c:otherwise>
                    <i class="bi bi-person-fill"></i>
                  </c:otherwise>
                </c:choose>
              </span>
              <span class="user-meta d-none d-sm-block">
                <span class="name">
                  <c:choose>
                    <c:when test="${not empty sessionScope.donor}">
                      <c:out value="${sessionScope.donor.fullName != null ? sessionScope.donor.fullName : sessionScope.authUser.email}"/>
                    </c:when>
                    <c:when test="${not empty sessionScope.hospital}">
                      <c:out value="${sessionScope.hospital.name != null ? sessionScope.hospital.name : sessionScope.authUser.email}"/>
                    </c:when>
                    <c:otherwise>
                      <c:out value="${sessionScope.authUser.email}"/>
                    </c:otherwise>
                  </c:choose>
                </span>
                <div class="bt">
                  <c:choose>
                    <c:when test="${not empty sessionScope.donor and not empty sessionScope.donor.bloodGroup}">
                      <c:out value="${sessionScope.donor.bloodGroup}"/>
                    </c:when>
                    <c:when test="${not empty sessionScope.hospital}">
                      <c:choose>
                        <c:when test="${not empty sessionScope.hospital.region}">
                          <c:out value="${sessionScope.hospital.region}"/>
                        </c:when>
                        <c:otherwise>
                          <c:out value="Bệnh viện"/>
                        </c:otherwise>
                      </c:choose>
                    </c:when>
                    <c:otherwise>
                      <c:out value="—"/>
                    </c:otherwise>
                  </c:choose>
                </div>
              </span>
              <i class="bi bi-caret-down-fill small ms-1 d-none d-sm-inline text-muted"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow" 
                aria-labelledby="userMenuBtn" 
                style="min-width:280px; margin-top: 8px;">
              <!-- User Info Header -->
              <li class="px-3 py-3 bg-light border-bottom">
                <div class="user-chip">
                  <span class="avatar ${sessionScope.role == 'HOSPITAL' ? 'hospital' : sessionScope.role == 'ADMIN' ? 'admin' : ''}" style="width: 40px; height: 40px;">
                    <c:choose>
                      <c:when test="${sessionScope.role == 'HOSPITAL'}">
                        <i class="bi bi-hospital"></i>
                      </c:when>
                      <c:when test="${sessionScope.role == 'ADMIN'}">
                        <i class="bi bi-shield-check"></i>
                      </c:when>
                      <c:otherwise>
                        <i class="bi bi-person-fill"></i>
                      </c:otherwise>
                    </c:choose>
                  </span>
                  <div class="user-meta">
                    <div class="name" style="font-size: 0.95rem;">
                      <c:choose>
                        <c:when test="${not empty sessionScope.donor}">
                          <c:out value="${sessionScope.donor.fullName != null ? sessionScope.donor.fullName : sessionScope.authUser.email}"/>
                        </c:when>
                        <c:when test="${not empty sessionScope.hospital}">
                          <c:out value="${sessionScope.hospital.name != null ? sessionScope.hospital.name : sessionScope.authUser.email}"/>
                        </c:when>
                        <c:otherwise>
                          <c:out value="${sessionScope.authUser.email}"/>
                        </c:otherwise>
                      </c:choose>
                    </div>
                    <div class="bt" style="font-size: 0.75rem; margin-top: 2px;">
                      <c:choose>
                        <c:when test="${not empty sessionScope.donor and not empty sessionScope.donor.bloodGroup}">
                          Nhóm máu: <strong><c:out value="${sessionScope.donor.bloodGroup}"/></strong>
                        </c:when>
                        <c:when test="${not empty sessionScope.hospital}">
                          <c:choose>
                            <c:when test="${not empty sessionScope.hospital.region}">
                              Khu vực: <strong><c:out value="${sessionScope.hospital.region}"/></strong>
                            </c:when>
                            <c:otherwise>
                              Bệnh viện
                            </c:otherwise>
                          </c:choose>
                        </c:when>
                        <c:otherwise>
                          <c:out value="${sessionScope.authUser.email}"/>
                        </c:otherwise>
                      </c:choose>
                    </div>
                  </div>
                </div>
              </li>

              <!-- Main Menu Items -->
              <li><a class="dropdown-item" href="${dashUrl}">
                <i class="bi bi-speedometer2"></i>
                <span>Bảng điều khiển</span>
              </a></li>

              <c:choose>
                <c:when test="${sessionScope.role == 'DONOR'}">
                  <li><a class="dropdown-item" href="${ctx}/donor/profile">
                    <i class="bi bi-person-gear"></i>
                    <span>Chỉnh sửa thông tin cá nhân</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/donor/security">
                    <i class="bi bi-shield-lock"></i>
                    <span>Bảo mật tài khoản</span>
                  </a></li>
                </c:when>
                <c:when test="${sessionScope.role == 'HOSPITAL'}">
                  <li><a class="dropdown-item" href="${ctx}/hospital/profile">
                    <i class="bi bi-person-gear"></i>
                    <span>Chỉnh sửa thông tin cá nhân</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/hospital/security">
                    <i class="bi bi-shield-lock"></i>
                    <span>Bảo mật tài khoản</span>
                  </a></li>
                </c:when>
                <c:when test="${sessionScope.role == 'ADMIN'}">
                  <li><a class="dropdown-item" href="${ctx}/admin/profile">
                    <i class="bi bi-person-gear"></i>
                    <span>Chỉnh sửa thông tin cá nhân</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/admin/security">
                    <i class="bi bi-shield-lock"></i>
                    <span>Bảo mật tài khoản</span>
                  </a></li>
                </c:when>
                <c:otherwise>
                  <li><a class="dropdown-item" href="${ctx}/profile">
                    <i class="bi bi-person-gear"></i>
                    <span>Chỉnh sửa thông tin cá nhân</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/security">
                    <i class="bi bi-shield-lock"></i>
                    <span>Bảo mật tài khoản</span>
                  </a></li>
                </c:otherwise>
              </c:choose>

              <!-- Role-specific Menu Items -->
              <li><hr class="dropdown-divider" style="margin: 0.5rem 0;"></li>
              <c:choose>
                <c:when test="${sessionScope.role == 'DONOR'}">
                  <li><a class="dropdown-item" href="${ctx}/donor/schedule">
                    <i class="bi bi-calendar-check"></i>
                    <span>Đặt lịch hiến máu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/donor/history">
                    <i class="bi bi-clock-history"></i>
                    <span>Lịch sử hiến máu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/donor/certificate">
                    <i class="bi bi-award"></i>
                    <span>Chứng nhận hiến máu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/donor/eligibility">
                    <i class="bi bi-clipboard2-pulse"></i>
                    <span>Kiểm tra điều kiện</span>
                  </a></li>
                </c:when>
                <c:when test="${sessionScope.role == 'RECIPIENT'}">
                  <li><a class="dropdown-item" href="${ctx}/recipient/requests/create">
                    <i class="bi bi-plus-circle"></i>
                    <span>Tạo yêu cầu máu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/recipient/requests">
                    <i class="bi bi-layers"></i>
                    <span>Yêu cầu của tôi</span>
                  </a></li>
                </c:when>
                <c:when test="${sessionScope.role == 'HOSPITAL'}">
                  <li><a class="dropdown-item" href="${ctx}/hospital/dashboard">
                    <i class="bi bi-house-door"></i>
                    <span>Trang chủ bệnh viện</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/hospital/inventory">
                    <i class="bi bi-droplet-half"></i>
                    <span>Quản lý kho máu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/hospital/requests/create">
                    <i class="bi bi-plus-square"></i>
                    <span>Tạo yêu cầu khẩn</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/hospital/requests">
                    <i class="bi bi-list-check"></i>
                    <span>Quản lý yêu cầu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/hospital/donors">
                    <i class="bi bi-people"></i>
                    <span>Người hiến máu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/hospital/verify-donor">
                    <i class="bi bi-person-check"></i>
                    <span>Xác thực người hiến</span>
                  </a></li>
                </c:when>
                <c:when test="${sessionScope.role == 'ADMIN'}">
                  <li><a class="dropdown-item" href="${ctx}/admin/dashboard">
                    <i class="bi bi-house-door"></i>
                    <span>Trang chủ quản trị</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/admin/manage-user">
                    <i class="bi bi-people-gear"></i>
                    <span>Quản trị người dùng</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/admin/manage-hospital">
                    <i class="bi bi-hospital"></i>
                    <span>Quản lý bệnh viện</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/admin/manage-request">
                    <i class="bi bi-journal-text"></i>
                    <span>Quản lý yêu cầu</span>
                  </a></li>
                  <li><a class="dropdown-item" href="${ctx}/admin/settings">
                    <i class="bi bi-sliders"></i>
                    <span>Cấu hình hệ thống</span>
                  </a></li>
                </c:when>
              </c:choose>

              <!-- Additional Common Items -->
              <li><hr class="dropdown-divider" style="margin: 0.5rem 0;"></li>
              <li><a class="dropdown-item" href="${ctx}/notifications">
                <i class="bi bi-bell"></i>
                <span>Thông báo</span>
                <c:if test="${unreadCount gt 0}">
                  <span class="badge bg-danger rounded-pill ms-auto">${unreadCount}</span>
                </c:if>
              </a></li>
              <li><a class="dropdown-item" href="${ctx}/help">
                <i class="bi bi-question-circle"></i>
                <span>Trợ giúp & Hỗ trợ</span>
              </a></li>

              <!-- Logout -->
              <li><hr class="dropdown-divider" style="margin: 0.5rem 0;"></li>
              <li>
                <form method="post" action="${ctx}/logout" style="margin: 0;">
                  <button type="submit" class="dropdown-item text-danger" style="width: 100%; text-align: left; border: none; background: none;">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Đăng xuất</span>
                  </button>
                </form>
              </li>
            </ul>
          </div>
        </c:if>
      </div>
    </div>
  </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  (function() {
    'use strict';
    
    // Sticky shadow
    const nav = document.querySelector('.navbar-bl');
    if (nav) {
      const onScroll = () => nav.classList.toggle('stuck', window.scrollY > 2);
      document.addEventListener('scroll', onScroll, {passive:true}); 
      onScroll();
    }

    // Mark all notifications read
    const markReadBtn = document.getElementById('markAllReadBtn');
    if (markReadBtn) {
      markReadBtn.addEventListener('click', function(e){
        e.preventDefault();
        fetch('${ctx}/notifications/mark-all-read', {
          method:'POST', 
          headers:{'X-Requested-With':'XMLHttpRequest'}
        })
        .then(()=>location.href='${ctx}/notifications')
        .catch(()=>location.href='${ctx}/notifications');
      });
    }

    // Đơn giản hóa: chỉ dùng JavaScript thuần để toggle dropdown
    function setupUserDropdown() {
      const userMenuBtn = document.getElementById('userMenuBtn');
      if (!userMenuBtn) return;
      
      const dropdown = userMenuBtn.closest('.dropdown');
      const menu = dropdown?.querySelector('.dropdown-menu');
      if (!menu) return;
      
      // Đảm bảo chỉ setup 1 lần
      if (userMenuBtn.hasAttribute('data-dropdown-setup')) return;
      userMenuBtn.setAttribute('data-dropdown-setup', 'true');
      
      // Handler để đóng khi click bên ngoài
      let outsideClickHandler = null;
      
      function setupOutsideClick() {
        if (!outsideClickHandler) {
          outsideClickHandler = function(event) {
            if (!dropdown.contains(event.target)) {
              menu.classList.remove('show');
              userMenuBtn.setAttribute('aria-expanded', 'false');
              document.removeEventListener('click', outsideClickHandler);
              outsideClickHandler = null;
            }
          };
          // Delay để tránh đóng ngay khi click button
          setTimeout(function() {
            document.addEventListener('click', outsideClickHandler);
          }, 100);
        }
      }
      
      // Toggle dropdown khi click
      userMenuBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const isOpen = menu.classList.contains('show');
        
        // Đóng tất cả dropdown khác
        document.querySelectorAll('.dropdown-menu.show').forEach(m => {
          if (m !== menu) {
            m.classList.remove('show');
          }
        });
        document.querySelectorAll('[aria-expanded="true"]').forEach(btn => {
          if (btn !== userMenuBtn) {
            btn.setAttribute('aria-expanded', 'false');
          }
        });
        
        // Toggle menu hiện tại
        if (isOpen) {
          menu.classList.remove('show');
          userMenuBtn.setAttribute('aria-expanded', 'false');
          // Remove outside click handler nếu có
          if (outsideClickHandler) {
            document.removeEventListener('click', outsideClickHandler);
            outsideClickHandler = null;
          }
        } else {
          menu.classList.add('show');
          userMenuBtn.setAttribute('aria-expanded', 'true');
          // Setup handler để đóng khi click outside
          setupOutsideClick();
        }
      });
    }
    
    // Chờ DOM ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setupUserDropdown);
    } else {
      setupUserDropdown();
    }
  })();
</script>

