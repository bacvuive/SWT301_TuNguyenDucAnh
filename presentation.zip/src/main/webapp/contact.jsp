<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Liên hệ</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="header.jsp" %>

<style>
  .section{padding:72px 0}
  .section-title{font-weight:800;margin-bottom:12px}
  .muted{color:#64748b}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
  .bg-blush{background:#fff5f6}
</style>

<!-- =================== HERO =================== -->
<section class="bg-blush">
  <div class="container py-5">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold mb-3">
          <span class="text-danger">Liên hệ</span> với chúng tôi
        </h1>
        <p class="lead text-muted mb-4">
          Có thắc mắc về hiến máu? Hãy để chúng tôi tư vấn miễn phí. 
          Chúng tôi luôn sẵn sàng hỗ trợ bạn 24/7.
        </p>
      </div>
      <div class="col-lg-6 text-center">
        <div class="card card-soft p-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-danger">24/7</div>
                <div class="small text-muted">Hỗ trợ</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-success">100%</div>
                <div class="small text-muted">Miễn phí</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-primary">15</div>
                <div class="small text-muted">Phút phản hồi</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-warning">5★</div>
                <div class="small text-muted">Đánh giá</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== LIÊN HỆ =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Liên hệ với chúng tôi</h2>
    <p class="text-center muted mb-4">Có thắc mắc về hiến máu? Hãy để chúng tôi tư vấn miễn phí</p>
    
    <div class="row g-4">
      <div class="col-lg-5">
        <div class="card card-soft h-100">
          <div class="card-body">
            <h5 class="fw-bold mb-3">Thông tin liên hệ</h5>
            <div class="mb-3">
              <i class="bi bi-telephone me-2 text-danger"></i>
              <strong>Hotline 24/7:</strong> 0917849617
            </div>
            <div class="mb-3">
              <i class="bi bi-envelope me-2 text-danger"></i>
              <strong>Email:</strong> bacmtp1104@gmail.com
            </div>
            <div class="mb-3">
              <i class="bi bi-geo-alt me-2 text-danger"></i>
              <strong>Trụ sở:</strong> Đại Học FPT, Ngũ Hành Sơn, Đà Nẵng
            </div>
            <div class="mb-3">
              <i class="bi bi-clock me-2 text-danger"></i>
              <strong>Giờ làm việc:</strong> T2–T7: 7:00–17:00
            </div>
            <div class="d-flex gap-2 fs-5">
              <a href="https://facebook.com/bloodlink" target="_blank" rel="noopener" class="text-danger">
                <i class="bi bi-facebook"></i>
              </a>
              <a href="https://instagram.com/bloodlink" target="_blank" rel="noopener" class="text-danger">
                <i class="bi bi-instagram"></i>
              </a>
              <a href="https://youtube.com/bloodlink" target="_blank" rel="noopener" class="text-danger">
                <i class="bi bi-youtube"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      
      <div class="col-lg-7">
        <div class="card card-soft">
          <div class="card-body">
            <h5 class="fw-bold mb-3">Gửi tin nhắn cho chúng tôi</h5>
            
            <c:if test="${not empty error}">
              <div class="alert alert-danger" role="alert">${error}</div>
            </c:if>
            <c:if test="${not empty success}">
              <div class="alert alert-success" role="alert">${success}</div>
            </c:if>
            
            <form method="post" action="${pageContext.request.contextPath}/contact" class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Họ và tên *</label>
                <input name="fullName" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Email *</label>
                <input type="email" name="email" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Số điện thoại *</label>
                <input name="phone" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Nhóm máu</label>
                <select name="bloodType" class="form-select">
                  <option value="">Chọn nhóm máu</option>
                  <option>O-</option><option>O+</option>
                  <option>A-</option><option>A+</option>
                  <option>B-</option><option>B+</option>
                  <option>AB-</option><option>AB+</option>
                </select>
              </div>
              <div class="col-12">
                <label class="form-label">Tin nhắn</label>
                <textarea name="message" class="form-control" rows="4" placeholder="Nhập tin nhắn của bạn..."></textarea>
              </div>
              <div class="col-12">
                <button class="btn btn-danger pill px-4" type="submit">
                  <i class="bi bi-send me-2"></i>Gửi tin nhắn
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== FAQ =================== -->
<section class="section bg-blush">
  <div class="container">
    <h2 class="text-center section-title">Câu hỏi thường gặp</h2>
    <p class="text-center muted mb-4">Những câu hỏi phổ biến về hiến máu</p>
    
    <div class="row g-4">
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <h6 class="fw-bold mb-2">Tôi có thể hiến máu bao lâu một lần?</h6>
            <p class="text-muted small">Khoảng cách tối thiểu giữa 2 lần hiến máu là 12 tuần (3 tháng) để đảm bảo sức khỏe.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <h6 class="fw-bold mb-2">Hiến máu có đau không?</h6>
            <p class="text-muted small">Chỉ cảm thấy đau nhẹ khi chích kim, quá trình hiến máu hoàn toàn không đau.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <h6 class="fw-bold mb-2">Tôi cần chuẩn bị gì trước khi hiến máu?</h6>
            <p class="text-muted small">Ăn uống đầy đủ, ngủ đủ giấc, uống nhiều nước và không uống rượu bia.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <h6 class="fw-bold mb-2">Hiến máu có an toàn không?</h6>
            <p class="text-muted small">Hoàn toàn an toàn với quy trình vô trùng và kiểm tra sức khỏe trước khi hiến.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<%@ include file="footer.jsp" %>
</body>
</html>
