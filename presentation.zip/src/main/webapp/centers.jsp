<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Bản đồ máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
</head>
<body>
<%@ include file="header.jsp" %>

<style>
  .section{padding:72px 0}
  .section-title{font-weight:800;margin-bottom:12px}
  .muted{color:#64748b}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
  .bg-blush{background:#fff5f6}
  .bg-ice{background:linear-gradient(180deg,#f1f5ff 0%,#f8fbff 100%)}
  #vnMap{width:100%;height:500px;border-radius:14px}
  .marker-critical{background-color:#dc3545}
  .marker-low{background-color:#ffc107}
  .marker-good{background-color:#28a745}
  .marker-empty{background-color:#6c757d}
</style>

<!-- =================== HERO =================== -->
<section class="bg-blush">
  <div class="container py-5">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold mb-3">
          Bản đồ <span class="text-danger">Trung tâm hiến máu</span>
        </h1>
        <p class="lead text-muted mb-4">
          Tìm kiếm các trung tâm hiến máu gần nhất và xem tình trạng kho máu 
          tại các bệnh viện trên toàn quốc.
        </p>
        <div class="d-flex gap-3">
          <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/donor/schedule" class="btn btn-danger pill px-4">
            <i class="bi bi-calendar-check me-2"></i>Đặt lịch hiến máu
          </a>
          <a href="${pageContext.request.contextPath}/register" class="btn btn-outline-danger pill px-4">
            <i class="bi bi-heart-fill me-2"></i>Đăng ký hiến máu
          </a>
        </div>
      </div>
      <div class="col-lg-6 text-center">
        <div class="card card-soft p-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-danger">${totalCenters != null ? totalCenters : 0}</div>
                <div class="small text-muted">Trung tâm</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-success">24/7</div>
                <div class="small text-muted">Hoạt động</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-primary">${totalBags != null ? totalBags : 0}</div>
                <div class="small text-muted">Túi máu</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-warning"><fmt:formatNumber value="${totalCenters != null && totalCenters > 0 ? (totalBags != null ? totalBags / totalCenters : 0) : 0}" maxFractionDigits="0"/></div>
                <div class="small text-muted">TB/Hiện trường</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== BỘ LỌC =================== -->
<section class="section">
  <div class="container">
    <div class="card card-soft mb-4">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Tìm kiếm trung tâm hiến máu</h5>
        <div class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Tỉnh/Thành</label>
            <select id="provinceFilter" class="form-select">
              <option value="">Tất cả</option>
              <option>Hà Nội</option>
              <option>Hải Phòng</option>
              <option>Quảng Ninh</option>
              <option>Thừa Thiên Huế</option>
              <option>Đà Nẵng</option>
              <option>Quảng Nam</option>
              <option>Khánh Hòa</option>
              <option>Bình Định</option>
              <option>Gia Lai</option>
              <option>Đăk Lăk</option>
              <option>Đồng Nai</option>
              <option>Bình Dương</option>
              <option>TP.HCM</option>
              <option>Cần Thơ</option>
              <option>An Giang</option>
              <option>Kiên Giang</option>
              <option>Nghệ An</option>
              <option>Thanh Hóa</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Tìm kiếm (tên, địa chỉ…)</label>
            <input id="keywordFilter" class="form-control" placeholder="Ví dụ: Chợ Rẫy, Nguyễn Thị Minh Khai...">
          </div>
          <div class="col-md-3">
            <label class="form-label">Nhóm máu</label>
            <select id="bloodGroupFilter" class="form-select">
              <option value="">Tất cả</option>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>
          <div class="col-md-2">
            <label class="form-label">&nbsp;</label>
            <div class="d-grid gap-2">
              <button id="btnFindNearby" class="btn btn-primary pill" title="Tìm trung tâm gần tôi">
                <i class="bi bi-geo-alt me-1"></i>Tìm gần tôi
              </button>
              <button id="btnClearFilter" class="btn btn-outline-secondary pill">
                Xóa lọc
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-lg-6">
        <h4 class="fw-bold mb-3">Danh sách trung tâm</h4>
        <div id="centerList" class="row g-3"></div>
      </div>
      <div class="col-lg-6">
        <h4 class="fw-bold mb-3">Bản đồ</h4>
        <div id="vnMap" class="shadow-soft" aria-label="Bản đồ Việt Nam"></div>
        <div id="vnMapFallback" class="mt-2 d-none">
          <iframe
            src="https://www.openstreetmap.org/export/embed.html?bbox=102.14441%2C8.179066%2C109.46966%2C23.392694&layer=mapnik"
            style="border:0;width:100%;height:500px;border-radius:14px"></iframe>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== THỐNG KÊ =================== -->
<section class="section bg-ice">
  <div class="container">
    <h2 class="text-center section-title">Thống kê kho máu</h2>
    <p class="text-center muted mb-4">Tình trạng kho máu tại các trung tâm lớn</p>
    
    <div class="row g-4">
      <c:forEach var="bg" items="${['O-', 'A-', 'O+', 'A+', 'B+', 'AB+']}">
        <div class="col-md-4">
          <div class="card card-soft text-center">
            <div class="card-body">
              <div class="display-6 fw-bold text-danger mb-2">${bg}</div>
              <div class="small text-muted mb-3">Nhóm máu ${bg.contains('-') ? 'hiếm' : 'phổ biến'}</div>
              <c:set var="count" value="${bloodGroupStats[bg] != null ? bloodGroupStats[bg] : 0}" />
              <c:set var="percentage" value="${totalBags != null && totalBags > 0 ? (count * 100 / totalBags) : 0}" />
              <div class="progress mb-2" style="height: 8px;">
                <div class="progress-bar ${percentage < 30 ? 'bg-danger' : (percentage < 60 ? 'bg-warning' : 'bg-success')}" 
                     style="width: ${percentage}%"></div>
              </div>
              <div class="small text-muted">${count} túi máu (${percentage < 30 ? 'Cần gấp' : (percentage < 60 ? 'Thấp' : 'Đủ')})</div>
            </div>
          </div>
        </div>
      </c:forEach>
    </div>
  </div>
</section>

<!-- =================== HƯỚNG DẪN =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Hướng dẫn sử dụng</h2>
    <div class="row g-4">
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="display-6 text-danger mb-3">1</div>
            <h6 class="fw-bold mb-2">Tìm trung tâm</h6>
            <p class="small text-muted">Sử dụng bộ lọc hoặc GPS để tìm trung tâm hiến máu gần bạn</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="display-6 text-danger mb-3">2</div>
            <h6 class="fw-bold mb-2">Kiểm tra thông tin</h6>
            <p class="small text-muted">Xem giờ làm việc, địa chỉ, số điện thoại và tình trạng kho máu</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="display-6 text-danger mb-3">3</div>
            <h6 class="fw-bold mb-2">Đặt lịch</h6>
            <p class="small text-muted">Gọi điện hoặc đặt lịch trực tuyến để hiến máu</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft text-center h-100">
          <div class="card-body">
            <div class="display-6 text-danger mb-3">4</div>
            <h6 class="fw-bold mb-2">Hiến máu</h6>
            <p class="small text-muted">Đến trung tâm theo lịch hẹn để hiến máu</p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="text-center mt-4">
      <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
        <i class="bi bi-heart-fill me-2"></i>Đăng ký hiến máu ngay
      </a>
    </div>
  </div>
</section>

<!-- JS: Map & Data -->
<script>
/* DỮ LIỆU TRUNG TÂM HIẾN MÁU - Từ Database */
var BLOOD_CENTERS = [
  <c:forEach var="hospital" items="${hospitals}" varStatus="loop">
  {
    id: ${hospital.hospitalId},
    name: '<c:out value="${hospital.name}" />',
    addr: '<c:out value="${hospital.address != null ? hospital.address : ''}" />',
    city: '<c:out value="${hospital.region != null ? hospital.region : ''}" />',
    phone: '<c:out value="${hospital.contact != null ? hospital.contact : ''}" />',
    hours: 'T2–T7: 7:00–17:00',
    lat: ${hospital.latitude != null ? hospital.latitude : 0},
    lng: ${hospital.longitude != null ? hospital.longitude : 0},
    totalBags: ${hospital.totalBags != null ? hospital.totalBags : 0},
    availableBags: ${hospital.availableBags != null ? hospital.availableBags : 0},
    inventoryStatus: '${hospital.inventoryStatus != null ? hospital.inventoryStatus : "unknown"}',
    bloodGroupCounts: ${hospital.bloodGroupCountsJson != null ? hospital.bloodGroupCountsJson : '{}'}
  }<c:if test="${!loop.last}">,</c:if>
  </c:forEach>
];

// Fallback data nếu không có hospitals từ database
var FALLBACK_CENTERS = [
  {name:'Viện Huyết học – Truyền máu TW', addr:'78 Giải Phóng, Đống Đa', city:'Hà Nội', phone:'024 3868 9364', hours:'T2–CN: 7:30–17:00', lat:21.00072, lng:105.83952, inventoryStatus:'good'},
  {name:'Trung tâm Hiến máu Hà Nội', addr:'123 Đống Đa', city:'Hà Nội', phone:'024 3456 7890', hours:'T2–T7: 7:00–17:00; CN: 8:00–12:00', lat:21.0278, lng:105.8342, inventoryStatus:'good'},
  {name:'BV Chợ Rẫy – Ngân hàng máu', addr:'201B Nguyễn Chí Thanh, Q5', city:'TP.HCM', phone:'028 3855 4137', hours:'T2–CN: 7:00–20:00', lat:10.75994, lng:106.66186, inventoryStatus:'good'}
];

// Merge với fallback nếu không có data
if (BLOOD_CENTERS.length === 0 || (BLOOD_CENTERS.length === 1 && BLOOD_CENTERS[0].lat === 0)) {
  BLOOD_CENTERS = FALLBACK_CENTERS;
}

(function(){
  var listEl = document.getElementById('centerList');
  var provinceEl = document.getElementById('provinceFilter');
  var keywordEl  = document.getElementById('keywordFilter');
  var bloodGroupEl = document.getElementById('bloodGroupFilter');
  var clearBtn   = document.getElementById('btnClearFilter');
  var findNearbyBtn = document.getElementById('btnFindNearby');

  var mapEl = document.getElementById('vnMap');
  var fbEl  = document.getElementById('vnMapFallback');
  var vnBounds = [[8.179066,102.14441],[23.392694,109.46966]];
  var map, markerLayer;
  var userLocation = null;
  var currentMarkers = [];

  function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,"\\'");}
  function gmapsLink(lat,lng){return 'https://www.google.com/maps/dir/?api=1&destination='+lat+','+lng+'&travelmode=driving&dir_action=navigate';}

  function getMarkerColor(status){
    switch(status){
      case 'critical': return '#dc3545';
      case 'low': return '#ffc107';
      case 'good': return '#28a745';
      case 'empty': return '#6c757d';
      default: return '#17a2b8';
    }
  }

  function getMarkerIcon(status){
    var color = getMarkerColor(status);
    return L.divIcon({
      className: 'custom-marker',
      html: '<div style="background-color:'+color+';width:20px;height:20px;border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);"></div>',
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });
  }

  function calculateDistance(lat1, lng1, lat2, lng2){
    var R = 6371; // Radius of the earth in km
    var dLat = (lat2 - lat1) * Math.PI / 180;
    var dLng = (lng2 - lng1) * Math.PI / 180;
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // Distance in km
  }

  function ensureMap(){
    if (!window.L){ fbEl.classList.remove('d-none'); mapEl.classList.add('d-none'); return null; }
    if (!map){
      map = L.map('vnMap',{maxBounds:L.latLngBounds(vnBounds),maxBoundsViscosity:1.0,minZoom:5,maxZoom:18,zoomControl:true})
            .fitBounds(L.latLngBounds(vnBounds).pad(-0.25));
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap'}).addTo(map);
      markerLayer = L.layerGroup().addTo(map);
      setTimeout(function(){ map.invalidateSize(); }, 300);
      map.on('tileerror', function(){ mapEl.classList.add('d-none'); fbEl.classList.remove('d-none'); });
    }
    return map;
  }

  function renderList(items){
    var html = '';
    if (items.length === 0) {
      html = '<div class="col-12"><div class="alert alert-info">Không tìm thấy trung tâm nào phù hợp</div></div>';
    } else {
      for (var i=0;i<items.length;i++){
        var c = items[i];
        var statusBadge = '';
        var statusText = '';
        switch(c.inventoryStatus){
          case 'critical': statusBadge = 'danger'; statusText = 'Cần gấp'; break;
          case 'low': statusBadge = 'warning'; statusText = 'Thấp'; break;
          case 'good': statusBadge = 'success'; statusText = 'Đủ'; break;
          case 'empty': statusBadge = 'secondary'; statusText = 'Trống'; break;
          default: statusBadge = 'info'; statusText = 'Hoạt động';
        }
        
        var distanceText = '';
        if (userLocation && c.lat && c.lng) {
          var dist = calculateDistance(userLocation.lat, userLocation.lng, c.lat, c.lng);
          distanceText = '<div class="small text-primary mb-1"><i class="bi bi-arrow-right-circle me-1"></i>Cách ' + dist.toFixed(1) + ' km</div>';
        }

        html += ''
        + '<div class="col-12"><div class="card card-soft h-100"><div class="card-body">'
        +   '<div class="d-flex justify-content-between align-items-start">'
        +     '<div style="flex:1;">'
        +       '<h6 class="mb-1">'+esc(c.name)+'</h6>'
        +       '<div class="small muted mb-1"><i class="bi bi-geo-alt me-1"></i>'+esc(c.addr)+', '+esc(c.city)+'</div>'
        +       distanceText
        +       '<div class="small muted mb-2"><i class="bi bi-telephone me-1"></i>'+(c.phone?esc(c.phone):'—')+' · <i class="bi bi-clock me-1"></i>'+(c.hours?esc(c.hours):'—')+'</div>'
        +       '<div class="small muted"><i class="bi bi-droplet me-1"></i>'+(c.availableBags||0)+'/'+(c.totalBags||0)+' túi máu có sẵn</div>'
        +     '</div>'
        +     '<span class="badge bg-'+statusBadge+'-subtle text-'+statusBadge+' pill ms-2">'+statusText+'</span>'
        +   '</div>'
        +   '<div class="d-flex gap-2 mt-2">'
        +     '<a href="'+gmapsLink(c.lat,c.lng)+'" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm pill"><i class="bi bi-geo me-1"></i>Chỉ đường</a>'
        +     '<button class="btn btn-danger btn-sm pill" onclick="window.scrollTo({top:document.getElementById(\'vnMap\').offsetTop-120,behavior:\'smooth\'}); _focusMarker('+c.lat+','+c.lng+',\''+esc(c.name)+'\')"><i class="bi bi-pin-map me-1"></i>Hiển thị</button>'
        +   '</div>'
        + '</div></div></div>';
      }
    }
    listEl.innerHTML = html;
  }

  function renderMarkers(items){
    var m = ensureMap(); if(!m) return;
    markerLayer.clearLayers();
    currentMarkers = [];
    var bounds=[];

    // Add user location marker if available
    if (userLocation) {
      L.marker([userLocation.lat, userLocation.lng], {
        icon: L.divIcon({
          className: 'user-location-marker',
          html: '<div style="background-color:#007bff;width:16px;height:16px;border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);"></div>',
          iconSize: [16, 16],
          iconAnchor: [8, 8]
        })
      }).addTo(markerLayer).bindPopup('<strong>Vị trí của bạn</strong>');
      bounds.push([userLocation.lat, userLocation.lng]);
    }

    for (var i=0;i<items.length;i++){
      var c=items[i];
      if (!c.lat || !c.lng || c.lat === 0 || c.lng === 0) continue;
      
      var marker = L.marker([c.lat, c.lng], {
        icon: getMarkerIcon(c.inventoryStatus || 'unknown')
      }).addTo(markerLayer);
      
      var popupContent = '<strong>'+esc(c.name)+'</strong><br>'+
                        esc(c.addr)+', '+esc(c.city)+'<br>'+
                        (c.hours?esc(c.hours):'')+'<br>'+
                        '<small><i class="bi bi-droplet me-1"></i>'+(c.availableBags||0)+'/'+(c.totalBags||0)+' túi máu</small>';
      
      marker.bindPopup(popupContent);
      currentMarkers.push(marker);
      bounds.push([c.lat, c.lng]);
    }
    
    if (bounds.length){ 
      m.fitBounds(bounds,{padding:[20,20]}); 
    }
  }

  function filterData(){
    var kw = (keywordEl.value||'').toLowerCase().trim();
    var pv = (provinceEl.value||'').trim();
    var bg = (bloodGroupEl.value||'').trim();
    var out = [];
    
    for (var i=0;i<BLOOD_CENTERS.length;i++){
      var c = BLOOD_CENTERS[i];
      if (!c.lat || !c.lng || c.lat === 0 || c.lng === 0) continue;
      
      var byPv = !pv || (c.city && c.city.toLowerCase().indexOf(pv.toLowerCase()) !== -1);
      var byKw = !kw || ((c.name+' '+(c.addr||'')+' '+(c.city||'')).toLowerCase().indexOf(kw)!==-1);
      var byBg = !bg || (c.bloodGroupCounts && c.bloodGroupCounts[bg] && c.bloodGroupCounts[bg] > 0);
      
      if (byPv && byKw && byBg) {
        out.push(c);
      }
    }

    // Sort by distance if user location available
    if (userLocation) {
      out.sort(function(a, b) {
        var distA = calculateDistance(userLocation.lat, userLocation.lng, a.lat, a.lng);
        var distB = calculateDistance(userLocation.lat, userLocation.lng, b.lat, b.lng);
        return distA - distB;
      });
    }

    return out;
  }

  function update(){ 
    var items = filterData(); 
    renderList(items); 
    renderMarkers(items); 
  }

  window._focusMarker = function(lat,lng,name){
    var m = ensureMap(); if(!m) return;
    m.setView([lat,lng], 15, {animate:true});
    L.popup().setLatLng([lat,lng]).setContent('<strong>'+esc(name)+'</strong>').openOn(m);
  };

  // Find nearby centers using Geolocation API
  findNearbyBtn.addEventListener('click', function(){
    if (!navigator.geolocation) {
      alert('Trình duyệt của bạn không hỗ trợ định vị GPS');
      return;
    }

    findNearbyBtn.disabled = true;
    findNearbyBtn.innerHTML = '<i class="bi bi-hourglass-split me-1"></i>Đang tìm...';

    navigator.geolocation.getCurrentPosition(
      function(position){
        userLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        findNearbyBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Đã tìm thấy';
        findNearbyBtn.classList.remove('btn-primary');
        findNearbyBtn.classList.add('btn-success');
        update();
        setTimeout(function(){
          findNearbyBtn.disabled = false;
          findNearbyBtn.innerHTML = '<i class="bi bi-geo-alt me-1"></i>Tìm gần tôi';
          findNearbyBtn.classList.remove('btn-success');
          findNearbyBtn.classList.add('btn-primary');
        }, 2000);
      },
      function(error){
        alert('Không thể lấy vị trí của bạn: ' + error.message);
        findNearbyBtn.disabled = false;
        findNearbyBtn.innerHTML = '<i class="bi bi-geo-alt me-1"></i>Tìm gần tôi';
      }
    );
  });

  ensureMap(); 
  update();
  provinceEl.addEventListener('change', update);
  keywordEl.addEventListener('input', function(){ clearTimeout(keywordEl._t); keywordEl._t = setTimeout(update, 200); });
  bloodGroupEl.addEventListener('change', update);
  clearBtn.addEventListener('click', function(){ 
    provinceEl.value=''; 
    keywordEl.value=''; 
    bloodGroupEl.value='';
    userLocation = null;
    update(); 
  });
})();
</script>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<%@ include file="footer.jsp" %>
</body>
</html>
