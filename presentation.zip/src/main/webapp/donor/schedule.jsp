<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" 
         isELIgnored="false" buffer="8kb" autoFlush="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Đặt lịch hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<jsp:include page="/header.jsp" />

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1200px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .appointment-card{border-left:4px solid var(--bl-red);padding:20px;margin-bottom:15px}
  .appointment-card.pending{border-left-color:#f59e0b}
  .appointment-card.confirmed{border-left-color:#10b981}
  .appointment-card.cancelled{border-left-color:#ef4444}
  .appointment-card.completed{border-left-color:#6366f1}
  .status-badge{padding:4px 12px;border-radius:999px;font-size:0.75rem;font-weight:600}
  .status-pending{background:#fef3c7;color:#d97706}
  .status-confirmed{background:#d1fae5;color:#059669}
  .status-cancelled{background:#fee2e2;color:#dc2626}
  .status-completed{background:#e0e7ff;color:#4338ca}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-2"><i class="bi bi-calendar-plus me-2"></i>Đặt lịch hiến máu</h1>
      <p class="mb-0">Đặt lịch hiến máu tại bệnh viện hoặc trung tâm gần nhất</p>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <div class="row">
      <!-- Form đặt lịch -->
      <div class="col-lg-5">
        <div class="card card-soft">
          <div class="card-header bg-white border-bottom">
            <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i>Đặt lịch mới</h5>
          </div>
          <div class="card-body p-4">
            <form method="post" action="${pageContext.request.contextPath}/donor/schedule">
              <div class="mb-3">
                <label class="form-label">Bệnh viện <span class="text-danger">*</span></label>
                <select class="form-select" name="hospitalId" required>
                  <option value="">Chọn bệnh viện</option>
                  <c:if test="${not empty hospitals}">
                    <c:forEach var="hospital" items="${hospitals}">
                      <option value="${hospital.hospitalId}">${hospital.name}</option>
                    </c:forEach>
                  </c:if>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Ngày và giờ <span class="text-danger">*</span></label>
                <input type="datetime-local" class="form-control" name="scheduledAt" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Ghi chú</label>
                <textarea class="form-control" name="note" rows="3" 
                          placeholder="Nhập ghi chú hoặc yêu cầu đặc biệt (nếu có)"></textarea>
              </div>
              <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-calendar-check me-2"></i>Đặt lịch
              </button>
            </form>
          </div>
        </div>
      </div>

      <!-- Danh sách lịch hẹn -->
      <div class="col-lg-7">
        <div class="card card-soft">
          <div class="card-header bg-white border-bottom">
            <h5 class="mb-0"><i class="bi bi-calendar-event me-2"></i>Lịch hẹn của tôi</h5>
          </div>
          <div class="card-body p-4">
            <c:choose>
              <c:when test="${not empty appointments && appointments.size() > 0}">
                <c:forEach var="appt" items="${appointments}">
                  <c:set var="statusLower" value="${appt.status != null ? appt.status.toLowerCase() : 'pending'}" />
                  <div class="appointment-card ${statusLower}">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                      <div>
                        <h6 class="mb-1">${appt.hospitalName != null ? appt.hospitalName : 'Không xác định'}</h6>
                        <c:if test="${not empty appt.scheduledAt}">
                          <p class="text-muted small mb-2">
                            <i class="bi bi-calendar me-1"></i>
                            <fmt:formatDate value="${appt.scheduledAt}" pattern="dd/MM/yyyy HH:mm"/>
                          </p>
                        </c:if>
                        <c:if test="${not empty appt.note}">
                          <p class="small mb-0"><i class="bi bi-chat-text me-1"></i>${appt.note}</p>
                        </c:if>
                      </div>
                      <c:choose>
                        <c:when test="${appt.status == 'PENDING'}">
                          <span class="status-badge status-pending">Đang chờ</span>
                        </c:when>
                        <c:when test="${appt.status == 'CONFIRMED'}">
                          <span class="status-badge status-confirmed">Đã duyệt</span>
                        </c:when>
                        <c:when test="${appt.status == 'CANCELLED'}">
                          <span class="status-badge status-cancelled">Đã hủy</span>
                        </c:when>
                        <c:when test="${appt.status == 'COMPLETED'}">
                          <span class="status-badge status-completed">Đã hoàn thành</span>
                        </c:when>
                        <c:otherwise>
                          <span class="status-badge status-pending">${appt.status != null ? appt.status : 'PENDING'}</span>
                        </c:otherwise>
                      </c:choose>
                    </div>
                    <div class="d-flex gap-2 mt-3">
                      <c:if test="${appt.status == 'PENDING' || appt.status == 'CONFIRMED'}">
                        <form method="post" action="${pageContext.request.contextPath}/donor/schedule/cancel" 
                              style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn hủy lịch hẹn này?');">
                          <input type="hidden" name="appointmentId" value="${appt.appointmentId}">
                          <button type="submit" class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-x-circle me-1"></i>Hủy lịch
                          </button>
                        </form>
                      </c:if>
                    </div>
                  </div>
                </c:forEach>
              </c:when>
              <c:otherwise>
                <div class="text-center py-5 text-muted">
                  <i class="bi bi-calendar-x display-4 d-block mb-3"></i>
                  <p>Bạn chưa có lịch hẹn nào. Hãy đặt lịch mới ở form bên trái.</p>
                </div>
              </c:otherwise>
            </c:choose>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<jsp:include page="/footer.jsp" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

