<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Kiểm tra điều kiện hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:900px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .eligibility-check{display:flex;align-items:center;gap:15px;padding:20px;border-bottom:1px solid var(--bl-border)}
  .eligibility-check:last-child{border-bottom:none}
  .check-icon{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
  .check-icon.pass{background:#dcfce7;color:#16a34a}
  .check-icon.fail{background:#fee2e2;color:#dc2626}
  .check-icon.warning{background:#fef3c7;color:#d97706}
  .result-banner{padding:30px;border-radius:16px;text-align:center;margin-bottom:30px}
  .result-banner.eligible{background:linear-gradient(135deg,#dcfce7 0%,#bbf7d0 100%);border:2px solid #16a34a}
  .result-banner.not-eligible{background:linear-gradient(135deg,#fee2e2 0%,#fecaca 100%);border:2px solid #dc2626}
  .result-banner.partial{background:linear-gradient(135deg,#fef3c7 0%,#fde68a 100%);border:2px solid #d97706}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-2"><i class="bi bi-clipboard2-pulse me-2"></i>Kiểm tra điều kiện hiến máu</h1>
      <p class="mb-0">Kiểm tra xem bạn có đủ điều kiện để hiến máu an toàn</p>
    </div>

    <c:if test="${not empty eligibilityResult}">
      <div class="result-banner ${eligibilityResult.status}">
        <h3 class="mb-3">
          <i class="bi bi-${eligibilityResult.status == 'eligible' ? 'check-circle' : (eligibilityResult.status == 'not-eligible' ? 'x-circle' : 'exclamation-triangle')}-fill me-2"></i>
          ${eligibilityResult.message}
        </h3>
        <c:if test="${not empty eligibilityResult.recommendations}">
          <div class="text-start mt-3">
            <h6>Khuyến nghị:</h6>
            <ul class="mb-0">
              <c:forEach var="rec" items="${eligibilityResult.recommendations}">
                <li>${rec}</li>
              </c:forEach>
            </ul>
          </div>
        </c:if>
      </div>
    </c:if>

    <!-- Form kiểm tra -->
    <div class="card card-soft">
      <div class="card-header bg-white border-bottom">
        <h5 class="mb-0"><i class="bi bi-clipboard-check me-2"></i>Thông tin kiểm tra</h5>
      </div>
      <div class="card-body p-4">
        <form method="post" action="${pageContext.request.contextPath}/donor/eligibility">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Tuổi <span class="text-danger">*</span></label>
              <input type="number" class="form-control" name="age" 
                     value="${age != null ? age : ''}" 
                     min="18" max="65" required>
              <small class="text-muted">Từ 18-65 tuổi</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Cân nặng (kg) <span class="text-danger">*</span></label>
              <input type="number" class="form-control" name="weight" 
                     value="${weight != null ? weight : (profile.weightKg != null ? profile.weightKg : '')}" 
                     step="0.1" min="0" required>
              <small class="text-muted">Tối thiểu 45kg</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Hemoglobin-nồng độ huyết sắc tố (g/dL)</label>
              <input type="number" class="form-control" name="hemoglobin" 
                     value="${hemoglobin != null ? hemoglobin : (profile.lastHbGdl != null ? profile.lastHbGdl : '')}" 
                     step="0.1" min="0">
              <small class="text-muted">Nam: ≥13g/dL, Nữ: ≥12.5g/dL</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Lần hiến máu gần nhất (ngày)</label>
              <input type="number" class="form-control" name="daysSinceLastDonation" 
                     value="${daysSinceLastDonation != null ? daysSinceLastDonation : ''}" 
                     min="0">
              <small class="text-muted">Tối thiểu 56 ngày (8 tuần)</small>
            </div>
            <div class="col-12">
              <label class="form-label">Bạn có đang:</label>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="conditions" value="pregnant" id="pregnant">
                <label class="form-check-label" for="pregnant">Đang mang thai hoặc cho con bú</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="conditions" value="sick" id="sick">
                <label class="form-check-label" for="sick">Đang bị ốm, sốt, hoặc nhiễm trùng</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="conditions" value="medication" id="medication">
                <label class="form-check-label" for="medication">Đang dùng thuốc (kháng sinh, aspirin, v.v.)</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="conditions" value="tattoo" id="tattoo">
                <label class="form-check-label" for="tattoo">Xăm mình trong 12 tháng qua</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="conditions" value="travel" id="travel">
                <label class="form-check-label" for="travel">Đi du lịch đến vùng dịch bệnh gần đây</label>
              </div>
            </div>
            <div class="col-12">
              <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-search me-2"></i>Kiểm tra điều kiện
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>

    <!-- Hướng dẫn -->
    <div class="card card-soft">
      <div class="card-header bg-white border-bottom">
        <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>Điều kiện hiến máu cơ bản</h5>
      </div>
      <div class="card-body p-4">
        <div class="eligibility-check">
          <div class="check-icon pass">
            <i class="bi bi-check-lg"></i>
          </div>
          <div>
            <h6 class="mb-1">Tuổi từ 18-65 tuổi</h6>
            <p class="text-muted small mb-0">Người hiến máu phải đủ 18 tuổi và không quá 65 tuổi</p>
          </div>
        </div>
        <div class="eligibility-check">
          <div class="check-icon pass">
            <i class="bi bi-check-lg"></i>
          </div>
          <div>
            <h6 class="mb-1">Cân nặng tối thiểu 45kg</h6>
            <p class="text-muted small mb-0">Đảm bảo cơ thể đủ khỏe mạnh để hiến máu</p>
          </div>
        </div>
        <div class="eligibility-check">
          <div class="check-icon pass">
            <i class="bi bi-check-lg"></i>
          </div>
          <div>
            <h6 class="mb-1">Hemoglobin đạt chuẩn</h6>
            <p class="text-muted small mb-0">Nam: ≥13g/dL, Nữ: ≥12.5g/dL</p>
          </div>
        </div>
        <div class="eligibility-check">
          <div class="check-icon pass">
            <i class="bi bi-check-lg"></i>
          </div>
          <div>
            <h6 class="mb-1">Khoảng cách giữa các lần hiến</h6>
            <p class="text-muted small mb-0">Tối thiểu 56 ngày (8 tuần) giữa các lần hiến máu</p>
          </div>
        </div>
        <div class="eligibility-check">
          <div class="check-icon warning">
            <i class="bi bi-exclamation-lg"></i>
          </div>
          <div>
            <h6 class="mb-1">Không đang mang thai hoặc cho con bú</h6>
            <p class="text-muted small mb-0">Phụ nữ đang mang thai hoặc cho con bú không nên hiến máu</p>
          </div>
        </div>
        <div class="eligibility-check">
          <div class="check-icon warning">
            <i class="bi bi-exclamation-lg"></i>
          </div>
          <div>
            <h6 class="mb-1">Không đang ốm hoặc dùng thuốc</h6>
            <p class="text-muted small mb-0">Cần khỏe mạnh và không dùng một số loại thuốc trước khi hiến</p>
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex justify-content-start mt-4">
      <a href="${pageContext.request.contextPath}/donor" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Quay lại
      </a>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

