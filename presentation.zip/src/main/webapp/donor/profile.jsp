<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Chỉnh sửa thông tin cá nhân</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:900px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .form-label{font-weight:600;color:var(--bl-dark);margin-bottom:8px}
  .form-control:focus{border-color:var(--bl-red);box-shadow:0 0 0 0.2rem rgba(225,29,72,.25)}
  .btn-primary{background:var(--bl-red);border-color:var(--bl-red)}
  .btn-primary:hover{background:#c21845;border-color:#c21845}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-2"><i class="bi bi-person-gear me-2"></i>Chỉnh sửa thông tin cá nhân</h1>
      <p class="mb-0">Cập nhật thông tin hồ sơ của bạn</p>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/donor/profile">
      <div class="card card-soft">
        <div class="card-header bg-white border-bottom">
          <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>Thông tin cơ bản</h5>
        </div>
        <div class="card-body p-4">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Họ và tên <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="fullName" 
                     value="${donor.fullName != null ? donor.fullName : ''}" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" 
                     value="${authUser.email}" disabled>
              <small class="text-muted">Email không thể thay đổi</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Ngày sinh</label>
              <input type="date" class="form-control" name="dob" 
                     value="${donor.dob != null ? donor.dob : ''}">
            </div>
            <div class="col-md-6">
              <label class="form-label">Giới tính</label>
              <select class="form-select" name="gender">
                <option value="">Chọn giới tính</option>
                <option value="male" ${donor.gender == 'male' ? 'selected' : ''}>Nam</option>
                <option value="female" ${donor.gender == 'female' ? 'selected' : ''}>Nữ</option>
                <option value="other" ${donor.gender == 'other' ? 'selected' : ''}>Khác</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Nhóm máu <span class="text-danger">*</span></label>
              <select class="form-select" name="bloodGroup" required>
                <option value="">Chọn nhóm máu</option>
                <option value="A+" ${donor.bloodGroup == 'A+' ? 'selected' : ''}>A+</option>
                <option value="A-" ${donor.bloodGroup == 'A-' ? 'selected' : ''}>A-</option>
                <option value="B+" ${donor.bloodGroup == 'B+' ? 'selected' : ''}>B+</option>
                <option value="B-" ${donor.bloodGroup == 'B-' ? 'selected' : ''}>B-</option>
                <option value="AB+" ${donor.bloodGroup == 'AB+' ? 'selected' : ''}>AB+</option>
                <option value="AB-" ${donor.bloodGroup == 'AB-' ? 'selected' : ''}>AB-</option>
                <option value="O+" ${donor.bloodGroup == 'O+' ? 'selected' : ''}>O+</option>
                <option value="O-" ${donor.bloodGroup == 'O-' ? 'selected' : ''}>O-</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Số điện thoại</label>
              <input type="tel" class="form-control" name="phone" 
                     value="${donor.phone != null ? donor.phone : ''}" 
                     placeholder="0912345678">
            </div>
            <div class="col-12">
              <label class="form-label">Địa chỉ</label>
              <textarea class="form-control" name="address" rows="2" 
                        placeholder="Nhập địa chỉ của bạn">${donor.address != null ? donor.address : ''}</textarea>
            </div>
          </div>
        </div>
      </div>

      <div class="card card-soft">
        <div class="card-header bg-white border-bottom">
          <h5 class="mb-0"><i class="bi bi-heart-pulse me-2"></i>Thông tin sức khỏe (Tùy chọn)</h5>
        </div>
        <div class="card-body p-4">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label">Chiều cao (cm)</label>
              <input type="number" class="form-control" name="heightCm" 
                     value="${profile.heightCm != null ? profile.heightCm : ''}" 
                     step="0.01" min="0" placeholder="170">
            </div>
            <div class="col-md-4">
              <label class="form-label">Cân nặng (kg)</label>
              <input type="number" class="form-control" name="weightKg" 
                     value="${profile.weightKg != null ? profile.weightKg : ''}" 
                     step="0.01" min="0" placeholder="65">
            </div>
            <div class="col-md-4">
              <label class="form-label">Hemoglobin (g/dL)</label>
              <input type="number" class="form-control" name="lastHbGdl" 
                     value="${profile.lastHbGdl != null ? profile.lastHbGdl : ''}" 
                     step="0.1" min="0" placeholder="14.5">
            </div>
            <div class="col-12">
              <label class="form-label">Bệnh mãn tính</label>
              <textarea class="form-control" name="chronicCond" rows="2" 
                        placeholder="Vui lòng liệt kê các bệnh mãn tính (nếu có)">${profile.chronicCond != null ? profile.chronicCond : ''}</textarea>
            </div>
            <div class="col-12">
              <label class="form-label">Dị ứng</label>
              <textarea class="form-control" name="allergies" rows="2" 
                        placeholder="Vui lòng liệt kê các dị ứng (nếu có)">${profile.allergies != null ? profile.allergies : ''}</textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Lần khám sàng lọc cuối</label>
              <input type="date" class="form-control" name="lastScreen" 
                     value="${profile.lastScreen != null ? profile.lastScreen : ''}">
            </div>
          </div>
        </div>
      </div>

      <div class="d-flex justify-content-between gap-3">
        <a href="${pageContext.request.contextPath}/donor" class="btn btn-outline-secondary">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-check-circle me-2"></i>Lưu thay đổi
        </button>
      </div>
    </form>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

