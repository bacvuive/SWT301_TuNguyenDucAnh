<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Bảng điều khiển Người hiến</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .dashboard-section{padding:40px 0}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}

  /* Dashboard Layout */
  .dashboard-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .dashboard-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .dashboard-header h1{font-weight:800;margin-bottom:8px}
  .dashboard-header p{opacity:.9;margin-bottom:0}

  /* Stats Grid */
  .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:30px}
  .stat-card{background:#fff;border-radius:16px;padding:24px;text-align:center;border:1px solid var(--bl-border);transition:transform .2s ease,box-shadow .2s ease}
  .stat-card:hover{transform:translateY(-4px);box-shadow:0 20px 40px rgba(2,8,23,.1)}
  .stat-card .icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:20px}
  .stat-card .icon.danger{background:#fee2e2;color:#dc2626}
  .stat-card .icon.success{background:#dcfce7;color:#16a34a}
  .stat-card .icon.warning{background:#fef3c7;color:#d97706}
  .stat-card .icon.info{background:#dbeafe;color:#2563eb}
  .stat-card h3{font-weight:800;margin-bottom:4px;color:var(--bl-dark)}
  .stat-card p{margin:0;color:var(--bl-muted);font-size:14px}

  /* Quick Actions */
  .quick-actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-bottom:30px}
  .action-card{background:#fff;border-radius:16px;padding:24px;border:1px solid var(--bl-border);transition:all .2s ease}
  .action-card:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(2,8,23,.08)}
  .action-card .icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;font-size:18px}
  .action-card .icon.danger{background:#fee2e2;color:#dc2626}
  .action-card .icon.warning{background:#fef3c7;color:#d97706}
  .action-card .icon.info{background:#dbeafe;color:#2563eb}
  .action-card h5{font-weight:700;margin-bottom:8px;color:var(--bl-dark)}
  .action-card p{margin-bottom:16px;color:var(--bl-muted);font-size:14px}
  .action-card .btn{width:100%;border-radius:10px;font-weight:600}

  /* Recent Activity */
  .activity-card{background:#fff;border-radius:16px;padding:24px;border:1px solid var(--bl-border)}
  .activity-item{display:flex;align-items:center;gap:16px;padding:12px 0;border-bottom:1px solid #f1f5f9}
  .activity-item:last-child{border-bottom:none}
  .activity-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px}
  .activity-icon.success{background:#dcfce7;color:#16a34a}
  .activity-icon.warning{background:#fef3c7;color:#d97706}
  .activity-icon.info{background:#dbeafe;color:#2563eb}
  .activity-content{flex:1}
  .activity-content h6{margin:0;font-weight:600;color:var(--bl-dark)}
  .activity-content p{margin:0;color:var(--bl-muted);font-size:13px}
  .activity-time{color:var(--bl-muted);font-size:12px}

  /* Responsive */
  @media (max-width:768px){
    .dashboard-header{padding:20px;margin-bottom:20px}
    .stats-grid{grid-template-columns:repeat(2,1fr);gap:15px}
    .quick-actions{grid-template-columns:1fr;gap:15px}
  }
</style>

<div class="dashboard-section">
  <div class="dashboard-container">

    <!-- Dashboard Header -->
    <div class="dashboard-header">
      <h1>Xin chào, <c:out value="${sessionScope.donor != null and not empty sessionScope.donor.fullName ? sessionScope.donor.fullName : (sessionScope.authUser != null ? sessionScope.authUser.email : 'Người hiến')}"/></h1>
      <p>Chào mừng bạn đến với bảng điều khiển người hiến máu. Theo dõi hoạt động và quản lý lịch hiến của bạn.</p>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon danger">
          <i class="bi bi-heart-fill"></i>
        </div>
        <h3>${donationCount != null ? donationCount : 0}</h3>
        <p>Lần hiến máu</p>
      </div>
      <div class="stat-card">
        <div class="icon success">
          <i class="bi bi-people-fill"></i>
        </div>
        <h3>${peopleHelped != null ? peopleHelped : 0}</h3>
        <p>Người được giúp</p>
      </div>
      <div class="stat-card">
        <div class="icon warning">
          <i class="bi bi-droplet-fill"></i>
        </div>
        <h3>${donor.bloodGroup != null ? donor.bloodGroup : '—'}</h3>
        <p>Nhóm máu</p>
      </div>
      <div class="stat-card">
        <div class="icon info">
          <i class="bi bi-calendar-check-fill"></i>
        </div>
        <h3>${nextAppointmentDate != null ? nextAppointmentDate : '—'}</h3>
        <p>Lịch sắp tới</p>
      </div>
      <div class="stat-card">
        <div class="icon warning">
          <i class="bi bi-bell-fill"></i>
        </div>
        <h3>${notifications != null ? notifications.size() : 0}</h3>
        <p>Thông báo mới</p>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
      <div class="action-card">
        <div class="icon danger">
          <i class="bi bi-calendar-plus"></i>
        </div>
        <h5>Đặt lịch hiến máu</h5>
        <p>Đặt lịch hiến máu tại trung tâm gần nhất và theo dõi lịch trình của bạn.</p>
        <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-danger">Đặt lịch</a>
      </div>

      <div class="action-card">
        <div class="icon warning">
          <i class="bi bi-clipboard2-pulse"></i>
        </div>
        <h5>Kiểm tra điều kiện</h5>
        <p>Kiểm tra xem bạn có đủ điều kiện để hiến máu an toàn hay không.</p>
        <a href="${pageContext.request.contextPath}/donor/eligibility" class="btn btn-warning">Kiểm tra</a>
      </div>

      <div class="action-card">
        <div class="icon info">
          <i class="bi bi-exclamation-triangle"></i>
        </div>
        <h5>Ca cần khẩn cấp</h5>
        <p>Xem các yêu cầu máu khẩn cấp gần bạn và tham gia cứu trợ.</p>
        <a href="${pageContext.request.contextPath}/requests" class="btn btn-info">Xem ca khẩn</a>
      </div>
    </div>

    <!-- Notifications Section -->
    <c:if test="${not empty notifications}">
      <div class="row mb-4">
        <div class="col-12">
          <div class="activity-card">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h5 class="mb-0"><i class="bi bi-bell-fill me-2"></i>Thông báo mới</h5>
              <a href="${pageContext.request.contextPath}/notifications" class="btn btn-sm btn-outline-secondary">Xem tất cả</a>
            </div>
            
            <c:forEach var="notif" items="${notifications}" varStatus="status" begin="0" end="4">
              <c:set var="isRead" value="${notif.isRead}" />
              <c:set var="notifType" value="${notif.type}" />
              <c:set var="notifLink" value="${notif.link}" />
              <c:set var="notifSubject" value="${notif.subject}" />
              <c:set var="notifMessage" value="${notif.message}" />
              <c:set var="notifCreatedAt" value="${notif.createdAt}" />
              
              <div class="activity-item ${not isRead ? 'bg-light' : ''}">
                <div class="activity-icon ${notifType == 'APPOINTMENT_CONFIRMED' ? 'success' : (notifType == 'APPOINTMENT_CANCELLED' ? 'warning' : (notifType == 'DONATION_COMPLETED' ? 'success' : (notifType == 'REQUEST_ACCEPTED' ? 'success' : (notifType == 'REQUEST_REJECTED' ? 'warning' : 'info'))))}">
                  <c:choose>
                    <c:when test="${notifType == 'APPOINTMENT_CONFIRMED'}">
                      <i class="bi bi-check-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'APPOINTMENT_CANCELLED'}">
                      <i class="bi bi-x-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'REQUEST_ACCEPTED'}">
                      <i class="bi bi-check-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'REQUEST_REJECTED'}">
                      <i class="bi bi-x-circle-fill"></i>
                    </c:when>
                    <c:when test="${notifType == 'DONATION_COMPLETED'}">
                      <i class="bi bi-heart-fill"></i>
                    </c:when>
                    <c:otherwise>
                      <i class="bi bi-info-circle-fill"></i>
                    </c:otherwise>
                  </c:choose>
                </div>
                <div class="activity-content">
                  <h6>
                    <c:choose>
                      <c:when test="${not empty notifLink}">
                        <a href="${pageContext.request.contextPath}${notifLink}" class="text-decoration-none text-dark">
                          ${fn:escapeXml(not empty notifSubject ? notifSubject : 'Thông báo')}
                          <c:if test="${not isRead}">
                            <span class="badge bg-danger rounded-pill ms-2" style="font-size: 0.6em;">Mới</span>
                          </c:if>
                        </a>
                      </c:when>
                      <c:otherwise>
                        ${fn:escapeXml(not empty notifSubject ? notifSubject : 'Thông báo')}
                        <c:if test="${not isRead}">
                          <span class="badge bg-danger rounded-pill ms-2" style="font-size: 0.6em;">Mới</span>
                        </c:if>
                      </c:otherwise>
                    </c:choose>
                  </h6>
                  <p class="mb-0">${fn:escapeXml(notifMessage)}</p>
                </div>
                <div class="activity-time">
                  <c:if test="${notifCreatedAt != null}">
                    <fmt:formatDate value="${notifCreatedAt}" type="both" dateStyle="short" timeStyle="short" />
                  </c:if>
                </div>
              </div>
              <c:if test="${!status.last and status.count < 5}">
                <div class="border-bottom"></div>
              </c:if>
            </c:forEach>
            
            <c:if test="${notifications.size() > 5}">
              <div class="text-center mt-3">
                <a href="${pageContext.request.contextPath}/notifications" class="btn btn-outline-secondary btn-sm">Xem thêm ${notifications.size() - 5} thông báo</a>
              </div>
            </c:if>
          </div>
        </div>
      </div>
    </c:if>

    <!-- Recent Activity & Upcoming -->
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="activity-card">
          <h5 class="mb-3"><i class="bi bi-clock-history me-2"></i>Hoạt động gần đây</h5>

          <div class="activity-item">
            <div class="activity-icon success">
              <i class="bi bi-check-circle-fill"></i>
            </div>
            <div class="activity-content">
              <h6>Hiến máu thành công</h6>
              <p>Bệnh viện Chợ Rẫy - 450ml</p>
            </div>
            <div class="activity-time">2 ngày trước</div>
          </div>

          <div class="activity-item">
            <div class="activity-icon info">
              <i class="bi bi-calendar-check"></i>
            </div>
            <div class="activity-content">
              <h6>Đặt lịch hiến máu</h6>
              <p>Trung tâm Hiến máu Đà Nẵng</p>
            </div>
            <div class="activity-time">1 tuần trước</div>
          </div>

          <div class="activity-item">
            <div class="activity-icon warning">
              <i class="bi bi-exclamation-triangle"></i>
            </div>
            <div class="activity-content">
              <h6>Tham gia ca khẩn cấp</h6>
              <p>Bệnh viện Đa khoa Quảng Nam</p>
            </div>
            <div class="activity-time">2 tuần trước</div>
          </div>

          <div class="text-center mt-3">
            <a href="${pageContext.request.contextPath}/donor/history" class="btn btn-outline-secondary btn-sm">Xem tất cả</a>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="activity-card">
          <h5 class="mb-3"><i class="bi bi-calendar-event me-2"></i>Lịch sắp tới</h5>

          <div class="activity-item">
            <div class="activity-icon info">
              <i class="bi bi-calendar-date"></i>
            </div>
            <div class="activity-content">
              <h6>Lịch hiến máu định kỳ</h6>
              <p>Trung tâm Hiến máu Đà Nẵng - 24/12/2024</p>
            </div>
            <div class="activity-time">3 ngày</div>
          </div>

          <div class="activity-item">
            <div class="activity-icon warning">
              <i class="bi bi-clipboard2-check"></i>
            </div>
            <div class="activity-content">
              <h6>Kiểm tra sức khỏe</h6>
              <p>Khám sàng lọc trước khi hiến</p>
            </div>
            <div class="activity-time">23/12/2024</div>
          </div>

          <div class="activity-item">
            <div class="activity-icon success">
              <i class="bi bi-award"></i>
            </div>
            <div class="activity-content">
              <h6>Nhận chứng nhận</h6>
              <p>Chứng nhận hiến máu lần thứ 3</p>
            </div>
            <div class="activity-time">Sau khi hiến</div>
          </div>

          <div class="text-center mt-3">
            <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-outline-secondary btn-sm">Quản lý lịch</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Health Tips -->
    <div class="row mt-4">
      <div class="col-12">
        <div class="card card-soft">
          <div class="card-body">
            <h5 class="mb-3"><i class="bi bi-lightbulb me-2"></i>Mẹo sức khỏe cho người hiến máu</h5>
            <div class="row g-3">
              <div class="col-md-4">
                <div class="d-flex align-items-start gap-3">
                  <div class="text-success fs-4"><i class="bi bi-droplet"></i></div>
                  <div>
                    <h6 class="mb-1">Uống đủ nước</h6>
                    <p class="text-muted small mb-0">Uống ít nhất 2-3 lít nước trước khi hiến máu để đảm bảo cơ thể đủ nước.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="d-flex align-items-start gap-3">
                  <div class="text-warning fs-4"><i class="bi bi-apple"></i></div>
                  <div>
                    <h6 class="mb-1">Ăn uống đầy đủ</h6>
                    <p class="text-muted small mb-0">Ăn bữa sáng đầy đủ và tránh thức ăn nhiều chất béo trước khi hiến.</p>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="d-flex align-items-start gap-3">
                  <div class="text-info fs-4"><i class="bi bi-moon"></i></div>
                  <div>
                    <h6 class="mb-1">Nghỉ ngơi đủ</h6>
                    <p class="text-muted small mb-0">Ngủ đủ 7-8 tiếng đêm trước để cơ thể khỏe mạnh.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<%@ include file="/footer.jsp" %>
</body>
</html>


