<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Chứng nhận hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1200px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  
  /* Certificate Card Styles */
  .certificate-card{
    border:3px solid #10b981;
    border-radius:20px;
    padding:40px;
    margin-bottom:30px;
    background:linear-gradient(135deg,#f0fdf4 0%,#fff 50%,#fff 100%);
    box-shadow:0 15px 35px rgba(16,185,129,.15);
    position:relative;
    overflow:hidden;
    transition:transform .3s ease,box-shadow .3s ease;
  }
  .certificate-card:hover{
    transform:translateY(-5px);
    box-shadow:0 20px 45px rgba(16,185,129,.25);
  }
  .certificate-card::before{
    content:'';
    position:absolute;
    top:0;
    left:0;
    right:0;
    height:5px;
    background:linear-gradient(90deg,#10b981 0%,#059669 50%,#10b981 100%);
  }
  
  .certificate-header{
    text-align:center;
    border-bottom:3px solid #10b981;
    padding-bottom:25px;
    margin-bottom:30px;
    position:relative;
  }
  .certificate-header::after{
    content:'';
    position:absolute;
    bottom:-3px;
    left:50%;
    transform:translateX(-50%);
    width:60px;
    height:3px;
    background:#10b981;
    border-radius:2px;
  }
  .certificate-header h3{
    font-size:2rem;
    font-weight:800;
    color:#10b981;
    margin-bottom:10px;
    text-shadow:0 2px 4px rgba(16,185,129,.1);
  }
  .certificate-header .trophy-icon{
    font-size:3rem;
    color:#10b981;
    margin-bottom:15px;
    display:block;
    animation:pulse 2s ease-in-out infinite;
  }
  @keyframes pulse{
    0%,100%{transform:scale(1);opacity:1}
    50%{transform:scale(1.05);opacity:.9}
  }
  
  .certificate-body{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:25px;
    margin-bottom:30px;
  }
  .certificate-item{
    padding:15px 20px;
    background:#fff;
    border-radius:12px;
    border-left:4px solid #10b981;
    transition:all .2s ease;
  }
  .certificate-item:hover{
    box-shadow:0 4px 12px rgba(16,185,129,.1);
    transform:translateX(5px);
  }
  .certificate-item strong{
    display:block;
    color:#059669;
    margin-bottom:8px;
    font-size:0.85rem;
    text-transform:uppercase;
    letter-spacing:0.5px;
    font-weight:700;
  }
  .certificate-item span{
    color:#0b1220;
    font-size:1.1rem;
    font-weight:600;
  }
  .certificate-item .value{
    color:#0b1220;
    font-size:1.1rem;
    font-weight:600;
    display:flex;
    align-items:center;
    gap:8px;
  }
  
  .certificate-footer{
    text-align:center;
    margin-top:30px;
    padding-top:25px;
    border-top:2px dashed #cbd5e1;
  }
  .certificate-message{
    background:linear-gradient(135deg,#dcfce7 0%,#bbf7d0 100%);
    border-left:4px solid #10b981;
    border-radius:12px;
    padding:20px;
    margin-bottom:25px;
    text-align:center;
  }
  .certificate-message h5{
    color:#059669;
    font-weight:700;
    margin-bottom:8px;
    font-size:1.2rem;
  }
  .certificate-message p{
    color:#047857;
    margin:0;
    font-size:0.95rem;
  }
  
  .certificate-actions{
    display:flex;
    gap:15px;
    justify-content:center;
    flex-wrap:wrap;
  }
  .btn-certificate{
    padding:12px 30px;
    border-radius:10px;
    font-weight:600;
    text-transform:uppercase;
    letter-spacing:0.5px;
    transition:all .3s ease;
    display:inline-flex;
    align-items:center;
    gap:8px;
  }
  .btn-certificate:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 20px rgba(16,185,129,.3);
  }
  
  /* Responsive */
  @media (max-width:768px){
    .certificate-card{padding:25px}
    .certificate-header h3{font-size:1.5rem}
    .certificate-body{grid-template-columns:1fr;gap:15px}
    .certificate-item{padding:12px 15px}
    .certificate-actions{flex-direction:column}
    .btn-certificate{width:100%}
  }
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-2"><i class="bi bi-award me-2"></i>Chứng nhận hiến máu</h1>
      <p class="mb-0">Xem và tải các chứng nhận hiến máu của bạn</p>
      <c:if test="${not empty certificates && certificates.size() > 0}">
        <div class="mt-3">
          <span class="badge bg-light text-dark px-3 py-2" style="font-size: 1rem;">
            <i class="bi bi-trophy-fill me-2"></i>Tổng số: ${certificates.size()} chứng nhận
          </span>
        </div>
      </c:if>
    </div>

    <c:choose>
      <c:when test="${not empty certificates && certificates.size() > 0}">
        <c:forEach var="cert" items="${certificates}" varStatus="status">
          <div class="certificate-card">
            <div class="certificate-header">
              <i class="bi bi-trophy-fill trophy-icon"></i>
              <h3>Chứng nhận hiến máu thành công</h3>
              <p class="text-muted mb-0">
                <i class="bi bi-award me-1"></i>BloodLink - Hệ thống quản lý hiến máu
                <c:if test="${certificates.size() > 1}">
                  <span class="badge bg-success ms-2">Lần thứ ${status.count}</span>
                </c:if>
              </p>
            </div>
            
            <div class="certificate-message">
              <h5><i class="bi bi-heart-fill me-2"></i>Cảm ơn bạn đã hiến máu!</h5>
              <p>Mỗi đơn vị máu của bạn có thể cứu sống tới 3 người bệnh. Hành động của bạn thật đáng quý!</p>
            </div>
            
            <div class="certificate-body">
              <div class="certificate-item">
                <strong><i class="bi bi-person-fill me-1"></i>Người hiến máu</strong>
                <span class="value">${cert.donorName}</span>
              </div>
              <div class="certificate-item">
                <strong><i class="bi bi-droplet-fill me-1"></i>Nhóm máu</strong>
                <span class="value">
                  <span class="badge bg-danger">${cert.bloodGroup != null ? cert.bloodGroup : 'N/A'}</span>
                </span>
              </div>
              <div class="certificate-item">
                <strong><i class="bi bi-calendar-check-fill me-1"></i>Ngày hiến máu</strong>
                <span class="value">
                  <fmt:formatDate value="${cert.donationDate}" pattern="dd/MM/yyyy"/>
                </span>
              </div>
              <div class="certificate-item">
                <strong><i class="bi bi-heart-pulse-fill me-1"></i>Lượng máu</strong>
                <span class="value">
                  <span class="badge bg-success" style="font-size: 1rem; padding: 6px 12px;">
                    ${cert.quantityMl != null ? cert.quantityMl : 0}ml
                  </span>
                </span>
              </div>
              <div class="certificate-item">
                <strong><i class="bi bi-hospital-fill me-1"></i>Bệnh viện</strong>
                <span class="value">${cert.hospitalName}</span>
              </div>
              <div class="certificate-item">
                <strong><i class="bi bi-check-circle-fill me-1"></i>Trạng thái</strong>
                <span class="value">
                  <c:choose>
                    <c:when test="${cert.status == 'COMPLETED'}">
                      <span class="badge bg-success" style="font-size: 1rem; padding: 6px 12px;">
                        <i class="bi bi-check-circle me-1"></i>Đã hoàn thành
                      </span>
                    </c:when>
                    <c:when test="${cert.status == 'CONFIRMED'}">
                      <span class="badge bg-info" style="font-size: 1rem; padding: 6px 12px;">
                        <i class="bi bi-check-circle me-1"></i>Đã xác nhận
                      </span>
                    </c:when>
                    <c:otherwise>
                      <span class="badge bg-secondary" style="font-size: 1rem; padding: 6px 12px;">
                        ${cert.status != null ? cert.status : 'N/A'}
                      </span>
                    </c:otherwise>
                  </c:choose>
                </span>
              </div>
            </div>
            
            <div class="certificate-footer">
              <div class="certificate-actions">
                <c:choose>
                  <c:when test="${not empty cert.certificateUrl}">
                    <a href="${cert.certificateUrl}" target="_blank" class="btn btn-certificate btn-success">
                      <i class="bi bi-download"></i>
                      <span>Tải chứng nhận PDF</span>
                    </a>
                    <a href="${cert.certificateUrl}" target="_blank" class="btn btn-certificate btn-outline-success">
                      <i class="bi bi-eye"></i>
                      <span>Xem trực tuyến</span>
                    </a>
                  </c:when>
                  <c:otherwise>
                    <div class="alert alert-info mb-0" style="width: 100%;">
                      <i class="bi bi-info-circle me-2"></i>
                      <strong>Chứng nhận đang được xử lý</strong>
                      <p class="mb-0 small mt-1">Chứng nhận của bạn sẽ sẵn sàng trong thời gian sớm nhất. Vui lòng quay lại sau.</p>
                    </div>
                  </c:otherwise>
                </c:choose>
              </div>
            </div>
          </div>
        </c:forEach>
      </c:when>
      <c:otherwise>
        <div class="card card-soft">
          <div class="card-body text-center py-5">
            <i class="bi bi-award display-1 text-muted d-block mb-3" style="color: #cbd5e1 !important;"></i>
            <h4 class="mb-3" style="color: #64748b;">Bạn chưa có chứng nhận hiến máu nào</h4>
            <p class="text-muted mb-4">
              Sau mỗi lần hiến máu thành công (trạng thái "Đã hoàn thành"), bạn sẽ nhận được chứng nhận tại đây.
            </p>
            <div class="d-flex gap-3 justify-content-center flex-wrap">
              <a href="${pageContext.request.contextPath}/donor/history" class="btn btn-primary">
                <i class="bi bi-clock-history me-2"></i>Xem lịch sử hiến máu
              </a>
              <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-outline-danger">
                <i class="bi bi-calendar-plus me-2"></i>Đặt lịch hiến máu
              </a>
            </div>
          </div>
        </div>
      </c:otherwise>
    </c:choose>

    <div class="d-flex justify-content-start mt-4">
      <a href="${pageContext.request.contextPath}/donor" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Quay lại
      </a>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

