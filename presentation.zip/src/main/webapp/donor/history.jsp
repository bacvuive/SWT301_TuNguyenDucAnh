<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" 
         isELIgnored="false" buffer="8kb" autoFlush="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Lịch sử hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<jsp:include page="/header.jsp" />

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1200px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .donation-card{border-left:4px solid var(--bl-red);padding:20px;margin-bottom:15px;transition:transform .2s;background:#fff;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.05)}
  .donation-card:hover{transform:translateX(5px);box-shadow:0 4px 12px rgba(0,0,0,.1)}
  .donation-card.completed{border-left:4px solid #10b981;background:linear-gradient(to right,#f0fdf4 0%,#fff 15%)}
  .donation-card.completed:hover{box-shadow:0 4px 16px rgba(16,185,129,.2)}
  .donation-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-right:16px;flex-shrink:0}
  .donation-icon.completed{background:linear-gradient(135deg,#10b981 0%,#059669 100%);color:#fff}
  .donation-icon.pending{background:#fef3c7;color:#d97706}
  .donation-icon.cancelled{background:#fee2e2;color:#dc2626}
  .donation-info h6{font-weight:700;color:#0b1220;margin-bottom:8px;font-size:1.1rem}
  .donation-info .donation-meta{display:flex;flex-wrap:wrap;gap:16px;margin-top:12px}
  .donation-meta-item{display:flex;align-items:center;gap:6px;color:#64748b;font-size:0.9rem}
  .donation-meta-item i{color:#e11d48;font-size:1rem}
  .donation-meta-item.completed i{color:#10b981}
  .status-badge{padding:6px 14px;border-radius:999px;font-size:0.75rem;font-weight:600;text-transform:uppercase;letter-spacing:0.5px}
  .status-confirmed{background:#d1fae5;color:#059669}
  .status-pending{background:#fef3c7;color:#d97706}
  .status-cancelled{background:#fee2e2;color:#dc2626}
  .status-completed{background:#d1fae5;color:#059669;font-weight:700}
  .status-rejected{background:#fee2e2;color:#dc2626}
  .certificate-link{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;background:#e0e7ff;color:#4338ca;border-radius:8px;text-decoration:none;font-weight:600;font-size:0.85rem;transition:all .2s}
  .certificate-link:hover{background:#c7d2fe;color:#3730a3;transform:translateY(-1px);box-shadow:0 2px 8px rgba(67,56,202,.2)}
  .certificate-link.completed{background:#dcfce7;color:#059669}
  .certificate-link.completed:hover{background:#bbf7d0;color:#047857}
  .quantity-badge{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;background:#fee2e2;color:#dc2626;border-radius:6px;font-weight:600;font-size:0.85rem}
  .quantity-badge.completed{background:#dcfce7;color:#059669}
  .stat-box{text-align:center;padding:20px;background:#fff;border-radius:12px;border:1px solid var(--bl-border)}
  .stat-box h3{margin:0;font-weight:800;color:var(--bl-red)}
  .stat-box p{margin:5px 0 0;color:var(--bl-muted);font-size:0.9rem}
  .appointment-card{border-left:4px solid #f59e0b;padding:20px;margin-bottom:15px;transition:transform .2s}
  .appointment-card:hover{transform:translateX(5px)}
  .appointment-card.pending{border-left-color:#f59e0b}
  .appointment-card.confirmed{border-left-color:#10b981}
  .appointment-card.cancelled{border-left-color:#ef4444}
  .appointment-card.completed{border-left-color:#6366f1}
  
  /* Responsive */
  @media (max-width: 768px) {
    .donation-card{padding:16px}
    .donation-icon{width:40px;height:40px;font-size:20px;margin-right:12px}
    .donation-info h6{font-size:1rem}
    .donation-meta{flex-direction:column;gap:12px}
    .donation-meta-item{font-size:0.85rem}
    .status-badge{font-size:0.7rem;padding:4px 10px}
    .stat-box{padding:16px}
    .stat-box h3{font-size:1.5rem}
  }
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-2"><i class="bi bi-clock-history me-2"></i>Lịch sử hiến máu</h1>
      <p class="mb-0">Xem lại tất cả các lần hiến máu của bạn</p>
    </div>

    <!-- Thống kê -->
    <div class="row g-3 mb-4">
      <div class="col-md-3">
        <div class="stat-box">
          <h3>${donationCount != null ? donationCount : 0}</h3>
          <p>Tổng số lần hiến</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="stat-box">
          <h3>${totalQuantity != null ? totalQuantity : 0}ml</h3>
          <p>Tổng lượng máu</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="stat-box">
          <h3>${donor.bloodGroup != null ? donor.bloodGroup : 'N/A'}</h3>
          <p>Nhóm máu</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="stat-box">
          <h3>${lastDonationDate != null ? lastDonationDate : 'Chưa có'}</h3>
          <p>Lần hiến gần nhất</p>
        </div>
      </div>
    </div>

    <c:if test="${param.success == 'appointment_created'}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>Đã đặt lịch hiến máu thành công! Dữ liệu đang được tải...
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Danh sách đăng ký hiến máu (Appointments) -->
    <div class="card card-soft mb-4">
      <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-calendar-check me-2"></i>Đăng ký hiến máu</h5>
      </div>
      <div class="card-body p-4">
        <c:choose>
          <c:when test="${not empty appointments && appointments.size() > 0}">
            <c:forEach var="appt" items="${appointments}">
              <c:set var="statusLower" value="${appt.status != null ? appt.status.toLowerCase() : 'pending'}" />
              <div class="appointment-card ${statusLower}">
                <div class="d-flex justify-content-between align-items-start mb-2">
                  <div class="flex-grow-1">
                    <h6 class="mb-2">
                      <i class="bi bi-hospital me-2"></i>${appt.hospitalName != null ? appt.hospitalName : 'Không xác định'}
                    </h6>
                    <div class="row g-3 text-muted small mb-2">
                      <div class="col-md-4">
                        <i class="bi bi-calendar me-1"></i>
                        <strong>Ngày hẹn:</strong>
                        <c:choose>
                          <c:when test="${not empty appt.scheduledAt}">
                            <fmt:formatDate value="${appt.scheduledAt}" pattern="dd/MM/yyyy HH:mm"/>
                          </c:when>
                          <c:otherwise>
                            <span class="text-muted">Chưa cập nhật</span>
                          </c:otherwise>
                        </c:choose>
                      </div>
                      <div class="col-md-4">
                        <i class="bi bi-clock me-1"></i>
                        <strong>Đăng ký:</strong>
                        <c:choose>
                          <c:when test="${not empty appt.createdAt}">
                            <fmt:formatDate value="${appt.createdAt}" pattern="dd/MM/yyyy HH:mm"/>
                          </c:when>
                          <c:otherwise>
                            <span class="text-muted">N/A</span>
                          </c:otherwise>
                        </c:choose>
                      </div>
                      <c:if test="${not empty appt.note}">
                        <div class="col-md-4">
                          <i class="bi bi-chat-text me-1"></i>
                          <strong>Ghi chú:</strong> ${appt.note}
                        </div>
                      </c:if>
                    </div>
                    <div class="mt-2">
                      <small class="text-muted">
                        <i class="bi bi-info-circle me-1"></i>
                        Mã đăng ký: #${appt.appointmentId != null ? appt.appointmentId : 'N/A'}
                      </small>
                    </div>
                  </div>
                  <div class="ms-3">
                    <c:choose>
                      <c:when test="${appt.status == 'PENDING'}">
                        <span class="status-badge status-pending">Đang chờ</span>
                      </c:when>
                      <c:when test="${appt.status == 'CONFIRMED'}">
                        <span class="status-badge status-confirmed">Đã duyệt</span>
                      </c:when>
                      <c:when test="${appt.status == 'CANCELLED'}">
                        <span class="status-badge status-cancelled">Đã hủy</span>
                      </c:when>
                      <c:when test="${appt.status == 'COMPLETED'}">
                        <span class="status-badge status-completed">Đã hoàn thành</span>
                      </c:when>
                      <c:otherwise>
                        <span class="status-badge status-pending">${appt.status != null ? appt.status : 'PENDING'}</span>
                      </c:otherwise>
                    </c:choose>
                  </div>
                </div>
              </div>
            </c:forEach>
          </c:when>
          <c:otherwise>
            <div class="text-center py-4 text-muted">
              <i class="bi bi-calendar-x display-6 d-block mb-2"></i>
              <p>Bạn chưa có đăng ký hiến máu nào.</p>
              <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-primary btn-sm mt-2">
                <i class="bi bi-calendar-plus me-2"></i>Đặt lịch hiến máu ngay
              </a>
            </div>
          </c:otherwise>
        </c:choose>
      </div>
    </div>

    <!-- Danh sách lịch sử hiến máu (Donations) -->
    <div class="card card-soft">
      <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Lịch sử hiến máu</h5>
        <span class="badge bg-danger rounded-pill">${donationCount != null ? donationCount : 0} lần</span>
      </div>
      <div class="card-body p-4">
        <c:choose>
          <c:when test="${not empty donations && donations.size() > 0}">
            <c:forEach var="donation" items="${donations}">
              <c:set var="statusLower" value="${donation.status != null ? donation.status.toLowerCase() : 'pending'}" />
              <c:set var="isCompleted" value="${statusLower == 'completed'}" />
              <div class="donation-card ${isCompleted ? 'completed' : ''}">
                <div class="d-flex align-items-start">
                  <!-- Icon -->
                  <div class="donation-icon ${statusLower}">
                    <c:choose>
                      <c:when test="${isCompleted}">
                        <i class="bi bi-check-circle-fill"></i>
                      </c:when>
                      <c:when test="${statusLower == 'pending'}">
                        <i class="bi bi-clock-fill"></i>
                      </c:when>
                      <c:when test="${statusLower == 'cancelled'}">
                        <i class="bi bi-x-circle-fill"></i>
                      </c:when>
                      <c:otherwise>
                        <i class="bi bi-info-circle-fill"></i>
                      </c:otherwise>
                    </c:choose>
                  </div>
                  
                  <!-- Content -->
                  <div class="flex-grow-1 donation-info">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                      <div>
                        <h6>
                          <i class="bi bi-hospital me-2"></i>
                          ${donation.hospitalName != null ? donation.hospitalName : 'Không xác định'}
                        </h6>
                        <c:if test="${not empty donation.donationDate}">
                          <div class="donation-meta-item ${isCompleted ? 'completed' : ''} mb-2">
                            <i class="bi bi-calendar-check"></i>
                            <strong>Ngày hiến:</strong>
                            <span><fmt:formatDate value="${donation.donationDate}" pattern="dd/MM/yyyy"/></span>
                          </div>
                        </c:if>
                      </div>
                      <span class="status-badge status-${statusLower}">
                        <c:choose>
                          <c:when test="${isCompleted}">
                            <i class="bi bi-check-circle me-1"></i>Hoàn thành
                          </c:when>
                          <c:when test="${statusLower == 'pending'}">
                            <i class="bi bi-clock me-1"></i>Đang chờ
                          </c:when>
                          <c:when test="${statusLower == 'cancelled'}">
                            <i class="bi bi-x-circle me-1"></i>Đã hủy
                          </c:when>
                          <c:otherwise>
                            ${donation.status != null ? donation.status : 'PENDING'}
                          </c:otherwise>
                        </c:choose>
                      </span>
                    </div>
                    
                    <div class="donation-meta">
                      <!-- Lượng máu & Nhóm máu -->
                      <div class="donation-meta-item">
                        <i class="bi bi-droplet-fill"></i>
                        <span class="quantity-badge ${isCompleted ? 'completed' : ''}">
                          ${donation.quantityMl != null ? donation.quantityMl : 0}ml
                        </span>
                        <span class="mx-2">•</span>
                        <strong>Nhóm máu:</strong>
                        <span class="badge bg-light text-dark">${donation.measuredBloodGroup != null ? donation.measuredBloodGroup : 'N/A'}</span>
                      </div>
                      
                      <!-- Chứng nhận -->
                      <div class="donation-meta-item">
                        <c:choose>
                          <c:when test="${not empty donation.certificateUrl}">
                            <a href="${donation.certificateUrl}" target="_blank" class="certificate-link ${isCompleted ? 'completed' : ''}">
                              <i class="bi bi-award-fill"></i>
                              <span>Xem chứng nhận</span>
                              <i class="bi bi-box-arrow-up-right" style="font-size: 0.7rem;"></i>
                            </a>
                          </c:when>
                          <c:otherwise>
                            <span class="text-muted">
                              <i class="bi bi-award"></i>
                              <span>Chứng nhận đang được xử lý</span>
                            </span>
                          </c:otherwise>
                        </c:choose>
                      </div>
                    </div>
                    
                    <!-- Thông tin bổ sung cho lần hiến hoàn thành -->
                    <c:if test="${isCompleted}">
                      <div class="mt-3 p-3 bg-light rounded" style="background: #f0fdf4 !important; border-left: 3px solid #10b981;">
                        <div class="d-flex align-items-center gap-2 text-success mb-1">
                          <i class="bi bi-heart-fill"></i>
                          <strong style="font-size: 0.9rem;">Cảm ơn bạn đã hiến máu!</strong>
                        </div>
                        <p class="mb-0 small text-muted" style="font-size: 0.85rem;">
                          Lượng máu của bạn đã được xử lý và sẵn sàng để cứu giúp những người cần. 
                          Mỗi đơn vị máu có thể cứu sống tới 3 người bệnh.
                        </p>
                      </div>
                    </c:if>
                  </div>
                </div>
              </div>
            </c:forEach>
          </c:when>
          <c:otherwise>
            <div class="text-center py-5 text-muted">
              <i class="bi bi-inbox display-1 d-block mb-3" style="color: #cbd5e1;"></i>
              <h5 class="mb-2">Chưa có lịch sử hiến máu</h5>
              <p class="mb-4">Bạn chưa có lịch sử hiến máu nào. Hãy đặt lịch hiến máu để bắt đầu hành trình cứu người của mình!</p>
              <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-danger">
                <i class="bi bi-calendar-plus me-2"></i>Đặt lịch hiến máu ngay
              </a>
            </div>
          </c:otherwise>
        </c:choose>
      </div>
    </div>

    <div class="d-flex justify-content-start mt-4">
      <a href="${pageContext.request.contextPath}/donor" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Quay lại
      </a>
    </div>
  </div>
</div>

<jsp:include page="/footer.jsp" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

