<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Báo cáo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1200px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#6366f1 0%,#4f46e5 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .report-card{transition:transform .2s;cursor:pointer}
  .report-card:hover{transform:translateY(-5px)}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header text-center">
      <h1 class="mb-0"><i class="bi bi-file-earmark-spreadsheet me-2"></i>Báo cáo & Thống kê</h1>
      <p class="mb-0 mt-2 opacity-75">Xuất báo cáo chi tiết về kho máu, hiến máu và yêu cầu máu</p>
    </div>

    <div class="row g-4">
      <!-- Báo cáo Kho máu -->
      <div class="col-md-4">
        <div class="card card-soft report-card h-100">
          <div class="card-body text-center p-4">
            <div class="bg-primary bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
              <i class="bi bi-box-seam text-primary fs-1"></i>
            </div>
            <h5 class="card-title">Báo cáo Kho máu</h5>
            <p class="text-muted small">Xuất danh sách tất cả túi máu trong kho với đầy đủ thông tin</p>
            <a href="${pageContext.request.contextPath}/hospital/reports?type=inventory&format=excel" 
               class="btn btn-primary">
              <i class="bi bi-download me-2"></i>Xuất Excel
            </a>
          </div>
        </div>
      </div>

      <!-- Báo cáo Hiến máu -->
      <div class="col-md-4">
        <div class="card card-soft report-card h-100">
          <div class="card-body text-center p-4">
            <div class="bg-success bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
              <i class="bi bi-heart-pulse text-success fs-1"></i>
            </div>
            <h5 class="card-title">Báo cáo Hiến máu</h5>
            <p class="text-muted small">Xuất báo cáo chi tiết về các lần hiến máu tại bệnh viện</p>
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#donationReportModal">
              <i class="bi bi-download me-2"></i>Xuất Excel
            </button>
          </div>
        </div>
      </div>

      <!-- Báo cáo Yêu cầu máu -->
      <div class="col-md-4">
        <div class="card card-soft report-card h-100">
          <div class="card-body text-center p-4">
            <div class="bg-warning bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
              <i class="bi bi-clipboard-data text-warning fs-1"></i>
            </div>
            <h5 class="card-title">Báo cáo Yêu cầu máu</h5>
            <p class="text-muted small">Xuất báo cáo về các yêu cầu máu đã nhận và xử lý</p>
            <a href="${pageContext.request.contextPath}/hospital/reports?type=requests&format=excel" 
               class="btn btn-warning">
              <i class="bi bi-download me-2"></i>Xuất Excel
            </a>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal cho Donation Report với date range -->
    <div class="modal fade" id="donationReportModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Xuất báo cáo Hiến máu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <form method="get" action="${pageContext.request.contextPath}/hospital/reports">
            <input type="hidden" name="type" value="donations">
            <input type="hidden" name="format" value="excel">
            <div class="modal-body">
              <p class="text-muted">Chọn khoảng thời gian (tùy chọn):</p>
              <div class="mb-3">
                <label class="form-label">Từ ngày</label>
                <input type="date" class="form-control" name="fromDate">
              </div>
              <div class="mb-3">
                <label class="form-label">Đến ngày</label>
                <input type="date" class="form-control" name="toDate">
              </div>
              <p class="text-muted small">Để trống để xuất tất cả dữ liệu</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
              <button type="submit" class="btn btn-success">
                <i class="bi bi-download me-2"></i>Xuất Excel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

