<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Xác thực Người hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:900px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .form-label{font-weight:600;color:var(--bl-dark);margin-bottom:8px}
  .form-control:focus,.form-select:focus{border-color:var(--bl-red);box-shadow:0 0 0 0.2rem rgba(225,29,72,.25)}
  .btn-primary{background:var(--bl-red);border-color:var(--bl-red)}
  .btn-primary:hover{background:#c21845;border-color:#c21845}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-person-check me-2"></i>Xác thực Người hiến máu</h1>
          <p class="mb-0">Xác nhận thông tin và tạo bản ghi hiến máu</p>
        </div>
        <a href="${pageContext.request.contextPath}/hospital/donors" class="btn btn-light">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Thông tin người hiến -->
    <c:if test="${not empty donor}">
      <div class="card card-soft">
        <div class="card-header bg-white border-bottom">
          <h5 class="mb-0"><i class="bi bi-person me-2"></i>Thông tin người hiến máu</h5>
        </div>
        <div class="card-body p-4">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Họ và tên</label>
              <input type="text" class="form-control" value="${donor.fullName != null ? donor.fullName : '—'}" readonly>
            </div>
            <div class="col-md-6">
              <label class="form-label">Nhóm máu</label>
              <input type="text" class="form-control" value="${donor.bloodGroup != null ? donor.bloodGroup : '—'}" readonly>
            </div>
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" value="${donor.email != null ? donor.email : '—'}" readonly>
            </div>
            <div class="col-md-6">
              <label class="form-label">Số điện thoại</label>
              <input type="tel" class="form-control" value="${donor.phone != null ? donor.phone : '—'}" readonly>
            </div>
            <div class="col-12">
              <label class="form-label">Địa chỉ</label>
              <textarea class="form-control" rows="2" readonly>${donor.address != null ? donor.address : '—'}</textarea>
            </div>
          </div>
        </div>
      </div>

      <!-- Form xác nhận hiến máu -->
      <form method="post" action="${pageContext.request.contextPath}/hospital/verify-donor">
        <input type="hidden" name="donorId" value="${donor.donorId}">
        
        <div class="card card-soft">
          <div class="card-header bg-white border-bottom">
            <h5 class="mb-0"><i class="bi bi-clipboard-check me-2"></i>Thông tin hiến máu</h5>
          </div>
          <div class="card-body p-4">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Ngày hiến máu <span class="text-danger">*</span></label>
                <input type="date" class="form-control" name="donationDate" 
                       value="${pageContext.request.getParameter('date') != null ? pageContext.request.getParameter('date') : ''}" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Nhóm máu xác nhận <span class="text-danger">*</span></label>
                <select class="form-select" name="bloodGroup" required>
                  <option value="${donor.bloodGroup != null ? donor.bloodGroup : ''}" selected>${donor.bloodGroup != null ? donor.bloodGroup : 'Chọn nhóm máu'}</option>
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                </select>
              </div>
              <div class="col-md-6">
                <label class="form-label">Số lượng (ml) <span class="text-danger">*</span></label>
                <input type="number" class="form-control" name="quantityMl" 
                       min="200" max="500" step="50" required placeholder="Ví dụ: 450">
                <small class="text-muted">Thông thường: 350-450ml</small>
              </div>
              <div class="col-md-6">
                <label class="form-label">Trạng thái</label>
                <select class="form-select" name="status">
                  <option value="CONFIRMED" selected>Đã xác nhận</option>
                  <option value="PENDING">Đang chờ</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div class="d-flex justify-content-between gap-3">
          <a href="${pageContext.request.contextPath}/hospital/donors" class="btn btn-outline-secondary">
            <i class="bi bi-x-circle me-2"></i>Hủy
          </a>
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-check-circle me-2"></i>Xác nhận hiến máu
          </button>
        </div>
      </form>
    </c:if>

    <c:if test="${empty donor}">
      <div class="card card-soft">
        <div class="card-body text-center py-5">
          <i class="bi bi-exclamation-circle display-6 text-warning d-block mb-3"></i>
          <h5>Không tìm thấy thông tin người hiến máu</h5>
          <p class="text-muted">Vui lòng quay lại và chọn người hiến máu khác.</p>
          <a href="${pageContext.request.contextPath}/hospital/donors" class="btn btn-primary">
            <i class="bi bi-arrow-left me-2"></i>Quay lại
          </a>
        </div>
      </div>
    </c:if>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

