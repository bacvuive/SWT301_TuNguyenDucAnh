<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Xác minh bệnh viện</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1000px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .badge-status{font-size:0.9rem;padding:0.35rem 0.75rem;border-radius:999px}
  .timeline::before{content:'';position:absolute;left:13px;top:0;bottom:0;width:2px;background:#e5e7eb}
  .timeline-item{position:relative;padding-left:40px;margin-bottom:25px}
  .timeline-item:last-child{margin-bottom:0}
  .timeline-icon{position:absolute;left:6px;top:4px;width:14px;height:14px;border-radius:50%;background:#e11d48}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-2"><i class="bi bi-shield-check me-2"></i>Trạng thái xác minh bệnh viện</h1>
      <p class="mb-0">Gửi yêu cầu xác minh và theo dõi tiến trình phê duyệt</p>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <c:if test="${empty hospital}">
      <div class="alert alert-warning" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>Không tìm thấy thông tin bệnh viện. Vui lòng liên hệ quản trị viên.
      </div>
    </c:if>

    <c:if test="${not empty hospital}">
      <div class="card card-soft">
        <div class="card-body p-4">
          <div class="d-flex flex-column flex-md-row justify-content-between">
            <div>
              <h4 class="fw-bold mb-2">${hospital.name}</h4>
              <div class="text-muted">
                <div><i class="bi bi-geo-alt me-2"></i>${hospital.address}</div>
                <div><i class="bi bi-telephone me-2"></i>${hospital.contact != null ? hospital.contact : 'Đang cập nhật'}</div>
              </div>
            </div>
            <div class="text-md-end mt-3 mt-md-0">
              <c:choose>
                <c:when test="${hospital.isVerified}">
                  <span class="badge bg-success badge-status"><i class="bi bi-patch-check me-1"></i>Đã xác minh</span>
                  <c:if test="${hospital.verifiedAt != null}">
                    <div class="small text-muted mt-2">Duyệt ngày: <fmt:formatDate value="${hospital.verifiedAt}" pattern="dd/MM/yyyy HH:mm"/></div>
                  </c:if>
                  <c:if test="${not empty hospital.verificationNote}">
                    <div class="small text-muted">Ghi chú: ${hospital.verificationNote}</div>
                  </c:if>
                </c:when>
                <c:when test="${hasPendingVerification}">
                  <span class="badge bg-warning text-dark badge-status"><i class="bi bi-hourglass-split me-1"></i>Đang chờ duyệt</span>
                </c:when>
                <c:otherwise>
                  <span class="badge bg-secondary badge-status"><i class="bi bi-question-circle me-1"></i>Chưa xác minh</span>
                </c:otherwise>
              </c:choose>
            </div>
          </div>
        </div>
      </div>

      <c:choose>
        <c:when test="${hasPendingVerification}">
          <div class="alert alert-info" role="alert">
            <i class="bi bi-info-circle me-2"></i>Bệnh viện đã gửi yêu cầu xác minh và đang chờ quản trị viên phê duyệt. Vui lòng chờ thêm.
          </div>
        </c:when>
        <c:otherwise>
          <div class="card card-soft">
            <div class="card-header bg-white border-bottom">
              <h5 class="mb-0"><i class="bi bi-send-check me-2"></i>Gửi yêu cầu xác minh</h5>
            </div>
            <div class="card-body p-4">
              <form method="post" action="${pageContext.request.contextPath}/hospital/verification">
                <div class="mb-3">
                  <label class="form-label fw-semibold">Số giấy phép hoạt động <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" name="registrationNumber" placeholder="VD: BYT-1234-2025" required>
                </div>
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label fw-semibold">Người liên hệ <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="contactPerson" placeholder="Họ và tên" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label fw-semibold">Số điện thoại <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="contactPhone" placeholder="0236-1234567" required>
                  </div>
                </div>
                <div class="mt-3">
                  <label class="form-label fw-semibold">Thông tin bổ sung</label>
                  <textarea class="form-control" name="extraData" rows="3" placeholder="Ví dụ: Giấy tờ đính kèm sẽ gửi qua email..."></textarea>
                  <div class="form-text">Nếu cần tải giấy tờ, vui lòng ghi rõ để quản trị viên liên hệ.</div>
                </div>
                <button type="submit" class="btn btn-primary mt-3">
                  <i class="bi bi-upload me-2"></i>Gửi yêu cầu xác minh
                </button>
              </form>
            </div>
          </div>
        </c:otherwise>
      </c:choose>

      <div class="card card-soft">
        <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
          <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Lịch sử yêu cầu xác minh</h5>
          <c:if test="${empty verificationHistory}">
            <span class="badge bg-light text-muted">Chưa có dữ liệu</span>
          </c:if>
        </div>
        <div class="card-body p-4 position-relative">
          <c:if test="${not empty verificationHistory}">
            <div class="timeline">
              <c:forEach var="item" items="${verificationHistoryView}" varStatus="loop">
                <div class="timeline-item">
                  <span class="timeline-icon"></span>
                  <div class="d-flex justify-content-between">
                    <div>
                      <h6 class="mb-1">Yêu cầu #${item.requestId}</h6>
                      <div class="mb-1">
                        <c:choose>
                          <c:when test="${item.status == 'APPROVED'}">
                            <span class="badge bg-success">ĐÃ DUYỆT</span>
                          </c:when>
                          <c:when test="${item.status == 'REJECTED'}">
                            <span class="badge bg-danger">BỊ TỪ CHỐI</span>
                          </c:when>
                          <c:when test="${item.status == 'PENDING'}">
                            <span class="badge bg-warning text-dark">ĐANG CHỜ</span>
                          </c:when>
                          <c:otherwise>
                            <span class="badge bg-secondary">${item.status}</span>
                          </c:otherwise>
                        </c:choose>
                      </div>
                      <div class="text-muted small">
                        <div>Số đăng ký: ${item.registrationNumber}</div>
                        <div>Người liên hệ: ${item.contactPerson} (${item.contactPhone})</div>
                        <c:if test="${not empty item.extraData}">
                          <div>Ghi chú: ${item.extraData}</div>
                        </c:if>
                        <c:if test="${not empty item.rejectionReason}">
                          <div class="text-danger">Lý do từ chối: ${item.rejectionReason}</div>
                        </c:if>
                      </div>
                    </div>
                    <div class="text-end text-muted small">
                      <div>Gửi: <fmt:formatDate value="${item.submittedAt}" pattern="dd/MM/yyyy HH:mm"/></div>
                      <c:if test="${not empty item.processedAt}">
                        <div>Duyệt: <fmt:formatDate value="${item.processedAt}" pattern="dd/MM/yyyy HH:mm"/></div>
                      </c:if>
                    </div>
                  </div>
                </div>
              </c:forEach>
            </div>
          </c:if>
        </div>
      </div>

      <div class="mt-4">
        <a href="${pageContext.request.contextPath}/hospital/profile" class="btn btn-outline-secondary">
          <i class="bi bi-arrow-left me-2"></i>Quay lại hồ sơ bệnh viện
        </a>
      </div>
    </c:if>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
