<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Quản lý Người hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .table{background:#fff;border-radius:12px;overflow:hidden}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-people-fill me-2"></i>Quản lý Người hiến máu</h1>
          <p class="mb-0">Xem danh sách và quản lý người hiến máu tại bệnh viện</p>
        </div>
        <a href="${pageContext.request.contextPath}/hospital/dashboard" class="btn btn-light">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
      </div>
    </div>

    <!-- Bộ lọc -->
    <div class="card card-soft mb-4">
      <div class="card-body">
        <form method="get" class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Nhóm máu</label>
            <select class="form-select" name="bloodGroup">
              <option value="">Tất cả</option>
              <option value="A+" ${selectedBloodGroup == 'A+' ? 'selected' : ''}>A+</option>
              <option value="A-" ${selectedBloodGroup == 'A-' ? 'selected' : ''}>A-</option>
              <option value="B+" ${selectedBloodGroup == 'B+' ? 'selected' : ''}>B+</option>
              <option value="B-" ${selectedBloodGroup == 'B-' ? 'selected' : ''}>B-</option>
              <option value="AB+" ${selectedBloodGroup == 'AB+' ? 'selected' : ''}>AB+</option>
              <option value="AB-" ${selectedBloodGroup == 'AB-' ? 'selected' : ''}>AB-</option>
              <option value="O+" ${selectedBloodGroup == 'O+' ? 'selected' : ''}>O+</option>
              <option value="O-" ${selectedBloodGroup == 'O-' ? 'selected' : ''}>O-</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Tìm kiếm</label>
            <input type="text" class="form-control" name="search" placeholder="Tên, email, số điện thoại..." value="${searchQuery}">
          </div>
          <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-search me-2"></i>Tìm kiếm
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Bảng danh sách -->
    <div class="card card-soft">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>Họ và tên</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Nhóm máu</th>
                <th>Địa chỉ</th>
                <th>Lần hiến</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <c:choose>
                <c:when test="${not empty donors and donors.size() > 0}">
                  <c:forEach var="donor" items="${donors}">
                    <tr>
                      <td><strong>${donor.fullName != null ? donor.fullName : '—'}</strong></td>
                      <td>${donor.email != null ? donor.email : '—'}</td>
                      <td>${donor.phone != null ? donor.phone : '—'}</td>
                      <td><span class="badge bg-danger">${donor.bloodGroup != null ? donor.bloodGroup : '—'}</span></td>
                      <td>${donor.address != null ? donor.address : '—'}</td>
                      <td>
                        <span class="badge bg-info">${donor.donationCount != null ? donor.donationCount : 0}</span>
                      </td>
                      <td>
                        <a href="${pageContext.request.contextPath}/hospital/verify-donor?id=${donor.donorId}" class="btn btn-sm btn-outline-primary">
                          <i class="bi bi-person-check"></i> Xác thực
                        </a>
                      </td>
                    </tr>
                  </c:forEach>
                </c:when>
                <c:otherwise>
                  <tr>
                    <td colspan="7" class="text-center py-5 text-muted">
                      <i class="bi bi-inbox display-6 d-block mb-2"></i>
                      <p>Chưa có người hiến máu nào</p>
                    </td>
                  </tr>
                </c:otherwise>
              </c:choose>
            </tbody>
          </table>
        </div>
      </div>
      
      <!-- Pagination -->
      <c:if test="${totalPages > 1}">
        <div class="card-footer">
          <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mb-0">
              <li class="page-item ${currentPage == 1 ? 'disabled' : ''}">
                <a class="page-link" href="?page=${currentPage - 1}&search=${searchQuery}&bloodGroup=${selectedBloodGroup}">Trước</a>
              </li>
              <c:forEach var="i" begin="1" end="${totalPages}">
                <c:if test="${i == 1 || i == totalPages || (i >= currentPage - 2 && i <= currentPage + 2)}">
                  <li class="page-item ${i == currentPage ? 'active' : ''}">
                    <a class="page-link" href="?page=${i}&search=${searchQuery}&bloodGroup=${selectedBloodGroup}">${i}</a>
                  </li>
                </c:if>
                <c:if test="${i == currentPage - 3 || i == currentPage + 3}">
                  <li class="page-item disabled"><span class="page-link">...</span></li>
                </c:if>
              </c:forEach>
              <li class="page-item ${currentPage == totalPages ? 'disabled' : ''}">
                <a class="page-link" href="?page=${currentPage + 1}&search=${searchQuery}&bloodGroup=${selectedBloodGroup}">Sau</a>
              </li>
            </ul>
          </nav>
          <div class="text-center mt-2 text-muted small">
            Hiển thị ${(currentPage - 1) * 20 + 1}-${currentPage * 20 > totalCount ? totalCount : currentPage * 20} trong tổng số ${totalCount} kết quả
          </div>
        </div>
      </c:if>
    </div>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

