<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Bảng điều khiển Bệnh viện</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .dashboard-section{padding:40px 0}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}

  /* Dashboard Layout */
  .dashboard-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .dashboard-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .dashboard-header h1{font-weight:800;margin-bottom:8px}
  .dashboard-header p{opacity:.9;margin-bottom:0}

  /* Stats Grid */
  .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:30px}
  .stat-card{background:#fff;border-radius:16px;padding:24px;text-align:center;border:1px solid var(--bl-border);transition:transform .2s ease,box-shadow .2s ease}
  .stat-card:hover{transform:translateY(-4px);box-shadow:0 20px 40px rgba(2,8,23,.1)}
  .stat-card .icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:20px}
  .stat-card .icon.danger{background:#fee2e2;color:#dc2626}
  .stat-card .icon.success{background:#dcfce7;color:#16a34a}
  .stat-card .icon.warning{background:#fef3c7;color:#d97706}
  .stat-card .icon.info{background:#dbeafe;color:#2563eb}
  .stat-card h3{font-weight:800;margin-bottom:4px;color:var(--bl-dark)}
  .stat-card p{margin:0;color:var(--bl-muted);font-size:14px}

  /* Quick Actions */
  .quick-actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-bottom:30px}
  .action-card{background:#fff;border-radius:16px;padding:24px;border:1px solid var(--bl-border);transition:all .2s ease}
  .action-card:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(2,8,23,.08)}
  .action-card .icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;font-size:18px}
  .action-card .icon.danger{background:#fee2e2;color:#dc2626}
  .action-card .icon.warning{background:#fef3c7;color:#d97706}
  .action-card .icon.info{background:#dbeafe;color:#2563eb}
  .action-card h5{font-weight:700;margin-bottom:8px;color:var(--bl-dark)}
  .action-card p{margin-bottom:16px;color:var(--bl-muted);font-size:14px}
  .action-card .btn{width:100%;border-radius:10px;font-weight:600}

  /* Recent Activity */
  .activity-card{background:#fff;border-radius:16px;padding:24px;border:1px solid var(--bl-border)}
  .activity-item{display:flex;align-items:center;gap:16px;padding:12px 0;border-bottom:1px solid #f1f5f9}
  .activity-item:last-child{border-bottom:none}
  .activity-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px}
  .activity-icon.success{background:#dcfce7;color:#16a34a}
  .activity-icon.warning{background:#fef3c7;color:#d97706}
  .activity-icon.info{background:#dbeafe;color:#2563eb}
  .activity-content{flex:1}
  .activity-content h6{margin:0;font-weight:600;color:var(--bl-dark)}
  .activity-content p{margin:0;color:var(--bl-muted);font-size:13px}
  .activity-time{color:var(--bl-muted);font-size:12px}

  /* Responsive */
  @media (max-width:768px){
    .dashboard-header{padding:20px;margin-bottom:20px}
    .stats-grid{grid-template-columns:repeat(2,1fr);gap:15px}
    .quick-actions{grid-template-columns:1fr;gap:15px}
  }
</style>

<div class="dashboard-section">
  <div class="dashboard-container">

    <!-- Dashboard Header -->
    <div class="dashboard-header">
      <h1>Xin chào, <c:out value="${hospital != null and not empty hospital.name ? hospital.name : (sessionScope.authUser != null ? sessionScope.authUser.email : 'Bệnh viện')}"/></h1>
      <p>Chào mừng bạn đến với bảng điều khiển bệnh viện. Quản lý kho máu, yêu cầu và người hiến máu.</p>
    </div>

    <!-- Success/Error Messages -->
    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert" style="border-radius: 12px; margin-bottom: 20px;">
        <i class="bi bi-check-circle-fill me-2"></i><strong>Thành công!</strong> ${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </c:if>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert" style="border-radius: 12px; margin-bottom: 20px;">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><strong>Lỗi!</strong> ${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </c:if>

    <!-- Stats Grid -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon danger">
          <i class="bi bi-droplet-fill"></i>
        </div>
        <h3>
          <c:set var="totalAvailable" value="${0}" />
          <c:forEach var="stock" items="${stockSummary}">
            <c:set var="totalAvailable" value="${totalAvailable + stock.units}" />
          </c:forEach>
          ${totalAvailable}
        </h3>
        <p>Túi máu có sẵn</p>
      </div>
      <div class="stat-card">
        <div class="icon success">
          <i class="bi bi-clipboard-check-fill"></i>
        </div>
        <h3>
          <c:set var="pendingAppointments" value="${0}" />
          <c:forEach var="apt" items="${appointments}">
            <c:if test="${apt.status == 'PENDING'}">
              <c:set var="pendingAppointments" value="${pendingAppointments + 1}" />
            </c:if>
          </c:forEach>
          ${pendingAppointments}
        </h3>
        <p>Lịch hẹn chờ xử lý</p>
      </div>
      <div class="stat-card">
        <div class="icon warning">
          <i class="bi bi-exclamation-triangle-fill"></i>
        </div>
        <h3>
          <c:set var="pendingRequests" value="${0}" />
          <c:forEach var="req" items="${requests}">
            <c:if test="${req.status == 'PENDING'}">
              <c:set var="pendingRequests" value="${pendingRequests + 1}" />
            </c:if>
          </c:forEach>
          ${pendingRequests}
        </h3>
        <p>Yêu cầu máu chờ xử lý</p>
      </div>
      <div class="stat-card">
        <div class="icon info">
          <i class="bi bi-bell-fill"></i>
        </div>
        <h3>${notifications != null ? notifications.size() : 0}</h3>
        <p>Thông báo mới</p>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
      <div class="action-card">
        <div class="icon danger">
          <i class="bi bi-plus-circle"></i>
        </div>
        <h5>Tạo yêu cầu máu</h5>
        <p>Tạo yêu cầu máu khẩn cấp và gửi thông báo đến người hiến máu.</p>
        <a href="${pageContext.request.contextPath}/hospital/requests/create" class="btn btn-danger">Tạo yêu cầu</a>
      </div>

      <div class="action-card">
        <div class="icon info">
          <i class="bi bi-box-seam"></i>
        </div>
        <h5>Quản lý kho máu</h5>
        <p>Xem và quản lý kho máu của bệnh viện, theo dõi hạn sử dụng.</p>
        <a href="${pageContext.request.contextPath}/hospital/inventory" class="btn btn-info">Quản lý kho</a>
      </div>

      <div class="action-card">
        <div class="icon warning">
          <i class="bi bi-people-fill"></i>
        </div>
        <h5>Quản lý người hiến</h5>
        <p>Xem danh sách người hiến máu và xác thực thông tin.</p>
        <a href="${pageContext.request.contextPath}/hospital/donors" class="btn btn-warning">Quản lý người hiến</a>
      </div>

      <div class="action-card">
        <div class="icon success">
          <i class="bi bi-calendar-check"></i>
        </div>
        <h5>Quản lý lịch hẹn</h5>
        <p>Xem và xử lý các yêu cầu đặt lịch hiến máu từ người hiến.</p>
        <a href="${pageContext.request.contextPath}/hospital/appointments" class="btn btn-success">Quản lý lịch hẹn</a>
      </div>
    </div>

    <!-- Recent Activity & Pending Requests -->
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="activity-card">
          <h5 class="mb-3"><i class="bi bi-list-check me-2"></i>Yêu cầu máu gần đây</h5>

          <c:choose>
            <c:when test="${not empty requests and requests.size() > 0}">
              <c:forEach var="req" items="${requests}" varStatus="loop">
                <c:if test="${loop.index < 5}">
                  <div class="activity-item">
                    <div class="activity-icon ${req.status == 'PENDING' ? 'warning' : req.status == 'ACCEPTED' ? 'success' : req.status == 'COMPLETED' ? 'success' : 'info'}">
                      <i class="bi ${req.status == 'PENDING' ? 'bi-hourglass-split' : req.status == 'ACCEPTED' ? 'bi-check-circle' : req.status == 'COMPLETED' ? 'bi-check-circle-fill' : 'bi-exclamation-circle'}"></i>
                    </div>
                    <div class="activity-content">
                      <h6>Yêu cầu ${req.bloodGroup} - ${req.component}</h6>
                      <p>
                        <i class="bi bi-droplet me-1"></i>
                        Số lượng: ${req.quantity} đơn vị
                        <span class="ms-2">
                          <span class="badge ${req.status == 'PENDING' ? 'bg-warning' : req.status == 'ACCEPTED' ? 'bg-info' : req.status == 'COMPLETED' ? 'bg-success' : req.status == 'REJECTED' ? 'bg-danger' : 'bg-secondary'}">
                            ${req.status == 'PENDING' ? 'Chờ xử lý' : req.status == 'ACCEPTED' ? 'Đã chấp nhận' : req.status == 'COMPLETED' ? 'Đã hoàn thành' : req.status == 'REJECTED' ? 'Đã từ chối' : req.status}
                          </span>
                        </span>
                      </p>
                    </div>
                    <div class="activity-time">
                      <c:if test="${req.createdAt != null}">
                        <small><fmt:formatDate value="${req.createdAt}" pattern="dd/MM"/></small>
                      </c:if>
                    </div>
                  </div>
                </c:if>
              </c:forEach>
            </c:when>
            <c:otherwise>
              <div class="text-center py-4 text-muted">
                <i class="bi bi-inbox display-6 d-block mb-2"></i>
                <p>Chưa có yêu cầu nào</p>
              </div>
            </c:otherwise>
          </c:choose>

          <div class="text-center mt-3">
            <a href="${pageContext.request.contextPath}/hospital/requests" class="btn btn-outline-secondary btn-sm">Xem tất cả</a>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="activity-card">
          <h5 class="mb-3"><i class="bi bi-calendar-event me-2"></i>Lịch hẹn sắp tới</h5>

          <c:choose>
            <c:when test="${not empty appointments and appointments.size() > 0}">
              <c:forEach var="apt" items="${appointments}" varStatus="loop">
                <c:if test="${loop.index < 5}">
                  <div class="activity-item">
                    <div class="activity-icon ${apt.status == 'PENDING' ? 'warning' : apt.status == 'CONFIRMED' ? 'success' : 'info'}">
                      <i class="bi ${apt.status == 'PENDING' ? 'bi-hourglass-split' : apt.status == 'CONFIRMED' ? 'bi-check-circle-fill' : 'bi-calendar-date'}"></i>
                    </div>
                    <div class="activity-content">
                      <h6>
                        <c:choose>
                          <c:when test="${apt.status == 'PENDING'}">Lịch hẹn chờ xử lý</c:when>
                          <c:when test="${apt.status == 'CONFIRMED'}">Lịch hẹn đã xác nhận</c:when>
                          <c:otherwise>Lịch hẹn hiến máu</c:otherwise>
                        </c:choose>
                      </h6>
                      <p>
                        <c:if test="${apt.scheduledAt != null}">
                          <i class="bi bi-calendar me-1"></i>
                          <fmt:formatDate value="${apt.scheduledAt}" pattern="dd/MM/yyyy HH:mm"/>
                        </c:if>
                        <c:if test="${apt.scheduledAt == null}">
                          <span class="text-muted">Chưa có thời gian</span>
                        </c:if>
                        <span class="ms-2">
                          <span class="badge ${apt.status == 'CONFIRMED' ? 'bg-success' : apt.status == 'PENDING' ? 'bg-warning' : apt.status == 'CANCELLED' ? 'bg-danger' : 'bg-secondary'}">
                            ${apt.status == 'PENDING' ? 'Chờ xử lý' : apt.status == 'CONFIRMED' ? 'Đã xác nhận' : apt.status == 'CANCELLED' ? 'Đã hủy' : apt.status == 'COMPLETED' ? 'Đã hoàn thành' : apt.status}
                          </span>
                        </span>
                      </p>
                    </div>
                  </div>
                </c:if>
              </c:forEach>
            </c:when>
            <c:otherwise>
              <div class="text-center py-4 text-muted">
                <i class="bi bi-calendar-x display-6 d-block mb-2"></i>
                <p>Chưa có lịch hẹn nào</p>
              </div>
            </c:otherwise>
          </c:choose>

          <div class="text-center mt-3">
            <a href="${pageContext.request.contextPath}/hospital/appointments" class="btn btn-outline-secondary btn-sm">Quản lý lịch hẹn</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Inventory Summary -->
    <div class="row mt-4">
      <div class="col-12">
        <div class="card card-soft">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h5 class="mb-0"><i class="bi bi-droplet-half me-2"></i>Tóm tắt kho máu</h5>
              <a href="${pageContext.request.contextPath}/hospital/inventory" class="btn btn-sm btn-outline-primary">Xem chi tiết</a>
            </div>
            <c:choose>
              <c:when test="${not empty stockSummary and stockSummary.size() > 0}">
                <div class="row g-3">
                  <c:set var="bloodGroups" value="${['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']}" />
                  <c:forEach var="bg" items="${bloodGroups}">
                    <c:set var="count" value="${0}" />
                    <c:forEach var="stock" items="${stockSummary}">
                      <c:if test="${stock.bloodGroup == bg}">
                        <c:set var="count" value="${count + stock.units}" />
                      </c:if>
                    </c:forEach>
                    <div class="col-md-3 col-6">
                      <div class="text-center p-3 border rounded bg-light">
                        <div class="fw-bold text-danger fs-5">${bg}</div>
                        <div class="small text-muted mt-1">${count} đơn vị</div>
                      </div>
                    </div>
                  </c:forEach>
                </div>
                <div class="mt-3">
                  <small class="text-muted">
                    <i class="bi bi-info-circle me-1"></i>
                    Chỉ hiển thị túi máu có trạng thái AVAILABLE
                  </small>
                </div>
              </c:when>
              <c:otherwise>
                <div class="text-center py-4 text-muted">
                  <i class="bi bi-inbox display-6 d-block mb-2"></i>
                  <p>Kho máu trống hoặc chưa có túi máu AVAILABLE</p>
                </div>
              </c:otherwise>
            </c:choose>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

