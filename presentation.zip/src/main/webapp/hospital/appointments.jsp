<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Quản lý lịch hẹn hiến máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- CSRF meta (đảm bảo bên BE cung cấp _csrfToken) -->
  <meta name="csrf-token" content="${_csrfToken}">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1200px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .appointment-card{border-left:4px solid var(--bl-red);padding:20px;margin-bottom:15px;transition:transform .2s}
  .appointment-card:hover{transform:translateX(5px)}
  .appointment-card.pending{border-left-color:#f59e0b}
  .appointment-card.confirmed{border-left-color:#10b981}
  .appointment-card.cancelled{border-left-color:#ef4444}
  .appointment-card.completed{border-left-color:#6366f1}
  .status-badge{padding:4px 12px;border-radius:999px;font-size:0.75rem;font-weight:600}
  .status-pending{background:#fef3c7;color:#92400e}
  .status-confirmed{background:#d1fae5;color:#065f46}
  .status-cancelled{background:#fee2e2;color:#991b1b}
  .status-completed{background:#e0e7ff;color:#3730a3}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-0"><i class="bi bi-calendar-check me-2"></i>Quản lý lịch hẹn hiến máu</h1>
      <p class="mb-0 mt-2 opacity-75">Xem và quản lý các lịch hẹn hiến máu tại bệnh viện của bạn</p>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>
        <c:out value="${success}"/>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <c:out value="${error}"/>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <div class="card-soft">
      <div class="card-body p-4">
        <c:choose>
          <c:when test="${not empty appointments && appointments.size() > 0}">
            <c:forEach var="appt" items="${appointments}">
              <c:set var="statusLower" value="${appt.status != null ? appt.status.toLowerCase() : 'pending'}" />
              <div class="appointment-card ${statusLower}">
                <div class="d-flex justify-content-between align-items-start mb-3">
                  <div class="flex-grow-1">
                    <h6 class="mb-2">
                      <i class="bi bi-person me-2"></i><c:out value="${appt.donorName != null ? appt.donorName : 'Không xác định'}"/>
                    </h6>
                    <div class="row g-3 text-muted small mb-2">
                      <div class="col-md-4">
                        <i class="bi bi-calendar me-1"></i>
                        <strong>Ngày hẹn:</strong>
                        <c:choose>
                          <c:when test="${not empty appt.scheduledAt}">
                            <fmt:formatDate value="${appt.scheduledAt}" pattern="dd/MM/yyyy HH:mm"/>
                          </c:when>
                          <c:otherwise>
                            <span class="text-muted">Chưa cập nhật</span>
                          </c:otherwise>
                        </c:choose>
                      </div>
                      <div class="col-md-4">
                        <i class="bi bi-droplet me-1"></i>
                        <strong>Nhóm máu:</strong> <c:out value="${appt.donorBloodGroup != null ? appt.donorBloodGroup : 'N/A'}"/>
                      </div>
                      <div class="col-md-4">
                        <i class="bi bi-telephone me-1"></i>
                        <strong>SĐT:</strong> <c:out value="${appt.donorPhone != null ? appt.donorPhone : 'N/A'}"/>
                      </div>
                      <c:if test="${not empty appt.note}">
                        <div class="col-12">
                          <i class="bi bi-chat-text me-1"></i>
                          <strong>Ghi chú:</strong> <c:out value="${appt.note}"/>
                        </div>
                      </c:if>
                      <div class="col-md-6">
                        <i class="bi bi-clock me-1"></i>
                        <strong>Đăng ký:</strong>
                        <c:choose>
                          <c:when test="${not empty appt.createdAt}">
                            <fmt:formatDate value="${appt.createdAt}" pattern="dd/MM/yyyy HH:mm"/>
                          </c:when>
                          <c:otherwise>
                            <span class="text-muted">N/A</span>
                          </c:otherwise>
                        </c:choose>
                      </div>
                    </div>
                    <div class="mt-2">
                      <small class="text-muted">
                        <i class="bi bi-info-circle me-1"></i>
                        Mã lịch hẹn: #<c:out value="${appt.appointmentId != null ? appt.appointmentId : 'N/A'}"/>
                      </small>
                    </div>
                  </div>
                  <div class="ms-3">
                    <c:choose>
                      <c:when test="${appt.status == 'PENDING'}">
                        <span class="status-badge status-pending">Đang chờ</span>
                      </c:when>
                      <c:when test="${appt.status == 'CONFIRMED'}">
                        <span class="status-badge status-confirmed">Đã duyệt</span>
                      </c:when>
                      <c:when test="${appt.status == 'CANCELLED'}">
                        <span class="status-badge status-cancelled">Đã hủy</span>
                      </c:when>
                      <c:when test="${appt.status == 'COMPLETED'}">
                        <span class="status-badge status-completed">Đã hoàn thành</span>
                      </c:when>
                      <c:otherwise>
                        <span class="status-badge status-pending"><c:out value="${appt.status != null ? appt.status : 'PENDING'}"/></span>
                      </c:otherwise>
                    </c:choose>
                  </div>
                </div>
                <div class="d-flex gap-2 mt-3">
                  <c:if test="${appt.status == 'PENDING'}">
                    <form method="post" action="${pageContext.request.contextPath}/hospital/appointments"
                          style="display:inline;"
                          onsubmit="this.querySelector('button[type=submit]').disabled=true; return confirm('Bạn có chắc muốn chấp nhận lịch hẹn này?');">
                      <input type="hidden" name="appointmentId" value="${appt.appointmentId}">
                      <input type="hidden" name="action" value="confirm">
                      <input type="hidden" name="_csrf" value="${_csrfToken}">
                      <button type="submit" class="btn btn-sm btn-success">
                        <i class="bi bi-check-circle me-1"></i>Chấp nhận
                      </button>
                    </form>
                    <form method="post" action="${pageContext.request.contextPath}/hospital/appointments"
                          style="display:inline;"
                          onsubmit="this.querySelector('button[type=submit]').disabled=true; return confirm('Bạn có chắc muốn hủy lịch hẹn này?');">
                      <input type="hidden" name="appointmentId" value="${appt.appointmentId}">
                      <input type="hidden" name="action" value="cancel">
                      <input type="hidden" name="_csrf" value="${_csrfToken}">
                      <button type="submit" class="btn btn-sm btn-outline-danger">
                        <i class="bi bi-x-circle me-1"></i>Từ chối
                      </button>
                    </form>
                  </c:if>

                  <c:if test="${appt.status == 'CONFIRMED'}">
                    <a href="${pageContext.request.contextPath}/hospital/complete-donation?appointmentId=${appt.appointmentId}" 
                       class="btn btn-sm btn-primary">
                      <i class="bi bi-check-circle me-1"></i>Hoàn thành hiến máu
                    </a>
                  </c:if>

                  <c:if test="${appt.status == 'COMPLETED'}">
                    <span class="text-muted small">
                      <i class="bi bi-check-circle-fill me-1 text-success"></i>Đã hoàn thành hiến máu
                    </span>
                  </c:if>
                </div>
              </div>
            </c:forEach>
          </c:when>
          <c:otherwise>
            <div class="text-center py-5 text-muted">
              <i class="bi bi-calendar-x display-4 d-block mb-3"></i>
              <p>Chưa có lịch hẹn nào. Các người hiến máu sẽ đặt lịch và hiển thị ở đây.</p>
            </div>
          </c:otherwise>
        </c:choose>
      </div>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
