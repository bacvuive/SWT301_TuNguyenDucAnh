<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Bảo mật tài khoản</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:700px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .form-label{font-weight:600;color:var(--bl-dark);margin-bottom:8px}
  .form-control:focus{border-color:var(--bl-red);box-shadow:0 0 0 0.2rem rgba(225,29,72,.25)}
  .btn-primary{background:var(--bl-red);border-color:var(--bl-red)}
  .btn-primary:hover{background:#c21845;border-color:#c21845}
  .security-item{display:flex;justify-content:space-between;align-items:center;padding:20px;border-bottom:1px solid var(--bl-border)}
  .security-item:last-child{border-bottom:none}
  .security-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-right:16px;font-size:20px}
  .security-icon.primary{background:#dbeafe;color:#2563eb}
  .security-icon.success{background:#dcfce7;color:#16a34a}
  .security-content{flex:1}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <h1 class="mb-2"><i class="bi bi-shield-lock me-2"></i>Bảo mật tài khoản</h1>
      <p class="mb-0">Quản lý mật khẩu và cài đặt bảo mật</p>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Đổi mật khẩu -->
    <div class="card card-soft">
      <div class="card-header bg-white border-bottom">
        <h5 class="mb-0"><i class="bi bi-key me-2"></i>Đổi mật khẩu</h5>
      </div>
      <div class="card-body p-4">
        <form method="post" action="${pageContext.request.contextPath}/hospital/security" id="changePasswordForm">
          <input type="hidden" name="action" value="changePassword">
          <div class="mb-3">
            <label class="form-label">Mật khẩu hiện tại <span class="text-danger">*</span></label>
            <input type="password" class="form-control" name="currentPassword" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Mật khẩu mới <span class="text-danger">*</span></label>
            <input type="password" class="form-control" name="newPassword" 
                   minlength="6" required>
            <small class="text-muted">Mật khẩu phải có ít nhất 6 ký tự</small>
          </div>
          <div class="mb-3">
            <label class="form-label">Xác nhận mật khẩu mới <span class="text-danger">*</span></label>
            <input type="password" class="form-control" name="confirmPassword" required>
          </div>
          <button type="submit" class="btn btn-primary">
            <i class="bi bi-check-circle me-2"></i>Đổi mật khẩu
          </button>
        </form>
      </div>
    </div>

    <!-- Thông tin tài khoản -->
    <div class="card card-soft">
      <div class="card-header bg-white border-bottom">
        <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>Thông tin tài khoản</h5>
      </div>
      <div class="card-body p-0">
        <div class="security-item">
          <div class="d-flex align-items-center">
            <div class="security-icon primary">
              <i class="bi bi-envelope"></i>
            </div>
            <div class="security-content">
              <h6 class="mb-1">Email</h6>
              <p class="text-muted mb-0 small">${authUser.email}</p>
            </div>
          </div>
        </div>
        <div class="security-item">
          <div class="d-flex align-items-center">
            <div class="security-icon success">
              <i class="bi bi-person-check"></i>
            </div>
            <div class="security-content">
              <h6 class="mb-1">Trạng thái tài khoản</h6>
              <p class="text-muted mb-0 small">
                <c:choose>
                  <c:when test="${authUser.status == 'active'}">
                    <span class="badge bg-success">Đang hoạt động</span>
                  </c:when>
                  <c:otherwise>
                    <span class="badge bg-secondary">Đã khóa</span>
                  </c:otherwise>
                </c:choose>
              </p>
            </div>
          </div>
        </div>
        <div class="security-item">
          <div class="d-flex align-items-center">
            <div class="security-icon primary">
              <i class="bi bi-calendar"></i>
            </div>
            <div class="security-content">
              <h6 class="mb-1">Ngày tạo tài khoản</h6>
              <p class="text-muted mb-0 small">
                <fmt:formatDate value="${authUser.createdAt}" pattern="dd/MM/yyyy HH:mm"/>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex justify-content-start">
      <a href="${pageContext.request.contextPath}/hospital/dashboard" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Quay lại
      </a>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
    const newPassword = document.querySelector('input[name="newPassword"]').value;
    const confirmPassword = document.querySelector('input[name="confirmPassword"]').value;
    
    if (newPassword !== confirmPassword) {
      e.preventDefault();
      alert('Mật khẩu xác nhận không khớp!');
      return false;
    }
    
    if (newPassword.length < 6) {
      e.preventDefault();
      alert('Mật khẩu phải có ít nhất 6 ký tự!');
      return false;
    }
  });
</script>
</body>
</html>

