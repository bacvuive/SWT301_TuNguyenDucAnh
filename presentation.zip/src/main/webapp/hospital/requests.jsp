<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Quản lý Yêu cầu máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .table{background:#fff;border-radius:12px;overflow:hidden}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-list-check me-2"></i>Quản lý Yêu cầu máu</h1>
          <p class="mb-0">Theo dõi và quản lý các yêu cầu máu của bệnh viện</p>
        </div>
        <div class="d-flex gap-2">
          <a href="${pageContext.request.contextPath}/hospital/dashboard" class="btn btn-light">
            <i class="bi bi-arrow-left me-2"></i>Quay lại
          </a>
          <a href="${pageContext.request.contextPath}/hospital/requests/create" class="btn btn-light">
            <i class="bi bi-plus-circle me-2"></i>Tạo yêu cầu mới
          </a>
        </div>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert" style="border-radius: 12px;">
        <i class="bi bi-check-circle-fill me-2"></i><strong>Thành công!</strong> ${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </c:if>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert" style="border-radius: 12px;">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><strong>Lỗi!</strong> ${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </c:if>

    <!-- Bộ lọc -->
    <div class="card card-soft mb-4">
      <div class="card-body">
        <form method="get" class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Trạng thái</label>
            <select class="form-select" name="status">
              <option value="">Tất cả</option>
              <option value="PENDING">Đang chờ</option>
              <option value="COMPLETED">Đã hoàn thành</option>
              <option value="CANCELLED">Đã hủy</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Nhóm máu</label>
            <select class="form-select" name="bloodGroup">
              <option value="">Tất cả</option>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>
          <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-funnel me-2"></i>Lọc
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Tabs để chuyển đổi giữa Yêu cầu đã tạo và Yêu cầu đến -->
    <ul class="nav nav-tabs mb-4" id="requestTabs" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="outgoing-tab" data-bs-toggle="tab" data-bs-target="#outgoing" type="button" role="tab">
          <i class="bi bi-arrow-up-circle me-2"></i>Yêu cầu đã tạo
          <c:if test="${not empty outgoingRequests and outgoingRequests.size() > 0}">
            <span class="badge bg-primary ms-2">${outgoingRequests.size()}</span>
          </c:if>
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="incoming-tab" data-bs-toggle="tab" data-bs-target="#incoming" type="button" role="tab">
          <i class="bi bi-arrow-down-circle me-2"></i>Yêu cầu đến
          <c:if test="${not empty incomingRequests and incomingRequests.size() > 0}">
            <span class="badge bg-warning ms-2">${incomingRequests.size()}</span>
          </c:if>
        </button>
      </li>
    </ul>

    <div class="tab-content" id="requestTabsContent">
      <!-- Tab: Yêu cầu đã tạo (Outgoing) -->
      <div class="tab-pane fade show active" id="outgoing" role="tabpanel">
        <div class="card card-soft">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-hover mb-0">
                <thead class="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Nhóm máu</th>
                    <th>Thành phần</th>
                    <th>Số lượng</th>
                    <th>Gửi đến</th>
                    <th>Ngày tạo</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  <c:choose>
                    <c:when test="${not empty outgoingRequests and outgoingRequests.size() > 0}">
                      <c:forEach var="req" items="${outgoingRequests}">
                        <tr>
                          <td>#${req.requestId}</td>
                          <td><span class="badge bg-danger">${req.bloodGroup}</span></td>
                          <td>${req.component}</td>
                          <td>${req.quantity} đơn vị</td>
                          <td>
                            <c:choose>
                              <c:when test="${req.toHospitalId == null}">
                                <span class="badge bg-info">Tất cả bệnh viện</span>
                              </c:when>
                              <c:otherwise>
                                <c:choose>
                                  <c:when test="${req.toHospitalName != null}">
                                    <span class="badge bg-secondary">${req.toHospitalName}</span>
                                  </c:when>
                                  <c:otherwise>
                                    <span class="badge bg-secondary">Bệnh viện #${req.toHospitalId}</span>
                                  </c:otherwise>
                                </c:choose>
                              </c:otherwise>
                            </c:choose>
                          </td>
                          <td>
                            <c:if test="${req.createdAt != null}">
                              <fmt:formatDate value="${req.createdAt}" pattern="dd/MM/yyyy HH:mm" />
                            </c:if>
                          </td>
                          <td>
                            <span class="badge ${req.status == 'PENDING' ? 'bg-warning' : req.status == 'ACCEPTED' ? 'bg-info' : req.status == 'COMPLETED' ? 'bg-success' : req.status == 'REJECTED' ? 'bg-danger' : 'bg-secondary'}">
                              ${req.status == 'PENDING' ? 'Chờ xử lý' : req.status == 'ACCEPTED' ? 'Đã chấp nhận' : req.status == 'COMPLETED' ? 'Đã hoàn thành' : req.status == 'REJECTED' ? 'Đã từ chối' : req.status == 'CANCELLED' ? 'Đã hủy' : req.status}
                            </span>
                          </td>
                          <td>
                            <c:if test="${req.status == 'PENDING' or req.status == 'ACCEPTED'}">
                              <form method="post" action="${pageContext.request.contextPath}/requests/${req.requestId}/complete" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn hoàn tất yêu cầu này?');">
                                <button type="submit" class="btn btn-sm btn-success">
                                  <i class="bi bi-check-circle"></i> Hoàn tất
                                </button>
                              </form>
                            </c:if>
                          </td>
                        </tr>
                      </c:forEach>
                    </c:when>
                    <c:otherwise>
                      <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                          <i class="bi bi-inbox display-6 d-block mb-2"></i>
                          <p>Chưa có yêu cầu nào được tạo</p>
                          <a href="${pageContext.request.contextPath}/hospital/requests/create" class="btn btn-primary mt-2">
                            <i class="bi bi-plus-circle me-2"></i>Tạo yêu cầu đầu tiên
                          </a>
                        </td>
                      </tr>
                    </c:otherwise>
                  </c:choose>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- Tab: Yêu cầu đến (Incoming) -->
      <div class="tab-pane fade" id="incoming" role="tabpanel">
        <div class="card card-soft">
          <div class="card-body p-0">
            <div class="table-responsive">
              <table class="table table-hover mb-0">
                <thead class="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Nhóm máu</th>
                    <th>Thành phần</th>
                    <th>Số lượng</th>
                    <th>Yêu cầu từ</th>
                    <th>Ngày tạo</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  <c:choose>
                    <c:when test="${not empty incomingRequests and incomingRequests.size() > 0}">
                      <c:forEach var="req" items="${incomingRequests}">
                        <tr>
                          <td>#${req.requestId}</td>
                          <td><span class="badge bg-danger">${req.bloodGroup}</span></td>
                          <td>${req.component}</td>
                          <td>${req.quantity} đơn vị</td>
                          <td>
                            <c:choose>
                              <c:when test="${req.toHospitalId == null}">
                                <span class="badge bg-info">Broadcast</span>
                              </c:when>
                              <c:otherwise>
                                <c:choose>
                                  <c:when test="${req.fromHospitalName != null}">
                                    <span class="badge bg-primary">${req.fromHospitalName}</span>
                                  </c:when>
                                  <c:otherwise>
                                    <span class="badge bg-primary">Bệnh viện #${req.fromHospitalId}</span>
                                  </c:otherwise>
                                </c:choose>
                              </c:otherwise>
                            </c:choose>
                          </td>
                          <td>
                            <c:if test="${req.createdAt != null}">
                              <fmt:formatDate value="${req.createdAt}" pattern="dd/MM/yyyy HH:mm" />
                            </c:if>
                          </td>
                          <td>
                            <span class="badge ${req.status == 'PENDING' ? 'bg-warning' : req.status == 'ACCEPTED' ? 'bg-info' : req.status == 'COMPLETED' ? 'bg-success' : req.status == 'REJECTED' ? 'bg-danger' : 'bg-secondary'}">
                              ${req.status == 'PENDING' ? 'Chờ xử lý' : req.status == 'ACCEPTED' ? 'Đã chấp nhận' : req.status == 'COMPLETED' ? 'Đã hoàn thành' : req.status == 'REJECTED' ? 'Đã từ chối' : req.status == 'CANCELLED' ? 'Đã hủy' : req.status}
                            </span>
                          </td>
                          <td>
                            <c:if test="${req.status == 'PENDING'}">
                              <div class="btn-group" role="group">
                                <button type="button"
                                        class="btn btn-sm btn-success btn-open-accept"
                                        data-request-id="${req.requestId}"
                                        data-blood-group="${req.bloodGroup}"
                                        data-component="${req.component}"
                                        data-quantity="${req.quantity}">
                                  <i class="bi bi-check-circle"></i> Chấp nhận
                                </button>
                                <button type="button"
                                        class="btn btn-sm btn-danger btn-open-reject"
                                        data-request-id="${req.requestId}">
                                  <i class="bi bi-x-circle"></i> Từ chối
                                </button>
                              </div>
                            </c:if>
                            <c:if test="${req.status == 'ACCEPTED'}">
                              <form method="post" action="${pageContext.request.contextPath}/requests/${req.requestId}/complete" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn hoàn tất yêu cầu này?');">
                                <button type="submit" class="btn btn-sm btn-success">
                                  <i class="bi bi-check-circle"></i> Hoàn tất
                                </button>
                              </form>
                            </c:if>
                          </td>
                        </tr>
                      </c:forEach>
                    </c:when>
                    <c:otherwise>
                      <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                          <i class="bi bi-inbox display-6 d-block mb-2"></i>
                          <p>Chưa có yêu cầu nào đến</p>
                        </td>
                      </tr>
                    </c:otherwise>
                  </c:choose>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Accept Modal -->
<div class="modal fade" id="acceptRequestModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post">
        <div class="modal-header">
          <h5 class="modal-title">Xác nhận chấp nhận yêu cầu</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="text-muted mb-3" data-field="requestInfo"></p>
          <div class="mb-3">
            <label class="form-label">Thời gian gửi hàng bắt đầu</label>
            <input type="datetime-local" name="deliveryStart" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Thời gian gửi hàng kết thúc</label>
            <input type="datetime-local" name="deliveryEnd" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Ghi chú thêm (tuỳ chọn)</label>
            <textarea class="form-control" name="extraNote" rows="3" placeholder="Ví dụ: Liên hệ đầu mối khi có thay đổi"></textarea>
          </div>
          <input type="hidden" name="note">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Huỷ</button>
          <button type="submit" class="btn btn-success"><i class="bi bi-check-circle"></i> Xác nhận chấp nhận</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectRequestModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post">
        <div class="modal-header">
          <h5 class="modal-title">Lý do từ chối yêu cầu</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Lý do từ chối</label>
            <textarea class="form-control" name="rejectReason" rows="4" placeholder="Ví dụ: Không đủ đơn vị dự trữ" required></textarea>
          </div>
          <input type="hidden" name="note">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Huỷ</button>
          <button type="submit" class="btn btn-danger"><i class="bi bi-x-circle"></i> Xác nhận từ chối</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    var contextPath = '${pageContext.request.contextPath}';
    var acceptModalEl = document.getElementById('acceptRequestModal');
    var rejectModalEl = document.getElementById('rejectRequestModal');
    var acceptModal = acceptModalEl ? new bootstrap.Modal(acceptModalEl) : null;
    var rejectModal = rejectModalEl ? new bootstrap.Modal(rejectModalEl) : null;

    document.querySelectorAll('.btn-open-accept').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!acceptModal) {
          return;
        }
        var requestId = btn.getAttribute('data-request-id');
        var bloodGroup = btn.getAttribute('data-blood-group');
        var component = btn.getAttribute('data-component');
        var quantity = btn.getAttribute('data-quantity');

        var form = acceptModalEl.querySelector('form');
        form.reset();
        form.action = contextPath + '/requests/' + requestId + '/accept';
        form.setAttribute('data-request-info', 'Yêu cầu #' + requestId + ' - ' + quantity + ' đơn vị ' + bloodGroup + ' (' + component + ')');

        var infoLabel = acceptModalEl.querySelector('[data-field="requestInfo"]');
        if (infoLabel) {
          infoLabel.textContent = form.getAttribute('data-request-info');
        }

        var noteHidden = form.querySelector('input[name="note"]');
        if (noteHidden) {
          noteHidden.value = '';
        }

        acceptModal.show();
      });
    });

    document.querySelectorAll('.btn-open-reject').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!rejectModal) {
          return;
        }
        var requestId = btn.getAttribute('data-request-id');
        var form = rejectModalEl.querySelector('form');
        form.reset();
        form.action = contextPath + '/requests/' + requestId + '/reject';

        var noteHidden = form.querySelector('input[name="note"]');
        if (noteHidden) {
          noteHidden.value = '';
        }

        rejectModal.show();
      });
    });

    if (acceptModalEl) {
      var acceptForm = acceptModalEl.querySelector('form');
      acceptForm.addEventListener('submit', function (event) {
        var startInput = acceptForm.querySelector('input[name="deliveryStart"]');
        var endInput = acceptForm.querySelector('input[name="deliveryEnd"]');
        var extraInput = acceptForm.querySelector('textarea[name="extraNote"]');
        var noteField = acceptForm.querySelector('input[name="note"]');

        if (!startInput.value || !endInput.value) {
          event.preventDefault();
          alert('Vui lòng chọn đầy đủ thời gian dự kiến gửi/nhận máu.');
          return;
        }

        var startText = new Date(startInput.value).toLocaleString('vi-VN');
        var endText = new Date(endInput.value).toLocaleString('vi-VN');
        var note = 'Dự kiến điều phối từ ' + startText + ' đến ' + endText + '.';
        if (extraInput && extraInput.value && extraInput.value.trim().length > 0) {
          note += ' ' + extraInput.value.trim();
        }

        if (noteField) {
          noteField.value = note;
        }
      });
    }

    if (rejectModalEl) {
      var rejectForm = rejectModalEl.querySelector('form');
      rejectForm.addEventListener('submit', function (event) {
        var reasonInput = rejectForm.querySelector('textarea[name="rejectReason"]');
        var noteField = rejectForm.querySelector('input[name="note"]');
        if (!reasonInput.value || !reasonInput.value.trim()) {
          event.preventDefault();
          alert('Vui lòng nhập lý do từ chối.');
          return;
        }

        if (noteField) {
          noteField.value = reasonInput.value.trim();
        }
      });
    }
  });
</script>
</body>
</html>
