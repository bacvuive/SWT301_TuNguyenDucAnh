<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Tạo yêu cầu máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:800px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .form-label{font-weight:600;color:var(--bl-dark);margin-bottom:8px}
  .form-control:focus,.form-select:focus{border-color:var(--bl-red);box-shadow:0 0 0 0.2rem rgba(225,29,72,.25)}
  .btn-primary{background:var(--bl-red);border-color:var(--bl-red)}
  .btn-primary:hover{background:#c21845;border-color:#c21845}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-plus-circle me-2"></i>Tạo yêu cầu máu</h1>
          <p class="mb-0">Gửi yêu cầu máu khẩn cấp đến người hiến máu và các bệnh viện khác</p>
        </div>
        <a href="${pageContext.request.contextPath}/hospital/requests" class="btn btn-light">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <div id="clientFormError" class="alert alert-danger d-none" role="alert"></div>

    <form method="post" action="${pageContext.request.contextPath}/hospital/requests/create" id="createRequestForm">
      <div class="card card-soft">
        <div class="card-header bg-white border-bottom">
          <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>Thông tin yêu cầu</h5>
        </div>
        <div class="card-body p-4">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nhóm máu cần <span class="text-danger">*</span></label>
              <select class="form-select" name="bloodGroup" required>
                <option value="">Chọn nhóm máu</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Thành phần máu <span class="text-danger">*</span></label>
              <select class="form-select" name="component" required>
                <option value="">Chọn thành phần</option>
                <option value="WB">Máu toàn phần (WB)</option>
                <option value="RBC">Hồng cầu lắng (RBC)</option>
                <option value="PLT">Tiểu cầu (PLT)</option>
                <option value="FFP">Huyết tương tươi đông lạnh (FFP)</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Số lượng cần (đơn vị) <span class="text-danger">*</span></label>
              <input type="number" class="form-control" name="quantity" 
                     min="1" required placeholder="Ví dụ: 5">
              <small class="text-muted">Nhập số lượng đơn vị máu cần thiết</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Gửi đến</label>
              <select class="form-select" name="toHospitalId" id="toHospitalSelect">
                <option value="">Tất cả bệnh viện (Broadcast)</option>
                <c:if test="${not empty hospitals}">
                  <c:forEach var="hosp" items="${hospitals}">
                    <option value="${hosp.hospitalId}">${hosp.name}
                      <c:if test="${not empty hosp.region}"> - ${hosp.region}</c:if>
                    </option>
                  </c:forEach>
                </c:if>
              </select>
              <small class="text-muted">Chọn bệnh viện cụ thể hoặc để trống để gửi đến tất cả</small>
            </div>
          </div>
        </div>
      </div>

      <div class="card card-soft">
        <div class="card-header bg-white border-bottom">
          <h5 class="mb-0"><i class="bi bi-exclamation-triangle me-2"></i>Mức độ khẩn cấp</h5>
        </div>
        <div class="card-body p-4">
          <p class="text-muted mb-3">Yêu cầu này sẽ được gửi thông báo đến:</p>
          <ul class="list-unstyled">
            <li><i class="bi bi-check-circle-fill text-success me-2"></i>Tất cả người hiến máu có nhóm máu tương ứng</li>
            <li><i class="bi bi-check-circle-fill text-success me-2"></i>Các bệnh viện trong hệ thống (nếu chọn broadcast)</li>
            <li><i class="bi bi-check-circle-fill text-success me-2"></i>Bệnh viện được chỉ định (nếu chọn bệnh viện cụ thể)</li>
          </ul>
        </div>
      </div>

      <div class="d-flex justify-content-between gap-3">
        <a href="${pageContext.request.contextPath}/hospital/requests" class="btn btn-outline-secondary">
          <i class="bi bi-x-circle me-2"></i>Hủy
        </a>
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-send-fill me-2"></i>Tạo yêu cầu
        </button>
      </div>
    </form>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const createForm = document.getElementById('createRequestForm');
  const clientError = document.getElementById('clientFormError');
  const quantityInput = document.querySelector('input[name="quantity"]');

  function showClientError(message) {
    if (quantityInput) {
      quantityInput.classList.add('is-invalid');
    }
    if (clientError) {
      clientError.textContent = message;
      clientError.classList.remove('d-none');
      clientError.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      alert(message);
    }
  }

  if (createForm) {
    createForm.addEventListener('submit', function(e) {
      if (clientError) {
        clientError.classList.add('d-none');
        clientError.textContent = '';
      }
      if (quantityInput) {
        quantityInput.classList.remove('is-invalid');
      }

      const bloodGroup = document.querySelector('select[name="bloodGroup"]').value;
      const component = document.querySelector('select[name="component"]').value;
      const quantity = quantityInput ? quantityInput.value : '';

      const qtyNumber = quantity ? parseInt(quantity, 10) : NaN;
      let message = '';

      if (!bloodGroup || !component || !quantity) {
        message = 'Vui lòng điền đầy đủ thông tin yêu cầu!';
      } else if (Number.isNaN(qtyNumber) || qtyNumber < 1) {
        message = 'Số lượng phải lớn hơn 0!';
      }

      if (message) {
        e.preventDefault();
        showClientError(message);
        return false;
      }
    });
  }

  if (quantityInput) {
    quantityInput.addEventListener('invalid', function(e) {
      e.preventDefault();
      showClientError('Số lượng phải lớn hơn 0!');
    });

    quantityInput.addEventListener('input', function() {
      quantityInput.classList.remove('is-invalid');
      if (clientError) {
        clientError.classList.add('d-none');
        clientError.textContent = '';
      }
    });
  }
</script>
</body>
</html>

