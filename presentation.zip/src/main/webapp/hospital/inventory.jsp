<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Quản lý Kho máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .table{background:#fff;border-radius:12px;overflow:hidden}
  .badge-expired{background:#dc2626}
  .badge-warning-date{background:#f59e0b}
  .badge-available{background:#16a34a}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-box-seam me-2"></i>Quản lý Kho máu</h1>
          <p class="mb-0">Theo dõi và quản lý túi máu trong kho</p>
        </div>
        <a href="${pageContext.request.contextPath}/hospital/dashboard" class="btn btn-light">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Thống kê nhanh -->
    <div class="row g-3 mb-4">
      <div class="col-md-3">
        <div class="card card-soft">
          <div class="card-body text-center">
            <div class="display-6 text-primary mb-2"><i class="bi bi-droplet-fill"></i></div>
            <h4>${totalBags != null ? totalBags : 0}</h4>
            <p class="text-muted mb-0 small">Tổng túi máu</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft">
          <div class="card-body text-center">
            <div class="display-6 text-success mb-2"><i class="bi bi-check-circle-fill"></i></div>
            <h4>${availableBags != null ? availableBags : 0}</h4>
            <p class="text-muted mb-0 small">Đang có sẵn</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft">
          <div class="card-body text-center">
            <div class="display-6 text-warning mb-2"><i class="bi bi-clock-history"></i></div>
            <h4>${reservedBags != null ? reservedBags : 0}</h4>
            <p class="text-muted mb-0 small">Đã đặt trước</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft">
          <div class="card-body text-center">
            <div class="display-6 text-warning mb-2"><i class="bi bi-exclamation-triangle-fill"></i></div>
            <h4>${expiringSoonBags != null ? expiringSoonBags : 0}</h4>
            <p class="text-muted mb-0 small">Sắp hết hạn (≤7 ngày)</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-soft">
          <div class="card-body text-center">
            <div class="display-6 text-danger mb-2"><i class="bi bi-x-circle-fill"></i></div>
            <h4>${expiredBags != null ? expiredBags : 0}</h4>
            <p class="text-muted mb-0 small">Đã hết hạn</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Bộ lọc -->
    <div class="card card-soft mb-4">
      <div class="card-body">
        <form method="get" class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Nhóm máu</label>
            <select class="form-select" name="bloodGroup">
              <option value="">Tất cả</option>
              <option value="A+" ${selectedBloodGroup == 'A+' ? 'selected' : ''}>A+</option>
              <option value="A-" ${selectedBloodGroup == 'A-' ? 'selected' : ''}>A-</option>
              <option value="B+" ${selectedBloodGroup == 'B+' ? 'selected' : ''}>B+</option>
              <option value="B-" ${selectedBloodGroup == 'B-' ? 'selected' : ''}>B-</option>
              <option value="AB+" ${selectedBloodGroup == 'AB+' ? 'selected' : ''}>AB+</option>
              <option value="AB-" ${selectedBloodGroup == 'AB-' ? 'selected' : ''}>AB-</option>
              <option value="O+" ${selectedBloodGroup == 'O+' ? 'selected' : ''}>O+</option>
              <option value="O-" ${selectedBloodGroup == 'O-' ? 'selected' : ''}>O-</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Thành phần</label>
            <select class="form-select" name="component">
              <option value="">Tất cả</option>
              <option value="WB" ${selectedComponent == 'WB' ? 'selected' : ''}>Máu toàn phần (WB)</option>
              <option value="RBC" ${selectedComponent == 'RBC' ? 'selected' : ''}>Hồng cầu lắng (RBC)</option>
              <option value="PLT" ${selectedComponent == 'PLT' ? 'selected' : ''}>Tiểu cầu (PLT)</option>
              <option value="FFP" ${selectedComponent == 'FFP' ? 'selected' : ''}>Huyết tương tươi đông lạnh (FFP)</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Trạng thái</label>
            <select class="form-select" name="status">
              <option value="">Tất cả</option>
              <option value="AVAILABLE" ${selectedStatus == 'AVAILABLE' ? 'selected' : ''}>Có sẵn</option>
              <option value="RESERVED" ${selectedStatus == 'RESERVED' ? 'selected' : ''}>Đã đặt</option>
              <option value="IN_USE" ${selectedStatus == 'IN_USE' ? 'selected' : ''}>Đang sử dụng</option>
              <option value="TRANSFERRED" ${selectedStatus == 'TRANSFERRED' ? 'selected' : ''}>Đã chuyển</option>
              <option value="EXPIRED" ${selectedStatus == 'EXPIRED' ? 'selected' : ''}>Hết hạn</option>
            </select>
          </div>
          <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-funnel me-2"></i>Lọc
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Bảng danh sách -->
    <div class="card card-soft">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>Mã túi</th>
                <th>Nhóm máu</th>
                <th>Thành phần</th>
                <th>Thể tích (ml)</th>
                <th>Ngày thu thập</th>
                <th>Hạn sử dụng</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <c:choose>
                <c:when test="${not empty inventory and inventory.size() > 0}">
                  <c:forEach var="bag" items="${inventory}">
                    <tr>
                      <td><code>${bag.bagCode}</code></td>
                      <td><span class="badge bg-danger">${bag.bloodGroup}</span></td>
                      <td>${bag.component}</td>
                      <td>${bag.volumeMl} ml</td>
                      <td>
                        <c:if test="${bag.collectionDate != null}">
                          <fmt:formatDate value="${bag.collectionDate}" pattern="dd/MM/yyyy"/>
                        </c:if>
                      </td>
                      <td>
                        <c:if test="${bag.expiryDate != null}">
                          <fmt:formatDate value="${bag.expiryDate}" pattern="dd/MM/yyyy"/>
                          <c:if test="${bag.daysUntilExpiry != null}">
                            <c:choose>
                              <c:when test="${bag.daysUntilExpiry < 0}">
                                <span class="badge badge-expired ms-2">Hết hạn</span>
                              </c:when>
                              <c:when test="${bag.daysUntilExpiry >= 0 && bag.daysUntilExpiry <= 7}">
                                <span class="badge badge-warning-date ms-2">Còn ${bag.daysUntilExpiry} ngày</span>
                              </c:when>
                              <c:otherwise>
                                <span class="badge bg-success ms-2">Còn ${bag.daysUntilExpiry} ngày</span>
                              </c:otherwise>
                            </c:choose>
                          </c:if>
                        </c:if>
                      </td>
                      <td>
                        <c:choose>
                          <c:when test="${bag.status == 'AVAILABLE'}">
                            <span class="badge bg-success">Có sẵn</span>
                          </c:when>
                          <c:when test="${bag.status == 'RESERVED'}">
                            <span class="badge bg-warning text-dark">Đã đặt</span>
                          </c:when>
                          <c:when test="${bag.status == 'IN_USE'}">
                            <span class="badge bg-info">Đang dùng</span>
                          </c:when>
                          <c:when test="${bag.status == 'TRANSFERRED'}">
                            <span class="badge bg-secondary">Đã chuyển</span>
                          </c:when>
                          <c:when test="${bag.status == 'EXPIRED'}">
                            <span class="badge bg-danger">Hết hạn</span>
                          </c:when>
                          <c:otherwise>
                            <span class="badge bg-secondary">${bag.status}</span>
                          </c:otherwise>
                        </c:choose>
                      </td>
                      <td>
                        <button class="btn btn-sm btn-outline-primary" 
                                onclick="showBagDetails('${bag.bagCode}', '${bag.bloodGroup}', '${bag.component}', '${bag.volumeMl}', '${bag.status}')">
                          <i class="bi bi-eye"></i> Chi tiết
                        </button>
                      </td>
                    </tr>
                  </c:forEach>
                </c:when>
                <c:otherwise>
                  <tr>
                    <td colspan="8" class="text-center py-5 text-muted">
                      <i class="bi bi-inbox display-6 d-block mb-2"></i>
                      <p>Chưa có túi máu nào trong kho</p>
                    </td>
                  </tr>
                </c:otherwise>
              </c:choose>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  function showBagDetails(bagCode, bloodGroup, component, volumeMl, status) {
    const statusMap = {
      'AVAILABLE': 'Có sẵn',
      'RESERVED': 'Đã đặt',
      'IN_USE': 'Đang dùng',
      'TRANSFERRED': 'Đã chuyển',
      'EXPIRED': 'Hết hạn'
    };
    
    const componentMap = {
      'WB': 'Máu toàn phần',
      'RBC': 'Hồng cầu lắng',
      'PLT': 'Tiểu cầu',
      'FFP': 'Huyết tương tươi đông lạnh'
    };
    
    alert('Thông tin túi máu:\n\n' +
          'Mã túi: ' + bagCode + '\n' +
          'Nhóm máu: ' + bloodGroup + '\n' +
          'Thành phần: ' + (componentMap[component] || component) + '\n' +
          'Thể tích: ' + volumeMl + ' ml\n' +
          'Trạng thái: ' + (statusMap[status] || status));
  }
</script>
</body>
</html>

