<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Chỉnh sửa thông tin Bệnh viện</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:900px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .form-label{font-weight:600;color:var(--bl-dark);margin-bottom:8px}
  .form-control:focus{border-color:var(--bl-red);box-shadow:0 0 0 0.2rem rgba(225,29,72,.25)}
  .btn-primary{background:var(--bl-red);border-color:var(--bl-red)}
  .btn-primary:hover{background:#c21845;border-color:#c21845}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
        <div>
          <h1 class="mb-2"><i class="bi bi-hospital me-2"></i>Chỉnh sửa thông tin Bệnh viện</h1>
          <p class="mb-0">Cập nhật thông tin bệnh viện của bạn</p>
        </div>
        <c:if test="${not empty hospital}">
          <div class="text-md-end">
            <c:choose>
              <c:when test="${hospital.isVerified}">
                <span class="badge bg-success fs-6"><i class="bi bi-patch-check me-1"></i>Đã xác minh</span>
                <c:if test="${not empty hospitalVerifiedAt}">
                  <div class="small mt-1 text-white-50">Duyệt ngày: <fmt:formatDate value="${hospitalVerifiedAt}" pattern="dd/MM/yyyy HH:mm"/></div>
                </c:if>
              </c:when>
              <c:when test="${hasPendingVerification}">
                <span class="badge bg-warning text-dark fs-6"><i class="bi bi-hourglass-split me-1"></i>Đang chờ duyệt</span>
              </c:when>
              <c:otherwise>
                <span class="badge bg-secondary fs-6"><i class="bi bi-question-circle me-1"></i>Chưa xác minh</span>
              </c:otherwise>
            </c:choose>
            <a href="${pageContext.request.contextPath}/hospital/verification" class="btn btn-light btn-sm mt-2">
              <i class="bi bi-shield-check me-1"></i>Quản lý xác minh
            </a>
          </div>
        </c:if>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <c:choose>
      <c:when test="${empty hospital}">
        <div class="alert alert-warning" role="alert">
          <i class="bi bi-exclamation-triangle me-2"></i>Không tìm thấy thông tin bệnh viện. Vui lòng liên hệ quản trị viên.
        </div>
      </c:when>
      <c:otherwise>
        <form method="post" action="${pageContext.request.contextPath}/hospital/profile">
          <div class="card card-soft">
            <div class="card-header bg-white border-bottom">
              <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>Thông tin Bệnh viện</h5>
            </div>
            <div class="card-body p-4">
              <div class="row g-3">
                <div class="col-md-12">
                  <label class="form-label">Tên Bệnh viện <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" name="name" 
                         value="${hospital.name != null ? hospital.name : ''}" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Email</label>
                  <input type="email" class="form-control" 
                         value="${authUser.email != null ? authUser.email : ''}" disabled>
                  <small class="text-muted">Email không thể thay đổi</small>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Số điện thoại</label>
                  <input type="tel" class="form-control" name="contact" 
                         value="${hospital.contact != null ? hospital.contact : ''}" 
                         placeholder="0236-1234567">
                </div>
                <div class="col-12">
                  <label class="form-label">Địa chỉ <span class="text-danger">*</span></label>
                  <textarea class="form-control" name="address" rows="3" required
                            placeholder="Nhập địa chỉ bệnh viện">${hospital.address != null ? hospital.address : ''}</textarea>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Khu vực</label>
                  <select class="form-select" name="region">
                    <option value="">Chọn khu vực</option>
                    <option value="Miền Bắc" ${hospital.region == 'Miền Bắc' ? 'selected' : ''}>Miền Bắc</option>
                    <option value="Miền Trung" ${hospital.region == 'Miền Trung' ? 'selected' : ''}>Miền Trung</option>
                    <option value="Miền Nam" ${hospital.region == 'Miền Nam' ? 'selected' : ''}>Miền Nam</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div class="d-flex justify-content-between gap-3">
            <a href="${pageContext.request.contextPath}/hospital/dashboard" class="btn btn-outline-secondary">
              <i class="bi bi-arrow-left me-2"></i>Quay lại
            </a>
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-check-circle me-2"></i>Lưu thay đổi
            </button>
          </div>
        </form>
      </c:otherwise>
    </c:choose>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

