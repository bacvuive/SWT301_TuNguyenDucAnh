<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Ghi nhận hiến máu thành công</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <meta name="csrf-token" content="${_csrfToken}">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:800px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#10b981 0%,#059669 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .form-card{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);padding:30px}
  .info-box{background:#f8fafc;border-left:4px solid #10b981;padding:20px;border-radius:10px;margin-bottom:25px}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header text-center">
      <div class="d-flex align-items-center justify-content-center gap-3 mb-3">
        <div class="bg-white bg-opacity-20 rounded-circle p-3" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
          <i class="bi bi-heart-pulse-fill fs-2"></i>
        </div>
        <div>
          <h2 class="mb-0 fw-bold">Ghi nhận hiến máu thành công</h2>
          <p class="mb-0 opacity-75">Vui lòng nhập thông tin hiến máu</p>
        </div>
      </div>
    </div>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>
        <c:out value="${error}"/>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <div class="form-card">
      <form method="post" action="${pageContext.request.contextPath}/hospital/complete-donation" novalidate id="completeForm">
        <input type="hidden" name="appointmentId" value="${appointment.appointmentId}">
        <input type="hidden" name="_csrf" value="${_csrfToken}">
        
        <!-- Thông tin người hiến máu -->
        <div class="info-box">
          <div class="d-flex align-items-center gap-2 mb-3">
            <i class="bi bi-person-circle text-success fs-4"></i>
            <strong class="text-dark fs-5">Thông tin người hiến máu</strong>
          </div>
          <div class="row g-3">
            <div class="col-md-6">
              <span class="text-muted">Tên:</span>
              <strong class="d-block"><c:out value="${appointment.donorName != null ? appointment.donorName : 'N/A'}"/></strong>
            </div>
            <div class="col-md-6">
              <span class="text-muted">Nhóm máu đăng ký:</span>
              <strong class="d-block text-danger"><c:out value="${appointment.donorBloodGroup != null ? appointment.donorBloodGroup : 'N/A'}"/></strong>
            </div>
            <div class="col-md-6">
              <span class="text-muted">SĐT:</span>
              <strong class="d-block"><c:out value="${appointment.donorPhone != null ? appointment.donorPhone : 'N/A'}"/></strong>
            </div>
            <div class="col-md-6">
              <span class="text-muted">Mã lịch hẹn:</span>
              <strong class="d-block">#<c:out value="${appointment.appointmentId}"/></strong>
            </div>
          </div>
        </div>

        <!-- Thông tin túi máu -->
        <div class="mb-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <label class="form-label fw-semibold mb-0">
              <i class="bi bi-box-seam text-danger me-2"></i>
              Chi tiết túi máu tạo ra
            </label>
            <button type="button" class="btn btn-outline-primary btn-sm" id="btnAddBagRow">
              <i class="bi bi-plus-circle me-1"></i>Thêm túi
            </button>
          </div>
          <div class="table-responsive">
            <table class="table table-bordered align-middle" id="bagsTable">
              <thead class="table-light">
                <tr>
                  <th style="width: 25%">Nhóm máu <span class="text-danger">*</span></th>
                  <th style="width: 25%">Thành phần (Component) <span class="text-danger">*</span></th>
                  <th style="width: 25%">Số lượng (ml) <span class="text-danger">*</span></th>
                  <th style="width: 20%">Ngày thu thập</th>
                  <th style="width: 5%"></th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
          <div class="form-text text-muted">Mỗi túi máu sẽ được đưa vào kho với trạng thái <strong>AVAILABLE</strong>.</div>
        </div>
        
        <div class="alert alert-info border-0 rounded-3" style="background: #dbeafe; border-left: 4px solid #3b82f6 !important;">
          <div class="d-flex align-items-start gap-2">
            <i class="bi bi-info-circle-fill text-primary fs-5 mt-1"></i>
            <div>
              <strong class="d-block mb-1">Lưu ý quan trọng</strong>
              <p class="mb-0 small">
                Sau khi xác nhận, lịch hẹn sẽ được đánh dấu hoàn thành,
                bản ghi hiến máu sẽ được tạo và người hiến máu sẽ nhận được thông báo cùng chứng nhận hiến máu.
              </p>
            </div>
          </div>
        </div>

        <div class="d-flex gap-3 justify-content-end mt-4">
          <a href="${pageContext.request.contextPath}/hospital/appointments" class="btn btn-secondary btn-lg px-4" style="border-radius: 10px;">
            <i class="bi bi-x-circle me-2"></i>Hủy
          </a>
          <button type="submit" class="btn btn-success btn-lg px-4" id="submitBtn"
                  style="border-radius: 10px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); border: none;">
            <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            <i class="bi bi-check-circle me-2"></i>
            <span class="btn-text">Xác nhận hoàn thành</span>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function() {
  const form = document.getElementById('completeForm');
  const registeredBloodGroup = document.getElementById('registeredBloodGroup').textContent.trim();
  const submitBtn = document.getElementById('submitBtn');
  const bagsTableBody = document.querySelector('#bagsTable tbody');
  const btnAddBagRow = document.getElementById('btnAddBagRow');

  function createBloodGroupSelect(namePrefix, defaultValue) {
    const select = document.createElement('select');
    select.name = namePrefix + '[bloodGroup]';
    select.className = 'form-select';
    select.required = true;
    select.innerHTML = `
      <option value="">-- Chọn nhóm máu --</option>
      <option value="A+">A+</option>
      <option value="A-">A-</option>
      <option value="B+">B+</option>
      <option value="B-">B-</option>
      <option value="AB+">AB+</option>
      <option value="AB-">AB-</option>
      <option value="O+">O+</option>
      <option value="O-">O-</option>`;
    if (defaultValue) {
      select.value = defaultValue;
    }
    return select;
  }

  function createComponentSelect(namePrefix) {
    const select = document.createElement('select');
    select.name = namePrefix + '[component]';
    select.className = 'form-select';
    select.required = true;
    select.innerHTML = `
      <option value="">-- Chọn thành phần --</option>
      <option value="WB">Toàn phần (WB)</option>
      <option value="RBC">Hồng cầu (RBC)</option>
      <option value="PLT">Tiểu cầu (PLT)</option>
      <option value="FFP">Huyết tương tươi đông lạnh (FFP)</option>`;
    return select;
  }

  function addBagRow(initial) {
    const rowIndex = bagsTableBody.children.length;
    const row = document.createElement('tr');
    row.dataset.rowIndex = rowIndex;

    const bloodGroupCell = document.createElement('td');
    const bloodGroupSelect = createBloodGroupSelect('bags[' + rowIndex + ']', initial?.bloodGroup || (registeredBloodGroup !== 'N/A' ? registeredBloodGroup : ''));
    bloodGroupCell.appendChild(bloodGroupSelect);

    const componentCell = document.createElement('td');
    const componentSelect = createComponentSelect('bags[' + rowIndex + ']');
    componentSelect.value = initial?.component || '';
    componentCell.appendChild(componentSelect);

    const quantityCell = document.createElement('td');
    const quantityInput = document.createElement('input');
    quantityInput.type = 'number';
    quantityInput.name = 'bags[' + rowIndex + '][quantityMl]';
    quantityInput.className = 'form-control';
    quantityInput.required = true;
    quantityInput.min = '10';
    quantityInput.max = '1000';
    quantityInput.step = '10';
    quantityInput.placeholder = 'ml';
    if (initial?.quantityMl) {
      quantityInput.value = initial.quantityMl;
    }
    quantityCell.appendChild(quantityInput);

    const dateCell = document.createElement('td');
    const dateInput = document.createElement('input');
    dateInput.type = 'date';
    dateInput.name = 'bags[' + rowIndex + '][collectionDate]';
    dateInput.className = 'form-control';
    dateInput.value = initial?.collectionDate || new Date().toISOString().split('T')[0];
    dateCell.appendChild(dateInput);

    const actionCell = document.createElement('td');
    actionCell.className = 'text-center';
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'btn btn-outline-danger btn-sm btn-remove-row';
    removeBtn.innerHTML = '<i class="bi bi-trash"></i>';
    removeBtn.addEventListener('click', function () {
      if (bagsTableBody.children.length === 1) {
        alert('Cần ít nhất một túi máu.');
        return;
      }
      bagsTableBody.removeChild(row);
      reindexBagRows();
    });
    actionCell.appendChild(removeBtn);

    row.appendChild(bloodGroupCell);
    row.appendChild(componentCell);
    row.appendChild(quantityCell);
    row.appendChild(dateCell);
    row.appendChild(actionCell);

    bagsTableBody.appendChild(row);
  }

  function reindexBagRows() {
    Array.from(bagsTableBody.children).forEach(function (row, index) {
      row.dataset.rowIndex = index;
      row.querySelectorAll('select, input').forEach(function (input) {
        input.name = input.name.replace(/bags\[\d+\]/, 'bags[' + index + ']');
      });
    });
  }

  if (btnAddBagRow) {
    btnAddBagRow.addEventListener('click', function () {
      addBagRow();
    });
  }

  // Tạo dòng mặc định
  if (bagsTableBody.children.length === 0) {
    addBagRow({
      bloodGroup: registeredBloodGroup !== 'N/A' ? registeredBloodGroup : '',
      component: 'WB',
      quantityMl: 350
    });
  }

  // Form submit
  if (form) {
    form.addEventListener('submit', function(e) {
      if (!form.checkValidity()) {
        e.preventDefault();
        e.stopPropagation();
        form.classList.add('was-validated');
        return;
      }

      if (bagsTableBody.children.length === 0) {
        e.preventDefault();
        alert('Cần ít nhất một túi máu.');
        return;
      }

      // Disable submit button
      if (submitBtn) {
        submitBtn.disabled = true;
        const spinner = submitBtn.querySelector('.spinner-border');
        const btnText = submitBtn.querySelector('.btn-text');
        if (spinner) spinner.classList.remove('d-none');
        if (btnText) btnText.textContent = 'Đang xử lý...';
      }
    });
  }
})();
</script>
</body>
</html>

