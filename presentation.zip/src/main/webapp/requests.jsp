<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Yêu cầu máu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="header.jsp" %>

<style>
  .section{padding:72px 0}
  .section-title{font-weight:800;margin-bottom:12px}
  .muted{color:#64748b}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
  .bg-blush{background:#fff5f6}
  .bg-ice{background:linear-gradient(180deg,#f1f5ff 0%,#f8fbff 100%)}
</style>

<!-- =================== HERO =================== -->
<section class="bg-blush">
  <div class="container py-5">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold mb-3">
          Yêu cầu <span class="text-danger">Máu khẩn cấp</span>
        </h1>
        <p class="lead text-muted mb-4">
          Tìm kiếm người hiến máu phù hợp trong khu vực của bạn. 
          Mỗi yêu cầu có thể cứu sống một con người.
        </p>
        <div class="d-flex gap-3">
          <c:if test="${sessionScope.role != 'DONOR'}">
            <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/recipient/requests/create" class="btn btn-danger pill px-4">
              <i class="bi bi-plus-circle me-2"></i>Tạo yêu cầu máu
            </a>
          </c:if>
          <c:choose>
            <c:when test="${not empty sessionScope.authUser && sessionScope.role == 'DONOR'}">
              <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-outline-danger pill px-4">
                <i class="bi bi-calendar-check me-2"></i>Đặt lịch hiến máu
              </a>
            </c:when>
            <c:otherwise>
              <a href="${pageContext.request.contextPath}/register" class="btn btn-outline-danger pill px-4">
                <i class="bi bi-heart-fill me-2"></i>Đăng ký hiến máu
              </a>
            </c:otherwise>
          </c:choose>
        </div>
      </div>
      <div class="col-lg-6 text-center">
        <div class="card card-soft p-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-danger">${totalPending != null ? totalPending : 0}</div>
                <div class="small text-muted">Yêu cầu đang chờ</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-success">24/7</div>
                <div class="small text-muted">Hỗ trợ</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== BỘ LỌC =================== -->
<section class="section">
  <div class="container">
    <div class="card card-soft mb-4">
      <div class="card-body">
        <h5 class="fw-bold mb-3">Tìm kiếm yêu cầu máu</h5>
        <div class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Tỉnh/Thành</label>
            <select class="form-select">
              <option value="">Tất cả</option>
              <option>Hà Nội</option>
              <option>TP.HCM</option>
              <option>Đà Nẵng</option>
              <option>Hải Phòng</option>
              <option>Cần Thơ</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Nhóm máu</label>
            <select class="form-select">
              <option value="">Tất cả</option>
              <option>O-</option>
              <option>O+</option>
              <option>A-</option>
              <option>A+</option>
              <option>B-</option>
              <option>B+</option>
              <option>AB-</option>
              <option>AB+</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Mức độ khẩn cấp</label>
            <select class="form-select">
              <option value="">Tất cả</option>
              <option>Khẩn cấp</option>
              <option>Cần gấp</option>
              <option>Bình thường</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">&nbsp;</label>
            <div class="d-grid">
              <button class="btn btn-outline-secondary pill">Tìm kiếm</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- =================== DANH SÁCH YÊU CẦU =================== -->
    <div class="row g-4">
      <div class="col-lg-8">
        <h4 class="fw-bold mb-3">Yêu cầu máu gần đây</h4>
        
        <c:choose>
          <c:when test="${not empty requests && requests.size() > 0}">
            <c:forEach var="req" items="${requests}">
              <div class="card card-soft mb-3">
                <div class="card-body">
                  <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                      <h6 class="fw-bold mb-1">
                        Cần máu nhóm <span class="text-danger">${req.bloodGroup}</span>
                        <c:if test="${not empty req.component && req.component != 'WB'}">
                          <small class="text-muted">(${req.component})</small>
                        </c:if>
                      </h6>
                      <div class="small text-muted">
                        <i class="bi bi-geo-alt me-1"></i>${req.hospitalName}
                        <c:if test="${not empty req.hospitalAddress}"> - ${req.hospitalAddress}</c:if>
                        <span class="ms-3"><i class="bi bi-clock me-1"></i>${req.timeAgo}</span>
                      </div>
                    </div>
                    <span class="badge bg-${req.urgencyBadge} pill">${req.urgency}</span>
                  </div>
                  <div class="mb-3">
                    <p class="text-muted mb-2">
                      <strong>Số lượng cần:</strong> ${req.quantity} đơn vị
                      <c:if test="${not empty req.hospitalContact}">
                        <br><strong>Liên hệ:</strong> ${req.hospitalContact}
                      </c:if>
                    </p>
                  </div>
                  <div class="d-flex gap-2">
                    <c:choose>
                      <c:when test="${not empty sessionScope.authUser && sessionScope.role == 'DONOR'}">
                        <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-danger btn-sm pill">
                          <i class="bi bi-calendar-check me-1"></i>Đặt lịch hiến máu
                        </a>
                      </c:when>
                      <c:otherwise>
                        <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/donor/schedule" class="btn btn-danger btn-sm pill">
                          <i class="bi bi-heart-fill me-1"></i>Ứng tuyển hiến máu
                        </a>
                      </c:otherwise>
                    </c:choose>
                    <button class="btn btn-outline-secondary btn-sm pill" 
                            onclick="shareRequest('${req.requestId}', '${req.bloodGroup}', '${req.hospitalName}')">
                      <i class="bi bi-share me-1"></i>Chia sẻ
                    </button>
                  </div>
                </div>
              </div>
            </c:forEach>
          </c:when>
          <c:otherwise>
            <div class="card card-soft mb-3">
              <div class="card-body text-center py-5">
                <i class="bi bi-inbox display-4 text-muted d-block mb-3"></i>
                <h5 class="text-muted">Hiện chưa có yêu cầu máu nào</h5>
                <p class="text-muted">Các yêu cầu máu sẽ được hiển thị tại đây khi có bệnh viện tạo yêu cầu.</p>
              </div>
            </div>
          </c:otherwise>
        </c:choose>
      </div>

      <!-- =================== SIDEBAR =================== -->
      <div class="col-lg-4">
        <div class="card card-soft mb-4">
          <div class="card-body">
            <h6 class="fw-bold mb-3">Thống kê theo nhóm máu</h6>
            <div class="row g-2">
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-danger">O-</div>
                  <div class="small text-muted">${bloodGroupStats['O-'] != null ? bloodGroupStats['O-'] : 0} yêu cầu</div>
                </div>
              </div>
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-danger">O+</div>
                  <div class="small text-muted">${bloodGroupStats['O+'] != null ? bloodGroupStats['O+'] : 0} yêu cầu</div>
                </div>
              </div>
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-warning">A-</div>
                  <div class="small text-muted">${bloodGroupStats['A-'] != null ? bloodGroupStats['A-'] : 0} yêu cầu</div>
                </div>
              </div>
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-warning">A+</div>
                  <div class="small text-muted">${bloodGroupStats['A+'] != null ? bloodGroupStats['A+'] : 0} yêu cầu</div>
                </div>
              </div>
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-warning">B-</div>
                  <div class="small text-muted">${bloodGroupStats['B-'] != null ? bloodGroupStats['B-'] : 0} yêu cầu</div>
                </div>
              </div>
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-warning">B+</div>
                  <div class="small text-muted">${bloodGroupStats['B+'] != null ? bloodGroupStats['B+'] : 0} yêu cầu</div>
                </div>
              </div>
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-danger">AB-</div>
                  <div class="small text-muted">${bloodGroupStats['AB-'] != null ? bloodGroupStats['AB-'] : 0} yêu cầu</div>
                </div>
              </div>
              <div class="col-6">
                <div class="text-center p-2 border rounded">
                  <div class="fw-bold text-success">AB+</div>
                  <div class="small text-muted">${bloodGroupStats['AB+'] != null ? bloodGroupStats['AB+'] : 0} yêu cầu</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="card card-soft">
          <div class="card-body">
            <h6 class="fw-bold mb-3">Hướng dẫn</h6>
            <div class="small text-muted">
              <p><strong>1. Tìm yêu cầu phù hợp:</strong> Sử dụng bộ lọc để tìm yêu cầu máu gần bạn.</p>
              <p><strong>2. Kiểm tra điều kiện:</strong> Đảm bảo bạn đủ điều kiện hiến máu.</p>
              <p><strong>3. Liên hệ:</strong> Gọi điện trực tiếp cho bệnh viện để xác nhận.</p>
              <p><strong>4. Hiến máu:</strong> Đến địa điểm được chỉ định để hiến máu.</p>
            </div>
            <c:choose>
              <c:when test="${not empty sessionScope.authUser && sessionScope.role == 'DONOR'}">
                <a href="${pageContext.request.contextPath}/donor/schedule" class="btn btn-danger btn-sm pill w-100 mt-3">
                  <i class="bi bi-calendar-check me-1"></i>Đặt lịch hiến máu ngay
                </a>
              </c:when>
              <c:otherwise>
                <a href="${pageContext.request.contextPath}/register" class="btn btn-danger btn-sm pill w-100 mt-3">
                  <i class="bi bi-heart-fill me-1"></i>Đăng ký hiến máu ngay
                </a>
              </c:otherwise>
            </c:choose>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<%@ include file="footer.jsp" %>

<script>
function shareRequest(requestId, bloodGroup, hospitalName) {
  const url = window.location.href + '/' + requestId;
  const text = 'Yêu cầu máu khẩn cấp: Cần máu nhóm ' + bloodGroup + ' từ ' + hospitalName;
  
  if (navigator.share) {
    navigator.share({
      title: 'Yêu cầu máu khẩn cấp',
      text: text,
      url: url
    }).catch(console.error);
  } else {
    // Fallback: copy to clipboard
    const fullText = text + '\n' + url;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(fullText).then(() => {
        alert('Đã sao chép liên kết!');
      });
    } else {
      // Fallback cũ hơn
      const textarea = document.createElement('textarea');
      textarea.value = fullText;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      alert('Đã sao chép liên kết!');
    }
  }
}
</script>
</body>
</html>
