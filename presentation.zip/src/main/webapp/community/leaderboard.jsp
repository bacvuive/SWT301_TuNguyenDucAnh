<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Bảng xếp hạng</title>

  <style>
    :root{
      --bl-red:#e11d48; --bl-dark:#0f172a; --bl-text:#0b1220; --bl-muted:#6b7280;
    }
    .section{padding:72px 0}
    .section-title{font-weight:800;margin-bottom:12px;color:var(--bl-dark)}
    .muted{color:var(--bl-muted)}
    .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
    .placeholder{border:1px dashed rgba(234,179,8,.5);border-radius:16px;background:#fff}
  </style>
</head>
<body>
<%@ include file="/header.jsp" %>

<main class="section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-9">
        <div class="text-center mb-4">
          <h1 class="section-title">Bảng xếp hạng hiến máu</h1>
          <p class="muted">Tôn vinh những cá nhân và tổ chức tích cực đóng góp cho cộng đồng BloodLink.</p>
        </div>

        <div class="card card-soft placeholder p-4">
          <div class="text-center">
            <h5 class="fw-bold text-warning">Tính năng đang được phát triển</h5>
            <p class="muted mb-4">Khi hoàn thiện, trang này sẽ hiển thị bảng xếp hạng, huy hiệu và thử thách hiến máu.</p>
            <a class="btn btn-outline-danger pill px-4" href="${pageContext.request.contextPath}/community">Quay về Cộng đồng</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<%@ include file="/footer.jsp" %>
</body>
</html>

