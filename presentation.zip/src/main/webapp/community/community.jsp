<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Cộng đồng</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --bl-red:#e11d48; --bl-dark:#0f172a; --bl-text:#0b1220; --bl-border:#eef2f7; --bl-muted:#6b7280;
    }
    .section{padding:72px 0}
    .section-title{font-weight:800;margin-bottom:12px}
    .muted{color:#64748b}
    .pill{border-radius:999px}
    .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
    .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}
    .bg-blush{background:#fff5f6}
    .bg-ice{background:linear-gradient(180deg,#f1f5ff 0%,#f8fbff 100%)}

    /* Community add-ons */
    .create-post{border:1px dashed #e5e7eb;border-radius:16px;background:#fff}
    .create-post:focus-within{border-color:#e11d48; box-shadow:0 0 0 4px rgba(225,29,72,.08)}
  </style>
</head>
<body>
<%@ include file="../header.jsp" %>

<%-- ==== Trạng thái đăng nhập & vai trò (đừng đổi) ==== --%>
<c:set var="isLoggedIn" value="${not empty sessionScope.user}" />
<c:set var="role" value="${(not empty sessionScope.user and not empty sessionScope.user.role) ? sessionScope.user.role : 'GUEST'}" />
<c:set var="displayName" value="${(not empty sessionScope.user and not empty sessionScope.user.fullName) ? sessionScope.user.fullName : 'Khách'}" />


<!-- =================== HERO =================== -->
<section class="bg-blush">
  <div class="container py-5">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold mb-3">
          Cộng đồng <span class="text-danger">Hiến máu</span>
        </h1>
        <p class="lead text-muted mb-4">
          Kết nối với những người hiến máu khác, chia sẻ kinh nghiệm và 
          cùng nhau tạo nên một cộng đồng mạnh mẽ vì sự sống.
        </p>

        <div class="d-flex gap-3">
          <c:choose>
            <c:when test="${!isLoggedIn}">
              <!-- KHÁCH: CTA đăng ký/đăng nhập -->
              <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
                <i class="bi bi-heart-fill me-2"></i>Tham gia cộng đồng
              </a>
              <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger pill px-4">
                <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
              </a>
            </c:when>
            <c:otherwise>
              <!-- ĐÃ LOGIN: CTA hành động trong cộng đồng -->
              <a href="#create" class="btn btn-danger pill px-4">
                <i class="bi bi-pencil-square me-2"></i>Viết bài
              </a>
              <a href="${pageContext.request.contextPath}/profile" class="btn btn-outline-danger pill px-4">
                <i class="bi bi-person-circle me-2"></i>${displayName}
              </a>
              <span class="badge bg-light text-dark align-self-center pill">
                <i class="bi bi-shield-check me-1"></i>${role}
              </span>
            </c:otherwise>
          </c:choose>
        </div>
      </div>

      <div class="col-lg-6 text-center mt-4 mt-lg-0">
        <div class="card card-soft p-4">
          <div class="row g-3">
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-danger">15,247</div>
                <div class="small text-muted">Thành viên</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-success">2,500+</div>
                <div class="small text-muted">Bài chia sẻ</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-primary">500+</div>
                <div class="small text-muted">Sự kiện</div>
              </div>
            </div>
            <div class="col-6">
              <div class="text-center">
                <div class="display-6 fw-bold text-warning">24/7</div>
                <div class="small text-muted">Hỗ trợ</div>
              </div>
            </div>
          </div>
        </div>
      </div><!-- /col -->
    </div>
  </div>
</section>

<!-- =================== CREATE POST (chỉ hiện khi đã login) =================== -->
<section id="create" class="section pt-0">
  <div class="container">
    <c:choose>
      <c:when test="${isLoggedIn}">
        <div class="create-post p-3 mb-4">
          <div class="d-flex gap-3">
            <img class="rounded-circle" style="width: 48px; height: 48px; object-fit: cover"
                 src="https://i.pravatar.cc/80?img=12" alt="${displayName}">
            <form class="flex-grow-1" method="post" action="${pageContext.request.contextPath}/community/create" enctype="multipart/form-data">
              <input name="title" type="text" class="form-control pill mb-2" placeholder="Chia sẻ câu chuyện, đặt câu hỏi..." required>
              <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex gap-2">
                  <label class="btn btn-sm btn-outline-secondary pill mb-0">
                    <i class="bi bi-link-45deg me-1"></i>Đính kèm
                    <input type="file" name="image" hidden>
                  </label>
                  <button type="button" class="btn btn-sm btn-outline-secondary pill">
                    <i class="bi bi-tags me-1"></i>Gắn thẻ
                  </button>
                </div>
                <button type="submit" class="btn btn-danger pill">Đăng</button>
              </div>
            </form>
          </div>
        </div>
      </c:when>
      <c:otherwise>
        <!-- KHÁCH: chỉ xem; gợi ý đăng nhập nếu muốn đăng bài -->
        <div class="alert alert-light border d-flex justify-content-between align-items-center">
          <div><i class="bi bi-unlock me-2"></i>Bạn đang xem Community ở chế độ công khai. 
               Đăng nhập để viết bài, bình luận và tham gia sự kiện.</div>
          <div class="d-flex gap-2">
            <a class="btn btn-sm btn-outline-secondary pill" href="${pageContext.request.contextPath}/register">Đăng ký</a>
            <a class="btn btn-sm btn-danger pill" href="${pageContext.request.contextPath}/login">Đăng nhập</a>
          </div>
        </div>
      </c:otherwise>
    </c:choose>
  </div>
</section>

<!-- =================== TÍNH NĂNG CỘNG ĐỒNG =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Tính năng cộng đồng</h2>
    <p class="text-center muted mb-4">Khám phá các tính năng giúp bạn kết nối với cộng đồng</p>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-danger mb-3"><i class="bi bi-chat-dots"></i></div>
            <h5 class="fw-bold mb-3">Diễn đàn thảo luận</h5>
            <p class="text-muted mb-3">Tham gia thảo luận về hiến máu, chia sẻ kinh nghiệm và học hỏi từ cộng đồng</p>
            <a href="${pageContext.request.contextPath}/community/forum" class="btn btn-outline-danger pill">Vào diễn đàn</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-primary mb-3"><i class="bi bi-calendar-event"></i></div>
            <h5 class="fw-bold mb-3">Sự kiện hiến máu</h5>
            <p class="text-muted mb-3">Tham gia các sự kiện hiến máu được tổ chức trong cộng đồng</p>
            <a href="${pageContext.request.contextPath}/community/events" class="btn btn-outline-danger pill">Xem sự kiện</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-success mb-3"><i class="bi bi-people"></i></div>
            <h5 class="fw-bold mb-3">Nhóm địa phương</h5>
            <p class="text-muted mb-3">Kết nối với những người hiến máu trong khu vực của bạn</p>
            <a href="${pageContext.request.contextPath}/community/groups" class="btn btn-outline-danger pill">Tìm nhóm</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-warning mb-3"><i class="bi bi-trophy"></i></div>
            <h5 class="fw-bold mb-3">Bảng xếp hạng</h5>
            <p class="text-muted mb-3">Xem những người hiến máu tích cực nhất và tham gia thử thách</p>
            <a href="${pageContext.request.contextPath}/community/leaderboard" class="btn btn-outline-danger pill">Xem bảng</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-info mb-3"><i class="bi bi-share"></i></div>
            <h5 class="fw-bold mb-3">Chia sẻ câu chuyện</h5>
            <p class="text-muted mb-3">Chia sẻ câu chuyện hiến máu của bạn và truyền cảm hứng</p>
            <a href="${pageContext.request.contextPath}/community/stories" class="btn btn-outline-danger pill">Xem câu chuyện</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-soft h-100 text-center">
          <div class="card-body">
            <div class="display-6 text-secondary mb-3"><i class="bi bi-question-circle"></i></div>
            <h5 class="fw-bold mb-3">Hỗ trợ cộng đồng</h5>
            <p class="text-muted mb-3">Nhận hỗ trợ từ cộng đồng và giúp đỡ những người khác</p>
            <a href="${pageContext.request.contextPath}/community/support" class="btn btn-outline-danger pill">Xem hỗ trợ</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== CÂU CHUYỆN CỘNG ĐỒNG =================== -->
<section class="section bg-ice">
  <div class="container">
    <h2 class="text-center section-title">Câu chuyện từ cộng đồng</h2>
    <p class="text-center muted mb-4">Những câu chuyện cảm động từ các thành viên</p>

    <div class="row g-4">
      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3 mb-3">
              <img class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover"
                   src="<c:url value='/assets/images/story-nam.jpg'/>"
                   onerror="this.src='https://randomuser.me/api/portraits/men/32.jpg'">
              <div>
                <h6 class="fw-bold mb-1">Nguyễn Văn Nam</h6>
                <small class="text-muted">Hà Nội • 15 lần hiến máu</small>
              </div>
            </div>
            <p class="text-muted mb-3">"Tôi đã hiến máu 15 lần trong 3 năm qua. Mỗi lần hiến máu, tôi đều cảm thấy mình đang làm một việc có ý nghĩa. Có lần tôi nhận được tin nhắn cảm ơn từ gia đình người được cứu sống, đó là khoảnh khắc hạnh phúc nhất."</p>
            <div class="d-flex justify-content-between align-items-center">
              <small class="text-muted">2 ngày trước</small>
              <a href="${pageContext.request.contextPath}/community/story/1" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3 mb-3">
              <img class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover"
                   src="<c:url value='/assets/images/story-huong.jpg'/>"
                   onerror="this.src='https://randomuser.me/api/portraits/women/65.jpg'">
              <div>
                <h6 class="fw-bold mb-1">Trần Thị Hương</h6>
                <small class="text-muted">TP.HCM • 8 lần hiến máu</small>
              </div>
            </div>
            <p class="text-muted mb-3">"Là một y tá, tôi hiểu rõ tầm quan trọng của máu trong cứu chữa bệnh nhân. Hiến máu không chỉ giúp người khác mà còn giúp tôi kiểm tra sức khỏe định kỳ. Đây là cách tôi đóng góp cho xã hội."</p>
            <div class="d-flex justify-content-between align-items-center">
              <small class="text-muted">1 tuần trước</small>
              <a href="${pageContext.request.contextPath}/community/story/2" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3 mb-3">
              <img class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover"
                   src="<c:url value='/assets/images/story-tuan.jpg'/>"
                   onerror="this.src='https://randomuser.me/api/portraits/men/83.jpg'">
              <div>
                <h6 class="fw-bold mb-1">Lê Minh Tuấn</h6>
                <small class="text-muted">Đà Nẵng • 12 lần hiến máu</small>
              </div>
            </div>
            <p class="text-muted mb-3">"Tôi bắt đầu hiến máu từ năm nhất đại học. Ban đầu chỉ vì tò mò, nhưng sau đó tôi nhận ra đây là cách đơn giản nhất để giúp đỡ người khác. Giờ đây, hiến máu đã trở thành thói quen của tôi."</p>
            <div class="d-flex justify-content-between align-items-center">
              <small class="text-muted">3 ngày trước</small>
              <a href="${pageContext.request.contextPath}/community/story/3" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-start gap-3 mb-3">
              <img class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover"
                   src="https://randomuser.me/api/portraits/women/44.jpg">
              <div>
                <h6 class="fw-bold mb-1">Phạm Thị Mai</h6>
                <small class="text-muted">Cần Thơ • 6 lần hiến máu</small>
              </div>
            </div>
            <p class="text-muted mb-3">"Cảm ơn BloodLink đã giúp tôi kết nối với những người cần máu. Có lần tôi đã cứu sống một em bé chỉ trong vài giờ sau khi nhận được thông báo. Đó là điều tuyệt vời nhất tôi từng làm."</p>
            <div class="d-flex justify-content-between align-items-center">
              <small class="text-muted">5 ngày trước</small>
              <a href="${pageContext.request.contextPath}/community/story/4" class="btn btn-sm btn-outline-danger pill">Đọc tiếp</a>
            </div>
          </div>
        </div>
      </div>

    </div><!-- /row -->
  </div>
</section>

<!-- =================== SỰ KIỆN SẮP TỚI =================== -->
<section class="section">
  <div class="container">
    <h2 class="text-center section-title">Sự kiện sắp tới</h2>
    <p class="text-center muted mb-4">Tham gia các sự kiện hiến máu trong cộng đồng</p>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-3">
              <div>
                <h6 class="fw-bold mb-1">Chiến dịch hiến máu tại Đại học FPT</h6>
                <div class="small text-muted">
                  <i class="bi bi-geo-alt me-1"></i>Đại học FPT, Đà Nẵng
                  <br><i class="bi bi-calendar me-1"></i>25/12/2024 - 8:00-17:00
                </div>
              </div>
              <span class="badge bg-danger pill">Sắp diễn ra</span>
            </div>
            <p class="text-muted small mb-3">Sự kiện hiến máu lớn nhất trong năm với sự tham gia của hàng trăm sinh viên và giảng viên.</p>

            <c:choose>
              <c:when test="${isLoggedIn}">
                <a href="${pageContext.request.contextPath}/events/register/1" class="btn btn-danger btn-sm pill w-100">Tham gia</a>
              </c:when>
              <c:otherwise>
                <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/events/register/1" class="btn btn-danger btn-sm pill w-100">Đăng nhập để tham gia</a>
              </c:otherwise>
            </c:choose>

          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-3">
              <div>
                <h6 class="fw-bold mb-1">Ngày hội hiến máu tại TP.HCM</h6>
                <div class="small text-muted">
                  <i class="bi bi-geo-alt me-1"></i>Nhà văn hóa Thanh niên, TP.HCM
                  <br><i class="bi bi-calendar me-1"></i>30/12/2024 - 7:00-18:00
                </div>
              </div>
              <span class="badge bg-warning pill">Đang đăng ký</span>
            </div>
            <p class="text-muted small mb-3">Sự kiện đặc biệt với nhiều hoạt động vui chơi và quà tặng cho người tham gia.</p>

            <c:choose>
              <c:when test="${isLoggedIn}">
                <a href="${pageContext.request.contextPath}/events/register/2" class="btn btn-danger btn-sm pill w-100">Tham gia</a>
              </c:when>
              <c:otherwise>
                <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/events/register/2" class="btn btn-danger btn-sm pill w-100">Đăng nhập để tham gia</a>
              </c:otherwise>
            </c:choose>

          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-3">
              <div>
                <h6 class="fw-bold mb-1">Chương trình hiến máu tại Hà Nội</h6>
                <div class="small text-muted">
                  <i class="bi bi-geo-alt me-1"></i>Trung tâm Hội nghị Quốc gia, Hà Nội
                  <br><i class="bi bi-calendar me-1"></i>05/01/2025 - 8:00-16:00
                </div>
              </div>
              <span class="badge bg-primary pill">Mở đăng ký</span>
            </div>
            <p class="text-muted small mb-3">Sự kiện đầu năm với mục tiêu thu thập 1000 đơn vị máu cho các bệnh viện.</p>

            <c:choose>
              <c:when test="${isLoggedIn}">
                <a href="${pageContext.request.contextPath}/events/register/3" class="btn btn-danger btn-sm pill w-100">Tham gia</a>
              </c:when>
              <c:otherwise>
                <a href="${pageContext.request.contextPath}/login?next=${pageContext.request.contextPath}/events/register/3" class="btn btn-danger btn-sm pill w-100">Đăng nhập để tham gia</a>
              </c:otherwise>
            </c:choose>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- =================== KHỐI THEO ROLE (hiện khi đã login) =================== -->
<c:if test="${isLoggedIn}">
  <!-- ADMIN -->
  <c:if test="${role eq 'ADMIN'}">
    <section class="section pt-0">
      <div class="container">
        <div class="card card-soft p-3">
          <div class="d-flex align-items-center gap-2 mb-2">
            <i class="bi bi-shield-lock text-danger"></i>
            <strong>Khu vực Admin</strong>
          </div>
          <div class="d-flex gap-2 flex-wrap">
            <a class="btn btn-outline-danger btn-sm pill" href="${pageContext.request.contextPath}/admin/moderation">
              <i class="bi bi-flag me-1"></i>Duyệt báo cáo
            </a>
            <a class="btn btn-outline-danger btn-sm pill" href="${pageContext.request.contextPath}/admin/posts">
              <i class="bi bi-card-checklist me-1"></i>Quản lý bài viết
            </a>
          </div>
        </div>
      </div>
    </section>
  </c:if>

  <!-- HOSPITAL -->
  <c:if test="${role eq 'HOSPITAL'}">
    <section class="section pt-0">
      <div class="container">
        <div class="card card-soft p-3">
          <div class="d-flex align-items-center gap-2 mb-2">
            <i class="bi bi-hospital text-primary"></i>
            <strong>Dành cho Bệnh viện/Tổ chức</strong>
          </div>
          <a class="btn btn-primary pill" href="${pageContext.request.contextPath}/events/create">
            <i class="bi bi-calendar-plus me-1"></i>Tạo sự kiện hiến máu
          </a>
        </div>
      </div>
    </section>
  </c:if>
</c:if>

<!-- =================== CTA =================== -->
<section class="section bg-blush">
  <div class="container text-center">
    <h2 class="section-title">Tham gia cộng đồng ngay hôm nay</h2>
    <p class="muted mb-4">Kết nối với hàng nghìn người hiến máu và cùng nhau tạo nên sự khác biệt</p>
    <div class="d-flex gap-3 justify-content-center">
      <a href="${pageContext.request.contextPath}/register" class="btn btn-danger pill px-4">
        <i class="bi bi-heart-fill me-2"></i>Tham gia cộng đồng
      </a>
      <a href="${pageContext.request.contextPath}/login" class="btn btn-outline-danger pill px-4">
        <i class="bi bi-box-arrow-in-right me-2"></i>Đăng nhập
      </a>
    </div>
  </div>
</section>

<%@ include file="../footer.jsp" %>

<%-- Nếu footer.jsp đã có bundle JS rồi, có thể bỏ dòng dưới --%>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
