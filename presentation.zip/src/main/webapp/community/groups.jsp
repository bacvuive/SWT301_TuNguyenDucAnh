<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Nhóm địa phương</title>

  <style>
    :root{
      --bl-red:#e11d48; --bl-dark:#0f172a; --bl-text:#0b1220; --bl-muted:#6b7280;
    }
    .section{padding:72px 0}
    .section-title{font-weight:800;margin-bottom:12px;color:var(--bl-dark)}
    .muted{color:var(--bl-muted)}
    .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
    .placeholder{border:1px dashed rgba(16,185,129,.45);border-radius:16px;background:#fff}
  </style>
</head>
<body>
<%@ include file="/header.jsp" %>

<main class="section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-9">
        <div class="text-center mb-4">
          <h1 class="section-title">Nhóm địa phương</h1>
          <p class="muted">Kết nối với những người hiến máu quanh bạn, xây dựng cộng đồng địa phương năng động.</p>
        </div>

        <div class="card card-soft placeholder p-4">
          <div class="text-center">
            <h5 class="fw-bold text-success">Tính năng đang được phát triển</h5>
            <p class="muted mb-4">Chúng tôi sẽ sớm ra mắt danh sách nhóm theo khu vực và công cụ trò chuyện để bạn dễ dàng kết nối.</p>
            <a class="btn btn-danger pill px-4" href="${pageContext.request.contextPath}/community">Quay về Cộng đồng</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<%@ include file="/footer.jsp" %>
</body>
</html>

