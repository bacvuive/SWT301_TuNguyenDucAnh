<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Quản lý Bệnh viện (Admin)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .table{background:#fff;border-radius:12px;overflow:hidden}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-hospital-fill me-2"></i>Quản lý Bệnh viện</h1>
          <p class="mb-0">Xem danh sách và quản lý tất cả bệnh viện trong hệ thống</p>
        </div>
        <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-light">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Bảng danh sách -->
    <div class="card card-soft">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>ID</th>
                <th>Tên bệnh viện</th>
                <th>Email</th>
                <th>Địa chỉ</th>
                <th>Vùng</th>
                <th>Liên hệ</th>
                <th>Tọa độ</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <c:choose>
                <c:when test="${not empty hospitals and hospitals.size() > 0}">
                  <c:forEach var="hospital" items="${hospitals}">
                    <tr>
                      <td>${hospital.hospitalId}</td>
                      <td><strong>${hospital.name != null ? hospital.name : '—'}</strong></td>
                      <td>${hospital.email != null ? hospital.email : 'Chưa có tài khoản'}</td>
                      <td>${hospital.address != null ? hospital.address : '—'}</td>
                      <td>${hospital.region != null ? hospital.region : '—'}</td>
                      <td>${hospital.contact != null ? hospital.contact : '—'}</td>
                      <td>
                        <c:if test="${hospital.latitude != null and hospital.longitude != null}">
                          <small>${hospital.latitude}, ${hospital.longitude}</small>
                        </c:if>
                        <c:if test="${hospital.latitude == null or hospital.longitude == null}">—</c:if>
                      </td>
                      <td>
                        <c:choose>
                          <c:when test="${hospital.status == 'active'}">
                            <span class="badge bg-success">Hoạt động</span>
                          </c:when>
                          <c:when test="${hospital.status == 'inactive'}">
                            <span class="badge bg-secondary">Không hoạt động</span>
                          </c:when>
                          <c:when test="${hospital.status == 'no_account'}">
                            <span class="badge bg-warning">Chưa có tài khoản</span>
                          </c:when>
                          <c:otherwise>
                            <span class="badge bg-warning">${hospital.status != null ? hospital.status : '—'}</span>
                          </c:otherwise>
                        </c:choose>
                      </td>
                      <td>
                        <c:if test="${hospital.userId != null}">
                          <form method="post" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn ${hospital.status == 'active' ? 'vô hiệu hóa' : 'kích hoạt'} tài khoản này?');">
                            <input type="hidden" name="action" value="toggleStatus">
                            <input type="hidden" name="userId" value="${hospital.userId}">
                            <button type="submit" class="btn btn-sm ${hospital.status == 'active' ? 'btn-warning' : 'btn-success'}">
                              <i class="bi bi-${hospital.status == 'active' ? 'x-circle' : 'check-circle'}"></i>
                              ${hospital.status == 'active' ? 'Vô hiệu hóa' : 'Kích hoạt'}
                            </button>
                          </form>
                        </c:if>
                      </td>
                    </tr>
                  </c:forEach>
                </c:when>
                <c:otherwise>
                  <tr>
                    <td colspan="9" class="text-center py-5 text-muted">
                      <i class="bi bi-inbox display-6 d-block mb-2"></i>
                      <p>Chưa có bệnh viện nào</p>
                    </td>
                  </tr>
                </c:otherwise>
              </c:choose>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

