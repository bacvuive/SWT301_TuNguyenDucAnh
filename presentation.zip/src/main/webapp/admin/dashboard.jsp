<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Bảng điều khiển Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .dashboard-section{padding:40px 0}
  .pill{border-radius:999px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06)}
  .shadow-soft{box-shadow:0 12px 30px rgba(2,8,23,.10)}

  /* Dashboard Layout */
  .dashboard-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .dashboard-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .dashboard-header h1{font-weight:800;margin-bottom:8px}
  .dashboard-header p{opacity:.9;margin-bottom:0}

  /* Stats Grid */
  .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:30px}
  .stat-card{background:#fff;border-radius:16px;padding:24px;text-align:center;border:1px solid var(--bl-border);transition:transform .2s ease,box-shadow .2s ease}
  .stat-card:hover{transform:translateY(-4px);box-shadow:0 20px 40px rgba(2,8,23,.1)}
  .stat-card .icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:20px}
  .stat-card .icon.danger{background:#fee2e2;color:#dc2626}
  .stat-card .icon.success{background:#dcfce7;color:#16a34a}
  .stat-card .icon.warning{background:#fef3c7;color:#d97706}
  .stat-card .icon.info{background:#dbeafe;color:#2563eb}
  .stat-card h3{font-weight:800;margin-bottom:4px;color:var(--bl-dark);font-size:32px}
  .stat-card p{margin:0;color:var(--bl-muted);font-size:14px}

  /* Quick Actions */
  .quick-actions{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-bottom:30px}
  .action-card{background:#fff;border-radius:16px;padding:24px;border:1px solid var(--bl-border);transition:all .2s ease}
  .action-card:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(2,8,23,.08)}
  .action-card .icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;font-size:18px}
  .action-card .icon.danger{background:#fee2e2;color:#dc2626}
  .action-card .icon.warning{background:#fef3c7;color:#d97706}
  .action-card .icon.info{background:#dbeafe;color:#2563eb}
  .action-card h5{font-weight:700;margin-bottom:8px;color:var(--bl-dark)}
  .action-card p{margin-bottom:16px;color:var(--bl-muted);font-size:14px}
  .action-card .btn{width:100%;border-radius:10px;font-weight:600}

  /* Table */
  .table-card{background:#fff;border-radius:16px;padding:24px;border:1px solid var(--bl-border)}
  .table-card h5{font-weight:700;margin-bottom:20px;color:var(--bl-dark)}
  .table{font-size:14px}
  .table thead{background:#f8fafc}
  .table th{border:none;padding:12px;font-weight:600;color:var(--bl-dark)}
  .table td{border:none;padding:12px;vertical-align:middle}
  .table tbody tr{border-bottom:1px solid #f1f5f9}
  .table tbody tr:hover{background:#f8fafc}

  /* Responsive */
  @media (max-width:768px){
    .dashboard-header{padding:20px;margin-bottom:20px}
    .stats-grid{grid-template-columns:repeat(2,1fr);gap:15px}
    .quick-actions{grid-template-columns:1fr;gap:15px}
  }
</style>

<div class="dashboard-section">
  <div class="dashboard-container">

    <!-- Dashboard Header -->
    <div class="dashboard-header">
      <h1>Xin chào, <c:out value="${sessionScope.authUser != null ? sessionScope.authUser.email : 'Admin'}"/></h1>
      <p>Chào mừng bạn đến với bảng điều khiển quản trị. Quản lý người dùng, bệnh viện và hệ thống.</p>
    </div>

    <!-- Success/Error Messages -->
    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert" style="border-radius: 12px; margin-bottom: 20px;">
        <i class="bi bi-check-circle-fill me-2"></i><strong>Thành công!</strong> ${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </c:if>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert" style="border-radius: 12px; margin-bottom: 20px;">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><strong>Lỗi!</strong> ${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    </c:if>

    <!-- Stats Grid -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="icon info">
          <i class="bi bi-people-fill"></i>
        </div>
        <h3>${totalUsers != null ? totalUsers : 0}</h3>
        <p>Tổng người dùng</p>
      </div>
      <div class="stat-card">
        <div class="icon success">
          <i class="bi bi-heart-fill"></i>
        </div>
        <h3>${totalDonors != null ? totalDonors : 0}</h3>
        <p>Người hiến máu</p>
      </div>
      <div class="stat-card">
        <div class="icon warning">
          <i class="bi bi-hospital-fill"></i>
        </div>
        <h3>${totalHospitals != null ? totalHospitals : 0}</h3>
        <p>Bệnh viện</p>
      </div>
      <div class="stat-card">
        <div class="icon danger">
          <i class="bi bi-check-circle-fill"></i>
        </div>
        <h3>${activeUsers != null ? activeUsers : 0}</h3>
        <p>Tài khoản hoạt động</p>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions">
      <div class="action-card">
        <div class="icon info">
          <i class="bi bi-person-gear"></i>
        </div>
        <h5>Quản lý người dùng</h5>
        <p>Xem và quản lý tất cả người dùng trong hệ thống.</p>
        <a href="${pageContext.request.contextPath}/admin/manage-user" class="btn btn-info">Quản lý người dùng</a>
      </div>

      <div class="action-card">
        <div class="icon success">
          <i class="bi bi-people"></i>
        </div>
        <h5>Quản lý người hiến</h5>
        <p>Xem và quản lý danh sách người hiến máu trong hệ thống.</p>
        <a href="${pageContext.request.contextPath}/admin/manage-donor" class="btn btn-success">Quản lý người hiến</a>
      </div>

      <div class="action-card">
        <div class="icon warning">
          <i class="bi bi-hospital"></i>
        </div>
        <h5>Quản lý bệnh viện</h5>
        <p>Xem và quản lý danh sách bệnh viện trong hệ thống.</p>
        <a href="${pageContext.request.contextPath}/admin/manage-hospital" class="btn btn-warning">Quản lý bệnh viện</a>
      </div>

      <div class="action-card">
        <div class="icon danger">
          <i class="bi bi-heart-pulse"></i>
        </div>
        <h5>Quản lý yêu cầu máu</h5>
        <p>Xem và quản lý tất cả yêu cầu máu trong hệ thống.</p>
        <a href="${pageContext.request.contextPath}/admin/manage-request" class="btn btn-danger">Quản lý yêu cầu</a>
      </div>

      <div class="action-card">
        <div class="icon secondary">
          <i class="bi bi-clock-history"></i>
        </div>
        <h5>Lịch sử hoạt động</h5>
        <p>Xem lịch sử các hoạt động và thay đổi trong hệ thống.</p>
        <a href="${pageContext.request.contextPath}/admin/history" class="btn btn-secondary">Xem lịch sử</a>
      </div>
    </div>

    <!-- Hospitals List -->
    <c:if test="${not empty hospitals}">
      <div class="table-card">
        <h5><i class="bi bi-hospital me-2"></i>Danh sách bệnh viện</h5>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Tên bệnh viện</th>
                <th>Địa chỉ</th>
                <th>Vùng</th>
                <th>Liên hệ</th>
              </tr>
            </thead>
            <tbody>
              <c:forEach var="hospital" items="${hospitals}">
                <tr>
                  <td>${hospital.hospitalId}</td>
                  <td><strong>${hospital.name}</strong></td>
                  <td>${hospital.address != null ? hospital.address : '—'}</td>
                  <td>${hospital.region != null ? hospital.region : '—'}</td>
                  <td>${hospital.contact != null ? hospital.contact : '—'}</td>
                </tr>
              </c:forEach>
            </tbody>
          </table>
        </div>
      </div>
    </c:if>

    <!-- Notifications -->
    <c:if test="${not empty notifications}">
      <div class="table-card mt-4">
        <h5><i class="bi bi-bell-fill me-2"></i>Thông báo mới</h5>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Loại</th>
                <th>Tiêu đề</th>
                <th>Nội dung</th>
                <th>Thời gian</th>
              </tr>
            </thead>
            <tbody>
              <c:forEach var="notif" items="${notifications}">
                <tr>
                  <td><span class="badge bg-info">${notif.type}</span></td>
                  <td><strong>${notif.subject}</strong></td>
                  <td>${notif.message}</td>
                  <td>
                    <c:if test="${not empty notif.createdAt}">
                      <fmt:formatDate value="${notif.createdAt}" pattern="dd/MM/yyyy HH:mm"/>
                    </c:if>
                  </td>
                </tr>
              </c:forEach>
            </tbody>
          </table>
        </div>
      </div>
    </c:if>

  </div>
</div>

<%@ include file="/footer.jsp" %>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

