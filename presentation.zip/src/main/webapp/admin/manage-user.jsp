<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Quản lý Người dùng (Admin)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .table{background:#fff;border-radius:12px;overflow:hidden}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-person-gear me-2"></i>Quản lý Người dùng</h1>
          <p class="mb-0">Xem danh sách và quản lý tất cả người dùng trong hệ thống</p>
        </div>
        <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-light">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Bộ lọc -->
    <div class="card card-soft mb-4">
      <div class="card-body">
        <form method="get" class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Vai trò</label>
            <select class="form-select" name="role">
              <option value="">Tất cả</option>
              <option value="hospital" ${selectedRole == 'hospital' ? 'selected' : ''}>Bệnh viện</option>
              <option value="donor" ${selectedRole == 'donor' ? 'selected' : ''}>Người hiến máu</option>
            </select>
            <small class="text-muted">Admin accounts được ẩn để bảo mật</small>
          </div>
          <div class="col-md-3">
            <label class="form-label">Trạng thái</label>
            <select class="form-select" name="status">
              <option value="">Tất cả</option>
              <option value="active" ${selectedStatus == 'active' ? 'selected' : ''}>Hoạt động</option>
              <option value="inactive" ${selectedStatus == 'inactive' ? 'selected' : ''}>Không hoạt động</option>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Tìm kiếm</label>
            <input type="text" class="form-control" name="search" placeholder="ID, email, username..." value="${searchQuery}">
          </div>
          <div class="col-md-2 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-search me-2"></i>Lọc
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Bảng danh sách -->
    <div class="card card-soft">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Vai trò</th>
                <th>Thông tin thêm</th>
                <th>Trạng thái</th>
                <th>Ngày tạo</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <c:choose>
                <c:when test="${not empty users and users.size() > 0}">
                  <c:forEach var="user" items="${users}">
                    <tr>
                      <td>${user.userId}</td>
                      <td><strong>${user.username != null ? user.username : '—'}</strong></td>
                      <td>${user.email != null ? user.email : '—'}</td>
                      <td>
                        <c:choose>
                          <c:when test="${user.roleCode == 'admin'}">
                            <span class="badge bg-danger">Admin</span>
                          </c:when>
                          <c:when test="${user.roleCode == 'hospital'}">
                            <span class="badge bg-warning">Bệnh viện</span>
                          </c:when>
                          <c:when test="${user.roleCode == 'donor'}">
                            <span class="badge bg-info">Người hiến</span>
                          </c:when>
                          <c:otherwise>
                            <span class="badge bg-secondary">${user.roleCode != null ? user.roleCode : '—'}</span>
                          </c:otherwise>
                        </c:choose>
                      </td>
                      <td>
                        <c:if test="${user.fullName != null}">
                          <small><i class="bi bi-person"></i> ${user.fullName}</small><br>
                        </c:if>
                        <c:if test="${user.hospitalName != null}">
                          <small><i class="bi bi-hospital"></i> ${user.hospitalName}</small><br>
                        </c:if>
                        <c:if test="${user.phone != null}">
                          <small><i class="bi bi-telephone"></i> ${user.phone}</small>
                        </c:if>
                        <c:if test="${user.region != null}">
                          <small><i class="bi bi-geo-alt"></i> ${user.region}</small>
                        </c:if>
                        <c:if test="${user.fullName == null and user.hospitalName == null and user.phone == null and user.region == null}">
                          <small class="text-muted">—</small>
                        </c:if>
                      </td>
                      <td>
                        <c:choose>
                          <c:when test="${user.status == 'active'}">
                            <span class="badge bg-success">Hoạt động</span>
                          </c:when>
                          <c:when test="${user.status == 'inactive'}">
                            <span class="badge bg-secondary">Không hoạt động</span>
                          </c:when>
                          <c:otherwise>
                            <span class="badge bg-warning">${user.status != null ? user.status : '—'}</span>
                          </c:otherwise>
                        </c:choose>
                      </td>
                      <td>
                        <c:if test="${user.createdAt != null}">
                          <fmt:formatDate value="${user.createdAt}" pattern="dd/MM/yyyy"/>
                        </c:if>
                        <c:if test="${user.createdAt == null}">—</c:if>
                      </td>
                      <td>
                        <div class="btn-group" role="group">
                          <!-- Toggle Status -->
                          <form method="post" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn ${user.status == 'active' ? 'vô hiệu hóa' : 'kích hoạt'} tài khoản này?');">
                            <input type="hidden" name="action" value="toggleStatus">
                            <input type="hidden" name="userId" value="${user.userId}">
                            <button type="submit" class="btn btn-sm ${user.status == 'active' ? 'btn-warning' : 'btn-success'}" title="${user.status == 'active' ? 'Vô hiệu hóa' : 'Kích hoạt'}">
                              <i class="bi bi-${user.status == 'active' ? 'x-circle' : 'check-circle'}"></i>
                            </button>
                          </form>
                          
                          <!-- Change Role -->
                          <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#roleModal${user.userId}" title="Đổi vai trò">
                            <i class="bi bi-person-badge"></i>
                          </button>
                          
                          <!-- Reset Password -->
                          <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#passwordModal${user.userId}" title="Reset mật khẩu">
                            <i class="bi bi-key"></i>
                          </button>
                        </div>
                        
                        <!-- Role Change Modal -->
                        <div class="modal fade" id="roleModal${user.userId}" tabindex="-1">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title">Đổi vai trò</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                              </div>
                              <form method="post">
                                <div class="modal-body">
                                  <input type="hidden" name="action" value="updateRole">
                                  <input type="hidden" name="userId" value="${user.userId}">
                                  <div class="mb-3">
                                    <label class="form-label">Vai trò hiện tại: <strong>${user.roleCode}</strong></label>
                                    <select class="form-select" name="newRole" required>
                                      <option value="hospital" ${user.roleCode == 'hospital' ? 'selected' : ''}>Bệnh viện</option>
                                      <option value="donor" ${user.roleCode == 'donor' ? 'selected' : ''}>Người hiến máu</option>
                                    </select>
                                    <small class="text-muted">Không thể đổi thành Admin (bảo mật)</small>
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                                  <button type="submit" class="btn btn-primary">Cập nhật</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                        
                        <!-- Password Reset Modal -->
                        <div class="modal fade" id="passwordModal${user.userId}" tabindex="-1">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title">Reset mật khẩu</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                              </div>
                              <form method="post">
                                <div class="modal-body">
                                  <input type="hidden" name="action" value="resetPassword">
                                  <input type="hidden" name="userId" value="${user.userId}">
                                  <div class="mb-3">
                                    <label class="form-label">Mật khẩu mới</label>
                                    <input type="password" class="form-control" name="newPassword" required minlength="6" placeholder="Tối thiểu 6 ký tự">
                                    <small class="form-text text-muted">Mật khẩu sẽ được reset cho user: ${user.email}</small>
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                                  <button type="submit" class="btn btn-primary" onclick="return confirm('Bạn có chắc muốn reset mật khẩu cho ${user.email}?');">Reset</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </c:forEach>
                </c:when>
                <c:otherwise>
                  <tr>
                    <td colspan="8" class="text-center py-5 text-muted">
                      <i class="bi bi-inbox display-6 d-block mb-2"></i>
                      <p>Chưa có người dùng nào</p>
                    </td>
                  </tr>
                </c:otherwise>
              </c:choose>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

