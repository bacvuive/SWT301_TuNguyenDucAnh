<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Quản lý Yêu cầu Máu (Admin)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0b1220; --bl-muted:#64748b; --bl-border:#eef2f7; }
  .page-section{padding:40px 0}
  .page-container{max-width:1400px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .table{background:#fff;border-radius:12px;overflow:hidden}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="mb-2"><i class="bi bi-heart-pulse me-2"></i>Quản lý Yêu cầu Máu</h1>
          <p class="mb-0">Xem danh sách và quản lý tất cả yêu cầu máu trong hệ thống</p>
        </div>
        <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-light">
          <i class="bi bi-arrow-left me-2"></i>Quay lại
        </a>
      </div>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <!-- Bộ lọc -->
    <div class="card card-soft mb-4">
      <div class="card-body">
        <form method="get" class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Trạng thái</label>
            <select class="form-select" name="status">
              <option value="">Tất cả</option>
              <option value="PENDING" ${selectedStatus == 'PENDING' ? 'selected' : ''}>Đang chờ</option>
              <option value="ACCEPTED" ${selectedStatus == 'ACCEPTED' ? 'selected' : ''}>Đã chấp nhận</option>
              <option value="REJECTED" ${selectedStatus == 'REJECTED' ? 'selected' : ''}>Đã từ chối</option>
              <option value="COMPLETED" ${selectedStatus == 'COMPLETED' ? 'selected' : ''}>Hoàn thành</option>
              <option value="CANCELLED" ${selectedStatus == 'CANCELLED' ? 'selected' : ''}>Đã hủy</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Nhóm máu</label>
            <select class="form-select" name="bloodGroup">
              <option value="">Tất cả</option>
              <option value="A+" ${selectedBloodGroup == 'A+' ? 'selected' : ''}>A+</option>
              <option value="A-" ${selectedBloodGroup == 'A-' ? 'selected' : ''}>A-</option>
              <option value="B+" ${selectedBloodGroup == 'B+' ? 'selected' : ''}>B+</option>
              <option value="B-" ${selectedBloodGroup == 'B-' ? 'selected' : ''}>B-</option>
              <option value="AB+" ${selectedBloodGroup == 'AB+' ? 'selected' : ''}>AB+</option>
              <option value="AB-" ${selectedBloodGroup == 'AB-' ? 'selected' : ''}>AB-</option>
              <option value="O+" ${selectedBloodGroup == 'O+' ? 'selected' : ''}>O+</option>
              <option value="O-" ${selectedBloodGroup == 'O-' ? 'selected' : ''}>O-</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Bệnh viện</label>
            <select class="form-select" name="hospitalId">
              <option value="">Tất cả</option>
              <c:forEach var="hospital" items="${hospitals}">
                <option value="${hospital.hospitalId}" ${selectedHospitalId == hospital.hospitalId.toString() ? 'selected' : ''}>
                  ${hospital.name}
                </option>
              </c:forEach>
            </select>
          </div>
          <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-search me-2"></i>Lọc
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Bảng danh sách -->
    <div class="card card-soft">
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>ID</th>
                <th>Từ bệnh viện</th>
                <th>Đến bệnh viện</th>
                <th>Nhóm máu</th>
                <th>Thành phần</th>
                <th>Số lượng</th>
                <th>Trạng thái</th>
                <th>Ngày tạo</th>
                <th>Thao tác</th>
              </tr>
            </thead>
            <tbody>
              <c:choose>
                <c:when test="${not empty requests and requests.size() > 0}">
                  <c:forEach var="req" items="${requests}">
                    <tr>
                      <td>${req.requestId}</td>
                      <td>
                        <strong>${req.fromHospitalName != null ? req.fromHospitalName : '—'}</strong><br>
                        <small class="text-muted">${req.fromHospitalRegion != null ? req.fromHospitalRegion : '—'}</small>
                      </td>
                      <td>
                        <strong>${req.toHospitalName != null ? req.toHospitalName : '—'}</strong><br>
                        <small class="text-muted">${req.toHospitalRegion != null ? req.toHospitalRegion : '—'}</small>
                      </td>
                      <td><span class="badge bg-danger">${req.bloodGroup != null ? req.bloodGroup : '—'}</span></td>
                      <td>
                        <c:choose>
                          <c:when test="${req.component == 'WB'}">Toàn phần</c:when>
                          <c:when test="${req.component == 'RBC'}">Hồng cầu</c:when>
                          <c:when test="${req.component == 'PLT'}">Tiểu cầu</c:when>
                          <c:when test="${req.component == 'FFP'}">Huyết tương</c:when>
                          <c:otherwise>${req.component != null ? req.component : '—'}</c:otherwise>
                        </c:choose>
                      </td>
                      <td><strong>${req.quantity != null ? req.quantity : 0}</strong> đơn vị</td>
                      <td>
                        <c:choose>
                          <c:when test="${req.status == 'PENDING'}">
                            <span class="badge bg-warning">Đang chờ</span>
                          </c:when>
                          <c:when test="${req.status == 'ACCEPTED'}">
                            <span class="badge bg-success">Đã chấp nhận</span>
                          </c:when>
                          <c:when test="${req.status == 'REJECTED'}">
                            <span class="badge bg-danger">Đã từ chối</span>
                          </c:when>
                          <c:when test="${req.status == 'COMPLETED'}">
                            <span class="badge bg-info">Hoàn thành</span>
                          </c:when>
                          <c:when test="${req.status == 'CANCELLED'}">
                            <span class="badge bg-secondary">Đã hủy</span>
                          </c:when>
                          <c:otherwise>
                            <span class="badge bg-secondary">${req.status != null ? req.status : '—'}</span>
                          </c:otherwise>
                        </c:choose>
                      </td>
                      <td>
                        <c:if test="${req.createdAt != null}">
                          <fmt:formatDate value="${req.createdAt}" pattern="dd/MM/yyyy HH:mm"/>
                        </c:if>
                        <c:if test="${req.createdAt == null}">—</c:if>
                      </td>
                      <td>
                        <div class="btn-group" role="group">
                          <c:if test="${req.status == 'PENDING'}">
                            <form method="post" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn approve yêu cầu này?');">
                              <input type="hidden" name="action" value="approve">
                              <input type="hidden" name="requestId" value="${req.requestId}">
                              <button type="submit" class="btn btn-sm btn-success" title="Approve">
                                <i class="bi bi-check-circle"></i>
                              </button>
                            </form>
                            <form method="post" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn reject yêu cầu này?');">
                              <input type="hidden" name="action" value="reject">
                              <input type="hidden" name="requestId" value="${req.requestId}">
                              <button type="submit" class="btn btn-sm btn-danger" title="Reject">
                                <i class="bi bi-x-circle"></i>
                              </button>
                            </form>
                          </c:if>
                          <c:if test="${req.status == 'ACCEPTED'}">
                            <form method="post" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn hoàn thành yêu cầu này?');">
                              <input type="hidden" name="action" value="complete">
                              <input type="hidden" name="requestId" value="${req.requestId}">
                              <button type="submit" class="btn btn-sm btn-info" title="Complete">
                                <i class="bi bi-check-all"></i>
                              </button>
                            </form>
                            <form method="post" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn reject yêu cầu này?');">
                              <input type="hidden" name="action" value="reject">
                              <input type="hidden" name="requestId" value="${req.requestId}">
                              <button type="submit" class="btn btn-sm btn-danger" title="Reject">
                                <i class="bi bi-x-circle"></i>
                              </button>
                            </form>
                          </c:if>
                          <c:if test="${req.status != 'COMPLETED' and req.status != 'CANCELLED'}">
                            <form method="post" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn hủy yêu cầu này?');">
                              <input type="hidden" name="action" value="cancel">
                              <input type="hidden" name="requestId" value="${req.requestId}">
                              <button type="submit" class="btn btn-sm btn-warning" title="Cancel">
                                <i class="bi bi-x-octagon"></i>
                              </button>
                            </form>
                          </c:if>
                        </div>
                      </td>
                    </tr>
                  </c:forEach>
                </c:when>
                <c:otherwise>
                  <tr>
                    <td colspan="9" class="text-center py-5 text-muted">
                      <i class="bi bi-inbox display-6 d-block mb-2"></i>
                      <p>Chưa có yêu cầu máu nào</p>
                    </td>
                  </tr>
                </c:otherwise>
              </c:choose>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

