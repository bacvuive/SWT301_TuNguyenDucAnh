<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Duyệt yêu cầu xác minh bệnh viện</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<%@ include file="/header.jsp" %>

<style>
  :root{ --bl-red:#e11d48; --bl-dark:#0f172a; --bl-muted:#64748b; }
  .page-section{padding:40px 0}
  .page-container{max-width:1200px;margin:0 auto;padding:0 15px}
  .page-header{background:linear-gradient(135deg,#e11d48 0%,#be185d 100%);color:#fff;border-radius:20px;padding:30px;margin-bottom:30px}
  .card-soft{border:0;border-radius:18px;box-shadow:0 10px 25px rgba(2,8,23,.06);margin-bottom:20px}
  .badge-rounded{border-radius:999px;padding:0.35rem 0.85rem;font-size:0.85rem}
  .timeline-line{width:3px;background:#f1f5f9;border-radius:999px}
  .request-card{border-radius:20px;border:1px solid #e2e8f0; padding:24px; margin-bottom:20px; transition:transform .2s ease, box-shadow .2s ease}
  .request-card:hover{transform:translateY(-2px); box-shadow:0 12px 30px rgba(15,23,42,.08)}
  .request-meta{color:#64748b;font-size:0.9rem}
  .empty-placeholder{border:2px dashed #e5e7eb;border-radius:18px;padding:40px;text-align:center;color:#94a3b8}
  .btn-approve{background:#0ea5e9;border:0}
  .btn-approve:hover{background:#0284c7}
  .btn-reject{background:#f87171;border:0}
  .btn-reject:hover{background:#ef4444}
</style>

<div class="page-section">
  <div class="page-container">
    <div class="page-header d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
      <div>
        <h1 class="mb-2"><i class="bi bi-shield-check me-2"></i>Duyệt xác minh bệnh viện</h1>
        <p class="mb-0">Quản lý yêu cầu xác minh do các bệnh viện gửi lên hệ thống</p>
      </div>
      <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-light">
        <i class="bi bi-arrow-left me-2"></i>Quay lại Dashboard
      </a>
    </div>

    <c:if test="${not empty success}">
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>${success}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>
    <c:if test="${not empty error}">
      <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i>${error}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    </c:if>

    <div class="card card-soft">
      <div class="card-body p-4">
        <h4 class="fw-bold mb-4">Yêu cầu đang chờ xử lý</h4>
        <c:choose>
          <c:when test="${empty pendingRequests}">
            <div class="empty-placeholder">
              <i class="bi bi-inbox display-5 d-block mb-3"></i>
              <p class="mb-0">Không có yêu cầu nào đang chờ xử lý</p>
            </div>
          </c:when>
          <c:otherwise>
            <div class="row g-3">
              <c:forEach var="item" items="${pendingRequests}">
                <div class="col-12">
                  <div class="request-card">
                    <div class="d-flex flex-column flex-lg-row justify-content-between gap-3">
                      <div class="flex-grow-1">
                        <div class="d-flex align-items-center gap-2 mb-1">
                          <span class="badge bg-warning text-dark badge-rounded">ĐANG CHỜ</span>
                          <span class="text-muted">Yêu cầu #${item.request.requestId}</span>
                        </div>
                        <h5 class="fw-bold mb-1">${item.hospital.name}</h5>
                        <div class="request-meta mb-3">
                          <div><i class="bi bi-geo-alt me-1"></i>${item.hospital.address}</div>
                          <div><i class="bi bi-telephone me-1"></i>${item.hospital.contact != null ? item.hospital.contact : '—'}</div>
                          <div><i class="bi bi-person-badge me-1"></i>Người liên hệ: ${item.request.contactPerson} (${item.request.contactPhone})</div>
                          <div><i class="bi bi-file-earmark-text me-1"></i>Số giấy phép: <strong>${item.request.registrationNumber}</strong></div>
                          <c:if test="${not empty item.request.extraData}">
                            <div><i class="bi bi-info-circle me-1"></i>Ghi chú: ${item.request.extraData}</div>
                          </c:if>
                        </div>
                        <div class="text-muted small">
                          Gửi lúc: <fmt:formatDate value="${item.submittedAt}" pattern="dd/MM/yyyy HH:mm"/>
                        </div>
                      </div>
                      <div>
                        <form method="post" class="d-flex flex-column gap-2">
                          <input type="hidden" name="requestId" value="${item.request.requestId}">
                          <div class="form-floating">
                            <textarea class="form-control" name="note" id="note-${item.request.requestId}" style="min-height:110px" placeholder="Lý do (nếu từ chối)"></textarea>
                            <label for="note-${item.request.requestId}">Ghi chú / Lý do từ chối</label>
                          </div>
                          <div class="d-flex gap-2">
                            <button type="submit" name="action" value="reject" class="btn btn-reject w-50">
                              <i class="bi bi-x-circle me-1"></i>Từ chối
                            </button>
                            <button type="submit" name="action" value="approve" class="btn btn-approve w-50">
                              <i class="bi bi-check-circle me-1"></i>Duyệt
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </c:forEach>
            </div>
          </c:otherwise>
        </c:choose>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-lg-6">
        <div class="card card-soft h-100">
          <div class="card-header bg-white border-bottom">
            <h5 class="mb-0"><i class="bi bi-check2-circle me-2 text-success"></i>Đã phê duyệt</h5>
          </div>
          <div class="card-body p-0">
            <c:choose>
              <c:when test="${empty approvedRequests}">
                <div class="empty-placeholder m-3">
                  <i class="bi bi-clipboard-check d-block mb-2"></i>
                  Chưa có yêu cầu nào được duyệt
                </div>
              </c:when>
              <c:otherwise>
                <div class="list-group list-group-flush">
                  <c:forEach var="item" items="${approvedRequests}">
                    <div class="list-group-item p-3 d-flex justify-content-between align-items-start gap-3">
                      <div>
                        <h6 class="mb-1">${item.hospital.name}</h6>
                        <div class="small text-muted">
                          <div>Số giấy phép: <strong>${item.request.registrationNumber}</strong></div>
                          <div>Người duyệt: <c:out value="${item.processedBy != null ? item.processedBy.email : '—'}"/></div>
                        </div>
                      </div>
                      <div class="text-end text-muted small">
                        <div>Gửi: <fmt:formatDate value="${item.submittedAt}" pattern="dd/MM/yyyy"/></div>
                        <div>Duyệt: <fmt:formatDate value="${item.processedAt}" pattern="dd/MM/yyyy"/></div>
                      </div>
                    </div>
                  </c:forEach>
                </div>
              </c:otherwise>
            </c:choose>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card card-soft h-100">
          <div class="card-header bg-white border-bottom">
            <h5 class="mb-0"><i class="bi bi-x-octagon me-2 text-danger"></i>Bị từ chối</h5>
          </div>
          <div class="card-body p-0">
            <c:choose>
              <c:when test="${empty rejectedRequests}">
                <div class="empty-placeholder m-3">
                  <i class="bi bi-clipboard-x d-block mb-2"></i>
                  Chưa có yêu cầu nào bị từ chối
                </div>
              </c:when>
              <c:otherwise>
                <div class="list-group list-group-flush">
                  <c:forEach var="item" items="${rejectedRequests}">
                    <div class="list-group-item p-3 d-flex justify-content-between align-items-start gap-3">
                      <div>
                        <h6 class="mb-1">${item.hospital.name}</h6>
                        <div class="small text-muted">
                          <div>Số giấy phép: <strong>${item.request.registrationNumber}</strong></div>
                          <div>Lý do: <span class="text-danger">${item.request.rejectionReason}</span></div>
                          <div>Người xử lý: <c:out value="${item.processedBy != null ? item.processedBy.email : '—'}"/></div>
                        </div>
                      </div>
                      <div class="text-end text-muted small">
                        <div>Gửi: <fmt:formatDate value="${item.submittedAt}" pattern="dd/MM/yyyy"/></div>
                        <div>Xử lý: <fmt:formatDate value="${item.processedAt}" pattern="dd/MM/yyyy"/></div>
                      </div>
                    </div>
                  </c:forEach>
                </div>
              </c:otherwise>
            </c:choose>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<%@ include file="/footer.jsp" %>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
