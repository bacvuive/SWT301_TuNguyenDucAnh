<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BloodLink – Đăng nhập</title>

  <!-- Font Inter -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

  <style>
    :root{
      --bl-red:#e63946;
      --bl-dark:#0f172a;
      --bl-muted:#64748b;
      --bl-border:#eef2f7;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0;
      font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,"Apple Color Emoji","Segoe UI Emoji",sans-serif;
      color:#0b1220;
      background:
        radial-gradient(1200px 800px at 10% -10%, #ffe7ea 0%, transparent 60%),
        radial-gradient(1000px 700px at 110% 10%, #e7f0ff 0%, transparent 55%),
        #ffffff;
    }

    .auth-wrap{
      min-height:100%;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:32px 16px;
    }
    .auth-inner{
      width:100%;
      max-width:960px;
      display:grid;
      grid-template-columns: 1.15fr 1fr;
      gap:28px;
      align-items:stretch;
    }
    @media (max-width: 992px){
      .auth-inner{ grid-template-columns: 1fr; max-width: 520px; }
      .art{ display:none }
    }

    /* Panel trái: logo + mô tả */
    .intro{
      background:#fff;
      border:1px solid var(--bl-border);
      border-radius:20px;
      padding:28px;
      box-shadow:0 10px 28px rgba(2,8,23,.06);
    }
    .brand{
      display:flex; align-items:center; gap:10px; margin-bottom:10px;
    }
    .brand img{ height:38px; width:auto; display:block }
    .brand span{ font-weight:800; font-size:22px; letter-spacing:.2px }

    .intro h1{
      font-size:32px; line-height:1.2; margin:14px 0 8px; font-weight:800;
    }
    .intro p{ color:var(--bl-muted); margin:0 0 8px }

    .badges{
      display:flex; flex-wrap:wrap; gap:8px; margin-top:14px;
    }
    .badges span{
      border:1px dashed #f5c1c7; color:#c21f2a; background:#fff7f8;
      font-weight:700; font-size:12px; padding:6px 10px; border-radius:999px;
    }

    /* Panel phải: Form */
    .card{
      background:#fff; border:1px solid var(--bl-border);
      border-radius:20px; padding:28px;
      box-shadow:0 10px 28px rgba(2,8,23,.06);
    }
    .title{ font-weight:800; margin:0 0 12px; font-size:22px }
    .subtitle{ color:var(--bl-muted); margin:0 0 18px }

    label{ display:block; font-weight:600; margin:12px 0 6px }
    .field{
      position:relative;
    }
    input[type="email"], input[type="password"]{
      width:100%; padding:12px 14px; border-radius:12px; border:1px solid #e5e7eb;
      font-size:15px; outline:none; transition:border-color .15s ease, box-shadow .15s ease;
    }
    input[type="email"]:focus, input[type="password"]:focus{
      border-color:#cbd5e1; box-shadow:0 0 0 4px rgba(230,57,70,.10);
    }
    .toggle-pass{
      position:absolute; right:10px; top:50%; transform:translateY(-50%);
      border:0; background:transparent; cursor:pointer; padding:6px;
      color:#64748b; font-size:14px;
    }

    .btn-primary{
      width:100%; margin-top:14px;
      display:inline-flex; justify-content:center; align-items:center; gap:8px;
      background:var(--bl-red); color:#fff; border:0; border-radius:999px;
      font-weight:800; padding:12px 16px; cursor:pointer;
      box-shadow:0 10px 20px rgba(230,57,70,.18);
    }
    .btn-primary:hover{ opacity:.94 }

    .muted{ color:var(--bl-muted) }
    .link{ color:var(--bl-red); text-decoration:none; font-weight:700 }
    .link:hover{ text-decoration:underline }

    .btn-back{
      display:inline-flex; align-items:center; gap:6px;
      color:var(--bl-red); text-decoration:none; font-weight:600; font-size:14px;
      padding:8px 12px; border-radius:999px; border:1px solid #fecdd3;
      background:#fff7f8; transition:all .15s ease;
    }
    .btn-back:hover{
      background:var(--bl-red); color:#fff; text-decoration:none;
      box-shadow:0 4px 12px rgba(230,57,70,.20);
    }

    .alert{
      background:#fff1f2; border:1px solid #fecdd3; color:#b91c1c;
      padding:10px 12px; border-radius:12px; margin-bottom:12px; font-weight:600;
    }

    .meta{
      display:flex; justify-content:space-between; align-items:center;
      margin-top:10px; font-size:14px;
    }
    .meta a{ color:#0f172a; text-decoration:none }
    .meta a:hover{ color:var(--bl-red) }

    /* Ảnh trang trí */
    .art{
      border-radius:20px; overflow:hidden; position:relative;
      background:url('${pageContext.request.contextPath}/assets/images/hero-hospital.jpg') center/cover no-repeat;
      min-height:360px;
    }
    .art::after{
      content:""; position:absolute; inset:0;
      background:linear-gradient(180deg,rgba(255,255,255,.75), rgba(255,255,255,.35));
    }

    footer.small{
      text-align:center; color:#94a3b8; margin-top:22px; font-size:12px;
    }
  </style>
</head>
<body>

  <div class="auth-wrap">
    <div class="auth-inner">

      <!-- Intro / Branding -->
      <div class="intro">
        <div class="brand">
          <img src="${pageContext.request.contextPath}/assets/images/logo-bloodlink.png" alt="BloodLink">
          <span>BloodLink</span>
        </div>
        <h1>Chào mừng trở lại 👋</h1>
        <p>Nơi kết nối người hiến máu và người cần máu khẩn cấp.</p>

        <div class="badges">
          <span>Đăng nhập an toàn</span>
          <span>Hỗ trợ 24/7</span>
          <span>Cộng đồng tin cậy</span>
        </div>

        <footer class="small">© <%= java.time.Year.now() %> BloodLink</footer>
      </div>

      <!-- Form -->
      <div class="card">
        <!-- Nút quay lại -->
        <div class="mb-3">
          <a href="${pageContext.request.contextPath}/" class="btn-back">
            <i class="bi bi-arrow-left"></i>
            Quay lại trang chủ
          </a>
        </div>

        <h2 class="title">Đăng nhập</h2>
        <p class="subtitle">Nhập email và mật khẩu để tiếp tục.</p>

        <c:if test="${not empty error}">
          <div class="alert">${error}</div>
        </c:if>

        <form method="post" action="${pageContext.request.contextPath}/login" autocomplete="on">
          <label for="email">Email</label>
          <div class="field">
            <input id="email" type="email" name="email" placeholder="you@example.com" required autofocus>
          </div>

          <label for="password">Mật khẩu</label>
          <div class="field">
            <input id="password" type="password" name="password" placeholder="••••••••" required>
            <button type="button" class="toggle-pass" aria-label="Hiện/ẩn mật khẩu" onclick="togglePass()">Hiện</button>
          </div>

          <!-- giữ tham số redirect nếu có -->
          <c:if test="${not empty param.next}">
            <input type="hidden" name="next" value="${param.next}"/>
          </c:if>

          <button class="btn-primary" type="submit">
            Đăng nhập
          </button>

          <div class="meta">
            <a href="#">Quên mật khẩu?</a>
            <span class="muted">Chưa có tài khoản? <a class="link" href="${pageContext.request.contextPath}/register">Đăng ký hiến máu</a></span>
          </div>
        </form>
      </div>

      <!-- Art / ảnh bên phải -->
      <div class="art" aria-hidden="true"></div>

    </div>
  </div>

  <script>
    function togglePass(){
      var i = document.getElementById('password');
      var b = event.currentTarget;
      if(i.type === 'password'){ i.type = 'text'; b.textContent = 'Ẩn'; }
      else { i.type = 'password'; b.textContent = 'Hiện'; }
    }
  </script>
</body>
</html>
