package com.bloodlink.service;

import com.bloodlink.dao.BagActionLogDAO;
import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.BloodBag;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Service xử lý expire các túi máu quá hạn
 */
public class ExpireBagsService {
    private BloodBagDAO bloodBagDAO;
    private BagActionLogDAO bagActionLogDAO;
    private HospitalDAO hospitalDAO;
    private NotificationService notificationService;
    private boolean hasTrigger;

    public ExpireBagsService() {
        this.bloodBagDAO = new BloodBagDAO();
        this.bagActionLogDAO = new BagActionLogDAO();
        this.hospitalDAO = new HospitalDAO();
        this.notificationService = new NotificationService();
        this.hasTrigger = bagActionLogDAO.hasTrigger();
    }

    // Constructor for dependency injection (for testing)
    public ExpireBagsService(BloodBagDAO bloodBagDAO, BagActionLogDAO bagActionLogDAO, 
                            HospitalDAO hospitalDAO, NotificationService notificationService,
                            boolean hasTrigger) {
        this.bloodBagDAO = bloodBagDAO;
        this.bagActionLogDAO = bagActionLogDAO;
        this.hospitalDAO = hospitalDAO;
        this.notificationService = notificationService;
        this.hasTrigger = hasTrigger;
    }

    /**
     * Expire tất cả túi máu quá hạn
     * Query: expiry_date < NOW AND status IN ('AVAILABLE','RESERVED')
     * Set status = 'EXPIRED' và ghi log
     * 
     * @return ExpireResult chứa số lượng bags đã expire
     * @throws SQLException
     */
    public ExpireResult expireExpiredBags() throws SQLException {
        // Lấy danh sách bag IDs quá hạn
        List<Integer> expiredBagIds = bloodBagDAO.findExpiredBagIds();
        
        if (expiredBagIds.isEmpty()) {
            return new ExpireResult(0, new ArrayList<>());
        }
        
        // Lấy thông tin old status của các bags trước khi update
        List<ExpiredBagInfo> expiredBags = new ArrayList<>();
        for (Integer bagId : expiredBagIds) {
            BloodBag bag = bloodBagDAO.findById(bagId);
            if (bag != null) {
                ExpiredBagInfo info = new ExpiredBagInfo();
                info.bagId = bagId;
                info.oldStatus = bag.getStatus();
                info.expiryDate = bag.getExpiryDate();
                expiredBags.add(info);
            }
        }
        
        // Batch update status thành EXPIRED
        int updatedCount = bloodBagDAO.batchUpdateStatus(expiredBagIds, "EXPIRED");
        
        // Ghi log nếu không có trigger
        if (!hasTrigger && updatedCount > 0) {
            for (ExpiredBagInfo info : expiredBags) {
                try {
                    bagActionLogDAO.logStatusChange(
                        info.bagId,
                        info.oldStatus,
                        "EXPIRED",
                        null, // System job, không có actor user
                        "Auto-expired by ExpireBagsJob"
                    );
                } catch (SQLException e) {
                    // Log error nhưng không throw để không làm gián đoạn quá trình
                    System.err.println("Error logging expired bag " + info.bagId + ": " + e.getMessage());
                }
            }
        }
        
        // Gửi notification cho các hospitals có bags expired
        if (updatedCount > 0) {
            try {
                // Lấy danh sách hospital IDs có bags expired
                Set<Integer> affectedHospitalIds = new HashSet<>();
                for (ExpiredBagInfo info : expiredBags) {
                    BloodBag bag = bloodBagDAO.findById(info.bagId);
                    if (bag != null && bag.getHospitalId() != null) {
                        affectedHospitalIds.add(bag.getHospitalId());
                    }
                }
                
                // Gửi notification cho mỗi hospital
                for (Integer hospitalId : affectedHospitalIds) {
                    try {
                        var hospital = hospitalDAO.findById(hospitalId);
                        if (hospital != null && hospital.getUserId() != null) {
                            // Đếm số bags expired của hospital này
                            long hospitalExpiredCount = expiredBags.stream()
                                .filter(info -> {
                                    try {
                                        BloodBag bag = bloodBagDAO.findById(info.bagId);
                                        return bag != null && bag.getHospitalId().equals(hospitalId);
                                    } catch (SQLException e) {
                                        return false;
                                    }
                                })
                                .count();
                            
                            if (hospitalExpiredCount > 0) {
                                notificationService.notifyBagExpired(
                                    hospital.getUserId(), 
                                    (int) hospitalExpiredCount
                                );
                            }
                        }
                    } catch (SQLException e) {
                        System.err.println("Error sending notification to hospital " + hospitalId + ": " + e.getMessage());
                    }
                }
            } catch (Exception e) {
                System.err.println("Error sending bag expired notifications: " + e.getMessage());
                // Không throw để không làm gián đoạn quá trình expire
            }
        }
        
        return new ExpireResult(updatedCount, expiredBagIds);
    }

    /**
     * Inner class để lưu thông tin bag quá hạn
     */
    private static class ExpiredBagInfo {
        Integer bagId;
        String oldStatus;
        LocalDate expiryDate;
    }

    /**
     * Class để trả về kết quả expire
     */
    public static class ExpireResult {
        private final int expiredCount;
        private final List<Integer> expiredBagIds;

        public ExpireResult(int expiredCount, List<Integer> expiredBagIds) {
            this.expiredCount = expiredCount;
            this.expiredBagIds = expiredBagIds;
        }

        public int getExpiredCount() {
            return expiredCount;
        }

        public List<Integer> getExpiredBagIds() {
            return expiredBagIds;
        }
    }
}

