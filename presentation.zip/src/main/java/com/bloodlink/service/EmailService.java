package com.bloodlink.service;

import com.bloodlink.util.AppConfig;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;

/**
 * EmailService - Gửi email notifications cho users
 * Sử dụng JavaMail API với SMTP
 */
public class EmailService {
    private static EmailService instance;
    private Properties mailProperties;
    private String smtpHost;
    private int smtpPort;
    private String smtpUsername;
    private String smtpPassword;
    private String fromEmail;
    private String fromName;
    private boolean enabled;

    private EmailService() {
        loadConfig();
    }

    public static synchronized EmailService getInstance() {
        if (instance == null) {
            instance = new EmailService();
        }
        return instance;
    }

    private void loadConfig() {
        // Đọc config từ application.properties (sử dụng static methods)
        enabled = Boolean.parseBoolean(AppConfig.getProperty("email.enabled", "false"));
        smtpHost = AppConfig.getProperty("email.smtp.host", "smtp.gmail.com");
        smtpPort = Integer.parseInt(AppConfig.getProperty("email.smtp.port", "587"));
        smtpUsername = AppConfig.getProperty("email.smtp.username", "");
        smtpPassword = AppConfig.getProperty("email.smtp.password", "");
        fromEmail = AppConfig.getProperty("email.from.address", "noreply@bloodlink.vn");
        fromName = AppConfig.getProperty("email.from.name", "BloodLink");

        // Setup mail properties
        mailProperties = new Properties();
        mailProperties.put("mail.smtp.host", smtpHost);
        mailProperties.put("mail.smtp.port", smtpPort);
        mailProperties.put("mail.smtp.auth", "true");
        mailProperties.put("mail.smtp.starttls.enable", "true");
        mailProperties.put("mail.smtp.starttls.required", "true");
        mailProperties.put("mail.smtp.ssl.trust", smtpHost);
    }

    /**
     * Gửi email đơn giản
     */
    public boolean sendEmail(String toEmail, String subject, String htmlContent) {
        if (!enabled) {
            System.out.println("[EmailService] Email service is disabled. Skipping email to: " + toEmail);
            return false;
        }

        if (toEmail == null || toEmail.trim().isEmpty()) {
            System.err.println("[EmailService] Invalid recipient email: " + toEmail);
            return false;
        }

        try {
            Session session = Session.getInstance(mailProperties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(smtpUsername, smtpPassword);
                }
            });

            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromEmail, fromName));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
            message.setSubject(subject, "UTF-8");
            message.setContent(htmlContent, "text/html; charset=UTF-8");

            Transport.send(message);
            System.out.println("[EmailService] Email sent successfully to: " + toEmail);
            return true;

        } catch (Exception e) {
            System.err.println("[EmailService] Error sending email to " + toEmail + ": " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Gửi email với template
     */
    public boolean sendEmailTemplate(String toEmail, String subject, String templateName, 
                                     java.util.Map<String, String> variables) {
        String htmlContent = buildEmailTemplate(templateName, variables);
        return sendEmail(toEmail, subject, htmlContent);
    }

    /**
     * Build email template với variables
     */
    private String buildEmailTemplate(String templateName, java.util.Map<String, String> variables) {
        String template = getTemplate(templateName);
        
        if (template == null) {
            return "<html><body><p>" + (variables.getOrDefault("message", "No template found")) + "</p></body></html>";
        }

        // Replace variables
        for (java.util.Map.Entry<String, String> entry : variables.entrySet()) {
            template = template.replace("{{" + entry.getKey() + "}}", entry.getValue());
        }

        return template;
    }

    /**
     * Get email template
     */
    private String getTemplate(String templateName) {
        // Basic templates - có thể mở rộng để đọc từ file
        switch (templateName) {
            case "welcome":
                return getWelcomeTemplate();
            case "appointment_confirmed":
                return getAppointmentConfirmedTemplate();
            case "appointment_reminder":
                return getAppointmentReminderTemplate();
            case "donation_completed":
                return getDonationCompletedTemplate();
            case "blood_request":
                return getBloodRequestTemplate();
            case "password_reset":
                return getPasswordResetTemplate();
            default:
                return getDefaultTemplate();
        }
    }

    // ========== EMAIL TEMPLATES ==========

    private String getWelcomeTemplate() {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #e11d48 0%, #be185d 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
                    .button { display: inline-block; padding: 12px 30px; background: #e11d48; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                    .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Chào mừng đến với BloodLink!</h1>
                    </div>
                    <div class="content">
                        <p>Xin chào <strong>{{name}}</strong>,</p>
                        <p>Cảm ơn bạn đã đăng ký tài khoản tại BloodLink - Hệ thống quản lý máu và hiến máu.</p>
                        <p>Với tài khoản của bạn, bạn có thể:</p>
                        <ul>
                            <li>Đặt lịch hẹn hiến máu</li>
                            <li>Theo dõi lịch sử hiến máu</li>
                            <li>Nhận chứng chỉ hiến máu</li>
                            <li>Nhận thông báo về yêu cầu máu khẩn cấp</li>
                        </ul>
                        <a href="{{loginUrl}}" class="button">Đăng nhập ngay</a>
                        <p>Nếu bạn có bất kỳ câu hỏi nào, vui lòng liên hệ với chúng tôi.</p>
                        <p>Trân trọng,<br>Đội ngũ BloodLink</p>
                    </div>
                    <div class="footer">
                        <p>© 2024 BloodLink. Tất cả quyền được bảo lưu.</p>
                    </div>
                </div>
            </body>
            </html>
            """;
    }

    private String getAppointmentConfirmedTemplate() {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
                    .info-box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #10b981; }
                    .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>✅ Lịch hẹn đã được xác nhận</h1>
                    </div>
                    <div class="content">
                        <p>Xin chào <strong>{{name}}</strong>,</p>
                        <p>Lịch hẹn hiến máu của bạn đã được xác nhận bởi bệnh viện.</p>
                        <div class="info-box">
                            <p><strong>Bệnh viện:</strong> {{hospitalName}}</p>
                            <p><strong>Thời gian:</strong> {{appointmentDate}}</p>
                            <p><strong>Địa chỉ:</strong> {{hospitalAddress}}</p>
                        </div>
                        <p>Vui lòng có mặt đúng giờ tại bệnh viện. Chúng tôi sẽ gửi email nhắc nhở 24 giờ trước lịch hẹn.</p>
                        <p>Nếu bạn cần hủy hoặc thay đổi lịch hẹn, vui lòng đăng nhập vào hệ thống.</p>
                        <p>Trân trọng,<br>Đội ngũ BloodLink</p>
                    </div>
                    <div class="footer">
                        <p>© 2024 BloodLink. Tất cả quyền được bảo lưu.</p>
                    </div>
                </div>
            </body>
            </html>
            """;
    }

    private String getAppointmentReminderTemplate() {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
                    .info-box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b; }
                    .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>⏰ Nhắc nhở lịch hẹn hiến máu</h1>
                    </div>
                    <div class="content">
                        <p>Xin chào <strong>{{name}}</strong>,</p>
                        <p>Đây là email nhắc nhở về lịch hẹn hiến máu của bạn <strong>{{timeRemaining}}</strong>.</p>
                        <div class="info-box">
                            <p><strong>Bệnh viện:</strong> {{hospitalName}}</p>
                            <p><strong>Thời gian:</strong> {{appointmentDate}}</p>
                            <p><strong>Địa chỉ:</strong> {{hospitalAddress}}</p>
                        </div>
                        <p><strong>Lưu ý trước khi hiến máu:</strong></p>
                        <ul>
                            <li>Ngủ đủ giấc (ít nhất 6-8 giờ)</li>
                            <li>Ăn nhẹ trước khi hiến máu</li>
                            <li>Uống đủ nước</li>
                            <li>Mang theo CMND/CCCD</li>
                        </ul>
                        <p>Nếu bạn cần hủy hoặc thay đổi lịch hẹn, vui lòng đăng nhập vào hệ thống.</p>
                        <p>Trân trọng,<br>Đội ngũ BloodLink</p>
                    </div>
                    <div class="footer">
                        <p>© 2024 BloodLink. Tất cả quyền được bảo lưu.</p>
                    </div>
                </div>
            </body>
            </html>
            """;
    }

    private String getDonationCompletedTemplate() {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #e11d48 0%, #be185d 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
                    .info-box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #e11d48; }
                    .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>❤️ Cảm ơn bạn đã hiến máu!</h1>
                    </div>
                    <div class="content">
                        <p>Xin chào <strong>{{name}}</strong>,</p>
                        <p>Cảm ơn bạn đã tham gia hiến máu tại <strong>{{hospitalName}}</strong>!</p>
                        <div class="info-box">
                            <p><strong>Ngày hiến máu:</strong> {{donationDate}}</p>
                            <p><strong>Nhóm máu:</strong> {{bloodGroup}}</p>
                            <p><strong>Số lượng:</strong> {{quantity}} ml</p>
                        </div>
                        <p>Máu của bạn sẽ được sử dụng để cứu sống nhiều người. Bạn có thể xem chứng chỉ hiến máu và tải về từ hệ thống.</p>
                        <p><strong>Lưu ý sau khi hiến máu:</strong></p>
                        <ul>
                            <li>Nghỉ ngơi ít nhất 15 phút</li>
                            <li>Uống nhiều nước</li>
                            <li>Tránh vận động mạnh trong 24 giờ</li>
                            <li>Ăn uống đầy đủ chất dinh dưỡng</li>
                        </ul>
                        <p>Trân trọng,<br>Đội ngũ BloodLink</p>
                    </div>
                    <div class="footer">
                        <p>© 2024 BloodLink. Tất cả quyền được bảo lưu.</p>
                    </div>
                </div>
            </body>
            </html>
            """;
    }

    private String getBloodRequestTemplate() {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
                    .alert-box { background: #fee2e2; border-left: 4px solid #ef4444; padding: 20px; border-radius: 8px; margin: 20px 0; }
                    .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🚨 Yêu cầu máu khẩn cấp</h1>
                    </div>
                    <div class="content">
                        <p>Xin chào <strong>{{name}}</strong>,</p>
                        <div class="alert-box">
                            <p><strong>Bệnh viện:</strong> {{hospitalName}}</p>
                            <p><strong>Cần:</strong> {{quantity}} đơn vị nhóm máu <strong>{{bloodGroup}}</strong> ({{component}})</p>
                            <p><strong>Mức độ:</strong> Khẩn cấp</p>
                        </div>
                        <p>Bệnh viện đang cần máu nhóm <strong>{{bloodGroup}}</strong> để cứu sống bệnh nhân. Nếu bạn có thể hỗ trợ, vui lòng liên hệ ngay với bệnh viện hoặc đặt lịch hẹn hiến máu.</p>
                        <p>Mỗi giọt máu của bạn đều quý giá và có thể cứu sống một mạng người.</p>
                        <p>Trân trọng,<br>Đội ngũ BloodLink</p>
                    </div>
                    <div class="footer">
                        <p>© 2024 BloodLink. Tất cả quyền được bảo lưu.</p>
                    </div>
                </div>
            </body>
            </html>
            """;
    }

    private String getPasswordResetTemplate() {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
                    .button { display: inline-block; padding: 12px 30px; background: #6366f1; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                    .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 12px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🔐 Đặt lại mật khẩu</h1>
                    </div>
                    <div class="content">
                        <p>Xin chào <strong>{{name}}</strong>,</p>
                        <p>Bạn đã yêu cầu đặt lại mật khẩu cho tài khoản BloodLink của mình.</p>
                        <p>Vui lòng click vào nút bên dưới để đặt lại mật khẩu:</p>
                        <a href="{{resetUrl}}" class="button">Đặt lại mật khẩu</a>
                        <p>Link này sẽ hết hạn sau 24 giờ.</p>
                        <p>Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này.</p>
                        <p>Trân trọng,<br>Đội ngũ BloodLink</p>
                    </div>
                    <div class="footer">
                        <p>© 2024 BloodLink. Tất cả quyền được bảo lưu.</p>
                    </div>
                </div>
            </body>
            </html>
            """;
    }

    private String getDefaultTemplate() {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .content { background: #f9fafb; padding: 30px; border-radius: 10px; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="content">
                        <p>{{message}}</p>
                    </div>
                </div>
            </body>
            </html>
            """;
    }

    // Getters
    public boolean isEnabled() {
        return enabled;
    }
}

