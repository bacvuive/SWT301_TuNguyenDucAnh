package com.bloodlink.service;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.HospitalVerificationRequestDAO;
import com.bloodlink.dao.UserDAO;
import com.bloodlink.model.Donor;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.HospitalVerificationRequest;
import com.bloodlink.model.User;

import java.sql.SQLException;
import java.util.List;

public class AdminService {
    private UserDAO userDAO;
    private HospitalDAO hospitalDAO;
    private DonorDAO donorDAO;
    private HospitalVerificationRequestDAO verificationRequestDAO;

    public AdminService() {
        this.userDAO = new UserDAO();
        this.hospitalDAO = new HospitalDAO();
        this.donorDAO = new DonorDAO();
        this.verificationRequestDAO = new HospitalVerificationRequestDAO();
    }

    // Constructor for dependency injection (for testing)
    public AdminService(UserDAO userDAO, HospitalDAO hospitalDAO, DonorDAO donorDAO,
                        HospitalVerificationRequestDAO verificationRequestDAO) {
        this.userDAO = userDAO;
        this.hospitalDAO = hospitalDAO;
        this.donorDAO = donorDAO;
        this.verificationRequestDAO = verificationRequestDAO;
    }

    public List<User> getAllUsers() throws SQLException {
        return userDAO.findAll();
    }

    public List<User> getUsersByRole(String roleCode) throws SQLException {
        return userDAO.findByRole(roleCode);
    }

    public List<Hospital> getAllHospitals() throws SQLException {
        return hospitalDAO.findAll();
    }

    public List<Donor> getAllDonors() throws SQLException {
        return donorDAO.findAll();
    }

    public Donor getDonorById(Integer donorId) throws SQLException {
        return donorDAO.findById(donorId);
    }

    public Hospital getHospitalById(Integer hospitalId) throws SQLException {
        return hospitalDAO.findById(hospitalId);
    }

    public User getUserById(Integer userId) throws SQLException {
        return userDAO.findById(userId);
    }

    public boolean updateUserStatus(Integer userId, String status) throws SQLException {
        User user = userDAO.findById(userId);
        if (user != null) {
            user.setStatus(status);
            return userDAO.update(user);
        }
        return false;
    }

    public boolean updateHospital(Hospital hospital) throws SQLException {
        return hospitalDAO.update(hospital);
    }

    public boolean updateDonor(Donor donor) throws SQLException {
        return donorDAO.update(donor);
    }

    public boolean updateUser(User user) throws SQLException {
        return userDAO.update(user);
    }

    public boolean updateUserPassword(Integer userId, String passwordHash) throws SQLException {
        return userDAO.updatePassword(userId, passwordHash);
    }

    public Donor getDonorByUserId(Integer userId) throws SQLException {
        return donorDAO.findByUserId(userId);
    }

    public Hospital getHospitalByUserId(Integer userId) throws SQLException {
        return hospitalDAO.findByUserId(userId);
    }

    public List<HospitalVerificationRequest> getVerificationRequestsByStatus(String status) throws SQLException {
        return verificationRequestDAO.findByStatus(status);
    }

    public HospitalVerificationRequest getVerificationRequestById(Integer requestId) throws SQLException {
        return verificationRequestDAO.findById(requestId);
    }
}

