package com.bloodlink.service;

import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.dao.BloodRequestDAO;
import com.bloodlink.dao.DonationRecordDAO;
import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.BloodBag;
import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.DonationRecord;
import com.bloodlink.util.ExcelExporter;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ReportService - Generate reports cho hospitals và admin
 */
public class ReportService {
    private BloodBagDAO bloodBagDAO;
    private DonationRecordDAO donationRecordDAO;
    private BloodRequestDAO bloodRequestDAO;
    private DonorDAO donorDAO;
    private HospitalDAO hospitalDAO;

    public ReportService() {
        this.bloodBagDAO = new BloodBagDAO();
        this.donationRecordDAO = new DonationRecordDAO();
        this.bloodRequestDAO = new BloodRequestDAO();
        this.donorDAO = new DonorDAO();
        this.hospitalDAO = new HospitalDAO();
    }

    /**
     * Generate inventory report (Excel)
     */
    public byte[] generateInventoryReport(Integer hospitalId, String hospitalName) 
            throws SQLException, IOException {
        List<BloodBag> bags = bloodBagDAO.findByHospitalId(hospitalId);
        
        // Convert to Map format for Excel export
        List<Map<String, Object>> inventoryData = new ArrayList<>();
        for (BloodBag bag : bags) {
            Map<String, Object> data = new HashMap<>();
            data.put("bagCode", bag.getBagCode());
            data.put("bloodGroup", bag.getBloodGroup());
            data.put("component", bag.getComponent());
            data.put("volumeMl", bag.getVolumeMl());
            data.put("collectionDate", bag.getCollectionDate());
            data.put("expiryDate", bag.getExpiryDate());
            data.put("status", bag.getStatus());
            inventoryData.add(data);
        }

        return ExcelExporter.exportInventoryReport(inventoryData, hospitalName);
    }

    /**
     * Generate donation report (Excel)
     */
    public byte[] generateDonationReport(Integer hospitalId, String hospitalName,
                                        LocalDate fromDate, LocalDate toDate) 
            throws SQLException, IOException {
        List<DonationRecord> records = donationRecordDAO.findByHospitalId(hospitalId);
        
        // Filter by date range if provided
        if (fromDate != null || toDate != null) {
            records = records.stream()
                .filter(record -> {
                    if (fromDate != null && record.getDonationDate().isBefore(fromDate)) {
                        return false;
                    }
                    if (toDate != null && record.getDonationDate().isAfter(toDate)) {
                        return false;
                    }
                    return true;
                })
                .collect(java.util.stream.Collectors.toList());
        }

        // Convert to Map format
        List<Map<String, Object>> donationData = new ArrayList<>();
        for (DonationRecord record : records) {
            Map<String, Object> data = new HashMap<>();
            data.put("donationDate", record.getDonationDate());
            
            // Get donor name
            try {
                var donor = donorDAO.findById(record.getDonorId());
                data.put("donorName", donor != null ? donor.getFullName() : "N/A");
            } catch (SQLException e) {
                data.put("donorName", "N/A");
            }
            
            data.put("bloodGroup", record.getMeasuredBloodGroup());
            data.put("quantityMl", record.getQuantityMl());
            data.put("status", record.getStatus());
            donationData.add(data);
        }

        return ExcelExporter.exportDonationReport(donationData, hospitalName);
    }

    /**
     * Generate blood request report (Excel)
     */
    public byte[] generateRequestReport(Integer hospitalId, String hospitalName) 
            throws SQLException, IOException {
        List<BloodRequest> requests = bloodRequestDAO.findByToHospitalId(hospitalId);
        
        // Convert to Map format
        List<Map<String, Object>> requestData = new ArrayList<>();
        for (BloodRequest request : requests) {
            Map<String, Object> data = new HashMap<>();
            data.put("requestId", request.getRequestId());
            
            // Get hospital names
            try {
                if (request.getFromHospitalId() != null) {
                    var fromHospital = hospitalDAO.findById(request.getFromHospitalId());
                    data.put("fromHospitalName", fromHospital != null ? fromHospital.getName() : "N/A");
                } else {
                    data.put("fromHospitalName", "N/A");
                }
                
                if (request.getToHospitalId() != null) {
                    var toHospital = hospitalDAO.findById(request.getToHospitalId());
                    data.put("toHospitalName", toHospital != null ? toHospital.getName() : "Tất cả");
                } else {
                    data.put("toHospitalName", "Tất cả");
                }
            } catch (SQLException e) {
                data.put("fromHospitalName", "N/A");
                data.put("toHospitalName", "N/A");
            }
            
            data.put("bloodGroup", request.getBloodGroup());
            data.put("component", request.getComponent());
            data.put("quantity", request.getQuantity());
            data.put("status", request.getStatus());
            data.put("createdAt", request.getCreatedAt());
            requestData.add(data);
        }

        return ExcelExporter.exportRequestReport(requestData, hospitalName);
    }

    /**
     * Generate summary statistics
     */
    public Map<String, Object> generateSummaryStatistics(Integer hospitalId) throws SQLException {
        Map<String, Object> stats = new HashMap<>();
        
        // Inventory stats
        List<BloodBag> bags = bloodBagDAO.findByHospitalId(hospitalId);
        long totalBags = bags.size();
        long availableBags = bags.stream().filter(b -> "AVAILABLE".equals(b.getStatus())).count();
        long reservedBags = bags.stream().filter(b -> "RESERVED".equals(b.getStatus())).count();
        long expiredBags = bags.stream().filter(b -> "EXPIRED".equals(b.getStatus())).count();
        
        stats.put("totalBags", totalBags);
        stats.put("availableBags", availableBags);
        stats.put("reservedBags", reservedBags);
        stats.put("expiredBags", expiredBags);
        
        // Donation stats
        List<DonationRecord> donations = donationRecordDAO.findByHospitalId(hospitalId);
        stats.put("totalDonations", donations.size());
        int totalMl = donations.stream()
            .mapToInt(d -> d.getQuantityMl() != null ? d.getQuantityMl() : 0)
            .sum();
        stats.put("totalMlDonated", totalMl);
        
        // Request stats
        List<BloodRequest> requests = bloodRequestDAO.findByToHospitalId(hospitalId);
        stats.put("totalRequests", requests.size());
        stats.put("pendingRequests", requests.stream().filter(r -> "PENDING".equals(r.getStatus())).count());
        stats.put("acceptedRequests", requests.stream().filter(r -> "ACCEPTED".equals(r.getStatus())).count());
        stats.put("completedRequests", requests.stream().filter(r -> "COMPLETED".equals(r.getStatus())).count());
        
        return stats;
    }
}

