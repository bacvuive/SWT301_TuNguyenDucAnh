package com.bloodlink.service;

import com.bloodlink.dao.AppointmentDAO;
import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.dao.BloodRequestDAO;
import com.bloodlink.dao.DonationRecordDAO;
import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.HospitalVerificationDocumentDAO;
import com.bloodlink.dao.HospitalVerificationRequestDAO;
import com.bloodlink.model.Appointment;
import com.bloodlink.model.BloodBag;
import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.DonationRecord;
import com.bloodlink.model.Donor;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.HospitalVerificationDocument;
import com.bloodlink.model.HospitalVerificationRequest;
import com.bloodlink.service.NotificationService;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

public class HospitalService {
    private HospitalDAO hospitalDAO;
    private BloodBagDAO bloodBagDAO;
    private BloodRequestDAO bloodRequestDAO;
    private AppointmentDAO appointmentDAO;
    private DonationRecordDAO donationRecordDAO;
    private DonorDAO donorDAO;
    private NotificationService notificationService;
    private HospitalVerificationRequestDAO verificationRequestDAO;
    private HospitalVerificationDocumentDAO verificationDocumentDAO;

    public HospitalService() {
        this.hospitalDAO = new HospitalDAO();
        this.bloodBagDAO = new BloodBagDAO();
        this.bloodRequestDAO = new BloodRequestDAO();
        this.appointmentDAO = new AppointmentDAO();
        this.donationRecordDAO = new DonationRecordDAO();
        this.donorDAO = new DonorDAO();
        this.notificationService = new NotificationService();
        this.verificationRequestDAO = new HospitalVerificationRequestDAO();
        this.verificationDocumentDAO = new HospitalVerificationDocumentDAO();
    }

    // Constructor for dependency injection (for testing)
    public HospitalService(HospitalDAO hospitalDAO, BloodBagDAO bloodBagDAO, 
                          BloodRequestDAO bloodRequestDAO, AppointmentDAO appointmentDAO,
                          DonationRecordDAO donationRecordDAO, DonorDAO donorDAO,
                          NotificationService notificationService,
                          HospitalVerificationRequestDAO verificationRequestDAO,
                          HospitalVerificationDocumentDAO verificationDocumentDAO) {
        this.hospitalDAO = hospitalDAO;
        this.bloodBagDAO = bloodBagDAO;
        this.bloodRequestDAO = bloodRequestDAO;
        this.appointmentDAO = appointmentDAO;
        this.donationRecordDAO = donationRecordDAO;
        this.donorDAO = donorDAO;
        this.notificationService = notificationService;
        this.verificationRequestDAO = verificationRequestDAO;
        this.verificationDocumentDAO = verificationDocumentDAO;
    }

    public Hospital getHospitalByUserId(Integer userId) throws SQLException {
        return hospitalDAO.findByUserId(userId);
    }

    public Hospital getHospitalById(Integer hospitalId) throws SQLException {
        return hospitalDAO.findById(hospitalId);
    }

    public List<BloodBag> getInventory(Integer hospitalId) throws SQLException {
        return bloodBagDAO.findByHospitalId(hospitalId);
    }

    public List<BloodBag> getAvailableBags(Integer hospitalId, String bloodGroup, String component) throws SQLException {
        return bloodBagDAO.findAvailable(hospitalId, bloodGroup, component);
    }

    public BloodBag addBloodBag(String bagCode, Integer hospitalId, Integer recordId,
                                String bloodGroup, String component, Integer volumeMl,
                                LocalDate collectionDate) throws SQLException {
        // Calculate expiry date based on component
        int shelfLifeDays = getShelfLifeDays(component);
        LocalDate expiryDate = collectionDate.plusDays(shelfLifeDays);

        BloodBag bag = new BloodBag();
        bag.setBagCode(bagCode);
        bag.setHospitalId(hospitalId);
        bag.setRecordId(recordId);
        bag.setBloodGroup(bloodGroup);
        bag.setComponent(component);
        bag.setVolumeMl(volumeMl);
        bag.setCollectionDate(collectionDate);
        bag.setExpiryDate(expiryDate);
        bag.setStatus("AVAILABLE");
        bag.setCreatedAt(LocalDateTime.now());
        bag.setUpdatedAt(LocalDateTime.now());

        Integer bagId = bloodBagDAO.create(bag);
        if (bagId != null) {
            return bloodBagDAO.findById(bagId);
        }
        return null;
    }

    private int getShelfLifeDays(String component) {
        return switch (component) {
            case "WB" -> 42;
            case "RBC" -> 42;
            case "PLT" -> 5;
            case "FFP" -> 365;
            default -> 42;
        };
    }

    public BloodRequest createRequest(Integer fromHospitalId, Integer toHospitalId,
                                      String bloodGroup, String component, Integer quantity) throws SQLException {
        BloodRequest request = new BloodRequest();
        request.setFromHospitalId(fromHospitalId);
        request.setToHospitalId(toHospitalId);
        request.setBloodGroup(bloodGroup);
        request.setComponent(component);
        request.setQuantity(quantity);
        request.setStatus("PENDING");
        request.setCreatedAt(LocalDateTime.now());

        Integer requestId = bloodRequestDAO.create(request);
        if (requestId != null) {
            return bloodRequestDAO.findById(requestId);
        }
        return null;
    }

    public List<BloodRequest> getRequests(Integer hospitalId) throws SQLException {
        return bloodRequestDAO.findByToHospitalId(hospitalId);
    }

    public List<BloodRequest> getPendingRequests() throws SQLException {
        return bloodRequestDAO.findByStatus("PENDING");
    }

    public List<Appointment> getAppointments(Integer hospitalId) throws SQLException {
        return appointmentDAO.findByHospitalId(hospitalId);
    }

    public boolean confirmAppointment(Integer appointmentId) throws SQLException {
        Appointment appointment = appointmentDAO.findById(appointmentId);
        if (appointment != null) {
            appointment.setStatus("CONFIRMED");
            appointment.setUpdatedAt(LocalDateTime.now());
            boolean updated = appointmentDAO.update(appointment);
            
            // Gửi notification cho donor
            if (updated) {
                System.out.println("[HospitalService] ====== START SENDING NOTIFICATION ======");
                System.out.println("[HospitalService] Appointment ID: " + appointmentId);
                
                try {
                    Donor donor = donorDAO.findById(appointment.getDonorId());
                    System.out.println("[HospitalService] Donor: " + (donor != null ? 
                        "ID=" + donor.getDonorId() + ", UserId=" + donor.getUserId() + ", Name=" + donor.getFullName() : "NULL"));
                    
                    Hospital hospital = hospitalDAO.findById(appointment.getHospitalId());
                    System.out.println("[HospitalService] Hospital: " + (hospital != null ? 
                        "ID=" + hospital.getHospitalId() + ", Name=" + hospital.getName() : "NULL"));
                    
                    if (donor != null && donor.getUserId() != null && hospital != null) {
                        // Format scheduledAt
                        String scheduledAtStr = "Chưa có";
                        if (appointment.getScheduledAt() != null) {
                            scheduledAtStr = appointment.getScheduledAt()
                                    .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
                        }
                        
                        System.out.println("[HospitalService] Calling notifyAppointmentConfirmed...");
                        notificationService.notifyAppointmentConfirmed(
                            donor.getUserId(),
                            appointmentId,
                            hospital.getName(),
                            scheduledAtStr
                        );
                        System.out.println("[HospitalService] ====== NOTIFICATION SENT SUCCESSFULLY ======");
                    } else {
                        System.err.println("[HospitalService] ====== CANNOT SEND NOTIFICATION ======");
                        System.err.println("[HospitalService] donor != null: " + (donor != null));
                        System.err.println("[HospitalService] donor.getUserId() != null: " + (donor != null && donor.getUserId() != null));
                        System.err.println("[HospitalService] hospital != null: " + (hospital != null));
                    }
                } catch (Exception e) {
                    System.err.println("[HospitalService] ====== EXCEPTION ======");
                    System.err.println("[HospitalService] Error: " + e.getClass().getName() + " - " + e.getMessage());
                    e.printStackTrace();
                    System.err.println("[HospitalService] =======================");
                }
            } else {
                System.err.println("[HospitalService] Appointment update failed, skipping notification");
            }
            
            return updated;
        }
        return false;
    }

    public boolean updateAppointment(Appointment appointment) throws SQLException {
        return appointmentDAO.update(appointment);
    }

    public DonationRecord createDonationRecord(Integer donorId, Integer hospitalId,
                                               LocalDate donationDate, List<BloodBag> bagInputs) throws SQLException {
        System.out.println("[HospitalService] Creating donation record - donorId: " + donorId + 
                         ", hospitalId: " + hospitalId);
        if (bagInputs == null || bagInputs.isEmpty()) {
            throw new IllegalArgumentException("Danh sách túi máu không được để trống");
        }

        DonationRecord record = new DonationRecord();
        record.setDonorId(donorId);
        record.setHospitalId(hospitalId);
        record.setDonationDate(donationDate);
        record.setMeasuredBloodGroup(
            bagInputs.stream()
                .map(BloodBag::getBloodGroup)
                .filter(Objects::nonNull)
                .findFirst()
                .orElse(null)
        );
        int totalQuantity = bagInputs.stream()
            .map(BloodBag::getVolumeMl)
            .filter(Objects::nonNull)
            .mapToInt(Integer::intValue)
            .sum();
        record.setQuantityMl(totalQuantity);
        record.setStatus("CONFIRMED");
        record.setCreatedAt(LocalDateTime.now());

        Integer recordId = donationRecordDAO.create(record);
        if (recordId != null) {
            DonationRecord createdRecord = donationRecordDAO.findById(recordId);

            if (createdRecord == null) {
                throw new SQLException("Không tìm thấy bản ghi hiến máu vừa tạo");
            }

            // Thêm túi máu vào kho
            createInventoryForDonation(createdRecord, bagInputs);

            // Gửi notification cho donor
            try {
                Donor donor = donorDAO.findById(donorId);
                Hospital hospital = hospitalDAO.findById(hospitalId);
                
                System.out.println("[HospitalService] Donor: " + (donor != null ? 
                    "ID=" + donor.getDonorId() + ", UserId=" + donor.getUserId() : "NULL"));
                System.out.println("[HospitalService] Hospital: " + (hospital != null ? 
                    "ID=" + hospital.getHospitalId() + ", Name=" + hospital.getName() : "NULL"));
                
                if (donor != null && donor.getUserId() != null && hospital != null) {
                    System.out.println("[HospitalService] Sending donation completed notification...");
                    notificationService.notifyDonationCompleted(
                        donor.getUserId(),
                        recordId,
                        hospital.getName(),
                        totalQuantity,
                        createdRecord.getMeasuredBloodGroup()
                    );
                    System.out.println("[HospitalService] Donation completed notification sent!");
                } else {
                    System.err.println("[HospitalService] Cannot send notification - missing data");
                }
            } catch (Exception e) {
                System.err.println("[HospitalService] Error sending donation notification: " + e.getMessage());
                e.printStackTrace();
            }
            
            return createdRecord;
        }
        return null;
    }

    private void createInventoryForDonation(DonationRecord record, List<BloodBag> bagInputs) throws SQLException {
        if (record == null) {
            throw new IllegalArgumentException("Donation record is required to create inventory entry");
        }
        if (bagInputs == null || bagInputs.isEmpty()) {
            throw new IllegalArgumentException("Danh sách túi máu không được để trống");
        }

        int row = 1;
        for (BloodBag input : bagInputs) {
            if (input == null) {
                continue;
            }

            String bloodGroup = input.getBloodGroup() != null
                ? input.getBloodGroup().toUpperCase()
                : (record.getMeasuredBloodGroup() != null ? record.getMeasuredBloodGroup().toUpperCase() : "UNKNOWN");

            if (bloodGroup == null || bloodGroup.trim().isEmpty()) {
                throw new SQLException("Nhóm máu không hợp lệ ở dòng túi " + row);
            }

            String component = input.getComponent() != null ? input.getComponent().toUpperCase() : "WB";
            if (!List.of("WB", "RBC", "PLT", "FFP").contains(component)) {
                throw new SQLException("Thành phần không hợp lệ ở dòng túi " + row + ": " + component);
            }

            Integer quantity = input.getVolumeMl();
            if (quantity == null || quantity <= 0) {
                throw new SQLException("Số lượng túi máu không hợp lệ ở dòng " + row);
            }

            LocalDate collectionDate = input.getCollectionDate() != null ? input.getCollectionDate() :
                (record.getDonationDate() != null ? record.getDonationDate() : LocalDate.now());

            String bagCode = generateDonationBagCode(record, component, row);

            BloodBag bag = addBloodBag(
                bagCode,
                record.getHospitalId(),
                record.getRecordId(),
                bloodGroup,
                component,
                quantity,
                collectionDate
            );

            if (bag == null) {
                throw new SQLException("Không thể tạo túi máu cho bản ghi hiến máu " + record.getRecordId() + " ở dòng " + row);
            }

            row++;
        }
    }

    private String generateDonationBagCode(DonationRecord record, String component, int rowIndex) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        return String.format("DN%s-%03d-%02d-%s%02d", timestamp, record.getHospitalId(), record.getRecordId() % 100, component, rowIndex);
    }

    public List<DonationRecord> getDonationRecords(Integer hospitalId) throws SQLException {
        return donationRecordDAO.findByHospitalId(hospitalId);
    }

    // ================= HOSPITAL VERIFICATION =================

    public HospitalVerificationRequest getLatestVerificationRequest(Integer hospitalId) throws SQLException {
        return verificationRequestDAO.findLatestByHospitalId(hospitalId);
    }

    public List<HospitalVerificationRequest> getVerificationHistory(Integer hospitalId) throws SQLException {
        return verificationRequestDAO.findByHospitalId(hospitalId);
    }

    public List<HospitalVerificationRequest> getPendingVerificationRequests() throws SQLException {
        return verificationRequestDAO.findByStatus("PENDING");
    }

    public HospitalVerificationRequest submitVerificationRequest(Integer hospitalId,
                                                                  String registrationNumber,
                                                                  String contactPerson,
                                                                  String contactPhone,
                                                                  String extraData,
                                                                  List<HospitalVerificationDocument> documents) throws SQLException {
        Objects.requireNonNull(hospitalId, "hospitalId is required");
        Objects.requireNonNull(registrationNumber, "registrationNumber is required");
        Objects.requireNonNull(contactPerson, "contactPerson is required");
        Objects.requireNonNull(contactPhone, "contactPhone is required");

        Hospital hospital = hospitalDAO.findById(hospitalId);
        if (hospital == null) {
            throw new IllegalArgumentException("Bệnh viện không tồn tại");
        }

        HospitalVerificationRequest pending = verificationRequestDAO.findPendingByHospitalId(hospitalId);
        if (pending != null) {
            throw new IllegalStateException("Bạn đã gửi yêu cầu xác minh và đang chờ duyệt");
        }

        HospitalVerificationRequest request = new HospitalVerificationRequest();
        request.setHospitalId(hospitalId);
        request.setStatus("PENDING");
        request.setSubmittedAt(LocalDateTime.now());
        request.setRegistrationNumber(registrationNumber.trim());
        request.setContactPerson(contactPerson.trim());
        request.setContactPhone(contactPhone.trim());
        request.setExtraData(extraData);

        Integer requestId = verificationRequestDAO.create(request);
        if (requestId == null) {
            throw new SQLException("Không thể tạo yêu cầu xác minh");
        }

        if (documents != null && !documents.isEmpty()) {
            for (HospitalVerificationDocument document : documents) {
                document.setRequestId(requestId);
                document.setUploadedAt(LocalDateTime.now());
                verificationDocumentDAO.create(document);
            }
        }

        return verificationRequestDAO.findById(requestId);
    }

    public HospitalVerificationRequest processVerification(Integer requestId, Integer adminUserId,
                                                            boolean approve, String rejectionReason) throws SQLException {
        HospitalVerificationRequest request = verificationRequestDAO.findById(requestId);
        if (request == null) {
            throw new IllegalArgumentException("Yêu cầu xác minh không tồn tại");
        }

        if (!"PENDING".equals(request.getStatus())) {
            throw new IllegalStateException("Yêu cầu đã được xử lý trước đó");
        }

        request.setProcessedAt(LocalDateTime.now());
        request.setProcessedBy(adminUserId);
        request.setStatus(approve ? "APPROVED" : "REJECTED");
        request.setRejectionReason(approve ? null : rejectionReason);

        if (!verificationRequestDAO.update(request)) {
            throw new SQLException("Không thể cập nhật trạng thái yêu cầu");
        }

        Hospital hospital = hospitalDAO.findById(request.getHospitalId());
        if (hospital == null) {
            throw new IllegalStateException("Không tìm thấy bệnh viện tương ứng");
        }

        hospital.setIsVerified(approve);
        hospital.setVerifiedAt(approve ? LocalDateTime.now() : null);
        hospital.setVerifiedBy(approve ? adminUserId : null);
        hospital.setVerificationNote(approve ? null : rejectionReason);
        hospitalDAO.update(hospital);

        // Notify hospital user if available
        if (hospital.getUserId() != null) {
            String subject = approve ? "Yêu cầu xác minh bệnh viện được chấp nhận" : "Yêu cầu xác minh bệnh viện bị từ chối";
            String message = approve
                ? "Bệnh viện của bạn đã được xác minh thành công."
                : "Yêu cầu xác minh bệnh viện của bạn đã bị từ chối. " + (rejectionReason != null ? ("Lý do: " + rejectionReason) : "");
            notificationService.createNotification(hospital.getUserId(), "HOSPITAL_VERIFICATION", subject, message, "/hospital/profile");
        }

        return request;
    }

    public List<HospitalVerificationDocument> getVerificationDocuments(Integer requestId) throws SQLException {
        return verificationDocumentDAO.findByRequestId(requestId);
    }
}

