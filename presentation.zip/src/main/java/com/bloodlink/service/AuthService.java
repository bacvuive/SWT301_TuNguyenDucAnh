package com.bloodlink.service;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.UserDAO;
import com.bloodlink.model.Donor;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.util.PasswordUtil;

import java.sql.SQLException;
import java.time.LocalDateTime;

public class AuthService {
    private UserDAO userDAO;
    private DonorDAO donorDAO;
    private HospitalDAO hospitalDAO;
    public AuthService(UserDAO userDAO, DonorDAO donorDAO, HospitalDAO hospitalDAO) {
        this.userDAO = userDAO;
        this.donorDAO = donorDAO;
        this.hospitalDAO = hospitalDAO;
    }


    public AuthService() {
        this.userDAO = new UserDAO();
        this.donorDAO = new DonorDAO();
        this.hospitalDAO = new HospitalDAO();
    }

    public User login(String email, String password) throws SQLException {
        try {
            User user = userDAO.findByEmail(email);
            if (user == null) {
                return null;
            }
            
            // Check if password hash exists
            if (user.getPasswordHash() == null || user.getPasswordHash().isEmpty()) {
                System.err.println("Warning: User " + email + " has no password hash");
                return null;
            }
            
            // Verify password
            if (!PasswordUtil.checkPassword(password, user.getPasswordHash())) {
                return null;
            }
            
            // Check if account is active
            if (!"active".equals(user.getStatus())) {
                return null;
            }
            
            return user;
        } catch (Exception e) {
            System.err.println("Error in AuthService.login: " + e.getMessage());
            e.printStackTrace();
            throw new SQLException("Lỗi khi đăng nhập: " + e.getMessage(), e);
        }
    }

    public User registerDonor(String username, String email, String password, 
                               String fullName, String bloodGroup, String phone, 
                               String address, String gender, String dob) throws SQLException {
        // Check if email or username already exists
        if (userDAO.findByEmail(email) != null) {
            throw new IllegalArgumentException("Email đã được sử dụng");
        }
        if (userDAO.findByUsername(username) != null) {
            throw new IllegalArgumentException("Tên đăng nhập đã được sử dụng");
        }

        // Create user
        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(PasswordUtil.hashPassword(password));
        user.setEmail(email);
        user.setRoleCode("donor");
        user.setStatus("active");
        user.setCreatedAt(LocalDateTime.now());

        Integer userId = userDAO.create(user);
        if (userId == null) {
            throw new SQLException("Không thể tạo tài khoản");
        }

        // Create donor profile
        Donor donor = new Donor();
        donor.setUserId(userId);
        donor.setFullName(fullName);
        donor.setBloodGroup(bloodGroup);
        donor.setPhone(phone);
        donor.setAddress(address);
        donor.setGender(gender);
        if (dob != null && !dob.isEmpty()) {
            donor.setDob(java.time.LocalDate.parse(dob));
        }
        donor.setCreatedAt(LocalDateTime.now());

        Integer donorId = donorDAO.create(donor);
        if (donorId == null) {
            // Rollback: delete user
            // For simplicity, we'll just throw exception
            throw new SQLException("Không thể tạo hồ sơ người hiến");
        }

        user.setUserId(userId);
        return user;
    }

    public User registerHospital(String username, String email, String password,
                                  String name, String address, String contact, 
                                  String region) throws SQLException {
        // Check if email or username already exists
        if (userDAO.findByEmail(email) != null) {
            throw new IllegalArgumentException("Email đã được sử dụng");
        }
        if (userDAO.findByUsername(username) != null) {
            throw new IllegalArgumentException("Tên đăng nhập đã được sử dụng");
        }

        // Create user
        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(PasswordUtil.hashPassword(password));
        user.setEmail(email);
        user.setRoleCode("hospital");
        user.setStatus("active");
        user.setCreatedAt(LocalDateTime.now());

        Integer userId = userDAO.create(user);
        if (userId == null) {
            throw new SQLException("Không thể tạo tài khoản");
        }

        // Create hospital profile
        Hospital hospital = new Hospital();
        hospital.setUserId(userId);
        hospital.setName(name);
        hospital.setAddress(address);
        hospital.setContact(contact);
        hospital.setRegion(region);
        hospital.setCreatedAt(LocalDateTime.now());

        Integer hospitalId = hospitalDAO.create(hospital);
        if (hospitalId == null) {
            throw new SQLException("Không thể tạo hồ sơ bệnh viện");
        }

        user.setUserId(userId);
        return user;
    }

    public User registerHospital(String username, String email, String password, Integer hospitalId) throws SQLException {
        // Check if email or username already exists
        if (userDAO.findByEmail(email) != null) {
            throw new IllegalArgumentException("Email đã được sử dụng");
        }
        if (userDAO.findByUsername(username) != null) {
            throw new IllegalArgumentException("Tên đăng nhập đã được sử dụng");
        }

        // Check if hospital exists and doesn't have a user yet
        Hospital hospital = hospitalDAO.findById(hospitalId);
        if (hospital == null) {
            throw new IllegalArgumentException("Bệnh viện không tồn tại");
        }
        if (hospital.getUserId() != null) {
            throw new IllegalArgumentException("Bệnh viện này đã có tài khoản");
        }

        // Create user
        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(PasswordUtil.hashPassword(password));
        user.setEmail(email);
        user.setRoleCode("hospital");
        user.setStatus("active");
        user.setCreatedAt(LocalDateTime.now());

        Integer userId = userDAO.create(user);
        if (userId == null) {
            throw new SQLException("Không thể tạo tài khoản");
        }

        // Link hospital với user mới tạo
        hospital.setUserId(userId);
        if (!hospitalDAO.update(hospital)) {
            throw new SQLException("Không thể liên kết bệnh viện với tài khoản");
        }

        user.setUserId(userId);
        return user;
    }

    public User getUserById(Integer userId) throws SQLException {
        return userDAO.findById(userId);
    }

    public Donor getDonorByUserId(Integer userId) throws SQLException {
        return donorDAO.findByUserId(userId);
    }

    public Hospital getHospitalByUserId(Integer userId) throws SQLException {
        return hospitalDAO.findByUserId(userId);
    }
}

