package com.bloodlink.service;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.NotificationDAO;
import com.bloodlink.dao.UserDAO;
import com.bloodlink.model.Donor;
import com.bloodlink.model.Notification;
import com.bloodlink.model.User;
import com.bloodlink.util.AppConfig;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * NotificationService với hỗ trợ các loại notification:
 * - REQUEST_ACCEPTED, REQUEST_REJECTED, REQUEST_COMPLETED
 * - TRANSFER_CREATED, TRANSFER_PICKED_UP, TRANSFER_IN_TRANSIT, TRANSFER_DELIVERED, TRANSFER_CANCELLED
 * - BAG_EXPIRED
 * - Tích hợp EmailService để gửi email notifications
 */
public class NotificationService {
    private NotificationDAO notificationDAO;
    private EmailService emailService;
    private UserDAO userDAO;
    private DonorDAO donorDAO;

    public NotificationService() {
        this.notificationDAO = new NotificationDAO();
        this.emailService = EmailService.getInstance();
        this.userDAO = new UserDAO();
        this.donorDAO = new DonorDAO();
    }

    // Constructor for dependency injection (for testing)
    public NotificationService(NotificationDAO notificationDAO) {
        this.notificationDAO = notificationDAO;
        this.emailService = EmailService.getInstance();
        this.userDAO = new UserDAO();
        this.donorDAO = new DonorDAO();
    }

    /**
     * Tạo notification với subject và link (mới)
     */
    public Notification createNotification(Integer userId, String type, String subject, 
                                          String message, String link) throws SQLException {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setType(type != null ? type : "info");
        notification.setSubject(subject);
        notification.setMessage(message);
        notification.setLink(link);
        notification.setIsRead(false);
        notification.setCreatedAt(LocalDateTime.now());

        Long notificationId = notificationDAO.create(notification);
        if (notificationId != null) {
            return notificationDAO.findById(notificationId);
        }
        return null;
    }

    /**
     * Tạo notification (backward compatible - không có subject và link)
     */
    public Notification createNotification(Integer userId, String type, String message) throws SQLException {
        return createNotification(userId, type, null, message, null);
    }

    // ========== EMAIL HELPER METHODS ==========

    /**
     * Gửi email notification cho user
     * @param userId User ID
     * @param templateName Email template name
     * @param subject Email subject
     * @param variables Variables để replace trong template
     */
    private void sendEmailNotification(Integer userId, String templateName, String subject, Map<String, String> variables) {
        if (!emailService.isEnabled()) {
            return; // Email service disabled, skip
        }

        try {
            User user = userDAO.findById(userId);
            if (user == null || user.getEmail() == null || user.getEmail().trim().isEmpty()) {
                System.out.println("[NotificationService] Cannot send email - user not found or no email: userId=" + userId);
                return;
            }

            // Get user's full name if donor
            String fullName = user.getUsername();
            if ("donor".equals(user.getRoleCode())) {
                try {
                    Donor donor = donorDAO.findByUserId(userId);
                    if (donor != null && donor.getFullName() != null && !donor.getFullName().trim().isEmpty()) {
                        fullName = donor.getFullName();
                    }
                } catch (SQLException e) {
                    System.err.println("[NotificationService] Error getting donor info: " + e.getMessage());
                    // Continue with username
                }
            }

            // Add common variables
            if (variables == null) {
                variables = new HashMap<>();
            }
            variables.put("name", fullName);
            variables.put("loginUrl", AppConfig.getProperty("app.base.url", "http://localhost:8080/bloodlink") + "/login");

            // Send email
            boolean sent = emailService.sendEmailTemplate(user.getEmail(), subject, templateName, variables);
            if (sent) {
                System.out.println("[NotificationService] Email sent successfully to: " + user.getEmail());
            } else {
                System.err.println("[NotificationService] Failed to send email to: " + user.getEmail());
            }
        } catch (Exception e) {
            System.err.println("[NotificationService] Error sending email notification: " + e.getMessage());
            // Không throw để không làm gián đoạn in-app notification
            e.printStackTrace();
        }
    }

    // ========== REQUEST NOTIFICATIONS ==========

    /**
     * Gửi notification khi request được accept
     */
    public void notifyRequestAccepted(Integer recipientUserId, Integer requestId,
                                     String bloodGroup, Integer quantity,
                                     String note) throws SQLException {
        String subject = "Yêu cầu máu đã được chấp nhận";
        String message = String.format("Yêu cầu máu #%d (%s, %d đơn vị) đã được chấp nhận", 
                                      requestId, bloodGroup, quantity);
        if (note != null && !note.trim().isEmpty()) {
            message += "\nGhi chú: " + note;
        }
        String link = "/hospital/requests/" + requestId;
        createNotification(recipientUserId, "REQUEST_ACCEPTED", subject, message, link);

        // Send email notification (for hospitals)
        Map<String, String> emailVars = new HashMap<>();
        emailVars.put("requestId", String.valueOf(requestId));
        emailVars.put("bloodGroup", bloodGroup);
        emailVars.put("quantity", String.valueOf(quantity));
        emailVars.put("message", message);
        sendEmailNotification(recipientUserId, "default", subject, emailVars);
    }

    /**
     * Gửi notification khi request bị reject
     */
    public void notifyRequestRejected(Integer recipientUserId, Integer requestId,
                                     String bloodGroup, Integer quantity,
                                     String note) throws SQLException {
        String subject = "Yêu cầu máu đã bị từ chối";
        String message = String.format("Yêu cầu máu #%d (%s, %d đơn vị) đã bị từ chối", 
                                      requestId, bloodGroup, quantity);
        if (note != null && !note.trim().isEmpty()) {
            message += "\nLý do: " + note;
        }
        String link = "/hospital/requests/" + requestId;
        createNotification(recipientUserId, "REQUEST_REJECTED", subject, message, link);
    }

    /**
     * Gửi notification khi request được complete
     */
    public void notifyRequestCompleted(Integer recipientUserId, Integer requestId,
                                      String bloodGroup, Integer quantity,
                                      String note) throws SQLException {
        String subject = "Yêu cầu máu đã hoàn tất";
        String message = String.format("Yêu cầu máu #%d (%s, %d đơn vị) đã được hoàn tất", 
                                      requestId, bloodGroup, quantity);
        if (note != null && !note.trim().isEmpty()) {
            message += "\nThông tin bàn giao: " + note;
        }
        String link = "/hospital/requests/" + requestId;
        createNotification(recipientUserId, "REQUEST_COMPLETED", subject, message, link);
    }

    // ========== TRANSFER NOTIFICATIONS ==========

    /**
     * Gửi notification khi transfer được tạo
     */
    public void notifyTransferCreated(Integer recipientUserId, Integer transferId, 
                                     String bloodGroup, Integer units) throws SQLException {
        String subject = "Điều phối túi máu mới";
        String message = String.format("Điều phối túi máu #%d (%s, %d đơn vị) đã được tạo", 
                                      transferId, bloodGroup, units);
        String link = "/transfers/" + transferId;
        createNotification(recipientUserId, "TRANSFER_CREATED", subject, message, link);
    }

    /**
     * Gửi notification khi transfer được picked up
     */
    public void notifyTransferPickedUp(Integer recipientUserId, Integer transferId) throws SQLException {
        String subject = "Điều phối túi máu đã được lấy";
        String message = String.format("Điều phối túi máu #%d đã được lấy", transferId);
        String link = "/transfers/" + transferId;
        createNotification(recipientUserId, "TRANSFER_PICKED_UP", subject, message, link);
    }

    /**
     * Gửi notification khi transfer đang trong quá trình vận chuyển
     */
    public void notifyTransferInTransit(Integer recipientUserId, Integer transferId) throws SQLException {
        String subject = "Điều phối túi máu đang vận chuyển";
        String message = String.format("Điều phối túi máu #%d đang trong quá trình vận chuyển", transferId);
        String link = "/transfers/" + transferId;
        createNotification(recipientUserId, "TRANSFER_IN_TRANSIT", subject, message, link);
    }

    /**
     * Gửi notification khi transfer được delivered
     */
    public void notifyTransferDelivered(Integer recipientUserId, Integer transferId) throws SQLException {
        String subject = "Điều phối túi máu đã được giao";
        String message = String.format("Điều phối túi máu #%d đã được giao thành công", transferId);
        String link = "/transfers/" + transferId;
        createNotification(recipientUserId, "TRANSFER_DELIVERED", subject, message, link);
    }

    /**
     * Gửi notification khi transfer bị cancelled
     */
    public void notifyTransferCancelled(Integer recipientUserId, Integer transferId) throws SQLException {
        String subject = "Điều phối túi máu đã bị hủy";
        String message = String.format("Điều phối túi máu #%d đã bị hủy", transferId);
        String link = "/transfers/" + transferId;
        createNotification(recipientUserId, "TRANSFER_CANCELLED", subject, message, link);
    }

    // ========== BAG NOTIFICATIONS ==========

    /**
     * Gửi notification khi bags bị expired
     */
    public void notifyBagExpired(Integer recipientUserId, Integer expiredCount) throws SQLException {
        String subject = "Túi máu quá hạn";
        String message = String.format("Có %d túi máu đã quá hạn và được đánh dấu EXPIRED", expiredCount);
        String link = "/hospital/inventory?status=EXPIRED";
        createNotification(recipientUserId, "BAG_EXPIRED", subject, message, link);

        // Send email notification (for hospitals)
        Map<String, String> emailVars = new HashMap<>();
        emailVars.put("expiredCount", String.valueOf(expiredCount));
        emailVars.put("message", message);
        sendEmailNotification(recipientUserId, "default", subject, emailVars);
    }

    // ========== APPOINTMENT NOTIFICATIONS ==========

    /**
     * Gửi notification khi appointment được confirm (chấp nhận)
     */
    public void notifyAppointmentConfirmed(Integer recipientUserId, Integer appointmentId, 
                                         String hospitalName, String scheduledAt) throws SQLException {
        System.out.println("[NotificationService] notifyAppointmentConfirmed - userId: " + recipientUserId);
        
        if (recipientUserId == null) {
            throw new SQLException("recipientUserId cannot be null");
        }
        
        String subject = "Lịch hẹn hiến máu đã được chấp nhận";
        String message = String.format("Lịch hẹn hiến máu của bạn tại %s đã được chấp nhận. " +
                                      "Thời gian dự kiến: %s. Vui lòng đến đúng giờ để thực hiện hiến máu.", 
                                      hospitalName, scheduledAt);
        String link = "/donor/schedule";
        
        System.out.println("[NotificationService] Creating notification...");
        Notification notification = createNotification(recipientUserId, "APPOINTMENT_CONFIRMED", subject, message, link);
        
        if (notification != null && notification.getNotificationId() != null) {
            System.out.println("[NotificationService] Notification created with ID: " + notification.getNotificationId());
        } else {
            System.err.println("[NotificationService] ERROR: Notification creation returned null!");
            throw new SQLException("Failed to create notification - createNotification returned null");
        }

        // Send email notification
        Map<String, String> emailVars = new HashMap<>();
        emailVars.put("hospitalName", hospitalName);
        emailVars.put("appointmentDate", scheduledAt);
        emailVars.put("hospitalAddress", ""); // Có thể lấy từ hospital nếu cần
        sendEmailNotification(recipientUserId, "appointment_confirmed", subject, emailVars);
    }

    /**
     * Gửi notification khi appointment bị cancelled (từ chối/hủy)
     */
    public void notifyAppointmentCancelled(Integer recipientUserId, Integer appointmentId, 
                                          String hospitalName) throws SQLException {
        String subject = "Lịch hẹn hiến máu đã bị hủy";
        String message = String.format("Lịch hẹn hiến máu của bạn tại %s đã bị hủy. " +
                                      "Vui lòng liên hệ bệnh viện để biết thêm chi tiết hoặc đặt lịch hẹn mới.", 
                                      hospitalName);
        String link = "/donor/schedule";
        createNotification(recipientUserId, "APPOINTMENT_CANCELLED", subject, message, link);

        // Send email notification
        Map<String, String> emailVars = new HashMap<>();
        emailVars.put("hospitalName", hospitalName);
        emailVars.put("message", message);
        sendEmailNotification(recipientUserId, "default", subject, emailVars);
    }
    
    /**
     * Gửi notification khi appointment bị reject (từ chối - khác với cancelled)
     */
    public void notifyAppointmentRejected(Integer recipientUserId, Integer appointmentId, 
                                         String hospitalName, String reason) throws SQLException {
        String subject = "Lịch hẹn hiến máu không được chấp nhận";
        String message = String.format("Lịch hẹn hiến máu của bạn tại %s không được chấp nhận. " +
                                      "%s Vui lòng liên hệ bệnh viện để biết thêm chi tiết hoặc đặt lịch hẹn mới.", 
                                      hospitalName, 
                                      reason != null && !reason.isEmpty() ? "Lý do: " + reason + ". " : "");
        String link = "/donor/schedule";
        createNotification(recipientUserId, "APPOINTMENT_CANCELLED", subject, message, link);
    }

    // ========== DONATION NOTIFICATIONS ==========

    /**
     * Gửi notification khi hiến máu thành công (donation record được tạo)
     */
    public void notifyDonationCompleted(Integer recipientUserId, Integer recordId, 
                                        String hospitalName, Integer quantityMl, String bloodGroup) throws SQLException {
        String subject = "Bạn đã hiến máu thành công";
        String message = String.format("Cảm ơn bạn đã hiến máu tại %s! Bạn đã hiến thành công %d ml nhóm máu %s. " +
                                      "Máu của bạn sẽ được sử dụng để cứu sống nhiều người.", 
                                      hospitalName, quantityMl, bloodGroup);
        String link = "/donor/history";
        createNotification(recipientUserId, "DONATION_COMPLETED", subject, message, link);

        // Send email notification
        Map<String, String> emailVars = new HashMap<>();
        emailVars.put("hospitalName", hospitalName);
        emailVars.put("donationDate", java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        emailVars.put("bloodGroup", bloodGroup);
        emailVars.put("quantity", String.valueOf(quantityMl));
        sendEmailNotification(recipientUserId, "donation_completed", subject, emailVars);
    }

    public Notification getNotificationById(Long notificationId) throws SQLException {
        return notificationDAO.findById(notificationId);
    }

    public List<Notification> getUserNotifications(Integer userId) throws SQLException {
        return notificationDAO.findByUserId(userId);
    }

    public List<Notification> getUnreadNotifications(Integer userId) throws SQLException {
        return notificationDAO.findUnreadByUserId(userId);
    }

    public boolean markAsRead(Long notificationId) throws SQLException {
        return notificationDAO.markAsRead(notificationId);
    }

    public boolean markAllAsRead(Integer userId) throws SQLException {
        List<Notification> notifications = notificationDAO.findByUserId(userId);
        boolean allSuccess = true;
        for (Notification notification : notifications) {
            if (!notification.getIsRead()) {
                if (!notificationDAO.markAsRead(notification.getNotificationId())) {
                    allSuccess = false;
                }
            }
        }
        return allSuccess;
    }
}

