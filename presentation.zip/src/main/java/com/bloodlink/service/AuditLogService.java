package com.bloodlink.service;

import com.bloodlink.dao.AuditLogDAO;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * AuditLogService - Service để log và query audit logs
 */
public class AuditLogService {
    private AuditLogDAO auditLogDAO;

    public AuditLogService() {
        this.auditLogDAO = new AuditLogDAO();
    }

    /**
     * Log user action
     */
    public void logAction(Integer userId, String action, String entityType, 
                         Integer entityId, String oldValue, String newValue,
                         String ipAddress, String userAgent) {
        try {
            auditLogDAO.create(userId, action, entityType, entityId, 
                              oldValue, newValue, ipAddress, userAgent);
        } catch (SQLException e) {
            System.err.println("[AuditLogService] Error logging action: " + e.getMessage());
            // Không throw để không làm gián đoạn business logic
        }
    }

    /**
     * Log simple action (không có old/new value)
     */
    public void logAction(Integer userId, String action, String entityType, 
                         Integer entityId, String ipAddress, String userAgent) {
        logAction(userId, action, entityType, entityId, null, null, ipAddress, userAgent);
    }

    /**
     * Query audit logs với filters
     */
    public List<Map<String, Object>> getLogs(Integer userId, String action,
                                             String entityType, LocalDateTime fromDate,
                                             LocalDateTime toDate, Integer limit,
                                             Integer offset) throws SQLException {
        return auditLogDAO.findLogs(userId, action, entityType, fromDate, toDate, limit, offset);
    }

    /**
     * Count logs
     */
    public int countLogs(Integer userId, String action, String entityType,
                         LocalDateTime fromDate, LocalDateTime toDate) throws SQLException {
        return auditLogDAO.countLogs(userId, action, entityType, fromDate, toDate);
    }
}

