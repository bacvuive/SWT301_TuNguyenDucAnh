package com.bloodlink.service;

import com.bloodlink.dao.*;
import com.bloodlink.model.BloodBag;
import com.bloodlink.model.TransferEvent;
import com.bloodlink.model.TransferRequest;
import com.bloodlink.util.AppConfig;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Service xử lý điều phối túi máu giữa các bệnh viện
 */
public class TransferService {
    private TransferRequestDAO transferRequestDAO;
    private TransferRequestBagsDAO transferRequestBagsDAO;
    private TransferEventDAO transferEventDAO;
    private BloodBagDAO bloodBagDAO;
    private HospitalDAO hospitalDAO;
    private NotificationService notificationService;
    private BloodRequestService bloodRequestService; // Lazy initialization để tránh circular dependency

    public TransferService() {
        this.transferRequestDAO = new TransferRequestDAO();
        this.transferRequestBagsDAO = new TransferRequestBagsDAO();
        this.transferEventDAO = new TransferEventDAO();
        this.bloodBagDAO = new BloodBagDAO();
        this.hospitalDAO = new HospitalDAO();
        this.notificationService = new NotificationService();
        // BloodRequestService sẽ được khởi tạo khi cần (lazy)
    }

    // Constructor for dependency injection (for testing)
    public TransferService(TransferRequestDAO transferRequestDAO,
                          TransferRequestBagsDAO transferRequestBagsDAO,
                          TransferEventDAO transferEventDAO,
                          BloodBagDAO bloodBagDAO,
                          HospitalDAO hospitalDAO,
                          NotificationService notificationService,
                          BloodRequestService bloodRequestService) {
        this.transferRequestDAO = transferRequestDAO;
        this.transferRequestBagsDAO = transferRequestBagsDAO;
        this.transferEventDAO = transferEventDAO;
        this.bloodBagDAO = bloodBagDAO;
        this.hospitalDAO = hospitalDAO;
        this.notificationService = notificationService;
        this.bloodRequestService = bloodRequestService;
    }

    /**
     * Lazy getter cho BloodRequestService để tránh circular dependency
     */
    private BloodRequestService getBloodRequestService() {
        if (bloodRequestService == null) {
            bloodRequestService = new BloodRequestService();
        }
        return bloodRequestService;
    }

    /**
     * Tạo transfer request và allocate bags theo FIFO (expiry_date)
     * Sử dụng stored procedure sp_allocate_transfer nếu có, nếu không thì implement trong Java
     * 
     * @param requestId ID của blood request (có thể null)
     * @param fromHospitalId Bệnh viện gửi
     * @param toHospitalId Bệnh viện nhận
     * @param bloodGroup Nhóm máu
     * @param component Thành phần (WB, RBC, PLT, FFP)
     * @param units Số lượng đơn vị
     * @return TransferRequest đã được tạo và allocate bags
     * @throws SQLException nếu không đủ hàng hoặc lỗi database
     */
    public TransferRequest createTransferWithAllocation(Integer requestId, Integer fromHospitalId,
                                                        Integer toHospitalId, String bloodGroup,
                                                        String component, Integer units) throws SQLException {
        
        // Validate
        if (fromHospitalId.equals(toHospitalId)) {
            throw new IllegalArgumentException("Không thể chuyển túi máu cho chính bệnh viện");
        }
        
        // Tạo transfer request
        TransferRequest transfer = new TransferRequest();
        transfer.setRequestId(requestId);
        transfer.setFromHospitalId(fromHospitalId);
        transfer.setToHospitalId(toHospitalId);
        transfer.setBloodGroup(bloodGroup);
        transfer.setComponent(component);
        transfer.setUnits(units);
        transfer.setStatus("PENDING");
        transfer.setCreatedAt(LocalDateTime.now());
        
        Integer transferId = transferRequestDAO.create(transfer);
        if (transferId == null) {
            throw new SQLException("Không thể tạo transfer request");
        }
        transfer.setTransferId(transferId);
        
        // Allocate bags với row-level locking và transaction
        try {
            allocateBagsForTransfer(transferId, fromHospitalId, bloodGroup, component, units);
            // Nếu allocate thành công, update status thành ACCEPTED
            transfer.setStatus("ACCEPTED");
            transferRequestDAO.updateStatus(transferId, "ACCEPTED");
            
            // Tạo event CREATED
            TransferEvent createdEvent = new TransferEvent();
            createdEvent.setTransferId(transferId);
            createdEvent.setEventType("CREATED");
            createdEvent.setNote("Transfer request created and bags allocated");
            createdEvent.setCreatedAt(LocalDateTime.now());
            transferEventDAO.create(createdEvent);
            
            // Gửi notifications
            sendTransferNotifications(transfer, "created");
            
        } catch (SQLException e) {
            // Nếu allocate thất bại, có thể xóa transfer request hoặc để status PENDING
            // Tùy vào business logic
            throw new SQLException("Không đủ túi máu để allocate: " + e.getMessage(), e);
        }
        
        return transfer;
    }

    /**
     * Allocate bags cho transfer request theo FIFO (expiry_date)
     * Sử dụng stored procedure sp_allocate_transfer nếu có, nếu không thì fallback về Java implementation
     */
    private void allocateBagsForTransfer(Integer transferId, Integer fromHospitalId,
                                        String bloodGroup, String component, Integer units) throws SQLException {
        
        Connection conn = com.bloodlink.util.DBConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);
            
            // Try to use stored procedure first
            try {
                String sql = "{call dbo.sp_allocate_transfer(?, ?, ?, ?, ?)}";
                try (PreparedStatement stmt = conn.prepareCall(sql)) {
                    stmt.setInt(1, transferId);
                    stmt.setInt(2, fromHospitalId);
                    stmt.setString(3, bloodGroup);
                    stmt.setString(4, component);
                    stmt.setInt(5, units);
                    stmt.execute();
                }
                conn.commit();
                return; // Success with stored procedure
            } catch (SQLException e) {
                // If stored procedure doesn't exist or fails, rollback and use Java implementation
                conn.rollback();
                System.err.println("Stored procedure sp_allocate_transfer not available, using Java implementation: " + e.getMessage());
            }
            
            // Fallback: Java implementation với row-level locking
            conn.setAutoCommit(false);
            
            // Query với row-level locking để allocate bags theo FIFO
            // Sử dụng WITH (ROWLOCK, UPDLOCK, READPAST) để tránh deadlock và skip locked rows
            String sql = "SELECT TOP (?) bag_id, status " +
                         "FROM blood_bag WITH (ROWLOCK, UPDLOCK, READPAST) " +
                         "WHERE hospital_id = ? " +
                         "  AND blood_group = ? " +
                         "  AND component = ? " +
                         "  AND status = 'AVAILABLE' " +
                         "  AND expiry_date >= CAST(GETDATE() AS DATE) " +
                         "ORDER BY expiry_date ASC, bag_id ASC";
            
            List<Integer> bagIds = new ArrayList<>();
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, units);
                stmt.setInt(2, fromHospitalId);
                stmt.setString(3, bloodGroup);
                stmt.setString(4, component);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        bagIds.add(rs.getInt("bag_id"));
                    }
                }
            }
            
            // Kiểm tra đủ số lượng
            if (bagIds.size() < units) {
                conn.rollback();
                throw new SQLException(String.format(
                    "Không đủ túi máu. Cần %d đơn vị nhưng chỉ có %d đơn vị khả dụng",
                    units, bagIds.size()
                ));
            }
            
            // Insert vào transfer_request_bags và update status = RESERVED
            String insertSql = "INSERT INTO transfer_request_bags (transfer_id, bag_id) VALUES (?, ?)";
            String updateSql = "UPDATE blood_bag SET status = 'RESERVED', updated_at = GETDATE() WHERE bag_id = ?";
            
            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql);
                 PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                
                for (Integer bagId : bagIds) {
                    // Insert vào transfer_request_bags
                    insertStmt.setInt(1, transferId);
                    insertStmt.setInt(2, bagId);
                    insertStmt.addBatch();
                    
                    // Update status = RESERVED
                    updateStmt.setInt(1, bagId);
                    updateStmt.addBatch();
                }
                
                insertStmt.executeBatch();
                updateStmt.executeBatch();
            }
            
            conn.commit();
            
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                    conn.close();
                } catch (SQLException e) {
                    // Ignore
                }
            }
        }
    }

    /**
     * Xử lý event cho transfer (PICKED_UP, IN_TRANSIT, DELIVERED, CANCELLED)
     */
    public void handleTransferEvent(Integer transferId, String eventType, String note, Integer actorUserId) throws SQLException {
        TransferRequest transfer = transferRequestDAO.findById(transferId);
        if (transfer == null) {
            throw new IllegalArgumentException("Transfer request không tồn tại");
        }
        
        // Validate status transition
        String currentStatus = transfer.getStatus();
        switch (eventType.toUpperCase()) {
            case "PICKED_UP":
                if (!"ACCEPTED".equals(currentStatus)) {
                    throw new IllegalArgumentException("Chỉ có thể PICKED_UP từ trạng thái ACCEPTED");
                }
                transfer.setStatus("IN_TRANSIT");
                break;
                
            case "IN_TRANSIT":
                if (!"ACCEPTED".equals(currentStatus) && !"IN_TRANSIT".equals(currentStatus)) {
                    throw new IllegalArgumentException("Chỉ có thể IN_TRANSIT từ trạng thái ACCEPTED hoặc IN_TRANSIT");
                }
                transfer.setStatus("IN_TRANSIT");
                break;
                
            case "DELIVERED":
                if (!"IN_TRANSIT".equals(currentStatus)) {
                    throw new IllegalArgumentException("Chỉ có thể DELIVERED từ trạng thái IN_TRANSIT");
                }
                // Chuyển bags sang to_hospital và set status = AVAILABLE
                completeTransfer(transfer);
                
                // Auto-link: Tự động complete request nếu enabled và có request_id
                if (AppConfig.isAutoLinkEnabled() && transfer.getRequestId() != null) {
                    try {
                        autoCompleteRequestForTransfer(transfer.getRequestId(), actorUserId);
                    } catch (SQLException e) {
                        // Log error nhưng không throw để không làm gián đoạn deliver transfer
                        System.err.println("Error auto-completing request " + transfer.getRequestId() + ": " + e.getMessage());
                        e.printStackTrace();
                    }
                }
                break;
                
            case "CANCELLED":
                if ("COMPLETED".equals(currentStatus) || "CANCELLED".equals(currentStatus)) {
                    throw new IllegalArgumentException("Không thể hủy transfer đã hoàn tất hoặc đã hủy");
                }
                // Trả bags về AVAILABLE
                cancelTransfer(transfer);
                break;
                
            default:
                throw new IllegalArgumentException("Event type không hợp lệ: " + eventType);
        }
        
        // Update transfer status
        transferRequestDAO.updateStatus(transferId, transfer.getStatus());
        
        // Tạo event record
        TransferEvent event = new TransferEvent();
        event.setTransferId(transferId);
        event.setEventType(eventType.toUpperCase());
        event.setNote(note);
        event.setCreatedAt(LocalDateTime.now());
        transferEventDAO.create(event);
        
        // Gửi notifications
        sendTransferNotifications(transfer, eventType.toLowerCase());
    }

    /**
     * Hoàn tất transfer: chuyển bags sang to_hospital và set status = AVAILABLE
     * Sử dụng stored procedure sp_complete_transfer nếu có
     */
    private void completeTransfer(TransferRequest transfer) throws SQLException {
        Connection conn = com.bloodlink.util.DBConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);
            
            // Try to use stored procedure first
            try {
                String sql = "{call dbo.sp_complete_transfer(?, ?)}";
                try (PreparedStatement stmt = conn.prepareCall(sql)) {
                    stmt.setInt(1, transfer.getTransferId());
                    stmt.setNull(2, Types.INTEGER); // actor_user_id (optional)
                    stmt.execute();
                }
                conn.commit();
                transfer.setStatus("COMPLETED");
                return; // Success with stored procedure
            } catch (SQLException e) {
                // If stored procedure doesn't exist or fails, rollback and use Java implementation
                conn.rollback();
                System.err.println("Stored procedure sp_complete_transfer not available, using Java implementation: " + e.getMessage());
            }
            
            // Fallback: Java implementation
            conn.setAutoCommit(false);
            
            // Lấy danh sách bag IDs
            List<Integer> bagIds = transferRequestBagsDAO.getBagIdsByTransferId(transfer.getTransferId());
            
            // Update bags: chuyển hospital_id và set status = AVAILABLE
            String updateSql = "UPDATE blood_bag SET hospital_id = ?, status = 'AVAILABLE', updated_at = GETDATE() " +
                              "WHERE bag_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                for (Integer bagId : bagIds) {
                    stmt.setInt(1, transfer.getToHospitalId());
                    stmt.setInt(2, bagId);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
            
            // Update transfer status
            transfer.setStatus("COMPLETED");
            transferRequestDAO.updateStatus(transfer.getTransferId(), "COMPLETED");
            
            conn.commit();
            
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                    conn.close();
                } catch (SQLException e) {
                    // Ignore
                }
            }
        }
    }

    /**
     * Hủy transfer: trả bags về status = AVAILABLE
     */
    private void cancelTransfer(TransferRequest transfer) throws SQLException {
        Connection conn = com.bloodlink.util.DBConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);
            
            // Lấy danh sách bag IDs
            List<Integer> bagIds = transferRequestBagsDAO.getBagIdsByTransferId(transfer.getTransferId());
            
            // Update bags: set status = AVAILABLE (giữ nguyên hospital_id)
            String updateSql = "UPDATE blood_bag SET status = 'AVAILABLE', updated_at = GETDATE() WHERE bag_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateSql)) {
                for (Integer bagId : bagIds) {
                    stmt.setInt(1, bagId);
                    stmt.addBatch();
                }
                stmt.executeBatch();
            }
            
            // Xóa bags khỏi transfer_request_bags (optional, vì có CASCADE DELETE)
            // transferRequestBagsDAO.removeAllBagsFromTransfer(transfer.getTransferId());
            
            // Update transfer status
            transfer.setStatus("CANCELLED");
            transferRequestDAO.updateStatus(transfer.getTransferId(), "CANCELLED");
            
            conn.commit();
            
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                } catch (SQLException e) {
                    // Ignore
                }
            }
        }
    }

    /**
     * Lấy transfer request với full details (bao gồm events và bags)
     */
    public TransferRequest getTransferWithDetails(Integer transferId) throws SQLException {
        return transferRequestDAO.findById(transferId);
    }

    /**
     * Lấy danh sách events của transfer
     */
    public List<TransferEvent> getTransferEvents(Integer transferId) throws SQLException {
        return transferEventDAO.findByTransferId(transferId);
    }

    /**
     * Lấy danh sách bags trong transfer
     */
    public List<BloodBag> getTransferBags(Integer transferId) throws SQLException {
        List<Integer> bagIds = transferRequestBagsDAO.getBagIdsByTransferId(transferId);
        List<BloodBag> bags = new ArrayList<>();
        for (Integer bagId : bagIds) {
            BloodBag bag = bloodBagDAO.findById(bagId);
            if (bag != null) {
                bags.add(bag);
            }
        }
        return bags;
    }

    /**
     * Tự động complete request khi transfer delivered
     */
    private void autoCompleteRequestForTransfer(Integer requestId, Integer actorUserId) throws SQLException {
        try {
            getBloodRequestService().completeRequest(requestId, actorUserId, 
                "Auto-completed khi transfer đã được delivered");
            System.out.println(String.format(
                "Auto-completed request #%d after transfer delivered",
                requestId
            ));
        } catch (IllegalArgumentException e) {
            // Request có thể đã được complete hoặc ở trạng thái không hợp lệ
            System.out.println("Cannot auto-complete request " + requestId + ": " + e.getMessage());
            // Không throw để không làm gián đoạn deliver transfer
        }
    }

    /**
     * Gửi notifications cho các bệnh viện liên quan
     */
    private void sendTransferNotifications(TransferRequest transfer, String eventType) {
        try {
            // Gửi cho from_hospital và to_hospital
            var fromHospital = hospitalDAO.findById(transfer.getFromHospitalId());
            var toHospital = hospitalDAO.findById(transfer.getToHospitalId());
            
            Integer transferId = transfer.getTransferId();
            
            // Gửi notification theo type mới
            switch (eventType.toUpperCase()) {
                case "created":
                    if (fromHospital != null && fromHospital.getUserId() != null) {
                        notificationService.notifyTransferCreated(
                            fromHospital.getUserId(), transferId, 
                            transfer.getBloodGroup(), transfer.getUnits());
                    }
                    if (toHospital != null && toHospital.getUserId() != null) {
                        notificationService.notifyTransferCreated(
                            toHospital.getUserId(), transferId, 
                            transfer.getBloodGroup(), transfer.getUnits());
                    }
                    break;
                    
                case "picked_up":
                    if (fromHospital != null && fromHospital.getUserId() != null) {
                        notificationService.notifyTransferPickedUp(fromHospital.getUserId(), transferId);
                    }
                    if (toHospital != null && toHospital.getUserId() != null) {
                        notificationService.notifyTransferPickedUp(toHospital.getUserId(), transferId);
                    }
                    break;
                    
                case "in_transit":
                    if (fromHospital != null && fromHospital.getUserId() != null) {
                        notificationService.notifyTransferInTransit(fromHospital.getUserId(), transferId);
                    }
                    if (toHospital != null && toHospital.getUserId() != null) {
                        notificationService.notifyTransferInTransit(toHospital.getUserId(), transferId);
                    }
                    break;
                    
                case "delivered":
                    if (fromHospital != null && fromHospital.getUserId() != null) {
                        notificationService.notifyTransferDelivered(fromHospital.getUserId(), transferId);
                    }
                    if (toHospital != null && toHospital.getUserId() != null) {
                        notificationService.notifyTransferDelivered(toHospital.getUserId(), transferId);
                    }
                    break;
                    
                case "cancelled":
                    if (fromHospital != null && fromHospital.getUserId() != null) {
                        notificationService.notifyTransferCancelled(fromHospital.getUserId(), transferId);
                    }
                    if (toHospital != null && toHospital.getUserId() != null) {
                        notificationService.notifyTransferCancelled(toHospital.getUserId(), transferId);
                    }
                    break;
            }
            
        } catch (SQLException e) {
            System.err.println("Error sending transfer notifications: " + e.getMessage());
            // Không throw để không làm gián đoạn luồng chính
        }
    }

    private String getEventTypeText(String eventType) {
        return switch (eventType.toLowerCase()) {
            case "created" -> "đã tạo và allocate túi";
            case "picked_up" -> "đã lấy hàng";
            case "in_transit" -> "đang vận chuyển";
            case "delivered" -> "đã bàn giao";
            case "cancelled" -> "đã hủy";
            default -> eventType;
        };
    }
}

