package com.bloodlink.service;

import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.dao.BloodRequestDAO;
import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.RequestAuditDAO;
import com.bloodlink.dao.UserDAO;
import com.bloodlink.model.BloodBag;
import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.Donor;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.RequestAudit;
import com.bloodlink.model.TransferRequest;
import com.bloodlink.model.User;
import com.bloodlink.util.AppConfig;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.bloodlink.util.DBConnection;

public class BloodRequestService {
    private BloodRequestDAO bloodRequestDAO;
    private DonorDAO donorDAO;
    private HospitalDAO hospitalDAO;
    private UserDAO userDAO;
    private NotificationService notificationService;
    private TransferService transferService; // Lazy initialization để tránh circular dependency
    private BloodBagDAO bloodBagDAO; // Để kiểm tra stock

    public BloodRequestService() {
        this.bloodRequestDAO = new BloodRequestDAO();
        this.donorDAO = new DonorDAO();
        this.hospitalDAO = new HospitalDAO();
        this.userDAO = new UserDAO();
        this.notificationService = new NotificationService();
        this.bloodBagDAO = new BloodBagDAO();
        // TransferService sẽ được khởi tạo khi cần (lazy)
    }

    private void transferBagsForCompletedRequest(Connection conn, BloodRequest request, Integer actorUserId) throws SQLException {
        if (request.getToHospitalId() == null || request.getQuantity() == null || request.getQuantity() <= 0) {
            return;
        }

        Integer providerHospitalId = request.getToHospitalId();
        Integer receiverHospitalId = request.getFromHospitalId();
        int units = request.getQuantity();

        List<BloodBag> availableBags = bloodBagDAO.findAvailableForTransfer(
            conn,
            providerHospitalId,
            request.getBloodGroup(),
            request.getComponent(),
            units
        );

        if (availableBags.size() < units) {
            throw new IllegalStateException(String.format(
                "Không đủ túi máu khả dụng tại bệnh viện #%d để hoàn tất yêu cầu #%d",
                providerHospitalId,
                request.getRequestId()
            ));
        }

        List<Integer> bagIdsToMove = availableBags.stream()
            .limit(units)
            .map(BloodBag::getBagId)
            .collect(Collectors.toList());

        bloodBagDAO.moveBagsToHospital(
            conn,
            bagIdsToMove,
            receiverHospitalId,
            actorUserId,
            request.getRequestId()
        );
    }

    // Constructor for dependency injection (for testing)
    public BloodRequestService(BloodRequestDAO bloodRequestDAO, DonorDAO donorDAO,
                               HospitalDAO hospitalDAO, UserDAO userDAO,
                               NotificationService notificationService,
                               TransferService transferService,
                               BloodBagDAO bloodBagDAO) {
        this.bloodRequestDAO = bloodRequestDAO;
        this.donorDAO = donorDAO;
        this.hospitalDAO = hospitalDAO;
        this.userDAO = userDAO;
        this.notificationService = notificationService;
        this.transferService = transferService;
        this.bloodBagDAO = bloodBagDAO;
    }

    /**
     * Lazy getter cho TransferService để tránh circular dependency
     */
    private TransferService getTransferService() {
        if (transferService == null) {
            transferService = new TransferService();
        }
        return transferService;
    }

    /**
     * Tạo yêu cầu máu và gửi thông báo đến:
     * 1. Các donors có nhóm máu phù hợp
     * 2. Các bệnh viện (tất cả hoặc bệnh viện cụ thể)
     * 
     * Validation:
     * - from_hospital_id != to_hospital_id (CHECK constraint in DB)
     * - quantity > 0
     * - bloodGroup valid
     */
    public BloodRequest createRequest(Integer fromHospitalId, Integer toHospitalId,
                                      String bloodGroup, String component, Integer quantity,
                                      Integer actorUserId) 
            throws SQLException {
        
        // Validate: from_hospital_id != to_hospital_id
        if (toHospitalId != null && fromHospitalId.equals(toHospitalId)) {
            throw new IllegalArgumentException("Không thể tạo yêu cầu máu cho chính bệnh viện của mình");
        }
        
        // Validate quantity
        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("Số lượng phải lớn hơn 0");
        }
        
        // Validate bloodGroup
        if (bloodGroup == null || bloodGroup.trim().isEmpty()) {
            throw new IllegalArgumentException("Nhóm máu không được để trống");
        }
        
        // Tạo yêu cầu máu
        BloodRequest request = new BloodRequest();
        request.setFromHospitalId(fromHospitalId);
        request.setToHospitalId(toHospitalId); // NULL = broadcast to all hospitals
        request.setBloodGroup(bloodGroup);
        request.setComponent(component != null ? component : "WB"); // Default to Whole Blood
        request.setQuantity(quantity);
        request.setStatus("PENDING");
        request.setCreatedAt(LocalDateTime.now());
        request.setUpdatedAt(LocalDateTime.now());

        Integer requestId = bloodRequestDAO.create(request);
        if (requestId == null) {
            throw new SQLException("Không thể tạo yêu cầu máu");
        }

        request.setRequestId(requestId);
        
        // Create audit record for PENDING status
        // Note: Stored procedure will handle audit, but we can also create it here for initial creation
        try {
            RequestAuditDAO requestAuditDAO = new RequestAuditDAO();
            RequestAudit audit = new RequestAudit();
            audit.setRequestId(requestId);
            audit.setActorUserId(actorUserId);
            audit.setOldStatus(null);
            audit.setNewStatus("PENDING");
            audit.setNote("Request created");
            audit.setCreatedAt(LocalDateTime.now());
            requestAuditDAO.create(audit);
        } catch (SQLException e) {
            // Log error but don't fail the request creation
            System.err.println("Error creating audit record: " + e.getMessage());
        }
        
        // Lấy thông tin bệnh viện tạo yêu cầu
        Hospital fromHospital = hospitalDAO.findById(fromHospitalId);
        String hospitalName = fromHospital != null ? fromHospital.getName() : "Bệnh viện";
        
        // Gửi thông báo cho donors có nhóm máu phù hợp
        sendNotificationsToDonors(request, hospitalName);
        
        // Gửi thông báo cho các bệnh viện
        sendNotificationsToHospitals(request, hospitalName);
        
        return request;
    }
    
    /**
     * Overload method for backward compatibility (without actorUserId)
     */
    public BloodRequest createRequest(Integer fromHospitalId, Integer toHospitalId,
                                      String bloodGroup, String component, Integer quantity) 
            throws SQLException {
        return createRequest(fromHospitalId, toHospitalId, bloodGroup, component, quantity, null);
    }

    /**
     * Gửi thông báo đến các donors có nhóm máu phù hợp
     */
    private void sendNotificationsToDonors(BloodRequest request, String hospitalName) {
        try {
            List<Donor> matchingDonors = donorDAO.findByBloodGroup(request.getBloodGroup());
            
            String message = String.format(
                "🚨 Yêu cầu máu khẩn cấp từ %s: Cần %d đơn vị nhóm máu %s (%s). " +
                "Vui lòng liên hệ nếu bạn có thể hỗ trợ!",
                hospitalName, request.getQuantity(), request.getBloodGroup(), 
                getComponentName(request.getComponent())
            );
            
            for (Donor donor : matchingDonors) {
                try {
                    // Chỉ gửi cho donors đang active
                    User user = userDAO.findById(donor.getUserId());
                    if (user != null && "active".equals(user.getStatus())) {
                        notificationService.createNotification(
                            donor.getUserId(),
                            "warning", // Loại cảnh báo
                            message
                        );
                    }
                } catch (SQLException e) {
                    System.err.println("Error sending notification to donor " + donor.getDonorId() + ": " + e.getMessage());
                    // Continue với donors khác
                }
            }
            
            System.out.println("Sent blood request notifications to " + matchingDonors.size() + " donors");
        } catch (SQLException e) {
            System.err.println("Error finding donors for blood request: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Gửi thông báo đến các bệnh viện
     * - Nếu toHospitalId == null: gửi cho tất cả bệnh viện (trừ bệnh viện tạo yêu cầu)
     * - Nếu toHospitalId != null: chỉ gửi cho bệnh viện đó
     */
    private void sendNotificationsToHospitals(BloodRequest request, String fromHospitalName) {
        try {
            List<Hospital> targetHospitals = new ArrayList<>();
            
            if (request.getToHospitalId() != null) {
                // Gửi cho bệnh viện cụ thể
                Hospital targetHospital = hospitalDAO.findById(request.getToHospitalId());
                if (targetHospital != null) {
                    targetHospitals.add(targetHospital);
                }
            } else {
                // Broadcast: gửi cho tất cả bệnh viện (trừ bệnh viện tạo yêu cầu)
                List<Hospital> allHospitals = hospitalDAO.findAll();
                for (Hospital hospital : allHospitals) {
                    if (!hospital.getHospitalId().equals(request.getFromHospitalId())) {
                        // Chỉ gửi cho bệnh viện có user (đã có tài khoản)
                        if (hospital.getUserId() != null) {
                            targetHospitals.add(hospital);
                        }
                    }
                }
            }
            
            String message = String.format(
                "🏥 Yêu cầu máu từ %s: Cần %d đơn vị nhóm máu %s (%s). " +
                "Vui lòng kiểm tra kho máu và phản hồi nếu có thể hỗ trợ.",
                fromHospitalName, request.getQuantity(), request.getBloodGroup(),
                getComponentName(request.getComponent())
            );
            
            for (Hospital hospital : targetHospitals) {
                try {
                    if (hospital.getUserId() != null) {
                        notificationService.createNotification(
                            hospital.getUserId(),
                            "info",
                            message
                        );
                    }
                } catch (SQLException e) {
                    System.err.println("Error sending notification to hospital " + hospital.getHospitalId() + ": " + e.getMessage());
                    // Continue với hospitals khác
                }
            }
            
            System.out.println("Sent blood request notifications to " + targetHospitals.size() + " hospitals");
        } catch (SQLException e) {
            System.err.println("Error finding hospitals for blood request: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Đóng yêu cầu máu (chỉ bệnh viện tạo yêu cầu mới có quyền)
     */
    public boolean closeRequest(Integer requestId, Integer hospitalId) throws SQLException {
        BloodRequest request = bloodRequestDAO.findById(requestId);
        if (request == null) {
            throw new IllegalArgumentException("Yêu cầu máu không tồn tại");
        }
        
        // Kiểm tra quyền: chỉ bệnh viện tạo yêu cầu mới có quyền đóng
        if (!request.getFromHospitalId().equals(hospitalId)) {
            throw new IllegalArgumentException("Bạn không có quyền đóng yêu cầu này");
        }
        
        // Kiểm tra trạng thái hiện tại
        if ("COMPLETED".equals(request.getStatus()) || "CANCELLED".equals(request.getStatus())) {
            throw new IllegalArgumentException("Yêu cầu này đã được đóng trước đó");
        }
        
        // Đóng yêu cầu
        request.setStatus("COMPLETED");
        request.setUpdatedAt(LocalDateTime.now());
        
        return bloodRequestDAO.update(request);
    }

    /**
     * Hủy yêu cầu máu (chỉ bệnh viện tạo yêu cầu mới có quyền)
     */
    public boolean cancelRequest(Integer requestId, Integer hospitalId) throws SQLException {
        BloodRequest request = bloodRequestDAO.findById(requestId);
        if (request == null) {
            throw new IllegalArgumentException("Yêu cầu máu không tồn tại");
        }
        
        // Kiểm tra quyền: chỉ bệnh viện tạo yêu cầu mới có quyền hủy
        if (!request.getFromHospitalId().equals(hospitalId)) {
            throw new IllegalArgumentException("Bạn không có quyền hủy yêu cầu này");
        }
        
        // Kiểm tra trạng thái hiện tại
        if ("COMPLETED".equals(request.getStatus()) || "CANCELLED".equals(request.getStatus())) {
            throw new IllegalArgumentException("Yêu cầu này đã được đóng trước đó");
        }
        
        // Hủy yêu cầu
        request.setStatus("CANCELLED");
        request.setUpdatedAt(LocalDateTime.now());
        
        return bloodRequestDAO.update(request);
    }

    /**
     * Lấy tất cả yêu cầu máu của một bệnh viện
     */
    public List<BloodRequest> getRequestsByHospital(Integer hospitalId) throws SQLException {
        return bloodRequestDAO.findByToHospitalId(hospitalId);
    }

    /**
     * Lấy tất cả yêu cầu máu đang pending
     */
    public List<BloodRequest> getPendingRequests() throws SQLException {
        return bloodRequestDAO.findByStatus("PENDING");
    }

    /**
     * Lấy yêu cầu máu theo ID
     */
    public BloodRequest getRequestById(Integer requestId) throws SQLException {
        return bloodRequestDAO.findById(requestId);
    }

    /**
     * Lấy tất cả yêu cầu máu
     */
    public List<BloodRequest> getAllRequests() throws SQLException {
        return bloodRequestDAO.findAll();
    }

    /**
     * Lấy yêu cầu máu theo trạng thái
     */
    public List<BloodRequest> getRequestsByStatus(String status) throws SQLException {
        return bloodRequestDAO.findByStatus(status);
    }

    /**
     * Cập nhật yêu cầu máu
     */
    public boolean updateRequest(BloodRequest request) throws SQLException {
        request.setUpdatedAt(LocalDateTime.now());
        return bloodRequestDAO.update(request);
    }

    /**
     * Lấy yêu cầu máu do bệnh viện tạo ra (outgoing requests)
     */
    public List<BloodRequest> getRequestsCreatedByHospital(Integer hospitalId) throws SQLException {
        return bloodRequestDAO.findByFromHospitalId(hospitalId);
    }
    
    /**
     * Lấy các yêu cầu máu đến (incoming requests) cho một bệnh viện
     * Bao gồm:
     * 1. Yêu cầu gửi trực tiếp đến bệnh viện này (to_hospital_id = hospitalId)
     * 2. Yêu cầu broadcast (to_hospital_id IS NULL) nhưng không phải do bệnh viện này tạo
     */
    public List<BloodRequest> getIncomingRequests(Integer hospitalId) throws SQLException {
        return bloodRequestDAO.findIncomingRequests(hospitalId);
    }

    /**
     * Chấp nhận yêu cầu máu (PENDING → ACCEPTED)
     * Sử dụng row-level locking để tránh race condition (đặc biệt với broadcast requests)
     * Nếu auto-link enabled và có to_hospital + đủ stock → tự động tạo transfer
     * 
     * Broadcast logic: First-accept wins
     * - Nếu request là broadcast (to_hospital_id = NULL), bệnh viện đầu tiên accept sẽ win
     * - Các bệnh viện khác sẽ thấy request đã được accept (status != PENDING)
     */
    public boolean acceptRequest(Integer requestId, Integer actorUserId, String note) throws SQLException {
        Connection conn = DBConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        
        try {
            conn.setAutoCommit(false);
            
            // Lock request row with UPDLOCK để tránh concurrent accept
            BloodRequest request = findByIdWithLock(conn, requestId);
            if (request == null) {
                conn.rollback();
                throw new IllegalArgumentException("Yêu cầu máu không tồn tại");
            }
            
            // Validate status transition: chỉ cho phép PENDING → ACCEPTED
            if (!"PENDING".equals(request.getStatus())) {
                conn.rollback();
                throw new IllegalArgumentException(
                    String.format("Không thể chấp nhận yêu cầu ở trạng thái %s. Yêu cầu có thể đã được xử lý bởi bệnh viện khác.", 
                        request.getStatus())
                );
            }
            
            // Validate: Chỉ to_hospital (hoặc bất kỳ hospital nào với broadcast) mới có thể accept
            // Lấy hospital của actor
            Hospital actorHospital = hospitalDAO.findByUserId(actorUserId);
            if (actorHospital == null) {
                conn.rollback();
                throw new IllegalArgumentException("Không tìm thấy thông tin bệnh viện của bạn");
            }
            
            // Nếu là targeted request, chỉ to_hospital mới có thể accept
            if (request.getToHospitalId() != null && !request.getToHospitalId().equals(actorHospital.getHospitalId())) {
                conn.rollback();
                throw new IllegalArgumentException("Bạn không có quyền chấp nhận yêu cầu này. Yêu cầu này được gửi đến bệnh viện khác.");
            }
            
            // Nếu là broadcast, từ_hospital không thể accept chính request của mình
            if (request.getToHospitalId() == null && request.getFromHospitalId().equals(actorHospital.getHospitalId())) {
                conn.rollback();
                throw new IllegalArgumentException("Bạn không thể chấp nhận yêu cầu do chính bạn tạo ra");
            }
            
            // Cập nhật status thông qua stored procedure (sẽ lock và update trong transaction)
            // Note: stored procedure sẽ tự commit nếu thành công, nhưng chúng ta đang trong transaction
            // Tạm thời update trực tiếp trong transaction này
            boolean success = updateRequestStatusInTransaction(conn, requestId, "ACCEPTED", actorUserId, note);
            
            if (!success) {
                conn.rollback();
                return false;
            }
            
            // Reload request để lấy status mới trong cùng transaction
            request =   reloadRequestWithinTransaction(conn, requestId);
            
            conn.commit();
            
            // Gửi notification (sau khi commit)
            sendStatusChangeNotifications(request, "ACCEPTED", actorUserId, note);
            
            // Auto-link: Tự động tạo transfer nếu enabled
            // Logic: from_hospital trong transfer = actorHospital (người accept, cung cấp máu)
            //        to_hospital trong transfer = request.fromHospitalId (người tạo request, nhận máu)
            if (AppConfig.isAutoLinkEnabled()) {
                try {
                    autoCreateTransferForRequest(request, actorUserId, actorHospital.getHospitalId());
                } catch (SQLException e) {
                    // Log error nhưng không throw để không làm gián đoạn accept request
                    System.err.println("Error auto-creating transfer for request " + requestId + ": " + e.getMessage());
                    e.printStackTrace();
                    // Có thể gửi notification về lỗi này
                }
            }
            
            return true;
            
        } catch (Exception e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                    conn.close();
                } catch (SQLException e) {
                    // Ignore
                }
            }
        }
    }
    
    /**
     * Find request by ID with row-level lock (UPDLOCK)
     */
    private BloodRequest findByIdWithLock(Connection conn, Integer requestId) throws SQLException {
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request WITH (UPDLOCK, ROWLOCK) " +
                     "WHERE request_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBloodRequest(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Reload request trong cùng transaction (không tạo connection mới)
     */
    private BloodRequest reloadRequestWithinTransaction(Connection conn, Integer requestId) throws SQLException {
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request WHERE request_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBloodRequest(rs);
                }
            }
        }
        return null;
    }

    /**
     * Update request status in transaction (calls stored procedure or direct update)
     */
    private boolean updateRequestStatusInTransaction(Connection conn, Integer requestId, String newStatus,
                                                    Integer actorUserId, String note) throws SQLException {
        // Use stored procedure if available, otherwise direct update
        String sql = "{call dbo.sp_update_request_status(?, ?, ?, ?)}";
        try (PreparedStatement stmt = conn.prepareCall(sql)) {
            stmt.setInt(1, requestId);
            stmt.setString(2, newStatus);
            if (actorUserId != null) {
                stmt.setInt(3, actorUserId);
            } else {
                stmt.setNull(3, Types.INTEGER);
            }
            if (note != null && !note.trim().isEmpty()) {
                stmt.setString(4, note);
            } else {
                stmt.setNull(4, Types.NVARCHAR);
            }
            stmt.execute();
            return true;
        }
    }
    
    /**
     * Map ResultSet to BloodRequest (helper method)
     */
    private BloodRequest mapResultSetToBloodRequest(ResultSet rs) throws SQLException {
        BloodRequest request = new BloodRequest();
        request.setRequestId(rs.getInt("request_id"));
        request.setFromHospitalId(rs.getInt("from_hospital_id"));
        int toHospitalId = rs.getInt("to_hospital_id");
        if (!rs.wasNull()) {
            request.setToHospitalId(toHospitalId);
        }
        request.setBloodGroup(rs.getString("blood_group"));
        request.setComponent(rs.getString("component"));
        request.setQuantity(rs.getInt("quantity"));
        request.setStatus(rs.getString("status"));
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            request.setCreatedAt(createdTs.toLocalDateTime());
        }
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        if (updatedTs != null) {
            request.setUpdatedAt(updatedTs.toLocalDateTime());
        }
        return request;
    }

    /**
     * Tự động tạo transfer khi accept request
     * Logic: Request được tạo bởi hospital A gửi đến hospital B
     * Khi hospital B accept → hospital B cung cấp máu cho hospital A
     * Transfer: from_hospital = B (actor), to_hospital = A (người tạo request)
     * 
     * @param request BloodRequest đã được accept
     * @param actorUserId User ID của người accept
     * @param actorHospitalId Hospital ID của người accept (đã được validate)
     */
    private void autoCreateTransferForRequest(BloodRequest request, Integer actorUserId, Integer actorHospitalId) throws SQLException {
        // Xác định to_hospital: là hospital tạo request (from_hospital_id trong request)
        Integer toHospitalId = request.getFromHospitalId();
        if (toHospitalId == null) {
            // Nếu request là broadcast và không có from_hospital_id cụ thể, không tạo transfer
            System.out.println("Cannot auto-create transfer: request is broadcast without from_hospital");
            return;
        }
        
        // Validate: from_hospital != to_hospital
        if (actorHospitalId.equals(toHospitalId)) {
            System.out.println("Cannot auto-create transfer: from_hospital equals to_hospital");
            return;
        }
        
        // Kiểm tra stock trước khi tạo transfer
        // Nếu không đủ stock, không tạo transfer (không throw exception để không làm gián đoạn accept)
        List<BloodBag> availableBags = bloodBagDAO.findAvailable(
            actorHospitalId,
            request.getBloodGroup(),
            request.getComponent()
        );
        
        if (availableBags.size() < request.getQuantity()) {
            System.out.println(String.format(
                "Không đủ stock để auto-create transfer. Cần %d nhưng chỉ có %d",
                request.getQuantity(), availableBags.size()
            ));
            return; // Không tạo transfer nếu không đủ stock
        }
        
        // Tạo transfer với auto-allocation
        // from_hospital = actorHospital (người accept, cung cấp máu)
        // to_hospital = request.fromHospitalId (người tạo request, nhận máu)
        TransferRequest transfer = getTransferService().createTransferWithAllocation(
            request.getRequestId(),
            actorHospitalId, // from_hospital: hospital đang accept
            toHospitalId,    // to_hospital: hospital tạo request
            request.getBloodGroup(),
            request.getComponent(),
            request.getQuantity()
        );
        
        System.out.println(String.format(
            "Auto-created transfer #%d for request #%d (from hospital %d to hospital %d)",
            transfer.getTransferId(), request.getRequestId(),
            actorHospitalId, toHospitalId
        ));
    }
    
    /**
     * Từ chối yêu cầu máu (PENDING → REJECTED)
     * Sử dụng row-level locking để tránh race condition
     */
    public boolean rejectRequest(Integer requestId, Integer actorUserId, String note) throws SQLException {
        Connection conn = DBConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        
        try {
            conn.setAutoCommit(false);
            
            // Lock request row with UPDLOCK
            BloodRequest request = findByIdWithLock(conn, requestId);
            if (request == null) {
                conn.rollback();
                throw new IllegalArgumentException("Yêu cầu máu không tồn tại");
            }
            
            // Validate status transition: chỉ cho phép PENDING → REJECTED
            if (!"PENDING".equals(request.getStatus())) {
                conn.rollback();
                throw new IllegalArgumentException(
                    String.format("Không thể từ chối yêu cầu ở trạng thái %s. Chỉ cho phép từ chối yêu cầu PENDING.", 
                        request.getStatus())
                );
            }
            
            // Validate: Chỉ to_hospital (hoặc bất kỳ hospital nào với broadcast) mới có thể reject
            Hospital actorHospital = hospitalDAO.findByUserId(actorUserId);
            if (actorHospital == null) {
                conn.rollback();
                throw new IllegalArgumentException("Không tìm thấy thông tin bệnh viện của bạn");
            }
            
            // Nếu là targeted request, chỉ to_hospital mới có thể reject
            if (request.getToHospitalId() != null && !request.getToHospitalId().equals(actorHospital.getHospitalId())) {
                conn.rollback();
                throw new IllegalArgumentException("Bạn không có quyền từ chối yêu cầu này. Yêu cầu này được gửi đến bệnh viện khác.");
            }
            
            // Nếu là broadcast, từ_hospital không thể reject chính request của mình
            if (request.getToHospitalId() == null && request.getFromHospitalId().equals(actorHospital.getHospitalId())) {
                conn.rollback();
                throw new IllegalArgumentException("Bạn không thể từ chối yêu cầu do chính bạn tạo ra");
            }
            
            // Cập nhật status thông qua stored procedure
            boolean success = updateRequestStatusInTransaction(conn, requestId, "REJECTED", actorUserId, note);
            
            if (!success) {
                conn.rollback();
                return false;
            }
            
            // Reload request để lấy status mới
            request = bloodRequestDAO.findById(requestId);
            
            conn.commit();
            
            // Gửi notification (sau khi commit)
            sendStatusChangeNotifications(request, "REJECTED", actorUserId, note);
            
            return true;
            
        } catch (Exception e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                    conn.close();
                } catch (SQLException e) {
                    // Ignore
                }
            }
        }
    }
    
    /**
     * Hoàn tất yêu cầu máu (ACCEPTED → COMPLETED)
     * Chỉ từ_hospital (người tạo request) mới có thể complete
     */
    public boolean completeRequest(Integer requestId, Integer actorUserId, String note) throws SQLException {
        Connection conn = DBConnection.getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        
        try {
            conn.setAutoCommit(false);
            
            // Lock request row with UPDLOCK
            BloodRequest request = findByIdWithLock(conn, requestId);
            if (request == null) {
                conn.rollback();
                throw new IllegalArgumentException("Yêu cầu máu không tồn tại");
            }
            
            // Validate status transition: chỉ cho phép ACCEPTED → COMPLETED
            if (!"ACCEPTED".equals(request.getStatus())) {
                conn.rollback();
                throw new IllegalArgumentException(
                    String.format("Không thể hoàn tất yêu cầu ở trạng thái %s. Chỉ cho phép hoàn tất yêu cầu ACCEPTED.", 
                        request.getStatus())
                );
            }
            
            // Validate: Chỉ from_hospital (người tạo request) mới có thể complete
            Hospital actorHospital = hospitalDAO.findByUserId(actorUserId);
            if (actorHospital == null) {
                conn.rollback();
                throw new IllegalArgumentException("Không tìm thấy thông tin bệnh viện của bạn");
            }
            
            if (!request.getFromHospitalId().equals(actorHospital.getHospitalId())) {
                conn.rollback();
                throw new IllegalArgumentException("Chỉ bệnh viện tạo yêu cầu mới có thể hoàn tất yêu cầu này");
            }
            
            // Cập nhật status thông qua stored procedure
            boolean success = updateRequestStatusInTransaction(conn, requestId, "COMPLETED", actorUserId, note);
            
            if (!success) {
                conn.rollback();
                return false;
            }
            
            // Chuyển túi máu từ bệnh viện chấp nhận sang bệnh viện yêu cầu
            try {
                transferBagsForCompletedRequest(conn, request, actorUserId);
            } catch (IllegalStateException transferEx) {
                conn.rollback();
                throw transferEx;
            }
            
            // Reload request để lấy status mới
            request = bloodRequestDAO.findById(requestId);
            
            conn.commit();
            
            // Gửi notification (sau khi commit)
            sendStatusChangeNotifications(request, "COMPLETED", actorUserId, note);
            
            return true;
            
        } catch (Exception e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(originalAutoCommit);
                    conn.close();
                } catch (SQLException e) {
                    // Ignore
                }
            }
        }
    }
    
    /**
     * Gửi thông báo khi trạng thái yêu cầu máu thay đổi
     * Gửi đến: from_hospital, to_hospital (nếu có), và requester
     */
    private void sendStatusChangeNotifications(BloodRequest request, String newStatus, Integer actorUserId, String note) {
        try {
            // Lấy thông tin bệnh viện tạo yêu cầu
            Hospital fromHospital = hospitalDAO.findById(request.getFromHospitalId());
            Hospital toHospital = null;
            if (request.getToHospitalId() != null) {
                toHospital = hospitalDAO.findById(request.getToHospitalId());
            }
            
            // Gửi notification theo type mới
            if ("ACCEPTED".equals(newStatus)) {
                // Gửi cho from_hospital (người tạo request)
                if (fromHospital != null && fromHospital.getUserId() != null) {
                    try {
                        notificationService.notifyRequestAccepted(
                            fromHospital.getUserId(),
                            request.getRequestId(),
                            request.getBloodGroup(),
                            request.getQuantity(),
                            note
                        );
                    } catch (SQLException e) {
                        System.err.println("Error sending notification to from_hospital: " + e.getMessage());
                    }
                }
                // Gửi cho to_hospital (người accept)
                if (toHospital != null && toHospital.getUserId() != null) {
                    try {
                        notificationService.notifyRequestAccepted(
                            toHospital.getUserId(),
                            request.getRequestId(),
                            request.getBloodGroup(),
                            request.getQuantity(),
                            note
                        );
                    } catch (SQLException e) {
                        System.err.println("Error sending notification to to_hospital: " + e.getMessage());
                    }
                }
            } else if ("REJECTED".equals(newStatus)) {
                // Gửi cho from_hospital (người tạo request)
                if (fromHospital != null && fromHospital.getUserId() != null) {
                    try {
                        notificationService.notifyRequestRejected(
                            fromHospital.getUserId(),
                            request.getRequestId(),
                            request.getBloodGroup(),
                            request.getQuantity(),
                            note
                        );
                    } catch (SQLException e) {
                        System.err.println("Error sending notification to from_hospital: " + e.getMessage());
                    }
                }
                // Gửi cho to_hospital (người reject)
                if (toHospital != null && toHospital.getUserId() != null) {
                    try {
                        notificationService.notifyRequestRejected(
                            toHospital.getUserId(),
                            request.getRequestId(),
                            request.getBloodGroup(),
                            request.getQuantity(),
                            note
                        );
                    } catch (SQLException e) {
                        System.err.println("Error sending notification to to_hospital: " + e.getMessage());
                    }
                }
            } else if ("COMPLETED".equals(newStatus)) {
                // Gửi cho from_hospital (người tạo request)
                if (fromHospital != null && fromHospital.getUserId() != null) {
                    try {
                        notificationService.notifyRequestCompleted(
                            fromHospital.getUserId(),
                            request.getRequestId(),
                            request.getBloodGroup(),
                            request.getQuantity(),
                            note
                        );
                    } catch (SQLException e) {
                        System.err.println("Error sending notification to from_hospital: " + e.getMessage());
                    }
                }
                // Gửi cho to_hospital
                if (toHospital != null && toHospital.getUserId() != null) {
                    try {
                        notificationService.notifyRequestCompleted(
                            toHospital.getUserId(),
                            request.getRequestId(),
                            request.getBloodGroup(),
                            request.getQuantity(),
                            note
                        );
                    } catch (SQLException e) {
                        System.err.println("Error sending notification to to_hospital: " + e.getMessage());
                    }
                }
            }
            
            // Nếu là broadcast (to_hospital_id = NULL), có thể gửi cho tất cả bệnh viện khác
            // (Logic này có thể được mở rộng sau)
            
        } catch (SQLException e) {
            System.err.println("Error sending status change notifications: " + e.getMessage());
            e.printStackTrace();
            // Không throw exception để không làm gián đoạn luồng chính
        }
    }
    
    /**
     * Helper method: Chuyển đổi status code thành tên hiển thị
     */
    private String getStatusText(String status) {
        if (status == null) {
            return "cập nhật";
        }
        return switch (status.toUpperCase()) {
            case "ACCEPTED" -> "chấp nhận";
            case "REJECTED" -> "từ chối";
            case "COMPLETED" -> "hoàn tất";
            case "PENDING" -> "đang chờ";
            default -> status.toLowerCase();
        };
    }
    
    /**
     * Helper method: Chuyển đổi component code thành tên hiển thị
     */
    private String getComponentName(String component) {
        if (component == null || component.isEmpty()) {
            return "Toàn phần";
        }
        return switch (component.toUpperCase()) {
            case "WB" -> "Máu toàn phần";
            case "RBC" -> "Hồng cầu";
            case "PLT" -> "Tiểu cầu";
            case "FFP" -> "Huyết tương tươi đông lạnh";
            default -> component;
        };
    }
}

