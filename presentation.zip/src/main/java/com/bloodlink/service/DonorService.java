package com.bloodlink.service;

import com.bloodlink.dao.AppointmentDAO;
import com.bloodlink.dao.DonationRecordDAO;
import com.bloodlink.dao.DonorDAO;
import com.bloodlink.model.Appointment;
import com.bloodlink.model.DonationRecord;
import com.bloodlink.model.Donor;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

public class DonorService {
    private DonorDAO donorDAO;
    private DonationRecordDAO donationRecordDAO;
    private AppointmentDAO appointmentDAO;

    public DonorService() {
        this.donorDAO = new DonorDAO();
        this.donationRecordDAO = new DonationRecordDAO();
        this.appointmentDAO = new AppointmentDAO();
    }

    // Constructor for dependency injection (for testing)
    public DonorService(DonorDAO donorDAO, DonationRecordDAO donationRecordDAO, AppointmentDAO appointmentDAO) {
        this.donorDAO = donorDAO;
        this.donationRecordDAO = donationRecordDAO;
        this.appointmentDAO = appointmentDAO;
    }

    public Donor getDonorByUserId(Integer userId) throws SQLException {
        return donorDAO.findByUserId(userId);
    }

    public Donor getDonorById(Integer donorId) throws SQLException {
        return donorDAO.findById(donorId);
    }

    public List<DonationRecord> getDonationHistory(Integer donorId) throws SQLException {
        return donationRecordDAO.findByDonorId(donorId);
    }

    public int getDonationCount(Integer donorId) throws SQLException {
        return donationRecordDAO.findByDonorId(donorId).size();
    }

    public List<Appointment> getAppointments(Integer donorId) throws SQLException {
        return appointmentDAO.findByDonorId(donorId);
    }

    public List<Appointment> getUpcomingAppointments(Integer donorId) throws SQLException {
        List<Appointment> appointments = appointmentDAO.findByDonorId(donorId);
        LocalDateTime now = LocalDateTime.now();
        return appointments.stream()
                .filter(apt -> apt.getScheduledAt().isAfter(now) && 
                        !"CANCELLED".equals(apt.getStatus()) && 
                        !"COMPLETED".equals(apt.getStatus()))
                .sorted((a, b) -> a.getScheduledAt().compareTo(b.getScheduledAt()))
                .toList();
    }

    public Appointment createAppointment(Integer donorId, Integer hospitalId, 
                                         LocalDateTime scheduledAt, String note) throws SQLException {
        Appointment appointment = new Appointment();
        appointment.setDonorId(donorId);
        appointment.setHospitalId(hospitalId);
        appointment.setScheduledAt(scheduledAt);
        appointment.setNote(note);
        appointment.setStatus("PENDING");
        appointment.setCreatedAt(LocalDateTime.now());

        Integer appointmentId = appointmentDAO.create(appointment);
        if (appointmentId != null) {
            return appointmentDAO.findById(appointmentId);
        }
        return null;
    }

    public boolean updateAppointment(Appointment appointment) throws SQLException {
        appointment.setUpdatedAt(LocalDateTime.now());
        return appointmentDAO.update(appointment);
    }

    public boolean cancelAppointment(Integer appointmentId) throws SQLException {
        Appointment appointment = appointmentDAO.findById(appointmentId);
        if (appointment != null) {
            appointment.setStatus("CANCELLED");
            appointment.setUpdatedAt(LocalDateTime.now());
            return appointmentDAO.update(appointment);
        }
        return false;
    }
}

