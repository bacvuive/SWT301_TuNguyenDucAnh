package com.bloodlink.service;

import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.dao.BloodRequestDAO;
import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.UserDAO;
import com.bloodlink.model.BloodBag;
import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.Donor;
import com.bloodlink.model.User;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SearchService - Cung cấp tìm kiếm và lọc nâng cao cho hệ thống
 */
public class SearchService {
    private DonorDAO donorDAO;
    private BloodBagDAO bloodBagDAO;
    private BloodRequestDAO bloodRequestDAO;
    private UserDAO userDAO;
    private HospitalDAO hospitalDAO;

    public SearchService() {
        this.donorDAO = new DonorDAO();
        this.bloodBagDAO = new BloodBagDAO();
        this.bloodRequestDAO = new BloodRequestDAO();
        this.userDAO = new UserDAO();
        this.hospitalDAO = new HospitalDAO();
    }

    // ========== DONOR SEARCH ==========

    /**
     * Tìm kiếm donors với full-text search và filters
     */
    public List<Map<String, Object>> searchDonors(String query, String bloodGroup, String region, 
                                                  Integer limit, Integer offset) throws SQLException {
        List<Donor> donors = donorDAO.findAll();
        List<Map<String, Object>> results = new ArrayList<>();

        for (Donor donor : donors) {
            // Apply filters
            if (bloodGroup != null && !bloodGroup.isEmpty()) {
                if (!bloodGroup.equals(donor.getBloodGroup())) {
                    continue;
                }
            }

            // Full-text search
            if (query != null && !query.trim().isEmpty()) {
                String searchQuery = query.toLowerCase().trim();
                boolean matches = false;

                // Search in name
                if (donor.getFullName() != null && 
                    donor.getFullName().toLowerCase().contains(searchQuery)) {
                    matches = true;
                }

                // Search in phone
                if (!matches && donor.getPhone() != null && 
                    donor.getPhone().contains(searchQuery)) {
                    matches = true;
                }

                // Search in address
                if (!matches && donor.getAddress() != null && 
                    donor.getAddress().toLowerCase().contains(searchQuery)) {
                    matches = true;
                }

                // Search in email (from user)
                if (!matches) {
                    try {
                        User user = userDAO.findById(donor.getUserId());
                        if (user != null && user.getEmail() != null && 
                            user.getEmail().toLowerCase().contains(searchQuery)) {
                            matches = true;
                        }
                    } catch (SQLException e) {
                        // Ignore
                    }
                }

                if (!matches) {
                    continue;
                }
            }

            // Enrich with user info
            Map<String, Object> enriched = new HashMap<>();
            enriched.put("donorId", donor.getDonorId());
            enriched.put("fullName", donor.getFullName());
            enriched.put("phone", donor.getPhone());
            enriched.put("bloodGroup", donor.getBloodGroup());
            enriched.put("address", donor.getAddress());
            enriched.put("gender", donor.getGender());
            enriched.put("dob", donor.getDob());

            try {
                User user = userDAO.findById(donor.getUserId());
                if (user != null) {
                    enriched.put("email", user.getEmail());
                }
            } catch (SQLException e) {
                // Ignore
            }

            results.add(enriched);
        }

        // Apply pagination
        if (offset != null && limit != null) {
            int start = offset;
            int end = Math.min(start + limit, results.size());
            if (start < results.size()) {
                return results.subList(start, end);
            }
            return new ArrayList<>();
        }

        return results;
    }

    /**
     * Đếm số lượng donors sau khi filter
     */
    public int countDonors(String query, String bloodGroup, String region) throws SQLException {
        List<Map<String, Object>> results = searchDonors(query, bloodGroup, region, null, null);
        return results.size();
    }

    // ========== BLOOD BAG SEARCH ==========

    /**
     * Tìm kiếm blood bags với filters
     */
    public List<Map<String, Object>> searchBloodBags(Integer hospitalId, String query, 
                                                     String bloodGroup, String component, 
                                                     String status, LocalDate fromDate, 
                                                     LocalDate toDate, Integer limit, 
                                                     Integer offset) throws SQLException {
        List<BloodBag> bags = bloodBagDAO.findByHospitalId(hospitalId);
        List<Map<String, Object>> results = new ArrayList<>();

        for (BloodBag bag : bags) {
            // Apply filters
            if (bloodGroup != null && !bloodGroup.isEmpty()) {
                if (!bloodGroup.equals(bag.getBloodGroup())) {
                    continue;
                }
            }

            if (component != null && !component.isEmpty()) {
                if (!component.equals(bag.getComponent())) {
                    continue;
                }
            }

            if (status != null && !status.isEmpty()) {
                if (!status.equals(bag.getStatus())) {
                    continue;
                }
            }

            // Date range filter
            if (fromDate != null && bag.getCollectionDate() != null) {
                if (bag.getCollectionDate().isBefore(fromDate)) {
                    continue;
                }
            }

            if (toDate != null && bag.getCollectionDate() != null) {
                if (bag.getCollectionDate().isAfter(toDate)) {
                    continue;
                }
            }

            // Full-text search
            if (query != null && !query.trim().isEmpty()) {
                String searchQuery = query.toLowerCase().trim();
                boolean matches = false;

                // Search in bag code
                if (bag.getBagCode() != null && 
                    bag.getBagCode().toLowerCase().contains(searchQuery)) {
                    matches = true;
                }

                if (!matches) {
                    continue;
                }
            }

            // Enrich bag data
            Map<String, Object> enriched = new HashMap<>();
            enriched.put("bagId", bag.getBagId());
            enriched.put("bagCode", bag.getBagCode());
            enriched.put("bloodGroup", bag.getBloodGroup());
            enriched.put("component", bag.getComponent());
            enriched.put("volumeMl", bag.getVolumeMl());
            enriched.put("collectionDate", bag.getCollectionDate());
            enriched.put("expiryDate", bag.getExpiryDate());
            enriched.put("status", bag.getStatus());
            enriched.put("hospitalId", bag.getHospitalId());

            results.add(enriched);
        }

        // Apply pagination
        if (offset != null && limit != null) {
            int start = offset;
            int end = Math.min(start + limit, results.size());
            if (start < results.size()) {
                return results.subList(start, end);
            }
            return new ArrayList<>();
        }

        return results;
    }

    /**
     * Đếm số lượng blood bags sau khi filter
     */
    public int countBloodBags(Integer hospitalId, String query, String bloodGroup, 
                             String component, String status, LocalDate fromDate, 
                             LocalDate toDate) throws SQLException {
        List<Map<String, Object>> results = searchBloodBags(hospitalId, query, bloodGroup, 
                                                           component, status, fromDate, 
                                                           toDate, null, null);
        return results.size();
    }

    // ========== BLOOD REQUEST SEARCH ==========

    /**
     * Tìm kiếm blood requests với filters
     */
    public List<Map<String, Object>> searchBloodRequests(Integer hospitalId, String query,
                                                         String bloodGroup, String component,
                                                         String status, Integer limit,
                                                         Integer offset) throws SQLException {
        List<BloodRequest> requests;
        
        // Get requests based on hospital role
        if (hospitalId != null) {
            requests = bloodRequestDAO.findByToHospitalId(hospitalId);
        } else {
            requests = bloodRequestDAO.findAll();
        }

        List<Map<String, Object>> results = new ArrayList<>();

        for (BloodRequest request : requests) {
            // Apply filters
            if (bloodGroup != null && !bloodGroup.isEmpty()) {
                if (!bloodGroup.equals(request.getBloodGroup())) {
                    continue;
                }
            }

            if (component != null && !component.isEmpty()) {
                if (!component.equals(request.getComponent())) {
                    continue;
                }
            }

            if (status != null && !status.isEmpty()) {
                if (!status.equals(request.getStatus())) {
                    continue;
                }
            }

            // Full-text search (search in request ID)
            if (query != null && !query.trim().isEmpty()) {
                String searchQuery = query.toLowerCase().trim();
                boolean matches = false;

                // Search in request ID
                if (String.valueOf(request.getRequestId()).contains(searchQuery)) {
                    matches = true;
                }

                // Search in hospital names
                if (!matches) {
                    try {
                        if (request.getFromHospitalId() != null) {
                            var fromHospital = hospitalDAO.findById(request.getFromHospitalId());
                            if (fromHospital != null && fromHospital.getName() != null &&
                                fromHospital.getName().toLowerCase().contains(searchQuery)) {
                                matches = true;
                            }
                        }
                        if (!matches && request.getToHospitalId() != null) {
                            var toHospital = hospitalDAO.findById(request.getToHospitalId());
                            if (toHospital != null && toHospital.getName() != null &&
                                toHospital.getName().toLowerCase().contains(searchQuery)) {
                                matches = true;
                            }
                        }
                    } catch (SQLException e) {
                        // Ignore
                    }
                }

                if (!matches) {
                    continue;
                }
            }

            // Enrich request data
            Map<String, Object> enriched = new HashMap<>();
            enriched.put("requestId", request.getRequestId());
            enriched.put("fromHospitalId", request.getFromHospitalId());
            enriched.put("toHospitalId", request.getToHospitalId());
            enriched.put("bloodGroup", request.getBloodGroup());
            enriched.put("component", request.getComponent());
            enriched.put("quantity", request.getQuantity());
            enriched.put("status", request.getStatus());
            enriched.put("createdAt", request.getCreatedAt());
            enriched.put("updatedAt", request.getUpdatedAt());

            // Add hospital names
            try {
                if (request.getFromHospitalId() != null) {
                    var fromHospital = hospitalDAO.findById(request.getFromHospitalId());
                    if (fromHospital != null) {
                        enriched.put("fromHospitalName", fromHospital.getName());
                    }
                }
                if (request.getToHospitalId() != null) {
                    var toHospital = hospitalDAO.findById(request.getToHospitalId());
                    if (toHospital != null) {
                        enriched.put("toHospitalName", toHospital.getName());
                    }
                }
            } catch (SQLException e) {
                // Ignore
            }

            results.add(enriched);
        }

        // Apply pagination
        if (offset != null && limit != null) {
            int start = offset;
            int end = Math.min(start + limit, results.size());
            if (start < results.size()) {
                return results.subList(start, end);
            }
            return new ArrayList<>();
        }

        return results;
    }

    /**
     * Đếm số lượng blood requests sau khi filter
     */
    public int countBloodRequests(Integer hospitalId, String query, String bloodGroup,
                                  String component, String status) throws SQLException {
        List<Map<String, Object>> results = searchBloodRequests(hospitalId, query, bloodGroup,
                                                                component, status, null, null);
        return results.size();
    }
}

