package com.bloodlink.service;

import com.bloodlink.dao.BagActionLogDAO;
import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.model.BloodBag;

import java.sql.SQLException;

/**
 * Service xử lý cập nhật status của blood bag với validation
 */
public class BloodBagStatusService {
    private BloodBagDAO bloodBagDAO;
    private BagActionLogDAO bagActionLogDAO;
    private boolean hasTrigger;

    public BloodBagStatusService() {
        this.bloodBagDAO = new BloodBagDAO();
        this.bagActionLogDAO = new BagActionLogDAO();
        // Kiểm tra xem DB có trigger không
        this.hasTrigger = bagActionLogDAO.hasTrigger();
    }

    // Constructor for dependency injection (for testing)
    public BloodBagStatusService(BloodBagDAO bloodBagDAO, BagActionLogDAO bagActionLogDAO, boolean hasTrigger) {
        this.bloodBagDAO = bloodBagDAO;
        this.bagActionLogDAO = bagActionLogDAO;
        this.hasTrigger = hasTrigger;
    }

    /**
     * Cập nhật status của blood bag với validation
     * Cho phép: AVAILABLE → RESERVED → IN_USE | TRANSFERRED
     * 
     * @param bagId ID của bag
     * @param newStatus Trạng thái mới
     * @param actorUserId ID của user thực hiện
     * @param note Ghi chú (optional)
     * @return StatusUpdateResult chứa bag và oldStatus
     * @throws IllegalArgumentException nếu status transition không hợp lệ
     * @throws SQLException nếu có lỗi database
     */
    public StatusUpdateResult updateBagStatus(Integer bagId, String newStatus, Integer actorUserId, String note) 
            throws SQLException {
        
        // Lấy bag hiện tại
        BloodBag bag = bloodBagDAO.findById(bagId);
        if (bag == null) {
            throw new IllegalArgumentException("Blood bag không tồn tại");
        }
        
        String oldStatus = bag.getStatus();
        
        // Validate status transition
        if (!isValidStatusTransition(oldStatus, newStatus)) {
            throw new IllegalArgumentException(
                String.format("Không thể chuyển từ %s sang %s. Chỉ cho phép: AVAILABLE → RESERVED → IN_USE | TRANSFERRED",
                    oldStatus, newStatus)
            );
        }
        
        // Update status
        boolean updated = bloodBagDAO.updateStatus(bagId, newStatus);
        if (!updated) {
            throw new SQLException("Không thể cập nhật status của blood bag");
        }
        
        // Ghi log nếu không có trigger trong DB
        if (!hasTrigger) {
            bagActionLogDAO.logStatusChange(bagId, oldStatus, newStatus, actorUserId, note);
        }
        
        // Reload bag để trả về dữ liệu mới nhất
        BloodBag updatedBag = bloodBagDAO.findById(bagId);
        return new StatusUpdateResult(updatedBag, oldStatus);
    }

    /**
     * Inner class để trả về kết quả update status
     */
    public static class StatusUpdateResult {
        private final BloodBag bag;
        private final String oldStatus;

        public StatusUpdateResult(BloodBag bag, String oldStatus) {
            this.bag = bag;
            this.oldStatus = oldStatus;
        }

        public BloodBag getBag() {
            return bag;
        }

        public String getOldStatus() {
            return oldStatus;
        }
    }

    /**
     * Validate status transition
     * Cho phép:
     * - AVAILABLE → RESERVED
     * - RESERVED → IN_USE
     * - RESERVED → TRANSFERRED
     * 
     * Cấm các luồng khác (VD: AVAILABLE → IN_USE trực tiếp)
     */
    private boolean isValidStatusTransition(String oldStatus, String newStatus) {
        if (oldStatus == null || newStatus == null) {
            return false;
        }
        
        // Không cho phép chuyển sang cùng status
        if (oldStatus.equals(newStatus)) {
            return false;
        }
        
        // Cho phép transitions
        return switch (oldStatus.toUpperCase()) {
            case "AVAILABLE" -> "RESERVED".equalsIgnoreCase(newStatus);
            case "RESERVED" -> "IN_USE".equalsIgnoreCase(newStatus) || 
                               "TRANSFERRED".equalsIgnoreCase(newStatus);
            default -> false; // Các status khác không cho phép chuyển
        };
    }
}

