package com.bloodlink.dao;

import com.bloodlink.model.Hospital;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class HospitalDAO {
    
    public Hospital findById(Integer hospitalId) throws SQLException {
        String sql = "SELECT hospital_id, user_id, name, address, contact, region, latitude, longitude, " +
                     "is_verified, verified_at, verified_by, verification_note, created_at " +
                     "FROM hospital WHERE hospital_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToHospital(rs);
                }
            }
        }
        return null;
    }
    
    public Hospital findByUserId(Integer userId) throws SQLException {
        String sql = "SELECT hospital_id, user_id, name, address, contact, region, latitude, longitude, " +
                     "is_verified, verified_at, verified_by, verification_note, created_at " +
                     "FROM hospital WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToHospital(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(Hospital hospital) throws SQLException {
        String sql = "INSERT INTO hospital (user_id, name, address, contact, region, is_verified, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, hospital.getUserId());
            stmt.setString(2, hospital.getName());
            stmt.setString(3, hospital.getAddress());
            stmt.setString(4, hospital.getContact());
            stmt.setString(5, hospital.getRegion());
            stmt.setBoolean(6, hospital.getIsVerified() != null ? hospital.getIsVerified() : false);
            stmt.setTimestamp(7, Timestamp.valueOf(hospital.getCreatedAt() != null ? 
                    hospital.getCreatedAt() : LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        }
        return null;
    }
    
    public boolean update(Hospital hospital) throws SQLException {
        String sql = "UPDATE hospital SET name = ?, address = ?, contact = ?, region = ?, " +
                     "latitude = ?, longitude = ?, is_verified = ?, verified_at = ?, verified_by = ?, verification_note = ? " +
                     "WHERE hospital_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hospital.getName());
            stmt.setString(2, hospital.getAddress());
            stmt.setString(3, hospital.getContact());
            stmt.setString(4, hospital.getRegion());
            if (hospital.getLatitude() != null) {
                stmt.setDouble(5, hospital.getLatitude());
            } else {
                stmt.setNull(5, Types.DOUBLE);
            }
            if (hospital.getLongitude() != null) {
                stmt.setDouble(6, hospital.getLongitude());
            } else {
                stmt.setNull(6, Types.DOUBLE);
            }
            stmt.setBoolean(7, hospital.getIsVerified() != null ? hospital.getIsVerified() : false);
            if (hospital.getVerifiedAt() != null) {
                stmt.setTimestamp(8, Timestamp.valueOf(hospital.getVerifiedAt()));
            } else {
                stmt.setNull(8, Types.TIMESTAMP);
            }
            if (hospital.getVerifiedBy() != null) {
                stmt.setInt(9, hospital.getVerifiedBy());
            } else {
                stmt.setNull(9, Types.INTEGER);
            }
            if (hospital.getVerificationNote() != null) {
                stmt.setString(10, hospital.getVerificationNote());
            } else {
                stmt.setNull(10, Types.NVARCHAR);
            }
            stmt.setInt(11, hospital.getHospitalId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<Hospital> findAll() throws SQLException {
        List<Hospital> hospitals = new ArrayList<>();
        String sql = "SELECT hospital_id, user_id, name, address, contact, region, latitude, longitude, " +
                     "is_verified, verified_at, verified_by, verification_note, created_at " +
                     "FROM hospital ORDER BY name";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                hospitals.add(mapResultSetToHospital(rs));
            }
        }
        return hospitals;
    }
    
    public List<Hospital> findByRegion(String region) throws SQLException {
        List<Hospital> hospitals = new ArrayList<>();
        String sql = "SELECT hospital_id, user_id, name, address, contact, region, latitude, longitude, " +
                     "is_verified, verified_at, verified_by, verification_note, created_at " +
                     "FROM hospital WHERE region = ? ORDER BY name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, region);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    hospitals.add(mapResultSetToHospital(rs));
                }
            }
        }
        return hospitals;
    }
    
    private Hospital mapResultSetToHospital(ResultSet rs) throws SQLException {
        Hospital hospital = new Hospital();
        hospital.setHospitalId(rs.getInt("hospital_id"));
        
        // Handle NULL user_id
        int userId = rs.getInt("user_id");
        if (rs.wasNull()) {
            hospital.setUserId(null);
        } else {
            hospital.setUserId(userId);
        }
        
        hospital.setName(rs.getString("name"));
        hospital.setAddress(rs.getString("address"));
        hospital.setContact(rs.getString("contact"));
        hospital.setRegion(rs.getString("region"));

        double lat = rs.getDouble("latitude");
        hospital.setLatitude(rs.wasNull() ? null : lat);

        double lng = rs.getDouble("longitude");
        hospital.setLongitude(rs.wasNull() ? null : lng);

        boolean verified = rs.getBoolean("is_verified");
        hospital.setIsVerified(rs.wasNull() ? null : verified);

        Timestamp verifiedAt = rs.getTimestamp("verified_at");
        if (verifiedAt != null) {
            hospital.setVerifiedAt(verifiedAt.toLocalDateTime());
        }

        int verifiedBy = rs.getInt("verified_by");
        hospital.setVerifiedBy(rs.wasNull() ? null : verifiedBy);

        hospital.setVerificationNote(rs.getString("verification_note"));

        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) {
            hospital.setCreatedAt(ts.toLocalDateTime());
        }
        return hospital;
    }
}

