package com.bloodlink.dao;

import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * AuditLogDAO - DAO cho bảng audit_log
 * Log tất cả user actions để audit và security
 */
public class AuditLogDAO {
    
    /**
     * Tạo audit log entry
     */
    public boolean create(Integer userId, String action, String entityType, 
                         Integer entityId, String oldValue, String newValue,
                         String ipAddress, String userAgent) throws SQLException {
        String sql = "INSERT INTO audit_log (user_id, action, entity_type, entity_id, " +
                     "old_value, new_value, ip_address, user_agent, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, userId, Types.INTEGER);
            stmt.setString(2, action);
            stmt.setString(3, entityType);
            stmt.setObject(4, entityId, Types.INTEGER);
            stmt.setString(5, oldValue);
            stmt.setString(6, newValue);
            stmt.setString(7, ipAddress);
            stmt.setString(8, userAgent);
            stmt.setTimestamp(9, Timestamp.valueOf(LocalDateTime.now()));
            
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Lấy audit logs với filters
     */
    public List<Map<String, Object>> findLogs(Integer userId, String action, 
                                             String entityType, LocalDateTime fromDate,
                                             LocalDateTime toDate, Integer limit, 
                                             Integer offset) throws SQLException {
        List<Map<String, Object>> logs = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder(
            "SELECT log_id, user_id, action, entity_type, entity_id, old_value, " +
            "new_value, ip_address, user_agent, created_at " +
            "FROM audit_log WHERE 1=1"
        );
        
        List<Object> params = new ArrayList<>();
        int paramIndex = 1;
        
        if (userId != null) {
            sql.append(" AND user_id = ?");
            params.add(userId);
        }
        
        if (action != null && !action.isEmpty()) {
            sql.append(" AND action = ?");
            params.add(action);
        }
        
        if (entityType != null && !entityType.isEmpty()) {
            sql.append(" AND entity_type = ?");
            params.add(entityType);
        }
        
        if (fromDate != null) {
            sql.append(" AND created_at >= ?");
            params.add(Timestamp.valueOf(fromDate));
        }
        
        if (toDate != null) {
            sql.append(" AND created_at <= ?");
            params.add(Timestamp.valueOf(toDate));
        }
        
        sql.append(" ORDER BY created_at DESC");
        
        if (limit != null) {
            sql.append(" OFFSET ? ROWS FETCH NEXT ? ROWS ONLY");
            params.add(offset != null ? offset : 0);
            params.add(limit);
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> log = new HashMap<>();
                    log.put("logId", rs.getLong("log_id"));
                    log.put("userId", rs.getObject("user_id"));
                    log.put("action", rs.getString("action"));
                    log.put("entityType", rs.getString("entity_type"));
                    log.put("entityId", rs.getObject("entity_id"));
                    log.put("oldValue", rs.getString("old_value"));
                    log.put("newValue", rs.getString("new_value"));
                    log.put("ipAddress", rs.getString("ip_address"));
                    log.put("userAgent", rs.getString("user_agent"));
                    Timestamp ts = rs.getTimestamp("created_at");
                    if (ts != null) {
                        log.put("createdAt", ts.toLocalDateTime());
                    }
                    logs.add(log);
                }
            }
        }
        
        return logs;
    }

    /**
     * Đếm số lượng logs
     */
    public int countLogs(Integer userId, String action, String entityType,
                        LocalDateTime fromDate, LocalDateTime toDate) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM audit_log WHERE 1=1");
        List<Object> params = new ArrayList<>();
        
        if (userId != null) {
            sql.append(" AND user_id = ?");
            params.add(userId);
        }
        
        if (action != null && !action.isEmpty()) {
            sql.append(" AND action = ?");
            params.add(action);
        }
        
        if (entityType != null && !entityType.isEmpty()) {
            sql.append(" AND entity_type = ?");
            params.add(entityType);
        }
        
        if (fromDate != null) {
            sql.append(" AND created_at >= ?");
            params.add(Timestamp.valueOf(fromDate));
        }
        
        if (toDate != null) {
            sql.append(" AND created_at <= ?");
            params.add(Timestamp.valueOf(toDate));
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        
        return 0;
    }
}

