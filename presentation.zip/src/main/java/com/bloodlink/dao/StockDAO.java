package com.bloodlink.dao;

import com.bloodlink.model.StockSummary;
import com.bloodlink.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO để đọc stock summary từ views v_stock_summary và v_stock_by_status
 */
public class StockDAO {
    
    /**
     * Lấy stock summary AVAILABLE từ view v_stock_summary
     * @param hospitalId ID của hospital (null = tất cả hospitals)
     * @return List StockSummary
     * @throws SQLException
     */
    public List<StockSummary> getAvailableStockSummary(Integer hospitalId) throws SQLException {
        List<StockSummary> summaries = new ArrayList<>();
        String sql = "SELECT hospital_id, hospital_name, blood_group, component, units " +
                     "FROM v_stock_summary";
        
        if (hospitalId != null) {
            sql += " WHERE hospital_id = ?";
        }
        
        sql += " ORDER BY hospital_id, blood_group, component";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            if (hospitalId != null) {
                stmt.setInt(1, hospitalId);
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    StockSummary summary = new StockSummary();
                    summary.setHospitalId(rs.getInt("hospital_id"));
                    summary.setHospitalName(rs.getString("hospital_name"));
                    summary.setBloodGroup(rs.getString("blood_group"));
                    summary.setComponent(rs.getString("component"));
                    summary.setStatus("AVAILABLE"); // View này chỉ có AVAILABLE
                    summary.setUnits(rs.getInt("units"));
                    summaries.add(summary);
                }
            }
        }
        return summaries;
    }
    
    /**
     * Lấy stock summary theo status từ view v_stock_by_status
     * @param hospitalId ID của hospital (null = tất cả hospitals)
     * @param status Status cần lấy (null = tất cả status)
     * @return List StockSummary
     * @throws SQLException
     */
    public List<StockSummary> getStockByStatus(Integer hospitalId, String status) throws SQLException {
        List<StockSummary> summaries = new ArrayList<>();
        // View v_stock_by_status chỉ có: hospital_id, blood_group, component, status, units
        // Không có hospital_name, cần join với hospital table nếu cần
        String sql = "SELECT v.hospital_id, h.[name] AS hospital_name, v.blood_group, v.component, v.[status], v.units " +
                     "FROM v_stock_by_status v " +
                     "LEFT JOIN hospital h ON h.hospital_id = v.hospital_id";
        
        List<String> conditions = new ArrayList<>();
        if (hospitalId != null) {
            conditions.add("v.hospital_id = ?");
        }
        if (status != null && !status.isEmpty()) {
            conditions.add("v.[status] = ?");
        }
        
        if (!conditions.isEmpty()) {
            sql += " WHERE " + String.join(" AND ", conditions);
        }
        
        sql += " ORDER BY v.hospital_id, v.blood_group, v.component, v.[status]";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            int paramIndex = 1;
            if (hospitalId != null) {
                stmt.setInt(paramIndex++, hospitalId);
            }
            if (status != null && !status.isEmpty()) {
                stmt.setString(paramIndex++, status);
            }
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    StockSummary summary = new StockSummary();
                    summary.setHospitalId(rs.getInt("hospital_id"));
                    String hospitalName = rs.getString("hospital_name");
                    if (hospitalName != null) {
                        summary.setHospitalName(hospitalName);
                    }
                    summary.setBloodGroup(rs.getString("blood_group"));
                    summary.setComponent(rs.getString("component"));
                    summary.setStatus(rs.getString("status"));
                    summary.setUnits(rs.getInt("units"));
                    summaries.add(summary);
                }
            }
        }
        return summaries;
    }
    
    /**
     * Lấy tổng stock summary theo hospital, blood_group, component, status
     * @param hospitalId ID của hospital (null = tất cả hospitals)
     * @return List StockSummary grouped by hospital, blood_group, component, status
     * @throws SQLException
     */
    public List<StockSummary> getStockSummaryGrouped(Integer hospitalId) throws SQLException {
        // Sử dụng view v_stock_by_status để lấy tất cả status
        return getStockByStatus(hospitalId, null);
    }
    
    /**
     * Lấy tổng số units theo blood_group cho một hospital (chỉ AVAILABLE)
     * @param hospitalId ID của hospital
     * @return List StockSummary với blood_group và tổng units
     * @throws SQLException
     */
    public List<StockSummary> getAvailableStockByBloodGroup(Integer hospitalId) throws SQLException {
        List<StockSummary> summaries = new ArrayList<>();
        String sql = "SELECT hospital_id, hospital_name, blood_group, SUM(units) AS units " +
                     "FROM v_stock_summary " +
                     "WHERE hospital_id = ? " +
                     "GROUP BY hospital_id, hospital_name, blood_group " +
                     "ORDER BY blood_group";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, hospitalId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    StockSummary summary = new StockSummary();
                    summary.setHospitalId(rs.getInt("hospital_id"));
                    summary.setHospitalName(rs.getString("hospital_name"));
                    summary.setBloodGroup(rs.getString("blood_group"));
                    summary.setComponent(null); // Grouped, không có component cụ thể
                    summary.setStatus("AVAILABLE");
                    summary.setUnits(rs.getInt("units"));
                    summaries.add(summary);
                }
            }
        }
        return summaries;
    }
}

