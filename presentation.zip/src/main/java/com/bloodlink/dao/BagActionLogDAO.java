package com.bloodlink.dao;

import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;

/**
 * DAO cho bảng bag_action_log (ghi log các thay đổi status của blood bag)
 */
public class BagActionLogDAO {
    
    /**
     * Ghi log vào bag_action_log
     * @param bagId ID của bag
     * @param oldStatus Trạng thái cũ
     * @param newStatus Trạng thái mới
     * @param actorUserId ID của user thực hiện (có thể null)
     * @param note Ghi chú (có thể null)
     * @return true nếu ghi log thành công
     * @throws SQLException
     */
    public boolean logStatusChange(Integer bagId, String oldStatus, String newStatus, 
                                   Integer actorUserId, String note) throws SQLException {
        String sql = "INSERT INTO bag_action_log (bag_id, action, message, by_user_id, created_at) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bagId);
            stmt.setString(2, "STATUS_CHANGE");
            
            String message = String.format("From %s to %s", oldStatus, newStatus);
            if (note != null && !note.trim().isEmpty()) {
                message += " - " + note;
            }
            stmt.setString(3, message);
            
            if (actorUserId != null) {
                stmt.setInt(4, actorUserId);
            } else {
                stmt.setNull(4, Types.INTEGER);
            }
            
            stmt.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Lấy danh sách logs của một bag
     * @param bagId ID của bag
     * @return Số lượng logs
     * @throws SQLException
     */
    public int getLogCountByBagId(Integer bagId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM bag_action_log WHERE bag_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bagId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }
    
    /**
     * Kiểm tra xem trigger có tồn tại trong DB không
     * Nếu có trigger, không cần ghi log ở app layer (trigger sẽ tự động ghi)
     * @return true nếu trigger tồn tại
     */
    public boolean hasTrigger() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT COUNT(*) FROM sys.triggers WHERE name = 'tr_blood_bag_status_log'";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            // Nếu không kiểm tra được, giả định không có trigger và ghi log ở app layer
            return false;
        }
        return false;
    }
}

