package com.bloodlink.dao;

import com.bloodlink.model.DonationRecord;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DonationRecordDAO {
    
    public DonationRecord findById(Integer recordId) throws SQLException {
        String sql = "SELECT record_id, donor_id, hospital_id, donation_date, measured_blood_group, " +
                     "quantity_ml, status, certificate_url, created_at " +
                     "FROM donation_record WHERE record_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, recordId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDonationRecord(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(DonationRecord record) throws SQLException {
        String sql = "INSERT INTO donation_record (donor_id, hospital_id, donation_date, measured_blood_group, " +
                     "quantity_ml, status, certificate_url, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, record.getDonorId());
            stmt.setInt(2, record.getHospitalId());
            stmt.setDate(3, Date.valueOf(record.getDonationDate()));
            stmt.setString(4, record.getMeasuredBloodGroup());
            stmt.setInt(5, record.getQuantityMl());
            stmt.setString(6, record.getStatus() != null ? record.getStatus() : "CONFIRMED");
            stmt.setString(7, record.getCertificateUrl());
            stmt.setTimestamp(8, Timestamp.valueOf(record.getCreatedAt() != null ? 
                    record.getCreatedAt() : LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        }
        return null;
    }
    
    public boolean update(DonationRecord record) throws SQLException {
        String sql = "UPDATE donation_record SET donor_id = ?, hospital_id = ?, donation_date = ?, " +
                     "measured_blood_group = ?, quantity_ml = ?, status = ?, certificate_url = ? " +
                     "WHERE record_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, record.getDonorId());
            stmt.setInt(2, record.getHospitalId());
            stmt.setDate(3, Date.valueOf(record.getDonationDate()));
            stmt.setString(4, record.getMeasuredBloodGroup());
            stmt.setInt(5, record.getQuantityMl());
            stmt.setString(6, record.getStatus());
            stmt.setString(7, record.getCertificateUrl());
            stmt.setInt(8, record.getRecordId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<DonationRecord> findByDonorId(Integer donorId) throws SQLException {
        List<DonationRecord> records = new ArrayList<>();
        String sql = "SELECT record_id, donor_id, hospital_id, donation_date, measured_blood_group, " +
                     "quantity_ml, status, certificate_url, created_at " +
                     "FROM donation_record WHERE donor_id = ? ORDER BY donation_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, donorId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    records.add(mapResultSetToDonationRecord(rs));
                }
            }
        }
        return records;
    }
    
    public List<DonationRecord> findByHospitalId(Integer hospitalId) throws SQLException {
        List<DonationRecord> records = new ArrayList<>();
        String sql = "SELECT record_id, donor_id, hospital_id, donation_date, measured_blood_group, " +
                     "quantity_ml, status, certificate_url, created_at " +
                     "FROM donation_record WHERE hospital_id = ? ORDER BY donation_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    records.add(mapResultSetToDonationRecord(rs));
                }
            }
        }
        return records;
    }
    
    private DonationRecord mapResultSetToDonationRecord(ResultSet rs) throws SQLException {
        DonationRecord record = new DonationRecord();
        record.setRecordId(rs.getInt("record_id"));
        record.setDonorId(rs.getInt("donor_id"));
        record.setHospitalId(rs.getInt("hospital_id"));
        Date donationDate = rs.getDate("donation_date");
        if (donationDate != null) {
            record.setDonationDate(donationDate.toLocalDate());
        }
        record.setMeasuredBloodGroup(rs.getString("measured_blood_group"));
        record.setQuantityMl(rs.getInt("quantity_ml"));
        record.setStatus(rs.getString("status"));
        record.setCertificateUrl(rs.getString("certificate_url"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) {
            record.setCreatedAt(ts.toLocalDateTime());
        }
        return record;
    }
}

