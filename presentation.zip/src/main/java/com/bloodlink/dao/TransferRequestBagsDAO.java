package com.bloodlink.dao;

import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO cho bảng transfer_request_bags (quan hệ many-to-many giữa transfer_requests và blood_bag)
 */
public class TransferRequestBagsDAO {
    
    /**
     * Thêm bag vào transfer request
     */
    public boolean addBagToTransfer(Integer transferId, Integer bagId) throws SQLException {
        String sql = "INSERT INTO transfer_request_bags (transfer_id, bag_id) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, transferId);
            stmt.setInt(2, bagId);
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Xóa tất cả bags khỏi transfer request (khi cancel)
     */
    public boolean removeAllBagsFromTransfer(Integer transferId) throws SQLException {
        String sql = "DELETE FROM transfer_request_bags WHERE transfer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, transferId);
            return stmt.executeUpdate() >= 0; // >= 0 vì có thể không có bags nào
        }
    }
    
    /**
     * Lấy danh sách bag IDs trong transfer request
     */
    public List<Integer> getBagIdsByTransferId(Integer transferId) throws SQLException {
        List<Integer> bagIds = new ArrayList<>();
        String sql = "SELECT bag_id FROM transfer_request_bags WHERE transfer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, transferId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    bagIds.add(rs.getInt("bag_id"));
                }
            }
        }
        return bagIds;
    }
    
    /**
     * Lấy transfer_id từ bag_id (để kiểm tra bag đang thuộc transfer nào)
     */
    public Integer getTransferIdByBagId(Integer bagId) throws SQLException {
        String sql = "SELECT transfer_id FROM transfer_request_bags WHERE bag_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bagId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("transfer_id");
                }
            }
        }
        return null;
    }
}

