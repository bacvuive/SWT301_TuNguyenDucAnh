package com.bloodlink.dao;

import com.bloodlink.model.Donor;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DonorDAO {
    
    public Donor findById(Integer donorId) throws SQLException {
        String sql = "SELECT donor_id, user_id, full_name, dob, gender, blood_group, phone, address, created_at " +
                     "FROM donor WHERE donor_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, donorId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDonor(rs);
                }
            }
        }
        return null;
    }
    
    public Donor findByUserId(Integer userId) throws SQLException {
        String sql = "SELECT donor_id, user_id, full_name, dob, gender, blood_group, phone, address, created_at " +
                     "FROM donor WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDonor(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(Donor donor) throws SQLException {
        String sql = "INSERT INTO donor (user_id, full_name, dob, gender, blood_group, phone, address, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, donor.getUserId());
            stmt.setString(2, donor.getFullName());
            if (donor.getDob() != null) {
                stmt.setDate(3, Date.valueOf(donor.getDob()));
            } else {
                stmt.setNull(3, Types.DATE);
            }
            stmt.setString(4, donor.getGender());
            stmt.setString(5, donor.getBloodGroup());
            stmt.setString(6, donor.getPhone());
            stmt.setString(7, donor.getAddress());
            stmt.setTimestamp(8, Timestamp.valueOf(donor.getCreatedAt() != null ? 
                    donor.getCreatedAt() : LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        }
        return null;
    }
    
    public boolean update(Donor donor) throws SQLException {
        String sql = "UPDATE donor SET full_name = ?, dob = ?, gender = ?, blood_group = ?, phone = ?, address = ? " +
                     "WHERE donor_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, donor.getFullName());
            if (donor.getDob() != null) {
                stmt.setDate(2, Date.valueOf(donor.getDob()));
            } else {
                stmt.setNull(2, Types.DATE);
            }
            stmt.setString(3, donor.getGender());
            stmt.setString(4, donor.getBloodGroup());
            stmt.setString(5, donor.getPhone());
            stmt.setString(6, donor.getAddress());
            stmt.setInt(7, donor.getDonorId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<Donor> findAll() throws SQLException {
        List<Donor> donors = new ArrayList<>();
        String sql = "SELECT donor_id, user_id, full_name, dob, gender, blood_group, phone, address, created_at " +
                     "FROM donor ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                donors.add(mapResultSetToDonor(rs));
            }
        }
        return donors;
    }
    
    public List<Donor> findByBloodGroup(String bloodGroup) throws SQLException {
        List<Donor> donors = new ArrayList<>();
        String sql = "SELECT donor_id, user_id, full_name, dob, gender, blood_group, phone, address, created_at " +
                     "FROM donor WHERE blood_group = ? ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, bloodGroup);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    donors.add(mapResultSetToDonor(rs));
                }
            }
        }
        return donors;
    }
    
    private Donor mapResultSetToDonor(ResultSet rs) throws SQLException {
        Donor donor = new Donor();
        donor.setDonorId(rs.getInt("donor_id"));
        donor.setUserId(rs.getInt("user_id"));
        donor.setFullName(rs.getString("full_name"));
        Date dob = rs.getDate("dob");
        if (dob != null) {
            donor.setDob(dob.toLocalDate());
        }
        donor.setGender(rs.getString("gender"));
        donor.setBloodGroup(rs.getString("blood_group"));
        donor.setPhone(rs.getString("phone"));
        donor.setAddress(rs.getString("address"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) {
            donor.setCreatedAt(ts.toLocalDateTime());
        }
        return donor;
    }
}

