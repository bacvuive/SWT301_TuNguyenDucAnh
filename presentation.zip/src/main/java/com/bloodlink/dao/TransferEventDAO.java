package com.bloodlink.dao;

import com.bloodlink.model.TransferEvent;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO cho bảng transfer_events (tracking events của transfer)
 */
public class TransferEventDAO {
    
    public Long create(TransferEvent event) throws SQLException {
        String sql = "INSERT INTO transfer_events (transfer_id, bag_id, event_type, note, created_at) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, event.getTransferId());
            if (event.getBagId() != null) {
                stmt.setInt(2, event.getBagId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            stmt.setString(3, event.getEventType());
            if (event.getNote() != null && !event.getNote().trim().isEmpty()) {
                stmt.setString(4, event.getNote());
            } else {
                stmt.setNull(4, Types.NVARCHAR);
            }
            stmt.setTimestamp(5, Timestamp.valueOf(event.getCreatedAt() != null ? 
                    event.getCreatedAt() : LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getLong(1);
                    }
                }
            }
        }
        return null;
    }
    
    public List<TransferEvent> findByTransferId(Integer transferId) throws SQLException {
        List<TransferEvent> events = new ArrayList<>();
        String sql = "SELECT event_id, transfer_id, bag_id, event_type, note, created_at " +
                     "FROM transfer_events WHERE transfer_id = ? ORDER BY created_at ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, transferId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    events.add(mapResultSetToTransferEvent(rs));
                }
            }
        }
        return events;
    }
    
    public TransferEvent findById(Long eventId) throws SQLException {
        String sql = "SELECT event_id, transfer_id, bag_id, event_type, note, created_at " +
                     "FROM transfer_events WHERE event_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, eventId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTransferEvent(rs);
                }
            }
        }
        return null;
    }
    
    private TransferEvent mapResultSetToTransferEvent(ResultSet rs) throws SQLException {
        TransferEvent event = new TransferEvent();
        event.setEventId(rs.getLong("event_id"));
        event.setTransferId(rs.getInt("transfer_id"));
        int bagId = rs.getInt("bag_id");
        if (!rs.wasNull()) {
            event.setBagId(bagId);
        }
        event.setEventType(rs.getString("event_type"));
        event.setNote(rs.getString("note"));
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            event.setCreatedAt(createdTs.toLocalDateTime());
        }
        return event;
    }
}

