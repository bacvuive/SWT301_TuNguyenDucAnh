package com.bloodlink.dao;

import com.bloodlink.model.DonorProfile;
import com.bloodlink.util.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class DonorProfileDAO {
    
    public DonorProfile findByDonorId(Integer donorId) throws SQLException {
        String sql = "SELECT donor_id, height_cm, weight_kg, last_hb_gdl, chronic_cond, allergies, " +
                     "last_screen, created_at, updated_at " +
                     "FROM donor_profile WHERE donor_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, donorId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDonorProfile(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(DonorProfile profile) throws SQLException {
        String sql = "INSERT INTO donor_profile (donor_id, height_cm, weight_kg, last_hb_gdl, " +
                     "chronic_cond, allergies, last_screen, created_at, updated_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, profile.getDonorId());
            setBigDecimal(stmt, 2, profile.getHeightCm());
            setBigDecimal(stmt, 3, profile.getWeightKg());
            setBigDecimal(stmt, 4, profile.getLastHbGdl());
            stmt.setString(5, profile.getChronicCond());
            stmt.setString(6, profile.getAllergies());
            if (profile.getLastScreen() != null) {
                stmt.setDate(7, Date.valueOf(profile.getLastScreen()));
            } else {
                stmt.setNull(7, Types.DATE);
            }
            LocalDateTime now = LocalDateTime.now();
            stmt.setTimestamp(8, Timestamp.valueOf(profile.getCreatedAt() != null ? profile.getCreatedAt() : now));
            if (profile.getUpdatedAt() != null) {
                stmt.setTimestamp(9, Timestamp.valueOf(profile.getUpdatedAt()));
            } else {
                stmt.setNull(9, Types.TIMESTAMP);
            }
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0 ? profile.getDonorId() : null;
        }
    }
    
    public boolean update(DonorProfile profile) throws SQLException {
        String sql = "UPDATE donor_profile SET height_cm = ?, weight_kg = ?, last_hb_gdl = ?, " +
                     "chronic_cond = ?, allergies = ?, last_screen = ?, updated_at = ? " +
                     "WHERE donor_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            setBigDecimal(stmt, 1, profile.getHeightCm());
            setBigDecimal(stmt, 2, profile.getWeightKg());
            setBigDecimal(stmt, 3, profile.getLastHbGdl());
            stmt.setString(4, profile.getChronicCond());
            stmt.setString(5, profile.getAllergies());
            if (profile.getLastScreen() != null) {
                stmt.setDate(6, Date.valueOf(profile.getLastScreen()));
            } else {
                stmt.setNull(6, Types.DATE);
            }
            stmt.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(8, profile.getDonorId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    private void setBigDecimal(PreparedStatement stmt, int index, BigDecimal value) throws SQLException {
        if (value != null) {
            stmt.setBigDecimal(index, value);
        } else {
            stmt.setNull(index, Types.DECIMAL);
        }
    }
    
    private DonorProfile mapResultSetToDonorProfile(ResultSet rs) throws SQLException {
        DonorProfile profile = new DonorProfile();
        profile.setDonorId(rs.getInt("donor_id"));
        BigDecimal height = rs.getBigDecimal("height_cm");
        if (!rs.wasNull()) {
            profile.setHeightCm(height);
        }
        BigDecimal weight = rs.getBigDecimal("weight_kg");
        if (!rs.wasNull()) {
            profile.setWeightKg(weight);
        }
        BigDecimal hb = rs.getBigDecimal("last_hb_gdl");
        if (!rs.wasNull()) {
            profile.setLastHbGdl(hb);
        }
        profile.setChronicCond(rs.getString("chronic_cond"));
        profile.setAllergies(rs.getString("allergies"));
        Date lastScreen = rs.getDate("last_screen");
        if (lastScreen != null) {
            profile.setLastScreen(lastScreen.toLocalDate());
        }
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            profile.setCreatedAt(createdTs.toLocalDateTime());
        }
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        if (updatedTs != null) {
            profile.setUpdatedAt(updatedTs.toLocalDateTime());
        }
        return profile;
    }
}

