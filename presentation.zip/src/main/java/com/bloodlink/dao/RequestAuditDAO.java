package com.bloodlink.dao;

import com.bloodlink.model.RequestAudit;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO cho bảng request_audit (audit trail của blood requests)
 */
public class RequestAuditDAO {
    
    /**
     * Tạo audit record
     */
    public Long create(RequestAudit audit) throws SQLException {
        String sql = "INSERT INTO request_audit (request_id, actor_user_id, old_status, new_status, note, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, audit.getRequestId());
            if (audit.getActorUserId() != null) {
                stmt.setInt(2, audit.getActorUserId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            if (audit.getOldStatus() != null) {
                stmt.setString(3, audit.getOldStatus());
            } else {
                stmt.setNull(3, Types.NVARCHAR);
            }
            stmt.setString(4, audit.getNewStatus());
            if (audit.getNote() != null && !audit.getNote().trim().isEmpty()) {
                stmt.setString(5, audit.getNote());
            } else {
                stmt.setNull(5, Types.NVARCHAR);
            }
            stmt.setTimestamp(6, Timestamp.valueOf(audit.getCreatedAt() != null ? 
                    audit.getCreatedAt() : LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getLong(1);
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Lấy audit history của một request
     */
    public List<RequestAudit> findByRequestId(Integer requestId) throws SQLException {
        List<RequestAudit> audits = new ArrayList<>();
        String sql = "SELECT audit_id, request_id, actor_user_id, old_status, new_status, note, created_at " +
                     "FROM request_audit WHERE request_id = ? ORDER BY created_at ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    audits.add(mapResultSetToRequestAudit(rs));
                }
            }
        }
        return audits;
    }
    
    /**
     * Lấy audit record theo ID
     */
    public RequestAudit findById(Long auditId) throws SQLException {
        String sql = "SELECT audit_id, request_id, actor_user_id, old_status, new_status, note, created_at " +
                     "FROM request_audit WHERE audit_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, auditId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToRequestAudit(rs);
                }
            }
        }
        return null;
    }
    
    private RequestAudit mapResultSetToRequestAudit(ResultSet rs) throws SQLException {
        RequestAudit audit = new RequestAudit();
        audit.setAuditId(rs.getLong("audit_id"));
        audit.setRequestId(rs.getInt("request_id"));
        
        int actorUserId = rs.getInt("actor_user_id");
        if (!rs.wasNull()) {
            audit.setActorUserId(actorUserId);
        }
        
        String oldStatus = rs.getString("old_status");
        if (oldStatus != null) {
            audit.setOldStatus(oldStatus);
        }
        
        audit.setNewStatus(rs.getString("new_status"));
        audit.setNote(rs.getString("note"));
        
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            audit.setCreatedAt(createdTs.toLocalDateTime());
        }
        
        return audit;
    }
}

