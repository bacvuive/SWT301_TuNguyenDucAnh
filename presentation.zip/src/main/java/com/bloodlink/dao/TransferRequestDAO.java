package com.bloodlink.dao;

import com.bloodlink.model.TransferRequest;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TransferRequestDAO {
    
    public TransferRequest findById(Integer transferId) throws SQLException {
        String sql = "SELECT transfer_id, request_id, from_hospital_id, to_hospital_id, blood_group, " +
                     "component, units, status, created_at, updated_at " +
                     "FROM transfer_requests WHERE transfer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, transferId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTransferRequest(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(TransferRequest transfer) throws SQLException {
        String sql = "INSERT INTO transfer_requests (request_id, from_hospital_id, to_hospital_id, " +
                     "blood_group, component, units, status, created_at, updated_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            if (transfer.getRequestId() != null) {
                stmt.setInt(1, transfer.getRequestId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }
            stmt.setInt(2, transfer.getFromHospitalId());
            stmt.setInt(3, transfer.getToHospitalId());
            stmt.setString(4, transfer.getBloodGroup());
            stmt.setString(5, transfer.getComponent());
            stmt.setInt(6, transfer.getUnits());
            stmt.setString(7, transfer.getStatus() != null ? transfer.getStatus() : "PENDING");
            LocalDateTime now = LocalDateTime.now();
            stmt.setTimestamp(8, Timestamp.valueOf(transfer.getCreatedAt() != null ? transfer.getCreatedAt() : now));
            if (transfer.getUpdatedAt() != null) {
                stmt.setTimestamp(9, Timestamp.valueOf(transfer.getUpdatedAt()));
            } else {
                stmt.setNull(9, Types.TIMESTAMP);
            }
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        }
        return null;
    }
    
    public boolean update(TransferRequest transfer) throws SQLException {
        String sql = "UPDATE transfer_requests SET request_id = ?, from_hospital_id = ?, to_hospital_id = ?, " +
                     "blood_group = ?, component = ?, units = ?, status = ?, updated_at = ? " +
                     "WHERE transfer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (transfer.getRequestId() != null) {
                stmt.setInt(1, transfer.getRequestId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }
            stmt.setInt(2, transfer.getFromHospitalId());
            stmt.setInt(3, transfer.getToHospitalId());
            stmt.setString(4, transfer.getBloodGroup());
            stmt.setString(5, transfer.getComponent());
            stmt.setInt(6, transfer.getUnits());
            stmt.setString(7, transfer.getStatus());
            stmt.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(9, transfer.getTransferId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public boolean updateStatus(Integer transferId, String newStatus) throws SQLException {
        String sql = "UPDATE transfer_requests SET status = ?, updated_at = ? WHERE transfer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newStatus);
            stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(3, transferId);
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<TransferRequest> findByFromHospitalId(Integer hospitalId) throws SQLException {
        List<TransferRequest> transfers = new ArrayList<>();
        String sql = "SELECT transfer_id, request_id, from_hospital_id, to_hospital_id, blood_group, " +
                     "component, units, status, created_at, updated_at " +
                     "FROM transfer_requests WHERE from_hospital_id = ? ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    transfers.add(mapResultSetToTransferRequest(rs));
                }
            }
        }
        return transfers;
    }
    
    public List<TransferRequest> findByToHospitalId(Integer hospitalId) throws SQLException {
        List<TransferRequest> transfers = new ArrayList<>();
        String sql = "SELECT transfer_id, request_id, from_hospital_id, to_hospital_id, blood_group, " +
                     "component, units, status, created_at, updated_at " +
                     "FROM transfer_requests WHERE to_hospital_id = ? ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    transfers.add(mapResultSetToTransferRequest(rs));
                }
            }
        }
        return transfers;
    }
    
    public List<TransferRequest> findByStatus(String status) throws SQLException {
        List<TransferRequest> transfers = new ArrayList<>();
        String sql = "SELECT transfer_id, request_id, from_hospital_id, to_hospital_id, blood_group, " +
                     "component, units, status, created_at, updated_at " +
                     "FROM transfer_requests WHERE status = ? ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    transfers.add(mapResultSetToTransferRequest(rs));
                }
            }
        }
        return transfers;
    }
    
    private TransferRequest mapResultSetToTransferRequest(ResultSet rs) throws SQLException {
        TransferRequest transfer = new TransferRequest();
        transfer.setTransferId(rs.getInt("transfer_id"));
        int requestId = rs.getInt("request_id");
        if (!rs.wasNull()) {
            transfer.setRequestId(requestId);
        }
        transfer.setFromHospitalId(rs.getInt("from_hospital_id"));
        transfer.setToHospitalId(rs.getInt("to_hospital_id"));
        transfer.setBloodGroup(rs.getString("blood_group"));
        transfer.setComponent(rs.getString("component"));
        transfer.setUnits(rs.getInt("units"));
        transfer.setStatus(rs.getString("status"));
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            transfer.setCreatedAt(createdTs.toLocalDateTime());
        }
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        if (updatedTs != null) {
            transfer.setUpdatedAt(updatedTs.toLocalDateTime());
        }
        return transfer;
    }
}

