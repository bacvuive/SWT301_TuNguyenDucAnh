package com.bloodlink.dao;

import com.bloodlink.model.BloodBag;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class BloodBagDAO {
    
    public BloodBag findById(Integer bagId) throws SQLException {
        String sql = "SELECT bag_id, bag_code, hospital_id, record_id, blood_group, component, " +
                     "volume_ml, collection_date, expiry_date, status, created_at, updated_at " +
                     "FROM blood_bag WHERE bag_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, bagId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBloodBag(rs);
                }
            }
        }
        return null;
    }
    
    public BloodBag findByBagCode(String bagCode) throws SQLException {
        String sql = "SELECT bag_id, bag_code, hospital_id, record_id, blood_group, component, " +
                     "volume_ml, collection_date, expiry_date, status, created_at, updated_at " +
                     "FROM blood_bag WHERE bag_code = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, bagCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBloodBag(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(BloodBag bag) throws SQLException {
        String sql = "INSERT INTO blood_bag (bag_code, hospital_id, record_id, blood_group, component, " +
                     "volume_ml, collection_date, expiry_date, status, created_at, updated_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, bag.getBagCode());
            stmt.setInt(2, bag.getHospitalId());
            if (bag.getRecordId() != null) {
                stmt.setInt(3, bag.getRecordId());
            } else {
                stmt.setNull(3, Types.INTEGER);
            }
            stmt.setString(4, bag.getBloodGroup());
            stmt.setString(5, bag.getComponent());
            stmt.setInt(6, bag.getVolumeMl());
            stmt.setDate(7, Date.valueOf(bag.getCollectionDate()));
            stmt.setDate(8, Date.valueOf(bag.getExpiryDate()));
            stmt.setString(9, bag.getStatus() != null ? bag.getStatus() : "AVAILABLE");
            LocalDateTime now = LocalDateTime.now();
            stmt.setTimestamp(10, Timestamp.valueOf(bag.getCreatedAt() != null ? bag.getCreatedAt() : now));
            stmt.setTimestamp(11, Timestamp.valueOf(bag.getUpdatedAt() != null ? bag.getUpdatedAt() : now));
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        }
        return null;
    }
    
    public boolean update(BloodBag bag) throws SQLException {
        String sql = "UPDATE blood_bag SET bag_code = ?, hospital_id = ?, record_id = ?, blood_group = ?, " +
                     "component = ?, volume_ml = ?, collection_date = ?, expiry_date = ?, status = ?, updated_at = ? " +
                     "WHERE bag_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, bag.getBagCode());
            stmt.setInt(2, bag.getHospitalId());
            if (bag.getRecordId() != null) {
                stmt.setInt(3, bag.getRecordId());
            } else {
                stmt.setNull(3, Types.INTEGER);
            }
            stmt.setString(4, bag.getBloodGroup());
            stmt.setString(5, bag.getComponent());
            stmt.setInt(6, bag.getVolumeMl());
            stmt.setDate(7, Date.valueOf(bag.getCollectionDate()));
            stmt.setDate(8, Date.valueOf(bag.getExpiryDate()));
            stmt.setString(9, bag.getStatus());
            stmt.setTimestamp(10, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(11, bag.getBagId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    /**
     * Chỉ update status của bag (dùng cho endpoint PATCH /bags/:id/status)
     * @param bagId ID của bag
     * @param newStatus Trạng thái mới
     * @return true nếu update thành công
     * @throws SQLException
     */
    public boolean updateStatus(Integer bagId, String newStatus) throws SQLException {
        String sql = "UPDATE blood_bag SET status = ?, updated_at = ? WHERE bag_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newStatus);
            stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(3, bagId);
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<BloodBag> findByHospitalId(Integer hospitalId) throws SQLException {
        List<BloodBag> bags = new ArrayList<>();
        String sql = "SELECT bag_id, bag_code, hospital_id, record_id, blood_group, component, " +
                     "volume_ml, collection_date, expiry_date, status, created_at, updated_at " +
                     "FROM blood_bag WHERE hospital_id = ? ORDER BY expiry_date ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    bags.add(mapResultSetToBloodBag(rs));
                }
            }
        }
        return bags;
    }

    public List<BloodBag> findAvailableForTransfer(Connection conn, Integer hospitalId, String bloodGroup,
                                                   String component, Integer limit) throws SQLException {
        List<BloodBag> bags = new ArrayList<>();
        String sql = "SELECT TOP (?) bag_id, bag_code, hospital_id, record_id, blood_group, component, " +
                     "volume_ml, collection_date, expiry_date, status, created_at, updated_at " +
                     "FROM blood_bag WITH (ROWLOCK, UPDLOCK, READPAST) " +
                     "WHERE hospital_id = ? AND blood_group = ? AND component = ? " +
                     "AND status = 'AVAILABLE' AND expiry_date >= CAST(GETDATE() AS DATE) " +
                     "ORDER BY expiry_date ASC, bag_id ASC";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, limit);
            stmt.setInt(2, hospitalId);
            stmt.setString(3, bloodGroup);
            stmt.setString(4, component);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    bags.add(mapResultSetToBloodBag(rs));
                }
            }
        }

        return bags;
    }

    public void moveBagsToHospital(Connection conn, List<Integer> bagIds, Integer toHospitalId,
                                   Integer actorUserId, Integer requestId) throws SQLException {
        if (bagIds == null || bagIds.isEmpty()) {
            return;
        }

        String updateSql = "UPDATE blood_bag SET hospital_id = ?, status = 'AVAILABLE', updated_at = SYSUTCDATETIME() " +
                           "WHERE bag_id = ?";

        try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
            for (Integer bagId : bagIds) {
                updateStmt.setInt(1, toHospitalId);
                updateStmt.setInt(2, bagId);
                updateStmt.addBatch();
            }
            updateStmt.executeBatch();
        }
    }
    
    public List<BloodBag> findAvailable(Integer hospitalId, String bloodGroup, String component) throws SQLException {
        List<BloodBag> bags = new ArrayList<>();
        String sql = "SELECT bag_id, bag_code, hospital_id, record_id, blood_group, component, " +
                     "volume_ml, collection_date, expiry_date, status, created_at, updated_at " +
                     "FROM blood_bag WHERE hospital_id = ? AND blood_group = ? AND component = ? " +
                     "AND status = 'AVAILABLE' AND expiry_date >= CAST(GETDATE() AS DATE) " +
                     "ORDER BY expiry_date ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            stmt.setString(2, bloodGroup);
            stmt.setString(3, component);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    bags.add(mapResultSetToBloodBag(rs));
                }
            }
        }
        return bags;
    }
    
    /**
     * Tìm tất cả bags quá hạn với status AVAILABLE hoặc RESERVED
     * @return List các bag IDs quá hạn
     * @throws SQLException
     */
    public List<Integer> findExpiredBagIds() throws SQLException {
        List<Integer> bagIds = new ArrayList<>();
        String sql = "SELECT bag_id FROM blood_bag " +
                     "WHERE expiry_date < CAST(GETDATE() AS DATE) " +
                     "  AND status IN ('AVAILABLE', 'RESERVED') " +
                     "ORDER BY bag_id";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                bagIds.add(rs.getInt("bag_id"));
            }
        }
        return bagIds;
    }
    
    /**
     * Batch update status của nhiều bags
     * @param bagIds List các bag IDs
     * @param newStatus Trạng thái mới
     * @return Số lượng bags đã update
     * @throws SQLException
     */
    public int batchUpdateStatus(List<Integer> bagIds, String newStatus) throws SQLException {
        if (bagIds == null || bagIds.isEmpty()) {
            return 0;
        }
        
        String sql = "UPDATE blood_bag SET status = ?, updated_at = ? WHERE bag_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            int count = 0;
            for (Integer bagId : bagIds) {
                stmt.setString(1, newStatus);
                stmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
                stmt.setInt(3, bagId);
                stmt.addBatch();
                count++;
            }
            stmt.executeBatch();
            return count;
        }
    }
    
    private BloodBag mapResultSetToBloodBag(ResultSet rs) throws SQLException {
        BloodBag bag = new BloodBag();
        bag.setBagId(rs.getInt("bag_id"));
        bag.setBagCode(rs.getString("bag_code"));
        bag.setHospitalId(rs.getInt("hospital_id"));
        int recordId = rs.getInt("record_id");
        if (!rs.wasNull()) {
            bag.setRecordId(recordId);
        }
        bag.setBloodGroup(rs.getString("blood_group"));
        bag.setComponent(rs.getString("component"));
        bag.setVolumeMl(rs.getInt("volume_ml"));
        Date collectionDate = rs.getDate("collection_date");
        if (collectionDate != null) {
            bag.setCollectionDate(collectionDate.toLocalDate());
        }
        Date expiryDate = rs.getDate("expiry_date");
        if (expiryDate != null) {
            bag.setExpiryDate(expiryDate.toLocalDate());
        }
        bag.setStatus(rs.getString("status"));
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            bag.setCreatedAt(createdTs.toLocalDateTime());
        }
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        if (updatedTs != null) {
            bag.setUpdatedAt(updatedTs.toLocalDateTime());
        }
        return bag;
    }
}

