package com.bloodlink.dao;

import com.bloodlink.model.Notification;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {
    
    public Notification findById(Long notificationId) throws SQLException {
        // Kiểm tra xem có cột subject và link không
        boolean hasSubjectAndLink = checkColumnExists("subject") && checkColumnExists("link");
        
        String sql;
        if (hasSubjectAndLink) {
            sql = "SELECT notification_id, user_id, type, " +
                 "COALESCE(subject, '') AS subject, " +
                 "message, " +
                 "COALESCE([link], '') AS [link], " +
                 "is_read, created_at " +
                 "FROM notification WHERE notification_id = ?";
        } else {
            sql = "SELECT notification_id, user_id, type, " +
                 "message, " +
                 "is_read, created_at " +
                 "FROM notification WHERE notification_id = ?";
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, notificationId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToNotification(rs, hasSubjectAndLink);
                }
            }
        }
        return null;
    }
    
    public Long create(Notification notification) throws SQLException {
        // Kiểm tra xem có cột subject và link không
        boolean hasSubjectAndLink = checkColumnExists("subject") && checkColumnExists("link");
        
        String sql;
        if (hasSubjectAndLink) {
            sql = "INSERT INTO notification (user_id, type, subject, message, [link], is_read, created_at) " +
                  "VALUES (?, ?, ?, ?, ?, ?, ?)";
        } else {
            sql = "INSERT INTO notification (user_id, type, message, is_read, created_at) " +
                  "VALUES (?, ?, ?, ?, ?)";
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            int paramIndex = 1;
            stmt.setInt(paramIndex++, notification.getUserId());
            stmt.setString(paramIndex++, notification.getType() != null ? notification.getType() : "info");
            
            if (hasSubjectAndLink) {
                stmt.setString(paramIndex++, notification.getSubject());
                stmt.setString(paramIndex++, notification.getMessage());
                stmt.setString(paramIndex++, notification.getLink());
            } else {
                // Nếu không có subject và link, dùng message làm subject
                String message = notification.getMessage();
                if (notification.getSubject() != null && !notification.getSubject().isEmpty()) {
                    message = notification.getSubject() + " - " + message;
                }
                stmt.setString(paramIndex++, message);
            }
            
            stmt.setBoolean(paramIndex++, notification.getIsRead() != null ? notification.getIsRead() : false);
            stmt.setTimestamp(paramIndex, Timestamp.valueOf(notification.getCreatedAt() != null ? 
                    notification.getCreatedAt() : LocalDateTime.now()));
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getLong(1);
                    }
                }
            }
        }
        return null;
    }
    
    /**
     * Kiểm tra xem cột có tồn tại trong table notification không
     */
    private boolean checkColumnExists(String columnName) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS " +
                        "WHERE TABLE_NAME = 'notification' AND COLUMN_NAME = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, columnName);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt(1) > 0;
                    }
                }
            }
        } catch (SQLException e) {
            // Nếu không kiểm tra được, giả định không có cột (backward compatible)
            return false;
        }
        return false;
    }
    
    public boolean update(Notification notification) throws SQLException {
        String sql = "UPDATE notification SET type = ?, message = ?, is_read = ? WHERE notification_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, notification.getType());
            stmt.setString(2, notification.getMessage());
            stmt.setBoolean(3, notification.getIsRead());
            stmt.setLong(4, notification.getNotificationId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public boolean markAsRead(Long notificationId) throws SQLException {
        String sql = "UPDATE notification SET is_read = 1 WHERE notification_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, notificationId);
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<Notification> findByUserId(Integer userId) throws SQLException {
        List<Notification> notifications = new ArrayList<>();
        
        // Kiểm tra xem có cột subject và link không
        boolean hasSubjectAndLink = checkColumnExists("subject") && checkColumnExists("link");
        
        String sql;
        if (hasSubjectAndLink) {
            sql = "SELECT notification_id, user_id, type, " +
                 "COALESCE(subject, '') AS subject, " +
                 "message, " +
                 "COALESCE([link], '') AS [link], " +
                 "is_read, created_at " +
                 "FROM notification WHERE user_id = ? ORDER BY created_at DESC";
        } else {
            sql = "SELECT notification_id, user_id, type, " +
                 "message, " +
                 "is_read, created_at " +
                 "FROM notification WHERE user_id = ? ORDER BY created_at DESC";
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    notifications.add(mapResultSetToNotification(rs, hasSubjectAndLink));
                }
            }
        }
        return notifications;
    }
    
    public List<Notification> findUnreadByUserId(Integer userId) throws SQLException {
        List<Notification> notifications = new ArrayList<>();
        
        // Kiểm tra xem có cột subject và link không
        boolean hasSubjectAndLink = checkColumnExists("subject") && checkColumnExists("link");
        
        String sql;
        if (hasSubjectAndLink) {
            sql = "SELECT notification_id, user_id, type, " +
                 "COALESCE(subject, '') AS subject, " +
                 "message, " +
                 "COALESCE([link], '') AS [link], " +
                 "is_read, created_at " +
                 "FROM notification WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC";
        } else {
            sql = "SELECT notification_id, user_id, type, " +
                 "message, " +
                 "is_read, created_at " +
                 "FROM notification WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC";
        }
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    notifications.add(mapResultSetToNotification(rs, hasSubjectAndLink));
                }
            }
        }
        return notifications;
    }
    
    private Notification mapResultSetToNotification(ResultSet rs, boolean hasSubjectAndLink) throws SQLException {
        Notification notification = new Notification();
        notification.setNotificationId(rs.getLong("notification_id"));
        notification.setUserId(rs.getInt("user_id"));
        notification.setType(rs.getString("type"));
        
        // Subject và link chỉ có trong schema mới
        if (hasSubjectAndLink) {
            try {
                String subject = rs.getString("subject");
                notification.setSubject(subject != null && !subject.isEmpty() ? subject : null);
            } catch (SQLException e) {
                notification.setSubject(null);
            }
            
            try {
                String link = rs.getString("link");
                notification.setLink(link != null && !link.isEmpty() ? link : null);
            } catch (SQLException e) {
                notification.setLink(null);
            }
        } else {
            // Schema cũ: không có subject và link
            notification.setSubject(null);
            notification.setLink(null);
        }
        
        notification.setMessage(rs.getString("message"));
        notification.setIsRead(rs.getBoolean("is_read"));
        
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) {
            notification.setCreatedAt(ts.toLocalDateTime());
        }
        return notification;
    }
    
    // Overload method for backward compatibility (nếu có code cũ đang dùng)
    private Notification mapResultSetToNotification(ResultSet rs) throws SQLException {
        // Mặc định kiểm tra xem có cột không
        boolean hasSubjectAndLink = checkColumnExists("subject") && checkColumnExists("link");
        return mapResultSetToNotification(rs, hasSubjectAndLink);
    }
}

