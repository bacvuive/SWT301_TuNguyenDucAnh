package com.bloodlink.dao;

import com.bloodlink.model.HospitalVerificationRequest;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class HospitalVerificationRequestDAO {

    public HospitalVerificationRequest findById(Integer requestId) throws SQLException {
        String sql = "SELECT request_id, hospital_id, status, submitted_at, processed_at, processed_by, " +
                     "rejection_reason, registration_number, contact_person, contact_phone, extra_data " +
                     "FROM hospital_verification_request WHERE request_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        return null;
    }

    public HospitalVerificationRequest findPendingByHospitalId(Integer hospitalId) throws SQLException {
        String sql = "SELECT TOP 1 request_id, hospital_id, status, submitted_at, processed_at, processed_by, " +
                     "rejection_reason, registration_number, contact_person, contact_phone, extra_data " +
                     "FROM hospital_verification_request WHERE hospital_id = ? AND status = 'PENDING'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        return null;
    }

    public HospitalVerificationRequest findLatestByHospitalId(Integer hospitalId) throws SQLException {
        String sql = "SELECT TOP 1 request_id, hospital_id, status, submitted_at, processed_at, processed_by, " +
                     "rejection_reason, registration_number, contact_person, contact_phone, extra_data " +
                     "FROM hospital_verification_request WHERE hospital_id = ? ORDER BY submitted_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        return null;
    }

    public List<HospitalVerificationRequest> findByHospitalId(Integer hospitalId) throws SQLException {
        String sql = "SELECT request_id, hospital_id, status, submitted_at, processed_at, processed_by, " +
                     "rejection_reason, registration_number, contact_person, contact_phone, extra_data " +
                     "FROM hospital_verification_request WHERE hospital_id = ? ORDER BY submitted_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                List<HospitalVerificationRequest> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(map(rs));
                }
                return list;
            }
        }
    }

    public List<HospitalVerificationRequest> findByStatus(String status) throws SQLException {
        String sql = "SELECT request_id, hospital_id, status, submitted_at, processed_at, processed_by, " +
                     "rejection_reason, registration_number, contact_person, contact_phone, extra_data " +
                     "FROM hospital_verification_request WHERE status = ? ORDER BY submitted_at ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                List<HospitalVerificationRequest> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(map(rs));
                }
                return list;
            }
        }
    }

    public Integer create(HospitalVerificationRequest request) throws SQLException {
        String sql = "INSERT INTO hospital_verification_request (hospital_id, status, submitted_at, processed_at, processed_by, " +
                     "rejection_reason, registration_number, contact_person, contact_phone, extra_data) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, request.getHospitalId());
            stmt.setString(2, request.getStatus());
            stmt.setTimestamp(3, toTimestamp(request.getSubmittedAt(), LocalDateTime.now()));
            if (request.getProcessedAt() != null) {
                stmt.setTimestamp(4, Timestamp.valueOf(request.getProcessedAt()));
            } else {
                stmt.setNull(4, Types.TIMESTAMP);
            }
            if (request.getProcessedBy() != null) {
                stmt.setInt(5, request.getProcessedBy());
            } else {
                stmt.setNull(5, Types.INTEGER);
            }
            stmt.setString(6, request.getRejectionReason());
            stmt.setString(7, request.getRegistrationNumber());
            stmt.setString(8, request.getContactPerson());
            stmt.setString(9, request.getContactPhone());
            stmt.setString(10, request.getExtraData());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = stmt.getGeneratedKeys()) {
                    if (keys.next()) {
                        return keys.getInt(1);
                    }
                }
            }
        }
        return null;
    }

    public boolean update(HospitalVerificationRequest request) throws SQLException {
        String sql = "UPDATE hospital_verification_request SET status = ?, processed_at = ?, processed_by = ?, " +
                     "rejection_reason = ?, registration_number = ?, contact_person = ?, contact_phone = ?, extra_data = ? " +
                     "WHERE request_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, request.getStatus());
            if (request.getProcessedAt() != null) {
                stmt.setTimestamp(2, Timestamp.valueOf(request.getProcessedAt()));
            } else {
                stmt.setNull(2, Types.TIMESTAMP);
            }
            if (request.getProcessedBy() != null) {
                stmt.setInt(3, request.getProcessedBy());
            } else {
                stmt.setNull(3, Types.INTEGER);
            }
            stmt.setString(4, request.getRejectionReason());
            stmt.setString(5, request.getRegistrationNumber());
            stmt.setString(6, request.getContactPerson());
            stmt.setString(7, request.getContactPhone());
            stmt.setString(8, request.getExtraData());
            stmt.setInt(9, request.getRequestId());
            return stmt.executeUpdate() > 0;
        }
    }

    private Timestamp toTimestamp(LocalDateTime value, LocalDateTime fallback) {
        LocalDateTime result = value != null ? value : fallback;
        return result != null ? Timestamp.valueOf(result) : null;
    }

    private HospitalVerificationRequest map(ResultSet rs) throws SQLException {
        HospitalVerificationRequest request = new HospitalVerificationRequest();
        request.setRequestId(rs.getInt("request_id"));
        request.setHospitalId(rs.getInt("hospital_id"));
        request.setStatus(rs.getString("status"));
        Timestamp submitted = rs.getTimestamp("submitted_at");
        if (submitted != null) {
            request.setSubmittedAt(submitted.toLocalDateTime());
        }
        Timestamp processed = rs.getTimestamp("processed_at");
        if (processed != null) {
            request.setProcessedAt(processed.toLocalDateTime());
        }
        int processedBy = rs.getInt("processed_by");
        request.setProcessedBy(rs.wasNull() ? null : processedBy);
        request.setRejectionReason(rs.getString("rejection_reason"));
        request.setRegistrationNumber(rs.getString("registration_number"));
        request.setContactPerson(rs.getString("contact_person"));
        request.setContactPhone(rs.getString("contact_phone"));
        request.setExtraData(rs.getString("extra_data"));
        return request;
    }
}
