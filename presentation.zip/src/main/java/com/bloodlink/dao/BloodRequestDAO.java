package com.bloodlink.dao;

import com.bloodlink.model.BloodRequest;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class BloodRequestDAO {
    
    public BloodRequest findById(Integer requestId) throws SQLException {
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request WHERE request_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBloodRequest(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(BloodRequest request) throws SQLException {
        String sql = "INSERT INTO blood_request (from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, request.getFromHospitalId());
            if (request.getToHospitalId() != null) {
                stmt.setInt(2, request.getToHospitalId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            stmt.setString(3, request.getBloodGroup());
            stmt.setString(4, request.getComponent());
            stmt.setInt(5, request.getQuantity());
            stmt.setString(6, request.getStatus() != null ? request.getStatus() : "PENDING");
            LocalDateTime now = LocalDateTime.now();
            stmt.setTimestamp(7, Timestamp.valueOf(request.getCreatedAt() != null ? request.getCreatedAt() : now));
            if (request.getUpdatedAt() != null) {
                stmt.setTimestamp(8, Timestamp.valueOf(request.getUpdatedAt()));
            } else {
                stmt.setNull(8, Types.TIMESTAMP);
            }
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        }
        return null;
    }
    
    public boolean update(BloodRequest request) throws SQLException {
        String sql = "UPDATE blood_request SET from_hospital_id = ?, to_hospital_id = ?, blood_group = ?, " +
                     "component = ?, quantity = ?, status = ?, updated_at = ? WHERE request_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, request.getFromHospitalId());
            if (request.getToHospitalId() != null) {
                stmt.setInt(2, request.getToHospitalId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            stmt.setString(3, request.getBloodGroup());
            stmt.setString(4, request.getComponent());
            stmt.setInt(5, request.getQuantity());
            stmt.setString(6, request.getStatus());
            stmt.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(8, request.getRequestId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<BloodRequest> findAll() throws SQLException {
        List<BloodRequest> requests = new ArrayList<>();
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                requests.add(mapResultSetToBloodRequest(rs));
            }
        }
        return requests;
    }
    
    public List<BloodRequest> findByStatus(String status) throws SQLException {
        List<BloodRequest> requests = new ArrayList<>();
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request WHERE status = ? ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    requests.add(mapResultSetToBloodRequest(rs));
                }
            }
        }
        return requests;
    }
    
    public List<BloodRequest> findByToHospitalId(Integer toHospitalId) throws SQLException {
        List<BloodRequest> requests = new ArrayList<>();
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request WHERE to_hospital_id = ? OR to_hospital_id IS NULL " +
                     "ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, toHospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    requests.add(mapResultSetToBloodRequest(rs));
                }
            }
        }
        return requests;
    }
    
    /**
     * Lấy các yêu cầu máu đến (incoming requests) cho một bệnh viện
     * Bao gồm:
     * 1. Yêu cầu gửi trực tiếp đến bệnh viện này (to_hospital_id = hospitalId)
     * 2. Yêu cầu broadcast (to_hospital_id IS NULL) nhưng không phải do bệnh viện này tạo
     * 
     * @param hospitalId ID của bệnh viện nhận yêu cầu
     * @return Danh sách yêu cầu máu đến
     */
    public List<BloodRequest> findIncomingRequests(Integer hospitalId) throws SQLException {
        List<BloodRequest> requests = new ArrayList<>();
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request " +
                     "WHERE (to_hospital_id = ? OR (to_hospital_id IS NULL AND from_hospital_id != ?)) " +
                     "ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            stmt.setInt(2, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    requests.add(mapResultSetToBloodRequest(rs));
                }
            }
        }
        return requests;
    }
    
    public List<BloodRequest> findByFromHospitalId(Integer fromHospitalId) throws SQLException {
        List<BloodRequest> requests = new ArrayList<>();
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request WHERE from_hospital_id = ? " +
                     "ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, fromHospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    requests.add(mapResultSetToBloodRequest(rs));
                }
            }
        }
        return requests;
    }
    
    public List<BloodRequest> findByBloodGroupAndStatus(String bloodGroup, String status) throws SQLException {
        List<BloodRequest> requests = new ArrayList<>();
        String sql = "SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                     "quantity, status, created_at, updated_at " +
                     "FROM blood_request WHERE blood_group = ? AND status = ? " +
                     "ORDER BY created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, bloodGroup);
            stmt.setString(2, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    requests.add(mapResultSetToBloodRequest(rs));
                }
            }
        }
        return requests;
    }
    
    /**
     * Cập nhật trạng thái yêu cầu máu thông qua stored procedure
     * Gọi sp_update_request_status(@request_id, @new_status, @by_user_id, @note)
     * 
     * @param requestId ID của yêu cầu máu
     * @param newStatus Trạng thái mới (ACCEPTED, REJECTED, COMPLETED)
     * @param actorUserId ID của user thực hiện thao tác (có thể null) - maps to @by_user_id
     * @param note Ghi chú (có thể null)
     * @return true nếu cập nhật thành công
     * @throws SQLException nếu có lỗi xảy ra
     */
    public boolean updateStatusViaStoredProcedure(Integer requestId, String newStatus, 
                                                   Integer actorUserId, String note) throws SQLException {
        // Stored procedure signature: sp_update_request_status(@request_id, @new_status, @by_user_id, @note)
        String sql = "{call dbo.sp_update_request_status(?, ?, ?, ?)}";
        try (Connection conn = DBConnection.getConnection();
             CallableStatement stmt = conn.prepareCall(sql)) {
            
            stmt.setInt(1, requestId);                    // @request_id
            stmt.setString(2, newStatus);                 // @new_status
            if (actorUserId != null) {
                stmt.setInt(3, actorUserId);             // @by_user_id
            } else {
                stmt.setNull(3, Types.INTEGER);
            }
            if (note != null && !note.trim().isEmpty()) {
                stmt.setString(4, note);                  // @note
            } else {
                stmt.setNull(4, Types.NVARCHAR);
            }
            
            stmt.execute();
            return true;
        }
    }
    
    private BloodRequest mapResultSetToBloodRequest(ResultSet rs) throws SQLException {
        BloodRequest request = new BloodRequest();
        request.setRequestId(rs.getInt("request_id"));
        request.setFromHospitalId(rs.getInt("from_hospital_id"));
        int toHospitalId = rs.getInt("to_hospital_id");
        if (!rs.wasNull()) {
            request.setToHospitalId(toHospitalId);
        }
        request.setBloodGroup(rs.getString("blood_group"));
        request.setComponent(rs.getString("component"));
        request.setQuantity(rs.getInt("quantity"));
        request.setStatus(rs.getString("status"));
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            request.setCreatedAt(createdTs.toLocalDateTime());
        }
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        if (updatedTs != null) {
            request.setUpdatedAt(updatedTs.toLocalDateTime());
        }
        return request;
    }
}

