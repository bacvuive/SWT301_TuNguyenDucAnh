package com.bloodlink.dao;

import com.bloodlink.model.HospitalVerificationDocument;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class HospitalVerificationDocumentDAO {

    public List<HospitalVerificationDocument> findByRequestId(Integer requestId) throws SQLException {
        String sql = "SELECT document_id, request_id, document_category, file_name, file_type, file_path, uploaded_at " +
                     "FROM hospital_verification_document WHERE request_id = ? ORDER BY uploaded_at";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                List<HospitalVerificationDocument> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(map(rs));
                }
                return list;
            }
        }
    }

    public Integer create(HospitalVerificationDocument document) throws SQLException {
        String sql = "INSERT INTO hospital_verification_document (request_id, document_category, file_name, file_type, file_path, uploaded_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, document.getRequestId());
            stmt.setString(2, document.getDocumentCategory());
            stmt.setString(3, document.getFileName());
            stmt.setString(4, document.getFileType());
            stmt.setString(5, document.getFilePath());
            stmt.setTimestamp(6, Timestamp.valueOf(document.getUploadedAt() != null ? document.getUploadedAt() : LocalDateTime.now()));

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = stmt.getGeneratedKeys()) {
                    if (keys.next()) {
                        return keys.getInt(1);
                    }
                }
            }
        }
        return null;
    }

    public void deleteByRequestId(Integer requestId) throws SQLException {
        String sql = "DELETE FROM hospital_verification_document WHERE request_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            stmt.executeUpdate();
        }
    }

    private HospitalVerificationDocument map(ResultSet rs) throws SQLException {
        HospitalVerificationDocument document = new HospitalVerificationDocument();
        document.setDocumentId(rs.getInt("document_id"));
        document.setRequestId(rs.getInt("request_id"));
        document.setDocumentCategory(rs.getString("document_category"));
        document.setFileName(rs.getString("file_name"));
        document.setFileType(rs.getString("file_type"));
        document.setFilePath(rs.getString("file_path"));
        Timestamp uploadedAt = rs.getTimestamp("uploaded_at");
        if (uploadedAt != null) {
            document.setUploadedAt(uploadedAt.toLocalDateTime());
        }
        return document;
    }
}
