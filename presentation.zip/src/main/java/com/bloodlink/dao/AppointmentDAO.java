package com.bloodlink.dao;

import com.bloodlink.model.Appointment;
import com.bloodlink.util.DBConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {
    
    public Appointment findById(Integer appointmentId) throws SQLException {
        String sql = "SELECT appointment_id, donor_id, hospital_id, note, scheduled_at, status, created_at, updated_at " +
                     "FROM appointments WHERE appointment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, appointmentId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToAppointment(rs);
                }
            }
        }
        return null;
    }
    
    public Integer create(Appointment appointment) throws SQLException {
        String sql = "INSERT INTO appointments (donor_id, hospital_id, note, scheduled_at, status, created_at, updated_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, appointment.getDonorId());
            stmt.setInt(2, appointment.getHospitalId());
            stmt.setString(3, appointment.getNote());
            stmt.setTimestamp(4, Timestamp.valueOf(appointment.getScheduledAt()));
            stmt.setString(5, appointment.getStatus() != null ? appointment.getStatus() : "PENDING");
            LocalDateTime now = LocalDateTime.now();
            stmt.setTimestamp(6, Timestamp.valueOf(appointment.getCreatedAt() != null ? appointment.getCreatedAt() : now));
            if (appointment.getUpdatedAt() != null) {
                stmt.setTimestamp(7, Timestamp.valueOf(appointment.getUpdatedAt()));
            } else {
                stmt.setNull(7, Types.TIMESTAMP);
            }
            
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1);
                    }
                }
            }
        }
        return null;
    }
    
    public boolean update(Appointment appointment) throws SQLException {
        String sql = "UPDATE appointments SET donor_id = ?, hospital_id = ?, note = ?, scheduled_at = ?, " +
                     "status = ?, updated_at = ? WHERE appointment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, appointment.getDonorId());
            stmt.setInt(2, appointment.getHospitalId());
            stmt.setString(3, appointment.getNote());
            stmt.setTimestamp(4, Timestamp.valueOf(appointment.getScheduledAt()));
            stmt.setString(5, appointment.getStatus());
            stmt.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(7, appointment.getAppointmentId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public List<Appointment> findByDonorId(Integer donorId) throws SQLException {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT appointment_id, donor_id, hospital_id, note, scheduled_at, status, created_at, updated_at " +
                     "FROM appointments WHERE donor_id = ? ORDER BY scheduled_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, donorId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    appointments.add(mapResultSetToAppointment(rs));
                }
            }
        }
        return appointments;
    }
    
    public List<Appointment> findByHospitalId(Integer hospitalId) throws SQLException {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT appointment_id, donor_id, hospital_id, note, scheduled_at, status, created_at, updated_at " +
                     "FROM appointments WHERE hospital_id = ? ORDER BY scheduled_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, hospitalId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    appointments.add(mapResultSetToAppointment(rs));
                }
            }
        }
        return appointments;
    }
    
    private Appointment mapResultSetToAppointment(ResultSet rs) throws SQLException {
        Appointment appointment = new Appointment();
        appointment.setAppointmentId(rs.getInt("appointment_id"));
        appointment.setDonorId(rs.getInt("donor_id"));
        appointment.setHospitalId(rs.getInt("hospital_id"));
        appointment.setNote(rs.getString("note"));
        Timestamp scheduledTs = rs.getTimestamp("scheduled_at");
        if (scheduledTs != null) {
            appointment.setScheduledAt(scheduledTs.toLocalDateTime());
        }
        appointment.setStatus(rs.getString("status"));
        Timestamp createdTs = rs.getTimestamp("created_at");
        if (createdTs != null) {
            appointment.setCreatedAt(createdTs.toLocalDateTime());
        }
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        if (updatedTs != null) {
            appointment.setUpdatedAt(updatedTs.toLocalDateTime());
        }
        return appointment;
    }
}

