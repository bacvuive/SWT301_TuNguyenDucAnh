package com.bloodlink.model;

import java.time.LocalDateTime;

public class User {
    private Integer userId;
    private String username;
    private String passwordHash;
    private String email;
    private String roleCode; // admin, hospital, donor
    private String status; // active, inactive
    private LocalDateTime createdAt;

    public User() {}

    public User(Integer userId, String username, String passwordHash, String email, 
                String roleCode, String status, LocalDateTime createdAt) {
        this.userId = userId;
        this.username = username;
        this.passwordHash = passwordHash;
        this.email = email;
        this.roleCode = roleCode;
        this.status = status;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRoleCode() { return roleCode; }
    public void setRoleCode(String roleCode) { this.roleCode = roleCode; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

