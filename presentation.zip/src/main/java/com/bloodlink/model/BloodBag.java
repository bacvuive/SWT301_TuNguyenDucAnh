package com.bloodlink.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class BloodBag {
    private Integer bagId;
    private String bagCode;
    private Integer hospitalId;
    private Integer recordId;
    private String bloodGroup;
    private String component; // WB, RBC, PLT, FFP
    private Integer volumeMl;
    private LocalDate collectionDate;
    private LocalDate expiryDate;
    private String status; // AVAILABLE, RESERVED, IN_USE, TRANSFERRED, EXPIRED
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public BloodBag() {}

    public BloodBag(Integer bagId, String bagCode, Integer hospitalId, Integer recordId,
                    String bloodGroup, String component, Integer volumeMl,
                    LocalDate collectionDate, LocalDate expiryDate, String status,
                    LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.bagId = bagId;
        this.bagCode = bagCode;
        this.hospitalId = hospitalId;
        this.recordId = recordId;
        this.bloodGroup = bloodGroup;
        this.component = component;
        this.volumeMl = volumeMl;
        this.collectionDate = collectionDate;
        this.expiryDate = expiryDate;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public Integer getBagId() { return bagId; }
    public void setBagId(Integer bagId) { this.bagId = bagId; }

    public String getBagCode() { return bagCode; }
    public void setBagCode(String bagCode) { this.bagCode = bagCode; }

    public Integer getHospitalId() { return hospitalId; }
    public void setHospitalId(Integer hospitalId) { this.hospitalId = hospitalId; }

    public Integer getRecordId() { return recordId; }
    public void setRecordId(Integer recordId) { this.recordId = recordId; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getComponent() { return component; }
    public void setComponent(String component) { this.component = component; }

    public Integer getVolumeMl() { return volumeMl; }
    public void setVolumeMl(Integer volumeMl) { this.volumeMl = volumeMl; }

    public LocalDate getCollectionDate() { return collectionDate; }
    public void setCollectionDate(LocalDate collectionDate) { this.collectionDate = collectionDate; }

    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

