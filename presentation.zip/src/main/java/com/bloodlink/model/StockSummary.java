package com.bloodlink.model;

/**
 * Model cho stock summary từ views
 */
public class StockSummary {
    private Integer hospitalId;
    private String hospitalName;
    private String bloodGroup;
    private String component;
    private String status;
    private Integer units;

    public StockSummary() {}

    public StockSummary(Integer hospitalId, String hospitalName, String bloodGroup, 
                       String component, String status, Integer units) {
        this.hospitalId = hospitalId;
        this.hospitalName = hospitalName;
        this.bloodGroup = bloodGroup;
        this.component = component;
        this.status = status;
        this.units = units;
    }

    // Getters and Setters
    public Integer getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(Integer hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getUnits() {
        return units;
    }

    public void setUnits(Integer units) {
        this.units = units;
    }
}

