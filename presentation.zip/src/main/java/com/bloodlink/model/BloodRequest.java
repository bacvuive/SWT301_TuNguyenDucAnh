package com.bloodlink.model;

import java.time.LocalDateTime;

public class BloodRequest {
    private Integer requestId;
    private Integer fromHospitalId;
    private Integer toHospitalId; // NULL = broadcast
    private String bloodGroup;
    private String component; // WB, RBC, PLT, FFP
    private Integer quantity;
    private String status; // PENDING, ACCEPTED, REJECTED, COMPLETED
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public BloodRequest() {}

    public BloodRequest(Integer requestId, Integer fromHospitalId, Integer toHospitalId,
                        String bloodGroup, String component, Integer quantity,
                        String status, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.requestId = requestId;
        this.fromHospitalId = fromHospitalId;
        this.toHospitalId = toHospitalId;
        this.bloodGroup = bloodGroup;
        this.component = component;
        this.quantity = quantity;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public Integer getRequestId() { return requestId; }
    public void setRequestId(Integer requestId) { this.requestId = requestId; }

    public Integer getFromHospitalId() { return fromHospitalId; }
    public void setFromHospitalId(Integer fromHospitalId) { this.fromHospitalId = fromHospitalId; }

    public Integer getToHospitalId() { return toHospitalId; }
    public void setToHospitalId(Integer toHospitalId) { this.toHospitalId = toHospitalId; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getComponent() { return component; }
    public void setComponent(String component) { this.component = component; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

