package com.bloodlink.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class DonationRecord {
    private Integer recordId;
    private Integer donorId;
    private Integer hospitalId;
    private LocalDate donationDate;
    private String measuredBloodGroup;
    private Integer quantityMl;
    private String status; // PENDING, CONFIRMED, CANCELLED
    private String certificateUrl;
    private LocalDateTime createdAt;

    public DonationRecord() {}

    public DonationRecord(Integer recordId, Integer donorId, Integer hospitalId, 
                          LocalDate donationDate, String measuredBloodGroup, 
                          Integer quantityMl, String status, String certificateUrl, 
                          LocalDateTime createdAt) {
        this.recordId = recordId;
        this.donorId = donorId;
        this.hospitalId = hospitalId;
        this.donationDate = donationDate;
        this.measuredBloodGroup = measuredBloodGroup;
        this.quantityMl = quantityMl;
        this.status = status;
        this.certificateUrl = certificateUrl;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Integer getRecordId() { return recordId; }
    public void setRecordId(Integer recordId) { this.recordId = recordId; }

    public Integer getDonorId() { return donorId; }
    public void setDonorId(Integer donorId) { this.donorId = donorId; }

    public Integer getHospitalId() { return hospitalId; }
    public void setHospitalId(Integer hospitalId) { this.hospitalId = hospitalId; }

    public LocalDate getDonationDate() { return donationDate; }
    public void setDonationDate(LocalDate donationDate) { this.donationDate = donationDate; }

    public String getMeasuredBloodGroup() { return measuredBloodGroup; }
    public void setMeasuredBloodGroup(String measuredBloodGroup) { this.measuredBloodGroup = measuredBloodGroup; }

    public Integer getQuantityMl() { return quantityMl; }
    public void setQuantityMl(Integer quantityMl) { this.quantityMl = quantityMl; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCertificateUrl() { return certificateUrl; }
    public void setCertificateUrl(String certificateUrl) { this.certificateUrl = certificateUrl; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

