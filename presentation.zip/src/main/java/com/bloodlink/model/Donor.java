package com.bloodlink.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Donor {
    private Integer donorId;
    private Integer userId;
    private String fullName;
    private LocalDate dob;
    private String gender; // male, female, other
    private String bloodGroup; // A+, A-, B+, B-, AB+, AB-, O+, O-
    private String phone;
    private String address;
    private LocalDateTime createdAt;

    public Donor() {}

    public Donor(Integer donorId, Integer userId, String fullName, LocalDate dob, 
                 String gender, String bloodGroup, String phone, String address, 
                 LocalDateTime createdAt) {
        this.donorId = donorId;
        this.userId = userId;
        this.fullName = fullName;
        this.dob = dob;
        this.gender = gender;
        this.bloodGroup = bloodGroup;
        this.phone = phone;
        this.address = address;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Integer getDonorId() { return donorId; }
    public void setDonorId(Integer donorId) { this.donorId = donorId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

