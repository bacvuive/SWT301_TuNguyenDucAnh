package com.bloodlink.model;

import java.time.LocalDateTime;

public class Hospital {
    private Integer hospitalId;
    private Integer userId;
    private String name;
    private String address;
    private String contact;
    private String region;
    private Double latitude;
    private Double longitude;
    private Boolean isVerified;
    private LocalDateTime verifiedAt;
    private Integer verifiedBy;
    private String verificationNote;
    private LocalDateTime createdAt;

    public Hospital() {}

    public Hospital(Integer hospitalId, Integer userId, String name, String address, 
                    String contact, String region, Double latitude, Double longitude,
                    Boolean isVerified, LocalDateTime verifiedAt, Integer verifiedBy,
                    String verificationNote, LocalDateTime createdAt) {
        this.hospitalId = hospitalId;
        this.userId = userId;
        this.name = name;
        this.address = address;
        this.contact = contact;
        this.region = region;
        this.latitude = latitude;
        this.longitude = longitude;
        this.isVerified = isVerified;
        this.verifiedAt = verifiedAt;
        this.verifiedBy = verifiedBy;
        this.verificationNote = verificationNote;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Integer getHospitalId() { return hospitalId; }
    public void setHospitalId(Integer hospitalId) { this.hospitalId = hospitalId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }

    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }

    public Boolean getIsVerified() { return isVerified; }
    public void setIsVerified(Boolean isVerified) { this.isVerified = isVerified; }

    public LocalDateTime getVerifiedAt() { return verifiedAt; }
    public void setVerifiedAt(LocalDateTime verifiedAt) { this.verifiedAt = verifiedAt; }

    public Integer getVerifiedBy() { return verifiedBy; }
    public void setVerifiedBy(Integer verifiedBy) { this.verifiedBy = verifiedBy; }

    public String getVerificationNote() { return verificationNote; }
    public void setVerificationNote(String verificationNote) { this.verificationNote = verificationNote; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

