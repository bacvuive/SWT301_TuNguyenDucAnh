package com.bloodlink.model;

import java.time.LocalDateTime;

public class TransferEvent {
    private Long eventId;
    private Integer transferId;
    private Integer bagId;
    private String eventType; // CREATED, PICKED_UP, IN_TRANSIT, DELIVERED, CANCELLED
    private String note;
    private LocalDateTime createdAt;

    public TransferEvent() {}

    public TransferEvent(Long eventId, Integer transferId, Integer bagId, 
                         String eventType, String note, LocalDateTime createdAt) {
        this.eventId = eventId;
        this.transferId = transferId;
        this.bagId = bagId;
        this.eventType = eventType;
        this.note = note;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Long getEventId() { return eventId; }
    public void setEventId(Long eventId) { this.eventId = eventId; }

    public Integer getTransferId() { return transferId; }
    public void setTransferId(Integer transferId) { this.transferId = transferId; }

    public Integer getBagId() { return bagId; }
    public void setBagId(Integer bagId) { this.bagId = bagId; }

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

