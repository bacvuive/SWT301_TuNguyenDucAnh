package com.bloodlink.model;

import java.time.LocalDateTime;

/**
 * Notification model với cấu trúc mở rộng:
 * - type: REQUEST_ACCEPTED, REQUEST_REJECTED, REQUEST_COMPLETED,
 *         TRANSFER_CREATED, TRANSFER_PICKED_UP, TRANSFER_IN_TRANSIT, 
 *         TRANSFER_DELIVERED, TRANSFER_CANCELLED, BAG_EXPIRED
 * - subject: Tiêu đề thông báo
 * - link: URL để xem chi tiết (optional)
 */
public class Notification {
    private Long notificationId;
    private Integer userId; // recipient_id
    private String type; // REQUEST_ACCEPTED, TRANSFER_CREATED, etc.
    private String subject; // Tiêu đề
    private String message; // Nội dung
    private String link; // URL để xem chi tiết (optional)
    private Boolean isRead;
    private LocalDateTime createdAt;

    public Notification() {}

    public Notification(Long notificationId, Integer userId, String type, 
                        String subject, String message, String link,
                        Boolean isRead, LocalDateTime createdAt) {
        this.notificationId = notificationId;
        this.userId = userId;
        this.type = type;
        this.subject = subject;
        this.message = message;
        this.link = link;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Long getNotificationId() { return notificationId; }
    public void setNotificationId(Long notificationId) { this.notificationId = notificationId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }

    public Boolean getIsRead() { return isRead; }
    public void setIsRead(Boolean isRead) { this.isRead = isRead; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

