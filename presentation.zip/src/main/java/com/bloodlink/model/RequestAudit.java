package com.bloodlink.model;

import java.time.LocalDateTime;

/**
 * Model cho bảng request_audit (audit trail của blood requests)
 */
public class RequestAudit {
    private Long auditId;
    private Integer requestId;
    private Integer actorUserId;
    private String oldStatus;
    private String newStatus;
    private String note;
    private LocalDateTime createdAt;

    public RequestAudit() {}

    public RequestAudit(Long auditId, Integer requestId, Integer actorUserId,
                       String oldStatus, String newStatus, String note, LocalDateTime createdAt) {
        this.auditId = auditId;
        this.requestId = requestId;
        this.actorUserId = actorUserId;
        this.oldStatus = oldStatus;
        this.newStatus = newStatus;
        this.note = note;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public Long getAuditId() { return auditId; }
    public void setAuditId(Long auditId) { this.auditId = auditId; }

    public Integer getRequestId() { return requestId; }
    public void setRequestId(Integer requestId) { this.requestId = requestId; }

    public Integer getActorUserId() { return actorUserId; }
    public void setActorUserId(Integer actorUserId) { this.actorUserId = actorUserId; }

    public String getOldStatus() { return oldStatus; }
    public void setOldStatus(String oldStatus) { this.oldStatus = oldStatus; }

    public String getNewStatus() { return newStatus; }
    public void setNewStatus(String newStatus) { this.newStatus = newStatus; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}

