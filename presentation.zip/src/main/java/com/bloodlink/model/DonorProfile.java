package com.bloodlink.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class DonorProfile {
    private Integer donorId;
    private BigDecimal heightCm;
    private BigDecimal weightKg;
    private BigDecimal lastHbGdl;
    private String chronicCond;
    private String allergies;
    private LocalDate lastScreen;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public DonorProfile() {}

    public DonorProfile(Integer donorId, BigDecimal heightCm, BigDecimal weightKg,
                        BigDecimal lastHbGdl, String chronicCond, String allergies,
                        LocalDate lastScreen, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.donorId = donorId;
        this.heightCm = heightCm;
        this.weightKg = weightKg;
        this.lastHbGdl = lastHbGdl;
        this.chronicCond = chronicCond;
        this.allergies = allergies;
        this.lastScreen = lastScreen;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public Integer getDonorId() { return donorId; }
    public void setDonorId(Integer donorId) { this.donorId = donorId; }

    public BigDecimal getHeightCm() { return heightCm; }
    public void setHeightCm(BigDecimal heightCm) { this.heightCm = heightCm; }

    public BigDecimal getWeightKg() { return weightKg; }
    public void setWeightKg(BigDecimal weightKg) { this.weightKg = weightKg; }

    public BigDecimal getLastHbGdl() { return lastHbGdl; }
    public void setLastHbGdl(BigDecimal lastHbGdl) { this.lastHbGdl = lastHbGdl; }

    public String getChronicCond() { return chronicCond; }
    public void setChronicCond(String chronicCond) { this.chronicCond = chronicCond; }

    public String getAllergies() { return allergies; }
    public void setAllergies(String allergies) { this.allergies = allergies; }

    public LocalDate getLastScreen() { return lastScreen; }
    public void setLastScreen(LocalDate lastScreen) { this.lastScreen = lastScreen; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}

