package com.bloodlink.util;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * ExcelExporter - Utility class để export data ra Excel file
 * Sử dụng Apache POI
 */
public class ExcelExporter {

    /**
     * Export inventory report ra Excel
     */
    public static byte[] exportInventoryReport(List<Map<String, Object>> inventory, 
                                               String hospitalName) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Kho máu");

        // Create styles
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);

        CellStyle dateStyle = workbook.createCellStyle();
        CreationHelper createHelper = workbook.getCreationHelper();
        dateStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/MM/yyyy"));

        // Header row
        Row headerRow = sheet.createRow(0);
        String[] headers = {"Mã túi máu", "Nhóm máu", "Thành phần", "Thể tích (ml)", 
                           "Ngày thu thập", "Ngày hết hạn", "Trạng thái"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }

        // Data rows
        int rowNum = 1;
        for (Map<String, Object> bag : inventory) {
            Row row = sheet.createRow(rowNum++);
            
            int colNum = 0;
            row.createCell(colNum++).setCellValue(bag.get("bagCode") != null ? bag.get("bagCode").toString() : "");
            row.createCell(colNum++).setCellValue(bag.get("bloodGroup") != null ? bag.get("bloodGroup").toString() : "");
            row.createCell(colNum++).setCellValue(bag.get("component") != null ? bag.get("component").toString() : "");
            row.createCell(colNum++).setCellValue(bag.get("volumeMl") != null ? Integer.parseInt(bag.get("volumeMl").toString()) : 0);
            
            // Date cells
            if (bag.get("collectionDate") != null) {
                Cell dateCell = row.createCell(colNum++);
                if (bag.get("collectionDate") instanceof LocalDate) {
                    dateCell.setCellValue(((LocalDate) bag.get("collectionDate")).toString());
                } else {
                    dateCell.setCellValue(bag.get("collectionDate").toString());
                }
            } else {
                row.createCell(colNum++).setCellValue("");
            }
            
            if (bag.get("expiryDate") != null) {
                Cell dateCell = row.createCell(colNum++);
                if (bag.get("expiryDate") instanceof LocalDate) {
                    dateCell.setCellValue(((LocalDate) bag.get("expiryDate")).toString());
                } else {
                    dateCell.setCellValue(bag.get("expiryDate").toString());
                }
            } else {
                row.createCell(colNum++).setCellValue("");
            }
            
            row.createCell(colNum++).setCellValue(bag.get("status") != null ? bag.get("status").toString() : "");
        }

        // Auto-size columns
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write to byte array
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        return outputStream.toByteArray();
    }

    /**
     * Export donation report ra Excel
     */
    public static byte[] exportDonationReport(List<Map<String, Object>> donations,
                                              String hospitalName) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Báo cáo hiến máu");

        // Create styles
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);

        // Header row
        Row headerRow = sheet.createRow(0);
        String[] headers = {"Ngày hiến máu", "Tên người hiến", "Nhóm máu", "Số lượng (ml)", "Trạng thái"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }

        // Data rows
        int rowNum = 1;
        for (Map<String, Object> donation : donations) {
            Row row = sheet.createRow(rowNum++);
            
            int colNum = 0;
            row.createCell(colNum++).setCellValue(donation.get("donationDate") != null ? donation.get("donationDate").toString() : "");
            row.createCell(colNum++).setCellValue(donation.get("donorName") != null ? donation.get("donorName").toString() : "");
            row.createCell(colNum++).setCellValue(donation.get("bloodGroup") != null ? donation.get("bloodGroup").toString() : "");
            row.createCell(colNum++).setCellValue(donation.get("quantityMl") != null ? Integer.parseInt(donation.get("quantityMl").toString()) : 0);
            row.createCell(colNum++).setCellValue(donation.get("status") != null ? donation.get("status").toString() : "");
        }

        // Auto-size columns
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write to byte array
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        return outputStream.toByteArray();
    }

    /**
     * Export blood request report ra Excel
     */
    public static byte[] exportRequestReport(List<Map<String, Object>> requests,
                                            String hospitalName) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Báo cáo yêu cầu máu");

        // Create styles
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);

        // Header row
        Row headerRow = sheet.createRow(0);
        String[] headers = {"Mã yêu cầu", "Từ bệnh viện", "Đến bệnh viện", "Nhóm máu", 
                           "Thành phần", "Số lượng", "Trạng thái", "Ngày tạo"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }

        // Data rows
        int rowNum = 1;
        for (Map<String, Object> request : requests) {
            Row row = sheet.createRow(rowNum++);
            
            int colNum = 0;
            row.createCell(colNum++).setCellValue(request.get("requestId") != null ? Integer.parseInt(request.get("requestId").toString()) : 0);
            row.createCell(colNum++).setCellValue(request.get("fromHospitalName") != null ? request.get("fromHospitalName").toString() : "");
            row.createCell(colNum++).setCellValue(request.get("toHospitalName") != null ? request.get("toHospitalName").toString() : "Tất cả");
            row.createCell(colNum++).setCellValue(request.get("bloodGroup") != null ? request.get("bloodGroup").toString() : "");
            row.createCell(colNum++).setCellValue(request.get("component") != null ? request.get("component").toString() : "");
            row.createCell(colNum++).setCellValue(request.get("quantity") != null ? Integer.parseInt(request.get("quantity").toString()) : 0);
            row.createCell(colNum++).setCellValue(request.get("status") != null ? request.get("status").toString() : "");
            row.createCell(colNum++).setCellValue(request.get("createdAt") != null ? request.get("createdAt").toString() : "");
        }

        // Auto-size columns
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write to byte array
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        return outputStream.toByteArray();
    }
}

