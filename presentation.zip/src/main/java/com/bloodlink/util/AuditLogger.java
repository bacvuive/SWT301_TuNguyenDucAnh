package com.bloodlink.util;

import com.bloodlink.service.AuditLogService;

import jakarta.servlet.http.HttpServletRequest;

/**
 * AuditLogger - Helper class để log user actions dễ dàng
 */
public class AuditLogger {
    private static AuditLogService auditLogService = new AuditLogService();

    /**
     * Log action từ HttpServletRequest
     */
    public static void logAction(HttpServletRequest request, Integer userId, 
                                 String action, String entityType, Integer entityId,
                                 String oldValue, String newValue) {
        String ipAddress = getClientIpAddress(request);
        String userAgent = request.getHeader("User-Agent");
        
        auditLogService.logAction(userId, action, entityType, entityId, 
                                  oldValue, newValue, ipAddress, userAgent);
    }

    /**
     * Log simple action
     */
    public static void logAction(HttpServletRequest request, Integer userId,
                                 String action, String entityType, Integer entityId) {
        logAction(request, userId, action, entityType, entityId, null, null);
    }

    /**
     * Get client IP address from request
     */
    private static String getClientIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }
}

