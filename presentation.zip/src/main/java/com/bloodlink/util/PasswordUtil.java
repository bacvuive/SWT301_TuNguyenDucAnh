package com.bloodlink.util;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {
    
    public static String hashPassword(String plainPassword) {
        if (plainPassword == null || plainPassword.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));
    }
    
    public static boolean checkPassword(String plainPassword, String hashedPassword) {
        try {
            if (plainPassword == null || hashedPassword == null || 
                plainPassword.isEmpty() || hashedPassword.isEmpty()) {
                System.err.println("PasswordUtil.checkPassword: null or empty password/hash");
                return false;
            }
            
            // Check if hash looks like BCrypt hash (starts with $2a$)
            if (!hashedPassword.startsWith("$2a$") && !hashedPassword.startsWith("$2b$")) {
                System.err.println("PasswordUtil.checkPassword: Invalid hash format");
                return false;
            }
            
            return BCrypt.checkpw(plainPassword, hashedPassword);
        } catch (IllegalArgumentException e) {
            System.err.println("PasswordUtil.checkPassword: IllegalArgumentException - " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.err.println("PasswordUtil.checkPassword: Unexpected error - " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}

