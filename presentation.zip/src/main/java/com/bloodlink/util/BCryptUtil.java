package com.bloodlink.util;

import org.mindrot.jbcrypt.BCrypt;

/**
 * BCryptUtil - Utility class để hash và verify password với BCrypt
 * Sử dụng thư viện jbcrypt (org.mindrot.jbcrypt.BCrypt)
 */
public class BCryptUtil {
    
    // Số rounds cho BCrypt (12 là giá trị cân bằng giữa security và performance)
    private static final int ROUNDS = 12;

    /**
     * Hash password thành BCrypt hash
     * 
     * @param plainPassword Password dạng plain text
     * @return BCrypt hash string (format: $2a$rounds$salt+hash)
     * @throws IllegalArgumentException nếu password null hoặc empty
     */
    public static String hashPassword(String plainPassword) {
        if (plainPassword == null || plainPassword.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(ROUNDS));
    }

    /**
     * Verify password với BCrypt hash
     * 
     * @param plainPassword Password dạng plain text cần verify
     * @param hashedPassword BCrypt hash từ database
     * @return true nếu password đúng, false nếu sai hoặc có lỗi
     */
    public static boolean verifyPassword(String plainPassword, String hashedPassword) {
        try {
            if (plainPassword == null || hashedPassword == null || 
                plainPassword.isEmpty() || hashedPassword.isEmpty()) {
                return false;
            }
            
            // Kiểm tra format BCrypt hash (phải bắt đầu với $2a$, $2b$, hoặc $2y$)
            if (!hashedPassword.startsWith("$2a$") && 
                !hashedPassword.startsWith("$2b$") && 
                !hashedPassword.startsWith("$2y$")) {
                return false;
            }
            
            return BCrypt.checkpw(plainPassword, hashedPassword);
        } catch (Exception e) {
            System.err.println("[BCryptUtil] Error verifying password: " + e.getMessage());
            return false;
        }
    }

    /**
     * Main method để chạy và convert password thành BCrypt hash
     * Có thể chạy từ command line: java BCryptUtil <password>
     * Hoặc chạy trực tiếp trong IDE
     */
    public static void main(String[] args) {
        if (args.length > 0) {
            // Chạy từ command line với argument
            String password = args[0];
            String hashed = hashPassword(password);
            System.out.println("Password: " + password);
            System.out.println("BCrypt Hash: " + hashed);
        } else {
            // Chạy trực tiếp - convert password mặc định
            String password = "12345678";
            String hashed = hashPassword(password);
            System.out.println("========================================");
            System.out.println("BCrypt Password Converter");
            System.out.println("========================================");
            System.out.println("Password: " + password);
            System.out.println("BCrypt Hash: " + hashed);
            System.out.println("========================================");
            System.out.println("Verify test:");
            System.out.println("  verifyPassword(\"" + password + "\", hash) = " + verifyPassword(password, hashed));
            System.out.println("  verifyPassword(\"wrong\", hash) = " + verifyPassword("wrong", hashed));
        }
    }
}

