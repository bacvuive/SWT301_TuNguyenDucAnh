package com.bloodlink.util;

import java.io.InputStream;
import java.util.Properties;

/**
 * Utility class để đọc application configuration từ application.properties
 */
public class AppConfig {
    private static AppConfig instance;
    private static final String PROPERTIES_FILE = "/application.properties";
    private Properties properties;
    private boolean initialized = false;

    private AppConfig() {
        loadProperties();
    }

    public static AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }

    /**
     * Load properties từ file application.properties
     */
    private void loadProperties() {
        properties = new Properties();
        try (InputStream inputStream = AppConfig.class.getResourceAsStream(PROPERTIES_FILE)) {
            if (inputStream != null) {
                properties.load(inputStream);
            } else {
                System.err.println("Warning: application.properties not found, using defaults");
                // Set defaults
                properties = new Properties();
                properties.setProperty("transfer.auto-link.enabled", "true");
            }
        } catch (Exception e) {
            System.err.println("Error loading application.properties: " + e.getMessage());
            // Set defaults
            properties = new Properties();
            properties.setProperty("transfer.auto-link.enabled", "true");
        }
        initialized = true;
    }

    /**
     * Lấy giá trị property (instance method)
     * @param key Key của property
     * @param defaultValue Giá trị mặc định nếu không tìm thấy
     * @return Giá trị property hoặc defaultValue
     */
    private String getPropertyInternal(String key, String defaultValue) {
        if (!initialized) {
            loadProperties();
        }
        return properties.getProperty(key, defaultValue);
    }

    /**
     * Lấy giá trị boolean property (instance method)
     * @param key Key của property
     * @param defaultValue Giá trị mặc định nếu không tìm thấy
     * @return Giá trị boolean
     */
    private boolean getBooleanPropertyInternal(String key, boolean defaultValue) {
        String value = getPropertyInternal(key, String.valueOf(defaultValue));
        return Boolean.parseBoolean(value);
    }

    /**
     * Kiểm tra xem auto-link có được bật không (instance method)
     * @return true nếu auto-link enabled
     */
    private boolean isAutoLinkEnabledInternal() {
        return getBooleanPropertyInternal("transfer.auto-link.enabled", true);
    }

    // Static methods for backward compatibility
    public static String getProperty(String key, String defaultValue) {
        return getInstance().getPropertyInternal(key, defaultValue);
    }

    public static boolean getBooleanProperty(String key, boolean defaultValue) {
        return getInstance().getBooleanPropertyInternal(key, defaultValue);
    }

    public static boolean isAutoLinkEnabled() {
        return getInstance().isAutoLinkEnabledInternal();
    }
}

