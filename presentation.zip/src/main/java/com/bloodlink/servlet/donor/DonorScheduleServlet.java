package com.bloodlink.servlet.donor;

import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.Appointment;
import com.bloodlink.model.Donor;
import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/donor/schedule")
public class DonorScheduleServlet extends HttpServlet {
    private DonorService donorService;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            donorService = new DonorService();
            hospitalDAO = new HospitalDAO();
            System.out.println("[DonorScheduleServlet] Initialized successfully");
        } catch (Exception e) {
            System.err.println("[DonorScheduleServlet] Error in init: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("Failed to initialize DonorScheduleServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("[DonorScheduleServlet] doGet called for: " + request.getRequestURI());
        
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("authUser") == null) {
                System.out.println("[DonorScheduleServlet] No session or authUser, redirecting to login");
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }

            User user = (User) session.getAttribute("authUser");
            System.out.println("[DonorScheduleServlet] User role: " + user.getRoleCode());
            
            if (!"donor".equals(user.getRoleCode())) {
                System.out.println("[DonorScheduleServlet] User is not donor, redirecting");
                response.sendRedirect(request.getContextPath() + "/");
                return;
            }

            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                System.out.println("[DonorScheduleServlet] Donor not found for userId: " + user.getUserId());
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy thông tin người hiến máu");
                return;
            }

            System.out.println("[DonorScheduleServlet] Fetching appointments and hospitals...");
            
            var appointments = donorService.getAppointments(donor.getDonorId());
            var hospitals = hospitalDAO.findAll();

            System.out.println("[DonorScheduleServlet] Appointments count: " + (appointments != null ? appointments.size() : 0));
            System.out.println("[DonorScheduleServlet] Hospitals count: " + (hospitals != null ? hospitals.size() : 0));

            // Enrich appointments with hospital names
            List<Map<String, Object>> enrichedAppointments = new ArrayList<>();
            if (appointments != null) {
                for (Appointment appt : appointments) {
                    if (appt != null) {
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("appointmentId", appt.getAppointmentId());
                        enriched.put("donorId", appt.getDonorId());
                        enriched.put("hospitalId", appt.getHospitalId());
                        enriched.put("note", appt.getNote());
                        
                        // Convert LocalDateTime to Timestamp for JSP fmt:formatDate
                        if (appt.getScheduledAt() != null) {
                            enriched.put("scheduledAt", Timestamp.valueOf(appt.getScheduledAt()));
                        } else {
                            enriched.put("scheduledAt", null);
                        }
                        
                        enriched.put("status", appt.getStatus());
                        
                        // Convert LocalDateTime to Timestamp for JSP fmt:formatDate
                        if (appt.getCreatedAt() != null) {
                            enriched.put("createdAt", Timestamp.valueOf(appt.getCreatedAt()));
                        } else {
                            enriched.put("createdAt", null);
                        }
                        
                        var hospital = hospitalDAO.findById(appt.getHospitalId());
                        enriched.put("hospitalName", hospital != null ? hospital.getName() : "Không xác định");
                        
                        enrichedAppointments.add(enriched);
                    }
                }
            }

            request.setAttribute("appointments", enrichedAppointments);
            request.setAttribute("hospitals", hospitals != null ? hospitals : new ArrayList<>());
            request.setAttribute("donor", donor);

            System.out.println("[DonorScheduleServlet] Forwarding to JSP...");
            response.setContentType("text/html;charset=UTF-8");
            request.getRequestDispatcher("/donor/schedule.jsp").forward(request, response);
            System.out.println("[DonorScheduleServlet] JSP forwarded successfully");
            
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("[DonorScheduleServlet] SQLException: " + e.getMessage());
            
            // Only forward if response hasn't been committed
            if (!response.isCommitted()) {
                request.setAttribute("error", "Lỗi khi tải dữ liệu! Vui lòng thử lại sau.");
                request.setAttribute("appointments", new ArrayList<>());
                request.setAttribute("hospitals", new ArrayList<>());
                
                // Try to get donor again for display
                try {
                    HttpSession session = request.getSession(false);
                    if (session != null) {
                        User user = (User) session.getAttribute("authUser");
                        if (user != null) {
                            Donor donor = donorService.getDonorByUserId(user.getUserId());
                            if (donor != null) {
                                request.setAttribute("donor", donor);
                            }
                        }
                    }
                } catch (Exception ex) {
                    // Ignore, just continue
                }
                
                try {
                    response.setContentType("text/html;charset=UTF-8");
                    request.getRequestDispatcher("/donor/schedule.jsp").forward(request, response);
                } catch (Exception ex) {
                    System.err.println("[DonorScheduleServlet] Error forwarding to JSP: " + ex.getMessage());
                    ex.printStackTrace();
                }
            } else {
                System.err.println("[DonorScheduleServlet] Response already committed, cannot forward");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("[DonorScheduleServlet] Exception: " + e.getMessage());
            
            // Only forward if response hasn't been committed
            if (!response.isCommitted()) {
                request.setAttribute("error", "Lỗi không xác định! Vui lòng thử lại sau.");
                request.setAttribute("appointments", new ArrayList<>());
                request.setAttribute("hospitals", new ArrayList<>());
                
                // Try to get donor again for display
                try {
                    HttpSession session = request.getSession(false);
                    if (session != null) {
                        User user = (User) session.getAttribute("authUser");
                        if (user != null) {
                            Donor donor = donorService.getDonorByUserId(user.getUserId());
                            if (donor != null) {
                                request.setAttribute("donor", donor);
                            }
                        }
                    }
                } catch (Exception ex) {
                    // Ignore, just continue
                }
                
                try {
                    response.setContentType("text/html;charset=UTF-8");
                    request.getRequestDispatcher("/donor/schedule.jsp").forward(request, response);
                } catch (Exception ex) {
                    System.err.println("[DonorScheduleServlet] Error forwarding to JSP: " + ex.getMessage());
                    ex.printStackTrace();
                }
            } else {
                System.err.println("[DonorScheduleServlet] Response already committed, cannot forward");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            String hospitalIdStr = request.getParameter("hospitalId");
            String scheduledAtStr = request.getParameter("scheduledAt");
            String note = request.getParameter("note");

            if (hospitalIdStr == null || scheduledAtStr == null || 
                hospitalIdStr.isEmpty() || scheduledAtStr.isEmpty()) {
                request.setAttribute("error", "Vui lòng điền đầy đủ thông tin!");
                doGet(request, response);
                return;
            }

            Integer hospitalId = Integer.parseInt(hospitalIdStr);
            // Parse datetime-local format: "yyyy-MM-ddTHH:mm" 
            LocalDateTime scheduledAt = LocalDateTime.parse(scheduledAtStr, 
                    DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            // Validate future date
            if (scheduledAt.isBefore(LocalDateTime.now())) {
                request.setAttribute("error", "Ngày giờ đặt lịch phải trong tương lai!");
                doGet(request, response);
                return;
            }

            System.out.println("[DonorScheduleServlet] Creating appointment for donorId: " + donor.getDonorId() + 
                ", hospitalId: " + hospitalId + ", scheduledAt: " + scheduledAt);
            
            var appointment = donorService.createAppointment(
                    donor.getDonorId(), hospitalId, scheduledAt, note);

            if (appointment != null) {
                System.out.println("[DonorScheduleServlet] Appointment created successfully: " + appointment.getAppointmentId());
                System.out.println("[DonorScheduleServlet] Redirecting to history page...");
                // Use redirect with a timestamp to prevent caching
                response.sendRedirect(request.getContextPath() + "/donor/history?success=appointment_created&t=" + System.currentTimeMillis());
            } else {
                System.err.println("[DonorScheduleServlet] Failed to create appointment");
                request.setAttribute("error", "Không thể tạo lịch hẹn!");
                doGet(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống!");
            doGet(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Dữ liệu không hợp lệ!");
            doGet(request, response);
        }
    }
}

