package com.bloodlink.servlet.donor;

import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/donor/schedule/cancel")
public class DonorScheduleCancelServlet extends HttpServlet {
    private DonorService donorService;

    @Override
    public void init() throws ServletException {
        super.init();
        donorService = new DonorService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            String appointmentIdStr = request.getParameter("appointmentId");
            if (appointmentIdStr == null || appointmentIdStr.isEmpty()) {
                response.sendRedirect(request.getContextPath() + "/donor/schedule?error=invalid_id");
                return;
            }

            Integer appointmentId = Integer.parseInt(appointmentIdStr);
            boolean cancelled = donorService.cancelAppointment(appointmentId);

            if (cancelled) {
                response.sendRedirect(request.getContextPath() + "/donor/schedule?success=appointment_cancelled");
            } else {
                response.sendRedirect(request.getContextPath() + "/donor/schedule?error=cancel_failed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/donor/schedule?error=system_error");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/donor/schedule?error=invalid_data");
        }
    }
}

