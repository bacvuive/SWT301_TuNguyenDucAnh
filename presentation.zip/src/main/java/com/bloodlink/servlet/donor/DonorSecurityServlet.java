package com.bloodlink.servlet.donor;

import com.bloodlink.model.User;
import com.bloodlink.service.AuthService;
import com.bloodlink.util.PasswordUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/donor/security")
public class DonorSecurityServlet extends HttpServlet {
    private AuthService authService;

    @Override
    public void init() throws ServletException {
        super.init();
        authService = new AuthService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        request.setAttribute("authUser", user);
        request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        String action = request.getParameter("action");
        
        if ("changePassword".equals(action)) {
            handleChangePassword(request, response, user);
        } else {
            request.setAttribute("error", "Hành động không hợp lệ!");
            request.setAttribute("authUser", user);
            request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
        }
    }

    private void handleChangePassword(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        String currentPassword = request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        if (currentPassword == null || newPassword == null || confirmPassword == null ||
            currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            request.setAttribute("error", "Vui lòng điền đầy đủ thông tin!");
            request.setAttribute("authUser", user);
            request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            request.setAttribute("error", "Mật khẩu xác nhận không khớp!");
            request.setAttribute("authUser", user);
            request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
            return;
        }

        if (newPassword.length() < 6) {
            request.setAttribute("error", "Mật khẩu phải có ít nhất 6 ký tự!");
            request.setAttribute("authUser", user);
            request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
            return;
        }

        try {
            // Verify current password
            User currentUser = authService.getUserById(user.getUserId());
            if (!PasswordUtil.checkPassword(currentPassword, currentUser.getPasswordHash())) {
                request.setAttribute("error", "Mật khẩu hiện tại không đúng!");
                request.setAttribute("authUser", user);
                request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
                return;
            }

            // Update password
            String newPasswordHash = PasswordUtil.hashPassword(newPassword);
            com.bloodlink.dao.UserDAO userDAO = new com.bloodlink.dao.UserDAO();
            boolean updated = userDAO.updatePassword(user.getUserId(), newPasswordHash);

            if (updated) {
                request.setAttribute("success", "Đổi mật khẩu thành công!");
            } else {
                request.setAttribute("error", "Không thể đổi mật khẩu!");
            }

            // Refresh user in session
            user = authService.getUserById(user.getUserId());
            request.setAttribute("authUser", user);
            request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            request.setAttribute("authUser", user);
            request.getRequestDispatcher("/donor/security.jsp").forward(request, response);
        }
    }
}

