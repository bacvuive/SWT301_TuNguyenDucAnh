package com.bloodlink.servlet.donor;

import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.Donor;
import com.bloodlink.model.DonationRecord;
import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@WebServlet("/donor/certificate")
public class DonorCertificateServlet extends HttpServlet {
    private DonorService donorService;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        donorService = new DonorService();
        hospitalDAO = new HospitalDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            var donations = donorService.getDonationHistory(donor.getDonorId());
            
            // Filter only completed/confirmed donations (both are considered successful)
            List<DonationRecord> completedDonations = donations.stream()
                    .filter(d -> "COMPLETED".equals(d.getStatus()) || "CONFIRMED".equals(d.getStatus()))
                    .collect(Collectors.toList());

            // Enrich with certificate data
            List<Map<String, Object>> certificates = new ArrayList<>();
            for (DonationRecord donation : completedDonations) {
                Map<String, Object> cert = new HashMap<>();
                cert.put("recordId", donation.getRecordId());
                
                // Convert LocalDate to Date for JSP fmt:formatDate
                if (donation.getDonationDate() != null) {
                    LocalDate localDate = donation.getDonationDate();
                    Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
                    cert.put("donationDate", date);
                } else {
                    cert.put("donationDate", null);
                }
                
                cert.put("bloodGroup", donation.getMeasuredBloodGroup());
                cert.put("quantityMl", donation.getQuantityMl());
                cert.put("status", donation.getStatus());
                cert.put("certificateUrl", donation.getCertificateUrl());
                cert.put("donorName", donor.getFullName());
                
                var hospital = hospitalDAO.findById(donation.getHospitalId());
                cert.put("hospitalName", hospital != null ? hospital.getName() : "Không xác định");
                
                certificates.add(cert);
            }

            request.setAttribute("certificates", certificates);
            request.setAttribute("donor", donor);

            request.getRequestDispatcher("/donor/certificate.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            request.getRequestDispatcher("/donor/certificate.jsp").forward(request, response);
        }
    }
}

