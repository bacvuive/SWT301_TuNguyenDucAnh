package com.bloodlink.servlet.donor;

import com.bloodlink.dao.DonorProfileDAO;
import com.bloodlink.model.Donor;
import com.bloodlink.model.DonorProfile;
import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/donor/eligibility")
public class DonorEligibilityServlet extends HttpServlet {
    private DonorService donorService;
    private DonorProfileDAO donorProfileDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        donorService = new DonorService();
        donorProfileDAO = new DonorProfileDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            DonorProfile profile = donorProfileDAO.findByDonorId(donor.getDonorId());
            
            // Calculate age if DOB available
            Integer age = null;
            if (donor.getDob() != null) {
                age = (int) ChronoUnit.YEARS.between(donor.getDob(), LocalDate.now());
            }

            request.setAttribute("donor", donor);
            request.setAttribute("profile", profile);
            request.setAttribute("age", age);

            request.getRequestDispatcher("/donor/eligibility.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            request.getRequestDispatcher("/donor/eligibility.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Get form data
            String ageStr = request.getParameter("age");
            String weightStr = request.getParameter("weight");
            String hemoglobinStr = request.getParameter("hemoglobin");
            String daysSinceStr = request.getParameter("daysSinceLastDonation");
            String[] conditions = request.getParameterValues("conditions");

            int age = ageStr != null ? Integer.parseInt(ageStr) : 0;
            double weight = weightStr != null ? Double.parseDouble(weightStr) : 0;
            double hemoglobin = hemoglobinStr != null && !hemoglobinStr.isEmpty() 
                    ? Double.parseDouble(hemoglobinStr) : 0;
            int daysSince = daysSinceStr != null && !daysSinceStr.isEmpty() 
                    ? Integer.parseInt(daysSinceStr) : 999;

            // Check eligibility
            List<String> failures = new ArrayList<>();
            List<String> recommendations = new ArrayList<>();
            boolean isEligible = true;

            // Age check
            if (age < 18 || age > 65) {
                failures.add("Tuổi không đủ điều kiện (18-65 tuổi)");
                isEligible = false;
            }

            // Weight check
            if (weight < 45) {
                failures.add("Cân nặng dưới 45kg");
                isEligible = false;
            }

            // Hemoglobin check
            String gender = donor.getGender();
            if (hemoglobin > 0) {
                if ("male".equals(gender) && hemoglobin < 13) {
                    failures.add("Hemoglobin thấp (Nam cần ≥13g/dL)");
                    isEligible = false;
                    recommendations.add("Bổ sung sắt và thực phẩm giàu sắt");
                } else if (("female".equals(gender) || gender == null) && hemoglobin < 12.5) {
                    failures.add("Hemoglobin thấp (Nữ cần ≥12.5g/dL)");
                    isEligible = false;
                    recommendations.add("Bổ sung sắt và thực phẩm giàu sắt");
                }
            }

            // Days since last donation
            if (daysSince < 56) {
                failures.add("Chưa đủ 56 ngày kể từ lần hiến máu cuối");
                recommendations.add("Vui lòng đợi thêm " + (56 - daysSince) + " ngày nữa");
                isEligible = false;
            }

            // Conditions check
            if (conditions != null) {
                for (String condition : conditions) {
                    switch (condition) {
                        case "pregnant":
                            failures.add("Đang mang thai hoặc cho con bú");
                            isEligible = false;
                            break;
                        case "sick":
                            failures.add("Đang ốm, sốt hoặc nhiễm trùng");
                            isEligible = false;
                            recommendations.add("Đợi đến khi hoàn toàn khỏe mạnh");
                            break;
                        case "medication":
                            failures.add("Đang dùng thuốc");
                            isEligible = false;
                            recommendations.add("Tham khảo ý kiến bác sĩ");
                            break;
                        case "tattoo":
                            failures.add("Xăm mình trong 12 tháng qua");
                            isEligible = false;
                            break;
                        case "travel":
                            recommendations.add("Cần khám sàng lọc kỹ hơn do đi du lịch vùng dịch");
                            break;
                    }
                }
            }

            // Create result object
            Map<String, Object> result = new HashMap<>();
            if (isEligible && failures.isEmpty()) {
                result.put("status", "eligible");
                result.put("message", "Bạn đủ điều kiện để hiến máu! Cảm ơn bạn đã quan tâm.");
            } else {
                result.put("status", failures.isEmpty() ? "partial" : "not-eligible");
                result.put("message", failures.isEmpty() 
                        ? "Bạn có thể hiến máu nhưng cần lưu ý một số điểm"
                        : "Hiện tại bạn chưa đủ điều kiện để hiến máu");
            }
            result.put("failures", failures);
            result.put("recommendations", recommendations);

            DonorProfile profile = donorProfileDAO.findByDonorId(donor.getDonorId());
            
            request.setAttribute("eligibilityResult", result);
            request.setAttribute("donor", donor);
            request.setAttribute("profile", profile);
            request.setAttribute("age", age);
            request.setAttribute("weight", weight);
            request.setAttribute("hemoglobin", hemoglobin > 0 ? hemoglobin : null);
            request.setAttribute("daysSinceLastDonation", daysSince < 999 ? daysSince : null);

            request.getRequestDispatcher("/donor/eligibility.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống!");
            request.getRequestDispatcher("/donor/eligibility.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Dữ liệu không hợp lệ!");
            request.getRequestDispatcher("/donor/eligibility.jsp").forward(request, response);
        }
    }
}

