package com.bloodlink.servlet.donor;

import com.bloodlink.model.Donor;
import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import com.bloodlink.service.NotificationService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/donor/dashboard")
public class DonorDashboardServlet extends HttpServlet {
    private DonorService donorService;
    private NotificationService notificationService;

    @Override
    public void init() throws ServletException {
        super.init();
        donorService = new DonorService();
        notificationService = new NotificationService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            int donationCount = donorService.getDonationCount(donor.getDonorId());
            var donations = donorService.getDonationHistory(donor.getDonorId());
            var appointments = donorService.getAppointments(donor.getDonorId());
            var upcomingAppointments = donorService.getUpcomingAppointments(donor.getDonorId());
            var notificationsRaw = notificationService.getUnreadNotifications(user.getUserId());
            
            // Enrich notifications với Timestamp cho JSP
            List<Map<String, Object>> notifications = new ArrayList<>();
            if (notificationsRaw != null) {
                for (var notif : notificationsRaw) {
                    if (notif != null) {
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("notificationId", notif.getNotificationId());
                        enriched.put("userId", notif.getUserId());
                        enriched.put("type", notif.getType());
                        enriched.put("subject", notif.getSubject());
                        enriched.put("message", notif.getMessage());
                        enriched.put("link", notif.getLink());
                        enriched.put("isRead", notif.getIsRead());
                        if (notif.getCreatedAt() != null) {
                            enriched.put("createdAt", Timestamp.valueOf(notif.getCreatedAt()));
                        } else {
                            enriched.put("createdAt", null);
                        }
                        notifications.add(enriched);
                    }
                }
            }

            // Calculate statistics
            int totalQuantity = donations.stream()
                    .mapToInt(d -> d.getQuantityMl() != null ? d.getQuantityMl() : 0)
                    .sum();
            
            int peopleHelped = (int) donations.stream()
                    .filter(d -> "CONFIRMED".equals(d.getStatus()))
                    .count();
            
            // Get next appointment date
            String nextAppointmentDate = null;
            if (!upcomingAppointments.isEmpty()) {
                var nextAppt = upcomingAppointments.get(0);
                if (nextAppt.getScheduledAt() != null) {
                    nextAppointmentDate = nextAppt.getScheduledAt()
                            .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM"));
                }
            }

            request.setAttribute("donor", donor);
            request.setAttribute("donationCount", donationCount);
            request.setAttribute("totalQuantity", totalQuantity);
            request.setAttribute("peopleHelped", peopleHelped);
            request.setAttribute("nextAppointmentDate", nextAppointmentDate);
            request.setAttribute("donations", donations);
            request.setAttribute("appointments", appointments);
            request.setAttribute("upcomingAppointments", upcomingAppointments);
            request.setAttribute("notifications", notifications);

            request.getRequestDispatcher("/donor/dashboard.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            request.getRequestDispatcher("/donor/dashboard.jsp").forward(request, response);
        }
    }
}

