package com.bloodlink.servlet.donor;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.DonorProfileDAO;
import com.bloodlink.model.Donor;
import com.bloodlink.model.DonorProfile;
import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;

@WebServlet("/donor/profile")
public class DonorProfileServlet extends HttpServlet {
    private DonorService donorService;
    private DonorDAO donorDAO;
    private DonorProfileDAO donorProfileDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        donorService = new DonorService();
        donorDAO = new DonorDAO();
        donorProfileDAO = new DonorProfileDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            DonorProfile profile = donorProfileDAO.findByDonorId(donor.getDonorId());

            request.setAttribute("donor", donor);
            request.setAttribute("profile", profile);
            request.setAttribute("authUser", user);

            request.getRequestDispatcher("/donor/profile.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            request.getRequestDispatcher("/donor/profile.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Cập nhật thông tin donor
            String fullName = request.getParameter("fullName");
            String dobStr = request.getParameter("dob");
            String gender = request.getParameter("gender");
            String bloodGroup = request.getParameter("bloodGroup");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");

            donor.setFullName(fullName);
            donor.setGender(gender);
            donor.setBloodGroup(bloodGroup);
            donor.setPhone(phone);
            donor.setAddress(address);
            
            if (dobStr != null && !dobStr.isEmpty()) {
                donor.setDob(LocalDate.parse(dobStr));
            }

            boolean updated = donorDAO.update(donor);
            if (!updated) {
                request.setAttribute("error", "Không thể cập nhật thông tin!");
            }

            // Cập nhật profile sức khỏe
            String heightStr = request.getParameter("heightCm");
            String weightStr = request.getParameter("weightKg");
            String hbStr = request.getParameter("lastHbGdl");
            String chronicCond = request.getParameter("chronicCond");
            String allergies = request.getParameter("allergies");
            String lastScreenStr = request.getParameter("lastScreen");

            DonorProfile profile = donorProfileDAO.findByDonorId(donor.getDonorId());
            if (profile == null) {
                profile = new DonorProfile();
                profile.setDonorId(donor.getDonorId());
            }

            if (heightStr != null && !heightStr.isEmpty()) {
                profile.setHeightCm(new BigDecimal(heightStr));
            }
            if (weightStr != null && !weightStr.isEmpty()) {
                profile.setWeightKg(new BigDecimal(weightStr));
            }
            if (hbStr != null && !hbStr.isEmpty()) {
                profile.setLastHbGdl(new BigDecimal(hbStr));
            }
            profile.setChronicCond(chronicCond);
            profile.setAllergies(allergies);
            if (lastScreenStr != null && !lastScreenStr.isEmpty()) {
                profile.setLastScreen(LocalDate.parse(lastScreenStr));
            }

            if (profile.getDonorId() != null && donorProfileDAO.findByDonorId(donor.getDonorId()) != null) {
                donorProfileDAO.update(profile);
            } else {
                donorProfileDAO.create(profile);
            }

            // Cập nhật session - reload từ service
            Donor updatedDonor = donorService.getDonorByUserId(user.getUserId());
            if (updatedDonor != null) {
                session.setAttribute("donor", updatedDonor);
            }

            request.setAttribute("success", "Cập nhật thông tin thành công!");
            request.setAttribute("donor", donor);
            request.setAttribute("profile", profile);
            request.setAttribute("authUser", user);

            request.getRequestDispatcher("/donor/profile.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            request.getRequestDispatcher("/donor/profile.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Dữ liệu không hợp lệ!");
            request.getRequestDispatcher("/donor/profile.jsp").forward(request, response);
        }
    }
}

