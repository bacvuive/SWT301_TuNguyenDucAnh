package com.bloodlink.servlet.donor;

import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.Appointment;
import com.bloodlink.model.Donor;
import com.bloodlink.model.DonationRecord;
import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/donor/history")
public class DonorHistoryServlet extends HttpServlet {
    private DonorService donorService;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            donorService = new DonorService();
            hospitalDAO = new HospitalDAO();
            System.out.println("[DonorHistoryServlet] Initialized successfully");
        } catch (Exception e) {
            System.err.println("[DonorHistoryServlet] Error in init: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("Failed to initialize DonorHistoryServlet", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("[DonorHistoryServlet] doGet called for: " + request.getRequestURI());
        response.setContentType("text/html;charset=UTF-8");
        // Prevent caching to ensure fresh data
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("authUser") == null) {
                System.out.println("[DonorHistoryServlet] No session or authUser, redirecting to login");
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }

            User user = (User) session.getAttribute("authUser");
            System.out.println("[DonorHistoryServlet] User role: " + user.getRoleCode());
            
            if (!"donor".equals(user.getRoleCode())) {
                System.out.println("[DonorHistoryServlet] User is not donor, redirecting");
                response.sendRedirect(request.getContextPath() + "/");
                return;
            }

            Donor donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                System.out.println("[DonorHistoryServlet] Donor not found for userId: " + user.getUserId());
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không tìm thấy thông tin người hiến máu");
                return;
            }

            System.out.println("[DonorHistoryServlet] Fetching donations and appointments...");

            var donations = donorService.getDonationHistory(donor.getDonorId());
            int donationCount = donations != null ? donations.size() : 0;
            
            // Calculate total quantity
            int totalQuantity = 0;
            if (donations != null) {
                totalQuantity = donations.stream()
                        .mapToInt(d -> d.getQuantityMl() != null ? d.getQuantityMl() : 0)
                        .sum();
            }

            // Get last donation date
            String lastDonationDate = null;
            if (donations != null && !donations.isEmpty()) {
                var lastDonation = donations.get(0);
                if (lastDonation.getDonationDate() != null) {
                    lastDonationDate = lastDonation.getDonationDate()
                            .format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                }
            }

            // Enrich donations with hospital names
            List<Map<String, Object>> enrichedDonations = new ArrayList<>();
            if (donations != null) {
                for (DonationRecord donation : donations) {
                    if (donation != null) {
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("recordId", donation.getRecordId());
                        enriched.put("donorId", donation.getDonorId());
                        enriched.put("hospitalId", donation.getHospitalId());
                        
                        // Convert LocalDate to Date for JSP fmt:formatDate
                        if (donation.getDonationDate() != null) {
                            LocalDate localDate = donation.getDonationDate();
                            Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
                            enriched.put("donationDate", date);
                        } else {
                            enriched.put("donationDate", null);
                        }
                        
                        enriched.put("measuredBloodGroup", donation.getMeasuredBloodGroup());
                        enriched.put("quantityMl", donation.getQuantityMl());
                        enriched.put("status", donation.getStatus());
                        enriched.put("certificateUrl", donation.getCertificateUrl());
                        enriched.put("createdAt", donation.getCreatedAt());
                        
                        var hospital = hospitalDAO.findById(donation.getHospitalId());
                        enriched.put("hospitalName", hospital != null ? hospital.getName() : "Không xác định");
                        
                        enrichedDonations.add(enriched);
                    }
                }
            }

            // Get appointments (registration forms)
            System.out.println("[DonorHistoryServlet] Fetching appointments for donorId: " + donor.getDonorId());
            var appointments = donorService.getAppointments(donor.getDonorId());
            System.out.println("[DonorHistoryServlet] Raw appointments from DB: " + (appointments != null ? appointments.size() : 0));
            
            List<Map<String, Object>> enrichedAppointments = new ArrayList<>();
            if (appointments != null && !appointments.isEmpty()) {
                System.out.println("[DonorHistoryServlet] Processing " + appointments.size() + " appointments...");
                for (Appointment appointment : appointments) {
                    if (appointment != null) {
                        System.out.println("[DonorHistoryServlet] Processing appointment ID: " + appointment.getAppointmentId() + 
                            ", Status: " + appointment.getStatus() + 
                            ", HospitalId: " + appointment.getHospitalId());
                        
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("appointmentId", appointment.getAppointmentId());
                        enriched.put("donorId", appointment.getDonorId());
                        enriched.put("hospitalId", appointment.getHospitalId());
                        
                        // Convert LocalDateTime to Date for JSP fmt:formatDate
                        if (appointment.getScheduledAt() != null) {
                            enriched.put("scheduledAt", Timestamp.valueOf(appointment.getScheduledAt()));
                        } else {
                            enriched.put("scheduledAt", null);
                        }
                        
                        enriched.put("note", appointment.getNote());
                        enriched.put("status", appointment.getStatus());
                        
                        // Convert LocalDateTime to Date for JSP fmt:formatDate
                        if (appointment.getCreatedAt() != null) {
                            enriched.put("createdAt", Timestamp.valueOf(appointment.getCreatedAt()));
                        } else {
                            enriched.put("createdAt", null);
                        }
                        
                        if (appointment.getUpdatedAt() != null) {
                            enriched.put("updatedAt", Timestamp.valueOf(appointment.getUpdatedAt()));
                        } else {
                            enriched.put("updatedAt", null);
                        }
                        
                        var hospital = hospitalDAO.findById(appointment.getHospitalId());
                        String hospitalName = hospital != null ? hospital.getName() : "Không xác định";
                        enriched.put("hospitalName", hospitalName);
                        
                        System.out.println("[DonorHistoryServlet] Enriched appointment: " + appointment.getAppointmentId() + 
                            " -> Hospital: " + hospitalName);
                        
                        enrichedAppointments.add(enriched);
                    } else {
                        System.err.println("[DonorHistoryServlet] Found null appointment in list");
                    }
                }
            } else {
                System.out.println("[DonorHistoryServlet] No appointments found or appointments list is null");
            }

            System.out.println("[DonorHistoryServlet] Donations count: " + donationCount);
            System.out.println("[DonorHistoryServlet] Appointments count: " + (appointments != null ? appointments.size() : 0));
            System.out.println("[DonorHistoryServlet] Enriched appointments count: " + enrichedAppointments.size());
            
            // Debug: Log appointment details
            for (Map<String, Object> apt : enrichedAppointments) {
                System.out.println("[DonorHistoryServlet] Appointment: " + apt.get("appointmentId") + 
                    ", Hospital: " + apt.get("hospitalName") + 
                    ", Status: " + apt.get("status") +
                    ", ScheduledAt: " + apt.get("scheduledAt") +
                    ", CreatedAt: " + apt.get("createdAt"));
            }

            request.setAttribute("donations", enrichedDonations);
            request.setAttribute("appointments", enrichedAppointments);
            request.setAttribute("donationCount", donationCount);
            request.setAttribute("totalQuantity", totalQuantity);
            request.setAttribute("lastDonationDate", lastDonationDate);
            request.setAttribute("donor", donor);

            System.out.println("[DonorHistoryServlet] Forwarding to JSP...");
            try {
                if (!response.isCommitted()) {
                    request.getRequestDispatcher("/donor/history.jsp").forward(request, response);
                    System.out.println("[DonorHistoryServlet] JSP forwarded successfully");
                } else {
                    System.err.println("[DonorHistoryServlet] Response already committed before forward");
                }
            } catch (Exception e) {
                System.err.println("[DonorHistoryServlet] Error forwarding to JSP: " + e.getMessage());
                e.printStackTrace();
                if (!response.isCommitted()) {
                    request.setAttribute("error", "Lỗi khi hiển thị trang!");
                    try {
                        request.getRequestDispatcher("/donor/history.jsp").forward(request, response);
                    } catch (Exception ex) {
                        System.err.println("[DonorHistoryServlet] Second forward also failed: " + ex.getMessage());
                        if (!response.isCommitted()) {
                            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                        }
                    }
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("[DonorHistoryServlet] SQLException: " + e.getMessage());
            request.setAttribute("error", "Lỗi khi tải dữ liệu! Vui lòng thử lại sau.");
            request.setAttribute("donations", new ArrayList<>());
            request.setAttribute("appointments", new ArrayList<>());
            request.setAttribute("donationCount", 0);
            request.setAttribute("totalQuantity", 0);
            request.setAttribute("lastDonationDate", null);
            
            // Try to get donor again for display
            try {
                User user = (User) request.getSession(false).getAttribute("authUser");
                if (user != null) {
                    Donor donor = donorService.getDonorByUserId(user.getUserId());
                    if (donor != null) {
                        request.setAttribute("donor", donor);
                    }
                }
            } catch (Exception ex) {
                // Ignore, just continue
            }
            
            if (!response.isCommitted()) {
                try {
                    request.getRequestDispatcher("/donor/history.jsp").forward(request, response);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    System.err.println("[DonorHistoryServlet] Error forwarding to JSP: " + ex.getMessage());
                    if (!response.isCommitted()) {
                        try {
                            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi hiển thị trang: " + ex.getMessage());
                        } catch (IOException ioEx) {
                            System.err.println("[DonorHistoryServlet] Cannot send error, response already committed");
                        }
                    }
                }
            } else {
                System.err.println("[DonorHistoryServlet] Response already committed, cannot forward");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("[DonorHistoryServlet] Exception: " + e.getMessage());
            
            if (!response.isCommitted()) {
                request.setAttribute("error", "Lỗi không xác định! Vui lòng thử lại sau. Chi tiết: " + e.getMessage());
                request.setAttribute("donations", new ArrayList<>());
                request.setAttribute("appointments", new ArrayList<>());
                request.setAttribute("donationCount", 0);
                request.setAttribute("totalQuantity", 0);
                request.setAttribute("lastDonationDate", null);
                
                // Try to get donor again for display
                try {
                    User user = (User) request.getSession(false).getAttribute("authUser");
                    if (user != null) {
                        Donor donor = donorService.getDonorByUserId(user.getUserId());
                        if (donor != null) {
                            request.setAttribute("donor", donor);
                        }
                    }
                } catch (Exception ex) {
                    // Ignore, just continue
                }
                
                try {
                    request.getRequestDispatcher("/donor/history.jsp").forward(request, response);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    System.err.println("[DonorHistoryServlet] Error forwarding to JSP: " + ex.getMessage());
                    if (!response.isCommitted()) {
                        try {
                            response.setContentType("text/html;charset=UTF-8");
                            response.getWriter().println("<html><body><h1>Lỗi hiển thị trang</h1><p>" + ex.getMessage() + "</p></body></html>");
                        } catch (IOException ioEx) {
                            System.err.println("[DonorHistoryServlet] Cannot write error response, already committed");
                        }
                    }
                }
            } else {
                System.err.println("[DonorHistoryServlet] Response already committed, cannot handle error");
            }
        }
    }
}

