package com.bloodlink.servlet.hospital;

import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.service.BloodRequestService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet to handle hospital blood requests listing and management.
 * Displays all blood requests created by the logged-in hospital.
 */
@WebServlet(value = {"/hospital/requests", "/hospital/requests/"})
public class HospitalRequestsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private BloodRequestService bloodRequestService;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        bloodRequestService = new BloodRequestService();
        hospitalDAO = new HospitalDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("[HospitalRequestsServlet] GET request received: " + request.getRequestURI());
        
        // Check authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get hospital info
            Hospital hospital = (Hospital) session.getAttribute("hospital");
            if (hospital == null) {
                hospital = hospitalDAO.findByUserId(user.getUserId());
                if (hospital != null) {
                    session.setAttribute("hospital", hospital);
                }
            }

            if (hospital == null) {
                request.setAttribute("error", "Không tìm thấy thông tin bệnh viện!");
                request.getRequestDispatcher("/hospital/requests.jsp").forward(request, response);
                return;
            }

            // Get success/error messages from session (if any)
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            
            if (success != null) {
                request.setAttribute("success", success);
                session.removeAttribute("success"); // Remove after displaying
            }
            if (error != null) {
                request.setAttribute("error", error);
                session.removeAttribute("error"); // Remove after displaying
            }

            // Load outgoing requests (yêu cầu đã tạo)
            var outgoingRequests = bloodRequestService.getRequestsCreatedByHospital(hospital.getHospitalId());
            
            // Load incoming requests (yêu cầu đến)
            var incomingRequests = bloodRequestService.getIncomingRequests(hospital.getHospitalId());
            
            // Enrich requests with hospital information
            List<Map<String, Object>> enrichedOutgoing = enrichRequestsWithHospitalInfo(outgoingRequests);
            List<Map<String, Object>> enrichedIncoming = enrichRequestsWithHospitalInfo(incomingRequests);
            
            request.setAttribute("outgoingRequests", enrichedOutgoing);
            request.setAttribute("incomingRequests", enrichedIncoming);
            request.setAttribute("hospital", hospital);
            
            System.out.println("[HospitalRequestsServlet] Loaded " + (outgoingRequests != null ? outgoingRequests.size() : 0) + " outgoing requests");
            System.out.println("[HospitalRequestsServlet] Loaded " + (incomingRequests != null ? incomingRequests.size() : 0) + " incoming requests");

            // Forward to JSP
            System.out.println("[HospitalRequestsServlet] Forwarding to JSP: /hospital/requests.jsp");
            try {
                RequestDispatcher dispatcher = request.getRequestDispatcher("/hospital/requests.jsp");
                if (dispatcher == null) {
                    System.err.println("[HospitalRequestsServlet] ERROR: RequestDispatcher is null!");
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "JSP page not found");
                    return;
                }
                dispatcher.forward(request, response);
                System.out.println("[HospitalRequestsServlet] Successfully forwarded to JSP");
            } catch (Exception ex) {
                System.err.println("[HospitalRequestsServlet] Error forwarding: " + ex.getMessage());
                ex.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading page: " + ex.getMessage());
            }
            
        } catch (SQLException e) {
            System.err.println("[HospitalRequestsServlet] SQL Error: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống khi tải danh sách yêu cầu máu!");
            try {
                request.getRequestDispatcher("/hospital/requests.jsp").forward(request, response);
            } catch (ServletException | IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    /**
     * Enrich requests with hospital information for display
     */
    private List<Map<String, Object>> enrichRequestsWithHospitalInfo(List<BloodRequest> requests) throws SQLException {
        List<Map<String, Object>> enriched = new ArrayList<>();
        if (requests != null) {
            for (BloodRequest req : requests) {
                Map<String, Object> map = new HashMap<>();
                map.put("requestId", req.getRequestId());
                map.put("fromHospitalId", req.getFromHospitalId());
                map.put("toHospitalId", req.getToHospitalId());
                map.put("bloodGroup", req.getBloodGroup());
                map.put("component", req.getComponent());
                map.put("quantity", req.getQuantity());
                map.put("status", req.getStatus());
                
                if (req.getCreatedAt() != null) {
                    map.put("createdAt", Timestamp.valueOf(req.getCreatedAt()));
                }
                if (req.getUpdatedAt() != null) {
                    map.put("updatedAt", Timestamp.valueOf(req.getUpdatedAt()));
                }
                
                // Get from hospital info
                if (req.getFromHospitalId() != null) {
                    try {
                        Hospital fromHospital = hospitalDAO.findById(req.getFromHospitalId());
                        if (fromHospital != null) {
                            map.put("fromHospitalName", fromHospital.getName());
                            map.put("fromHospitalRegion", fromHospital.getRegion());
                        } else {
                            map.put("fromHospitalName", "Bệnh viện không tồn tại");
                        }
                    } catch (SQLException e) {
                        map.put("fromHospitalName", "Lỗi khi tải thông tin");
                    }
                }
                
                // Get to hospital info
                if (req.getToHospitalId() != null) {
                    try {
                        Hospital toHospital = hospitalDAO.findById(req.getToHospitalId());
                        if (toHospital != null) {
                            map.put("toHospitalName", toHospital.getName());
                            map.put("toHospitalRegion", toHospital.getRegion());
                        } else {
                            map.put("toHospitalName", "Bệnh viện không tồn tại");
                        }
                    } catch (SQLException e) {
                        map.put("toHospitalName", "Lỗi khi tải thông tin");
                    }
                } else {
                    map.put("toHospitalName", "Tất cả bệnh viện");
                }
                
                enriched.add(map);
            }
        }
        return enriched;
    }
}

