package com.bloodlink.servlet.hospital;

import com.bloodlink.model.Hospital;
import com.bloodlink.model.HospitalVerificationDocument;
import com.bloodlink.model.HospitalVerificationRequest;
import com.bloodlink.model.User;
import com.bloodlink.service.HospitalService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/hospital/verification")
public class HospitalVerificationServlet extends HttpServlet {

    private HospitalService hospitalService;

    @Override
    public void init() throws ServletException {
        super.init();
        hospitalService = new HospitalService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            if (success != null) {
                request.setAttribute("success", success);
                session.removeAttribute("success");
            }
            if (error != null) {
                request.setAttribute("error", error);
                session.removeAttribute("error");
            }

            HospitalVerificationRequest latest = hospitalService.getLatestVerificationRequest(hospital.getHospitalId());
            List<HospitalVerificationRequest> history = hospitalService.getVerificationHistory(hospital.getHospitalId());

            Map<String, Object> latestView = null;
            if (latest != null) {
                latestView = toView(latest);
            }

            List<Map<String, Object>> historyView = new ArrayList<>();
            if (history != null) {
                for (HospitalVerificationRequest item : history) {
                    historyView.add(toView(item));
                }
            }

            request.setAttribute("hospital", hospital);
            request.setAttribute("latestVerification", latest);
            request.setAttribute("latestVerificationView", latestView);
            request.setAttribute("hasPendingVerification", latest != null && "PENDING".equals(latest.getStatus()));
            request.setAttribute("verificationHistory", history);
            request.setAttribute("verificationHistoryView", historyView);
            request.getRequestDispatcher("/hospital/verification.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            request.getRequestDispatcher("/hospital/verification.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        String registrationNumber = request.getParameter("registrationNumber");
        String contactPerson = request.getParameter("contactPerson");
        String contactPhone = request.getParameter("contactPhone");
        String extraData = request.getParameter("extraData");

        if (registrationNumber == null || registrationNumber.trim().isEmpty() ||
            contactPerson == null || contactPerson.trim().isEmpty() ||
            contactPhone == null || contactPhone.trim().isEmpty()) {
            session.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc.");
            response.sendRedirect(request.getContextPath() + "/hospital/verification");
            return;
        }

        try {
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            List<HospitalVerificationDocument> documents = new ArrayList<>();
            // Hiện tại chưa hỗ trợ upload file trong form. Có thể mở rộng sau bằng cách thêm multipart.

            hospitalService.submitVerificationRequest(
                hospital.getHospitalId(),
                registrationNumber,
                contactPerson,
                contactPhone,
                extraData,
                documents
            );

            session.setAttribute("success", "Đã gửi yêu cầu xác minh. Vui lòng chờ quản trị viên phê duyệt.");
        } catch (IllegalStateException ex) {
            session.setAttribute("error", ex.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            session.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
        }

        response.sendRedirect(request.getContextPath() + "/hospital/verification");
    }

    private Map<String, Object> toView(HospitalVerificationRequest request) {
        Map<String, Object> map = new HashMap<>();
        map.put("requestId", request.getRequestId());
        map.put("status", request.getStatus());
        map.put("registrationNumber", request.getRegistrationNumber());
        map.put("contactPerson", request.getContactPerson());
        map.put("contactPhone", request.getContactPhone());
        map.put("rejectionReason", request.getRejectionReason());
        map.put("extraData", request.getExtraData());
        if (request.getSubmittedAt() != null) {
            map.put("submittedAt", Timestamp.valueOf(request.getSubmittedAt()));
        }
        if (request.getProcessedAt() != null) {
            map.put("processedAt", Timestamp.valueOf(request.getProcessedAt()));
        }
        map.put("processedBy", request.getProcessedBy());
        return map;
    }
}
