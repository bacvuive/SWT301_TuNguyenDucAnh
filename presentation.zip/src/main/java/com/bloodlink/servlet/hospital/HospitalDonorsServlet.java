package com.bloodlink.servlet.hospital;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.UserDAO;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * Servlet to handle hospital donors management.
 */
@WebServlet(value = {"/hospital/donors", "/hospital/donors/"})
public class HospitalDonorsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DonorDAO donorDAO;
    private HospitalDAO hospitalDAO;
    private UserDAO userDAO;
    private DonorService donorService;

    @Override
    public void init() throws ServletException {
        super.init();
        donorDAO = new DonorDAO();
        hospitalDAO = new HospitalDAO();
        userDAO = new UserDAO();
        donorService = new DonorService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("[HospitalDonorsServlet] GET request received: " + request.getRequestURI());
        
        // Check authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get hospital info
            Hospital hospital = (Hospital) session.getAttribute("hospital");
            if (hospital == null) {
                hospital = hospitalDAO.findByUserId(user.getUserId());
                if (hospital != null) {
                    session.setAttribute("hospital", hospital);
                }
            }

            if (hospital == null) {
                request.setAttribute("error", "Không tìm thấy thông tin bệnh viện!");
                request.getRequestDispatcher("/hospital/donors.jsp").forward(request, response);
                return;
            }

            // Get success/error messages from session (if any)
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            
            if (success != null) {
                request.setAttribute("success", success);
                session.removeAttribute("success");
            }
            if (error != null) {
                request.setAttribute("error", error);
                session.removeAttribute("error");
            }

            // Get search and filter parameters
            String searchQuery = request.getParameter("search");
            String bloodGroupFilter = request.getParameter("bloodGroup");
            String pageStr = request.getParameter("page");
            String limitStr = request.getParameter("limit");
            
            int page = (pageStr != null && !pageStr.isEmpty()) ? Integer.parseInt(pageStr) : 1;
            int limit = (limitStr != null && !limitStr.isEmpty()) ? Integer.parseInt(limitStr) : 20;
            int offset = (page - 1) * limit;

            // Use SearchService for advanced search
            com.bloodlink.service.SearchService searchService = new com.bloodlink.service.SearchService();
            List<Map<String, Object>> enrichedDonors = searchService.searchDonors(
                searchQuery, bloodGroupFilter, null, limit, offset
            );
            
            // Get donation count for each donor
            for (Map<String, Object> donor : enrichedDonors) {
                try {
                    Integer donorId = (Integer) donor.get("donorId");
                    int donationCount = donorService.getDonationCount(donorId);
                    donor.put("donationCount", donationCount);
                } catch (SQLException e) {
                    donor.put("donationCount", 0);
                }
            }
            
            // Get total count for pagination
            int totalCount = searchService.countDonors(searchQuery, bloodGroupFilter, null);
            int totalPages = (int) Math.ceil((double) totalCount / limit);
            
            request.setAttribute("donors", enrichedDonors);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("totalCount", totalCount);
            request.setAttribute("searchQuery", searchQuery != null ? searchQuery : "");
            request.setAttribute("selectedBloodGroup", bloodGroupFilter != null ? bloodGroupFilter : "");
            request.setAttribute("hospital", hospital);

            // Forward to JSP
            System.out.println("[HospitalDonorsServlet] Forwarding to JSP: /hospital/donors.jsp");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/hospital/donors.jsp");
            if (dispatcher == null) {
                System.err.println("[HospitalDonorsServlet] ERROR: RequestDispatcher is null!");
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "JSP page not found");
                return;
            }
            dispatcher.forward(request, response);
            System.out.println("[HospitalDonorsServlet] Successfully forwarded to JSP");
            
        } catch (SQLException e) {
            System.err.println("[HospitalDonorsServlet] SQL Error: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống khi tải danh sách người hiến máu!");
            try {
                request.getRequestDispatcher("/hospital/donors.jsp").forward(request, response);
            } catch (ServletException | IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}

