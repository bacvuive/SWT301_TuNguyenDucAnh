package com.bloodlink.servlet.hospital;

import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.service.BloodRequestService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Servlet to handle hospital blood request creation.
 * GET: Display create request form
 * POST: Process and create new blood request
 */
@WebServlet("/hospital/requests/create")
public class HospitalCreateRequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private BloodRequestService bloodRequestService;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        bloodRequestService = new BloodRequestService();
        hospitalDAO = new HospitalDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("[HospitalCreateRequestServlet] GET request received: " + request.getRequestURI());
        
        // Check authentication
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("authUser");
        
        if (user == null || !"hospital".equalsIgnoreCase(user.getRoleCode())) {
            System.out.println("[HospitalCreateRequestServlet] Authentication failed or not hospital role");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        System.out.println("[HospitalCreateRequestServlet] User authenticated: " + user.getEmail() + ", Role: " + user.getRoleCode());
        
        // Get hospital info
        Hospital hospital = (Hospital) session.getAttribute("hospital");
        if (hospital == null) {
            try {
                hospital = hospitalDAO.findByUserId(user.getUserId());
                if (hospital != null) {
                    session.setAttribute("hospital", hospital);
                }
            } catch (SQLException e) {
                System.err.println("[HospitalCreateRequestServlet] Error loading hospital: " + e.getMessage());
            }
        }
        
        // Load list of hospitals for dropdown (to send to specific hospital)
        try {
            List<Hospital> hospitals = hospitalDAO.findAll();
            request.setAttribute("hospitals", hospitals);
        } catch (SQLException e) {
            System.err.println("[HospitalCreateRequestServlet] Error loading hospitals list: " + e.getMessage());
        }
        
        // Forward to create.jsp
        System.out.println("[HospitalCreateRequestServlet] Forwarding to JSP: /hospital/requests/create.jsp");
        try {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/hospital/requests/create.jsp");
            if (dispatcher == null) {
                System.err.println("[HospitalCreateRequestServlet] ERROR: RequestDispatcher is null!");
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "JSP page not found");
                return;
            }
            dispatcher.forward(request, response);
            System.out.println("[HospitalCreateRequestServlet] Successfully forwarded to JSP");
        } catch (Exception e) {
            System.err.println("[HospitalCreateRequestServlet] Error forwarding: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error loading page: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Check authentication
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("authUser");
        
        if (user == null || !"hospital".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Get hospital info
        Hospital hospital = (Hospital) session.getAttribute("hospital");
        if (hospital == null) {
            try {
                hospital = hospitalDAO.findByUserId(user.getUserId());
                if (hospital == null) {
                    request.setAttribute("error", "Không tìm thấy thông tin bệnh viện!");
                    request.getRequestDispatcher("/hospital/requests/create.jsp").forward(request, response);
                    return;
                }
                session.setAttribute("hospital", hospital);
            } catch (SQLException e) {
                System.err.println("[HospitalCreateRequestServlet] Error loading hospital: " + e.getMessage());
                request.setAttribute("error", "Lỗi khi tải thông tin bệnh viện!");
                request.getRequestDispatcher("/hospital/requests/create.jsp").forward(request, response);
                return;
            }
        }
        
        // Get form parameters
        String bloodGroup = request.getParameter("bloodGroup");
        String component = request.getParameter("component");
        String quantityStr = request.getParameter("quantity");
        String toHospitalIdStr = request.getParameter("toHospitalId");
        
        // Validate required fields
        if (bloodGroup == null || bloodGroup.trim().isEmpty() ||
            component == null || component.trim().isEmpty() ||
            quantityStr == null || quantityStr.trim().isEmpty()) {
            request.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc!");
            doGet(request, response);
            return;
        }
        
        // Parse quantity
        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
            if (quantity < 1) {
                request.setAttribute("error", "Số lượng phải lớn hơn 0!");
                doGet(request, response);
                return;
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Số lượng không hợp lệ!");
            doGet(request, response);
            return;
        }
        
        // Parse toHospitalId (can be null for broadcast)
        Integer toHospitalId = null;
        if (toHospitalIdStr != null && !toHospitalIdStr.trim().isEmpty()) {
            try {
                toHospitalId = Integer.parseInt(toHospitalIdStr);
            } catch (NumberFormatException e) {
                // Invalid hospital ID, treat as broadcast
                toHospitalId = null;
            }
        }
        
        try {
            // Create blood request with actorUserId for audit
            bloodRequestService.createRequest(
                hospital.getHospitalId(),
                toHospitalId,
                bloodGroup.trim(),
                component.trim(),
                quantity,
                user.getUserId() // actorUserId for audit
            );
            
            // Success - redirect to dashboard
            request.getSession().setAttribute("success", "Tạo yêu cầu máu thành công!");
            response.sendRedirect(request.getContextPath() + "/hospital/dashboard");
            
        } catch (IllegalArgumentException e) {
            request.setAttribute("error", e.getMessage());
            doGet(request, response);
        } catch (SQLException e) {
            System.err.println("[HospitalCreateRequestServlet] SQL Error: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống khi tạo yêu cầu máu. Vui lòng thử lại sau!");
            doGet(request, response);
        } catch (Exception e) {
            System.err.println("[HospitalCreateRequestServlet] Unexpected error: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi không xác định khi tạo yêu cầu máu!");
            doGet(request, response);
        }
    }
}

