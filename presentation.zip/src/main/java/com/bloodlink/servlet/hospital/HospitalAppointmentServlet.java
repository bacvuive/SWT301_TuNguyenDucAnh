package com.bloodlink.servlet.hospital;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.Appointment;
import com.bloodlink.model.BloodBag;
import com.bloodlink.model.Donor;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.service.HospitalService;
import com.bloodlink.service.NotificationService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet để bệnh viện xem và quản lý appointments (chấp nhận/từ chối)
 */
@WebServlet("/hospital/appointments")
public class HospitalAppointmentServlet extends HttpServlet {
    private HospitalService hospitalService;
    private DonorDAO donorDAO;
    private HospitalDAO hospitalDAO;
    private NotificationService notificationService;

    @Override
    public void init() throws ServletException {
        super.init();
        hospitalService = new HospitalService();
        donorDAO = new DonorDAO();
        hospitalDAO = new HospitalDAO();
        notificationService = new NotificationService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Lấy appointments và enrich với thông tin donor
            var appointments = hospitalService.getAppointments(hospital.getHospitalId());
            List<Map<String, Object>> enrichedAppointments = new ArrayList<>();
            
            if (appointments != null) {
                for (Appointment appt : appointments) {
                    if (appt != null) {
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("appointmentId", appt.getAppointmentId());
                        enriched.put("donorId", appt.getDonorId());
                        enriched.put("hospitalId", appt.getHospitalId());
                        enriched.put("note", appt.getNote());
                        enriched.put("status", appt.getStatus());
                        
                        // Convert LocalDateTime to Timestamp for JSP
                        if (appt.getScheduledAt() != null) {
                            enriched.put("scheduledAt", Timestamp.valueOf(appt.getScheduledAt()));
                        } else {
                            enriched.put("scheduledAt", null);
                        }
                        
                        if (appt.getCreatedAt() != null) {
                            enriched.put("createdAt", Timestamp.valueOf(appt.getCreatedAt()));
                        } else {
                            enriched.put("createdAt", null);
                        }
                        
                        if (appt.getUpdatedAt() != null) {
                            enriched.put("updatedAt", Timestamp.valueOf(appt.getUpdatedAt()));
                        } else {
                            enriched.put("updatedAt", null);
                        }
                        
                        // Lấy thông tin donor
                        try {
                            Donor donor = donorDAO.findById(appt.getDonorId());
                            if (donor != null) {
                                enriched.put("donorName", donor.getFullName());
                                enriched.put("donorBloodGroup", donor.getBloodGroup());
                                enriched.put("donorPhone", donor.getPhone());
                            } else {
                                enriched.put("donorName", "Không xác định");
                                enriched.put("donorBloodGroup", "N/A");
                                enriched.put("donorPhone", "N/A");
                            }
                        } catch (SQLException e) {
                            enriched.put("donorName", "Không xác định");
                            enriched.put("donorBloodGroup", "N/A");
                            enriched.put("donorPhone", "N/A");
                        }
                        
                        enrichedAppointments.add(enriched);
                    }
                }
            }

            request.setAttribute("hospital", hospital);
            request.setAttribute("appointments", enrichedAppointments);

            request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check if this is an AJAX request FIRST (before any redirects)
        String requestedWith = request.getHeader("X-Requested-With");
        boolean isAjax = "XMLHttpRequest".equals(requestedWith);
        
        // Set content-type early for AJAX to prevent HTML responses
        if (isAjax) {
            response.setContentType("application/json;charset=UTF-8");
            response.setCharacterEncoding("UTF-8");
        }
        
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("authUser") == null) {
                if (isAjax) {
                    sendJsonError(response, "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.", 401);
                    return;
                }
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }

            User user = (User) session.getAttribute("authUser");
            if (user == null) {
                if (isAjax) {
                    sendJsonError(response, "Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.", 401);
                    return;
                }
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }
            
            if (!"hospital".equals(user.getRoleCode())) {
                if (isAjax) {
                    sendJsonError(response, "Bạn không có quyền thực hiện hành động này.", 403);
                    return;
                }
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
        
            String action = request.getParameter("action");
            String appointmentIdStr = request.getParameter("appointmentId");

            if (action == null || appointmentIdStr == null) {
                if (isAjax) {
                    sendJsonError(response, "Thiếu thông tin!", 400);
                    return;
                }
                request.setAttribute("error", "Thiếu thông tin!");
                doGet(request, response);
                return;
            }
            Integer appointmentId = Integer.parseInt(appointmentIdStr);
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            
            if (hospital == null) {
                if (isAjax) {
                    sendJsonError(response, "Không tìm thấy thông tin bệnh viện!", 404);
                    return;
                }
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Verify appointment belongs to this hospital
            Appointment appointment = hospitalService.getAppointments(hospital.getHospitalId())
                    .stream()
                    .filter(apt -> apt.getAppointmentId().equals(appointmentId))
                    .findFirst()
                    .orElse(null);

            if (appointment == null) {
                if (isAjax) {
                    sendJsonError(response, "Lịch hẹn không tồn tại hoặc không thuộc bệnh viện của bạn!", 404);
                    return;
                }
                request.setAttribute("error", "Lịch hẹn không tồn tại hoặc không thuộc bệnh viện của bạn!");
                doGet(request, response);
                return;
            }

            boolean success = false;
            String message = "";

            if ("confirm".equals(action)) {
                // Chỉ confirm nếu status là PENDING
                if (!"PENDING".equals(appointment.getStatus())) {
                    if (isAjax) {
                        sendJsonError(response, "Chỉ có thể chấp nhận lịch hẹn ở trạng thái PENDING!", 400);
                        return;
                    }
                    request.setAttribute("error", "Chỉ có thể chấp nhận lịch hẹn ở trạng thái PENDING!");
                    doGet(request, response);
                    return;
                }
                success = hospitalService.confirmAppointment(appointmentId);
                message = success ? "Đã chấp nhận lịch hẹn thành công!" : "Không thể chấp nhận lịch hẹn!";
            } else if ("cancel".equals(action)) {
                // Cancel appointment
                if ("COMPLETED".equals(appointment.getStatus())) {
                    if (isAjax) {
                        sendJsonError(response, "Không thể hủy lịch hẹn đã hoàn thành!", 400);
                        return;
                    }
                    request.setAttribute("error", "Không thể hủy lịch hẹn đã hoàn thành!");
                    doGet(request, response);
                    return;
                }
                // Update status to CANCELLED
                appointment.setStatus("CANCELLED");
                appointment.setUpdatedAt(LocalDateTime.now());
                success = hospitalService.updateAppointment(appointment);
                
                // Gửi notification cho donor
                if (success) {
                    try {
                        Donor donor = donorDAO.findById(appointment.getDonorId());
                        // Sử dụng lại biến hospital đã có (appointment đã được verify thuộc về hospital này)
                        
                        if (donor != null && donor.getUserId() != null && hospital != null) {
                            notificationService.notifyAppointmentCancelled(
                                donor.getUserId(),
                                appointmentId,
                                hospital.getName()
                            );
                        }
                    } catch (SQLException e) {
                        // Log error nhưng không throw để không làm gián đoạn cancel appointment
                        System.err.println("Error sending cancellation notification for appointment " + appointmentId + ": " + e.getMessage());
                        e.printStackTrace();
                    }
                }
                
                message = success ? "Đã hủy lịch hẹn thành công!" : "Không thể hủy lịch hẹn!";
            } else if ("complete".equals(action)) {
                // Complete appointment - đánh dấu hiến máu thành công
                if (!"CONFIRMED".equals(appointment.getStatus())) {
                    if (isAjax) {
                        sendJsonError(response, "Chỉ có thể hoàn thành lịch hẹn ở trạng thái CONFIRMED!", 400);
                        return;
                    }
                    request.setAttribute("error", "Chỉ có thể hoàn thành lịch hẹn ở trạng thái CONFIRMED!");
                    doGet(request, response);
                    return;
                }
                
                try {
                    Map<String, String[]> parameterMap = request.getParameterMap();
                    List<BloodBag> bagInputs = new ArrayList<>();

                    try {
                        parameterMap.entrySet().stream()
                        .filter(entry -> entry.getKey().startsWith("bags[") && entry.getKey().endsWith("]"))
                        .map(entry -> entry.getKey().substring(0, entry.getKey().indexOf(']') + 1))
                        .distinct()
                        .forEach(keyPrefix -> {
                            String bloodGroup = request.getParameter(keyPrefix + "[bloodGroup]");
                            String component = request.getParameter(keyPrefix + "[component]");
                            String quantityStr = request.getParameter(keyPrefix + "[quantityMl]");
                            String collectionDateStr = request.getParameter(keyPrefix + "[collectionDate]");

                            if ((bloodGroup != null && !bloodGroup.trim().isEmpty()) ||
                                (component != null && !component.trim().isEmpty()) ||
                                (quantityStr != null && !quantityStr.trim().isEmpty())) {

                                BloodBag bagInput = new BloodBag();
                                bagInput.setBloodGroup(bloodGroup != null ? bloodGroup.trim().toUpperCase() : null);
                                bagInput.setComponent(component != null ? component.trim().toUpperCase() : null);
                                if (quantityStr != null && !quantityStr.trim().isEmpty()) {
                                    try {
                                        bagInput.setVolumeMl(Integer.parseInt(quantityStr.trim()));
                                    } catch (NumberFormatException ex) {
                                        throw new IllegalArgumentException("Số lượng ml không hợp lệ ở dòng " + bagInputs.size());
                                    }
                                }
                                if (collectionDateStr != null && !collectionDateStr.trim().isEmpty()) {
                                    bagInput.setCollectionDate(LocalDate.parse(collectionDateStr));
                                } else {
                                    bagInput.setCollectionDate(LocalDate.now());
                                }
                                bagInputs.add(bagInput);
                            }
                        });

                    } catch (IllegalArgumentException parseEx) {
                        if (isAjax) {
                            sendJsonError(response, parseEx.getMessage(), 400);
                            return;
                        }
                        request.setAttribute("error", parseEx.getMessage());
                        doGet(request, response);
                        return;
                    }

                    if (bagInputs.isEmpty()) {
                        if (isAjax) {
                            sendJsonError(response, "Vui lòng nhập ít nhất một túi máu hợp lệ!", 400);
                            return;
                        }
                        request.setAttribute("error", "Vui lòng nhập ít nhất một túi máu hợp lệ!");
                        doGet(request, response);
                        return;
                    }

                    // Lấy thông tin donor
                    Donor donor = donorDAO.findById(appointment.getDonorId());
                    if (donor == null) {
                        if (isAjax) {
                            sendJsonError(response, "Không tìm thấy thông tin người hiến máu!", 404);
                            return;
                        }
                        request.setAttribute("error", "Không tìm thấy thông tin người hiến máu!");
                        doGet(request, response);
                        return;
                    }
                    
                    // Tạo donation record
                    java.time.LocalDate donationDate = java.time.LocalDate.now();
                    var donationRecord = hospitalService.createDonationRecord(
                        appointment.getDonorId(),
                        hospital.getHospitalId(),
                        donationDate,
                        bagInputs
                    );
                    
                    if (donationRecord != null) {
                        // Update appointment status to COMPLETED
                        appointment.setStatus("COMPLETED");
                        appointment.setUpdatedAt(LocalDateTime.now());
                        success = hospitalService.updateAppointment(appointment);
                        
                        if (success) {
                            int totalQuantity = donationRecord.getQuantityMl() != null ? donationRecord.getQuantityMl() : 0;
                            String displayGroup = donationRecord.getMeasuredBloodGroup() != null ? donationRecord.getMeasuredBloodGroup() : "N/A";
                            message = String.format("Đã ghi nhận hiến máu thành công! %d ml nhóm máu %s", 
                                                   totalQuantity, displayGroup);
                        } else {
                            message = "Đã tạo donation record nhưng không thể cập nhật trạng thái appointment!";
                        }
                    } else {
                        success = false;
                        message = "Không thể tạo donation record!";
                    }
                } catch (NumberFormatException e) {
                    if (isAjax) {
                        sendJsonError(response, "Số lượng máu không hợp lệ!", 400);
                        return;
                    }
                    request.setAttribute("error", "Số lượng máu không hợp lệ!");
                    doGet(request, response);
                    return;
                } catch (SQLException e) {
                    e.printStackTrace();
                    String errorMsg = "Lỗi hệ thống khi tạo donation record: " + e.getMessage();
                    if (isAjax) {
                        sendJsonError(response, errorMsg, 500);
                        return;
                    }
                    request.setAttribute("error", errorMsg);
                    doGet(request, response);
                    return;
                }
            } else {
                if (isAjax) {
                    sendJsonError(response, "Hành động không hợp lệ!", 400);
                    return;
                }
                request.setAttribute("error", "Hành động không hợp lệ!");
                doGet(request, response);
                return;
            }
            
            // Return JSON response for AJAX requests
            if (isAjax) {
                response.setContentType("application/json;charset=UTF-8");
                response.setCharacterEncoding("UTF-8");
                PrintWriter out = response.getWriter();
                String jsonResponse = String.format("{\"success\":%s,\"message\":\"%s\",\"appointmentId\":%d}", 
                    success ? "true" : "false", escapeJson(message), appointmentId);
                out.print(jsonResponse);
                out.flush();
                return;
            }
            
            // Regular form submission - redirect
            if (success) {
                session.setAttribute("success", message);
            } else {
                session.setAttribute("error", message);
            }
            
            response.sendRedirect(request.getContextPath() + "/hospital/appointments");
        } catch (SQLException e) {
            e.printStackTrace();
            String errorMsg = "Lỗi hệ thống: " + (e.getMessage() != null ? e.getMessage() : "Lỗi database");
            if (isAjax) {
                sendJsonError(response, errorMsg, 500);
                return;
            }
            // Ensure response not committed before forwarding
            if (!response.isCommitted()) {
                request.setAttribute("error", errorMsg);
                doGet(request, response);
            }
        } catch (NumberFormatException e) {
            if (isAjax) {
                sendJsonError(response, "ID lịch hẹn không hợp lệ!", 400);
                return;
            }
            if (!response.isCommitted()) {
                request.setAttribute("error", "ID lịch hẹn không hợp lệ!");
                doGet(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            String errorMsg = "Lỗi không xác định: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
            if (isAjax) {
                sendJsonError(response, errorMsg, 500);
                return;
            }
            if (!response.isCommitted()) {
                request.setAttribute("error", errorMsg);
                doGet(request, response);
            }
        } catch (Throwable t) {
            // Catch-all for any unexpected errors (including before isAjax check)
            t.printStackTrace();
            String errorMsg = "Lỗi hệ thống: " + (t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName());
            // Always try to send JSON if possible
            try {
                if (!response.isCommitted()) {
                    // Check if it's an AJAX request (re-check in case error occurred before isAjax was set)
                    String requestedWithHeader = request.getHeader("X-Requested-With");
                    boolean isAjaxRequest = "XMLHttpRequest".equals(requestedWithHeader);
                    
                    if (isAjaxRequest) {
                        response.setContentType("application/json;charset=UTF-8");
                        response.setCharacterEncoding("UTF-8");
                        sendJsonError(response, errorMsg, 500);
                    } else {
                        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMsg);
                    }
                }
            } catch (Exception ex) {
                // If we can't send response, just log
                System.err.println("Cannot send error response: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
    
    /**
     * Send JSON error response for AJAX requests
     */
    private void sendJsonError(HttpServletResponse response, String message, int statusCode) 
            throws IOException {
        response.setStatus(statusCode);
        response.setContentType("application/json;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        String jsonResponse = String.format("{\"success\":false,\"message\":\"%s\"}", escapeJson(message));
        out.print(jsonResponse);
        out.flush();
    }
    
    /**
     * Escape JSON string
     */
    private String escapeJson(String str) {
        if (str == null) {
            return "";
        }
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}

