package com.bloodlink.servlet.hospital;

import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.StockDAO;
import com.bloodlink.model.BloodBag;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.StockSummary;
import com.bloodlink.model.User;
import com.bloodlink.service.HospitalService;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Servlet to handle hospital blood inventory management.
 */
@WebServlet(value = {"/hospital/inventory", "/hospital/inventory/"})
public class HospitalInventoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private HospitalService hospitalService;
    private HospitalDAO hospitalDAO;
    private BloodBagDAO bloodBagDAO;
    private StockDAO stockDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        hospitalService = new HospitalService();
        hospitalDAO = new HospitalDAO();
        bloodBagDAO = new BloodBagDAO();
        stockDAO = new StockDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("[HospitalInventoryServlet] GET request received: " + request.getRequestURI());
        
        // Check authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get hospital info
            Hospital hospital = (Hospital) session.getAttribute("hospital");
            if (hospital == null) {
                hospital = hospitalDAO.findByUserId(user.getUserId());
                if (hospital != null) {
                    session.setAttribute("hospital", hospital);
                }
            }

            if (hospital == null) {
                request.setAttribute("error", "Không tìm thấy thông tin bệnh viện!");
                request.getRequestDispatcher("/hospital/inventory.jsp").forward(request, response);
                return;
            }

            // Get success/error messages from session (if any)
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            
            if (success != null) {
                request.setAttribute("success", success);
                session.removeAttribute("success");
            }
            if (error != null) {
                request.setAttribute("error", error);
                session.removeAttribute("error");
            }

            // Get filter parameters
            String bloodGroupFilter = request.getParameter("bloodGroup");
            String componentFilter = request.getParameter("component");
            String statusFilter = request.getParameter("status");
            
            // Load inventory with filters
            List<BloodBag> inventory = hospitalService.getInventory(hospital.getHospitalId());
            
            // Apply filters
            if (bloodGroupFilter != null && !bloodGroupFilter.isEmpty()) {
                inventory = inventory.stream()
                    .filter(bag -> bag.getBloodGroup().equals(bloodGroupFilter))
                    .collect(Collectors.toList());
            }
            if (componentFilter != null && !componentFilter.isEmpty()) {
                inventory = inventory.stream()
                    .filter(bag -> bag.getComponent().equals(componentFilter))
                    .collect(Collectors.toList());
            }
            if (statusFilter != null && !statusFilter.isEmpty()) {
                inventory = inventory.stream()
                    .filter(bag -> bag.getStatus().equals(statusFilter))
                    .collect(Collectors.toList());
            }
            
            // Enrich inventory với Timestamp cho JSP
            List<Map<String, Object>> enrichedInventory = new ArrayList<>();
            if (inventory != null) {
                for (BloodBag bag : inventory) {
                    if (bag != null) {
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("bagId", bag.getBagId());
                        enriched.put("bagCode", bag.getBagCode());
                        enriched.put("hospitalId", bag.getHospitalId());
                        enriched.put("recordId", bag.getRecordId());
                        enriched.put("bloodGroup", bag.getBloodGroup());
                        enriched.put("component", bag.getComponent());
                        enriched.put("volumeMl", bag.getVolumeMl());
                        enriched.put("status", bag.getStatus());
                        
                        // Convert LocalDate to Timestamp for JSP
                        if (bag.getCollectionDate() != null) {
                            enriched.put("collectionDate", Timestamp.valueOf(bag.getCollectionDate().atStartOfDay()));
                        } else {
                            enriched.put("collectionDate", null);
                        }
                        
                        if (bag.getExpiryDate() != null) {
                            enriched.put("expiryDate", Timestamp.valueOf(bag.getExpiryDate().atStartOfDay()));
                        } else {
                            enriched.put("expiryDate", null);
                        }
                        
                        // Calculate days until expiry
                        if (bag.getExpiryDate() != null) {
                            LocalDate today = LocalDate.now();
                            long daysUntilExpiry = java.time.temporal.ChronoUnit.DAYS.between(today, bag.getExpiryDate());
                            enriched.put("daysUntilExpiry", daysUntilExpiry);
                        } else {
                            enriched.put("daysUntilExpiry", null);
                        }
                        
                        enrichedInventory.add(enriched);
                    }
                }
            }
            
            // Get stock summary for statistics
            List<StockSummary> stockSummary = stockDAO.getAvailableStockByBloodGroup(hospital.getHospitalId());
            List<StockSummary> stockByStatus = stockDAO.getStockSummaryGrouped(hospital.getHospitalId());
            
            // Calculate statistics
            long totalBags = inventory != null ? inventory.size() : 0;
            long availableBags = inventory != null ? inventory.stream()
                .filter(bag -> "AVAILABLE".equals(bag.getStatus())).count() : 0;
            long reservedBags = inventory != null ? inventory.stream()
                .filter(bag -> "RESERVED".equals(bag.getStatus())).count() : 0;
            long expiredBags = inventory != null ? inventory.stream()
                .filter(bag -> {
                    if (bag.getExpiryDate() == null) return false;
                    return bag.getExpiryDate().isBefore(LocalDate.now()) || "EXPIRED".equals(bag.getStatus());
                }).count() : 0;
            long expiringSoonBags = inventory != null ? inventory.stream()
                .filter(bag -> {
                    if (bag.getExpiryDate() == null || bag.getStatus().equals("EXPIRED")) return false;
                    LocalDate today = LocalDate.now();
                    long days = java.time.temporal.ChronoUnit.DAYS.between(today, bag.getExpiryDate());
                    return days > 0 && days <= 7;
                }).count() : 0;
            
            request.setAttribute("inventory", enrichedInventory);
            request.setAttribute("hospital", hospital);
            request.setAttribute("stockSummary", stockSummary);
            request.setAttribute("stockByStatus", stockByStatus);
            request.setAttribute("totalBags", totalBags);
            request.setAttribute("availableBags", availableBags);
            request.setAttribute("reservedBags", reservedBags);
            request.setAttribute("expiredBags", expiredBags);
            request.setAttribute("expiringSoonBags", expiringSoonBags);
            
            // Keep filter values for form
            request.setAttribute("selectedBloodGroup", bloodGroupFilter != null ? bloodGroupFilter : "");
            request.setAttribute("selectedComponent", componentFilter != null ? componentFilter : "");
            request.setAttribute("selectedStatus", statusFilter != null ? statusFilter : "");

            // Forward to JSP
            System.out.println("[HospitalInventoryServlet] Forwarding to JSP: /hospital/inventory.jsp");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/hospital/inventory.jsp");
            if (dispatcher == null) {
                System.err.println("[HospitalInventoryServlet] ERROR: RequestDispatcher is null!");
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "JSP page not found");
                return;
            }
            dispatcher.forward(request, response);
            System.out.println("[HospitalInventoryServlet] Successfully forwarded to JSP");
            
        } catch (SQLException e) {
            System.err.println("[HospitalInventoryServlet] SQL Error: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống khi tải kho máu!");
            try {
                request.getRequestDispatcher("/hospital/inventory.jsp").forward(request, response);
            } catch (ServletException | IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}

