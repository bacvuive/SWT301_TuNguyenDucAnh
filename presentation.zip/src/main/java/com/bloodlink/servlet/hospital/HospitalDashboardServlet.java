package com.bloodlink.servlet.hospital;

import com.bloodlink.dao.StockDAO;
import com.bloodlink.model.Appointment;
import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.StockSummary;
import com.bloodlink.model.User;
import com.bloodlink.service.HospitalService;
import com.bloodlink.service.NotificationService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/hospital/dashboard")
public class HospitalDashboardServlet extends HttpServlet {
    private HospitalService hospitalService;
    private NotificationService notificationService;
    private StockDAO stockDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        hospitalService = new HospitalService();
        notificationService = new NotificationService();
        stockDAO = new StockDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Get success/error messages from session (if any)
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            
            if (success != null) {
                request.setAttribute("success", success);
                session.removeAttribute("success"); // Remove after displaying
            }
            if (error != null) {
                request.setAttribute("error", error);
                session.removeAttribute("error"); // Remove after displaying
            }

            // Lấy stock summary từ views thay vì group thủ công
            List<StockSummary> stockSummary = stockDAO.getAvailableStockByBloodGroup(hospital.getHospitalId());
            List<StockSummary> stockByStatus = stockDAO.getStockSummaryGrouped(hospital.getHospitalId());
            
            // Vẫn giữ inventory để backward compatibility (nếu JSP cần)
            var inventory = hospitalService.getInventory(hospital.getHospitalId());
            var requestsRaw = hospitalService.getRequests(hospital.getHospitalId());
            var appointmentsRaw = hospitalService.getAppointments(hospital.getHospitalId());
            
            // Enrich requests với Timestamp cho JSP
            List<Map<String, Object>> requests = new ArrayList<>();
            if (requestsRaw != null) {
                for (BloodRequest req : requestsRaw) {
                    if (req != null) {
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("requestId", req.getRequestId());
                        enriched.put("fromHospitalId", req.getFromHospitalId());
                        enriched.put("toHospitalId", req.getToHospitalId());
                        enriched.put("bloodGroup", req.getBloodGroup());
                        enriched.put("component", req.getComponent());
                        enriched.put("quantity", req.getQuantity());
                        enriched.put("status", req.getStatus());
                        if (req.getCreatedAt() != null) {
                            enriched.put("createdAt", Timestamp.valueOf(req.getCreatedAt()));
                        } else {
                            enriched.put("createdAt", null);
                        }
                        if (req.getUpdatedAt() != null) {
                            enriched.put("updatedAt", Timestamp.valueOf(req.getUpdatedAt()));
                        } else {
                            enriched.put("updatedAt", null);
                        }
                        requests.add(enriched);
                    }
                }
            }
            
            // Enrich appointments với Timestamp cho JSP
            List<Map<String, Object>> appointments = new ArrayList<>();
            if (appointmentsRaw != null) {
                for (Appointment apt : appointmentsRaw) {
                    if (apt != null) {
                        Map<String, Object> enriched = new HashMap<>();
                        enriched.put("appointmentId", apt.getAppointmentId());
                        enriched.put("status", apt.getStatus());
                        if (apt.getScheduledAt() != null) {
                            enriched.put("scheduledAt", Timestamp.valueOf(apt.getScheduledAt()));
                        } else {
                            enriched.put("scheduledAt", null);
                        }
                        appointments.add(enriched);
                    }
                }
            }
            
            var notifications = notificationService.getUnreadNotifications(user.getUserId());

            request.setAttribute("hospital", hospital);
            request.setAttribute("inventory", inventory);
            request.setAttribute("stockSummary", stockSummary); // Tóm tắt theo blood_group (AVAILABLE)
            request.setAttribute("stockByStatus", stockByStatus); // Chi tiết theo status
            request.setAttribute("requests", requests);
            request.setAttribute("appointments", appointments);
            request.setAttribute("notifications", notifications);

            request.getRequestDispatcher("/hospital/dashboard.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            request.getRequestDispatcher("/hospital/dashboard.jsp").forward(request, response);
        }
    }
}

