package com.bloodlink.servlet.hospital;

import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.HospitalVerificationRequest;
import com.bloodlink.model.User;
import com.bloodlink.service.HospitalService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;

@WebServlet("/hospital/profile")
public class HospitalProfileServlet extends HttpServlet {
    private HospitalService hospitalService;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        hospitalService = new HospitalService();
        hospitalDAO = new HospitalDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            prepareHospitalView(request, user, hospital);
            request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            try {
                Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
                prepareHospitalView(request, user, hospital);
            } catch (SQLException ex) {
                // Ignore
            }
            request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Lấy thông tin từ form
            String name = request.getParameter("name");
            String address = request.getParameter("address");
            String contact = request.getParameter("contact");
            String region = request.getParameter("region");

            // Validate dữ liệu
            if (name == null || name.trim().isEmpty()) {
                request.setAttribute("error", "Tên bệnh viện không được để trống!");
                prepareHospitalView(request, user, hospital);
                request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
                return;
            }

            if (address == null || address.trim().isEmpty()) {
                request.setAttribute("error", "Địa chỉ không được để trống!");
                prepareHospitalView(request, user, hospital);
                request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
                return;
            }

            // Cập nhật thông tin bệnh viện
            hospital.setName(name.trim());
            hospital.setAddress(address.trim());
            hospital.setContact(contact != null ? contact.trim() : null);
            hospital.setRegion(region != null && !region.isEmpty() ? region : null);

            boolean updated = hospitalDAO.update(hospital);
            if (!updated) {
                request.setAttribute("error", "Không thể cập nhật thông tin!");
                request.setAttribute("hospital", hospital);
                request.setAttribute("authUser", user);
                request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
                return;
            }

            // Cập nhật lại từ database để đảm bảo dữ liệu mới nhất
            Hospital updatedHospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (updatedHospital != null) {
                session.setAttribute("hospital", updatedHospital);
            }

            request.setAttribute("success", "Cập nhật thông tin thành công!");
            prepareHospitalView(request, user, updatedHospital != null ? updatedHospital : hospital);
            request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            try {
                Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
                prepareHospitalView(request, user, hospital);
            } catch (SQLException ex) {
                // Ignore
            }
            request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Dữ liệu không hợp lệ!");
            try {
                Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
                prepareHospitalView(request, user, hospital);
            } catch (SQLException ex) {
                // Ignore
            }
            request.getRequestDispatcher("/hospital/profile.jsp").forward(request, response);
        }
    }

    private void prepareHospitalView(HttpServletRequest request, User user, Hospital hospital) throws SQLException {
        if (hospital != null) {
            HospitalVerificationRequest latestVerification = hospitalService.getLatestVerificationRequest(hospital.getHospitalId());
            Timestamp hospitalVerifiedAt = hospital.getVerifiedAt() != null ? Timestamp.valueOf(hospital.getVerifiedAt()) : null;
            request.setAttribute("hospital", hospital);
            request.setAttribute("latestVerification", latestVerification);
            request.setAttribute("hasPendingVerification", latestVerification != null && "PENDING".equals(latestVerification.getStatus()));
            request.setAttribute("hospitalVerifiedAt", hospitalVerifiedAt);
        }
        request.setAttribute("authUser", user);
    }
}

