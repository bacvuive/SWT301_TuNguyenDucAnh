package com.bloodlink.servlet.admin;

import com.bloodlink.model.Donor;
import com.bloodlink.model.User;
import com.bloodlink.service.AdminService;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/manage-donor")
public class AdminManageDonorServlet extends HttpServlet {
    private AdminService adminService;
    private DonorService donorService;

    @Override
    public void init() throws ServletException {
        super.init();
        adminService = new AdminService();
        donorService = new DonorService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get all donors
            List<Donor> donors = adminService.getAllDonors();
            
            // Enrich donors with user info and donation count
            List<Map<String, Object>> enrichedDonors = new ArrayList<>();
            for (Donor donor : donors) {
                Map<String, Object> enriched = new HashMap<>();
                enriched.put("donorId", donor.getDonorId());
                enriched.put("userId", donor.getUserId());
                enriched.put("fullName", donor.getFullName());
                enriched.put("dob", donor.getDob());
                enriched.put("gender", donor.getGender());
                enriched.put("bloodGroup", donor.getBloodGroup());
                enriched.put("phone", donor.getPhone());
                enriched.put("address", donor.getAddress());
                if (donor.getCreatedAt() != null) {
                    enriched.put("createdAt", Timestamp.valueOf(donor.getCreatedAt()));
                }
                
                // Get user info
                try {
                    User donorUser = adminService.getUserById(donor.getUserId());
                    if (donorUser != null) {
                        enriched.put("email", donorUser.getEmail());
                        enriched.put("username", donorUser.getUsername());
                        enriched.put("status", donorUser.getStatus());
                    }
                } catch (SQLException e) {
                    enriched.put("email", "—");
                    enriched.put("username", "—");
                    enriched.put("status", "unknown");
                }
                
                // Get donation count
                try {
                    int donationCount = donorService.getDonationCount(donor.getDonorId());
                    enriched.put("donationCount", donationCount);
                } catch (SQLException e) {
                    enriched.put("donationCount", 0);
                }
                
                enrichedDonors.add(enriched);
            }

            request.setAttribute("donors", enrichedDonors);
            request.getRequestDispatcher("/admin/manage-donor.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu người hiến máu!");
            request.getRequestDispatcher("/admin/manage-donor.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        String action = request.getParameter("action");
        String userIdStr = request.getParameter("userId");
        
        if ("toggleStatus".equals(action) && userIdStr != null) {
            try {
                Integer userId = Integer.parseInt(userIdStr);
                User targetUser = adminService.getUserById(userId);
                if (targetUser != null) {
                    String newStatus = "active".equals(targetUser.getStatus()) ? "inactive" : "active";
                    if (adminService.updateUserStatus(userId, newStatus)) {
                        session.setAttribute("success", "Đã cập nhật trạng thái tài khoản thành công!");
                    } else {
                        session.setAttribute("error", "Không thể cập nhật trạng thái tài khoản!");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                session.setAttribute("error", "Lỗi khi cập nhật trạng thái!");
            }
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/manage-donor");
    }
}

