package com.bloodlink.servlet.admin;

import com.bloodlink.model.Hospital;
import com.bloodlink.model.HospitalVerificationRequest;
import com.bloodlink.model.User;
import com.bloodlink.service.AdminService;
import com.bloodlink.service.HospitalService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/verification-requests")
public class AdminVerificationServlet extends HttpServlet {

    private AdminService adminService;
    private HospitalService hospitalService;

    @Override
    public void init() throws ServletException {
        super.init();
        this.adminService = new AdminService();
        this.hospitalService = new HospitalService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User authUser = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(authUser.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            String success = (String) session.getAttribute("success");
            String error = (String) session.getAttribute("error");
            if (success != null) {
                request.setAttribute("success", success);
                session.removeAttribute("success");
            }
            if (error != null) {
                request.setAttribute("error", error);
                session.removeAttribute("error");
            }

            List<HospitalVerificationRequest> pending = adminService.getVerificationRequestsByStatus("PENDING");
            List<HospitalVerificationRequest> approved = adminService.getVerificationRequestsByStatus("APPROVED");
            List<HospitalVerificationRequest> rejected = adminService.getVerificationRequestsByStatus("REJECTED");

            request.setAttribute("pendingRequests", buildView(pending));
            request.setAttribute("approvedRequests", buildView(approved));
            request.setAttribute("rejectedRequests", buildView(rejected));

            request.getRequestDispatcher("/admin/verification-requests.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Không thể tải danh sách yêu cầu: " + e.getMessage());
            request.getRequestDispatcher("/admin/verification-requests.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User authUser = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(authUser.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        String action = request.getParameter("action");
        String requestIdStr = request.getParameter("requestId");
        String note = request.getParameter("note");

        if (requestIdStr == null || requestIdStr.trim().isEmpty()) {
            session.setAttribute("error", "Thiếu thông tin yêu cầu");
            response.sendRedirect(request.getContextPath() + "/admin/verification-requests");
            return;
        }

        try {
            Integer requestId = Integer.parseInt(requestIdStr);
            boolean approve;
            if ("approve".equalsIgnoreCase(action)) {
                approve = true;
            } else if ("reject".equalsIgnoreCase(action)) {
                approve = false;
                if (note == null || note.trim().isEmpty()) {
                    session.setAttribute("error", "Vui lòng nhập lý do khi từ chối yêu cầu.");
                    response.sendRedirect(request.getContextPath() + "/admin/verification-requests");
                    return;
                }
            } else {
                session.setAttribute("error", "Hành động không hợp lệ");
                response.sendRedirect(request.getContextPath() + "/admin/verification-requests");
                return;
            }

            hospitalService.processVerification(requestId, authUser.getUserId(), approve, approve ? null : note.trim());
            session.setAttribute("success", approve ? "Đã phê duyệt yêu cầu xác minh." : "Đã từ chối yêu cầu xác minh.");
        } catch (NumberFormatException e) {
            session.setAttribute("error", "Mã yêu cầu không hợp lệ");
        } catch (IllegalStateException | IllegalArgumentException e) {
            session.setAttribute("error", e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            session.setAttribute("error", "Không thể xử lý yêu cầu: " + e.getMessage());
        }

        response.sendRedirect(request.getContextPath() + "/admin/verification-requests");
    }

    private List<Map<String, Object>> buildView(List<HospitalVerificationRequest> requests) throws SQLException {
        List<Map<String, Object>> view = new ArrayList<>();
        if (requests == null) {
            return view;
        }

        for (HospitalVerificationRequest req : requests) {
            Map<String, Object> item = new HashMap<>();
            item.put("request", req);
            Hospital hospital = adminService.getHospitalById(req.getHospitalId());
            item.put("hospital", hospital);
            if (req.getProcessedBy() != null) {
                User processedBy = adminService.getUserById(req.getProcessedBy());
                item.put("processedBy", processedBy);
            }
            if (req.getSubmittedAt() != null) {
                item.put("submittedAt", Timestamp.valueOf(req.getSubmittedAt()));
            }
            if (req.getProcessedAt() != null) {
                item.put("processedAt", Timestamp.valueOf(req.getProcessedAt()));
            }
            view.add(item);
        }
        return view;
    }
}
