package com.bloodlink.servlet.admin;

import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.service.AdminService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/manage-hospital")
public class AdminManageHospitalServlet extends HttpServlet {
    private AdminService adminService;

    @Override
    public void init() throws ServletException {
        super.init();
        adminService = new AdminService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get all hospitals
            List<Hospital> hospitals = adminService.getAllHospitals();
            
            // Enrich hospitals with user info
            List<Map<String, Object>> enrichedHospitals = new ArrayList<>();
            for (Hospital hospital : hospitals) {
                Map<String, Object> enriched = new HashMap<>();
                enriched.put("hospitalId", hospital.getHospitalId());
                enriched.put("userId", hospital.getUserId());
                enriched.put("name", hospital.getName());
                enriched.put("address", hospital.getAddress());
                enriched.put("contact", hospital.getContact());
                enriched.put("region", hospital.getRegion());
                enriched.put("latitude", hospital.getLatitude());
                enriched.put("longitude", hospital.getLongitude());
                enriched.put("isVerified", hospital.getIsVerified() != null ? hospital.getIsVerified() : Boolean.FALSE);
                enriched.put("verifiedAt", hospital.getVerifiedAt() != null ? Timestamp.valueOf(hospital.getVerifiedAt()) : null);
                enriched.put("verificationNote", hospital.getVerificationNote());
                if (hospital.getCreatedAt() != null) {
                    enriched.put("createdAt", Timestamp.valueOf(hospital.getCreatedAt()));
                }
                
                // Get user info
                if (hospital.getUserId() != null) {
                    try {
                        User hospitalUser = adminService.getUserById(hospital.getUserId());
                        if (hospitalUser != null) {
                            enriched.put("email", hospitalUser.getEmail());
                            enriched.put("username", hospitalUser.getUsername());
                            enriched.put("status", hospitalUser.getStatus());
                        }
                    } catch (SQLException e) {
                        enriched.put("email", "—");
                        enriched.put("username", "—");
                        enriched.put("status", "unknown");
                    }
                } else {
                    enriched.put("email", "Chưa có tài khoản");
                    enriched.put("username", "—");
                    enriched.put("status", "no_account");
                }
                
                enrichedHospitals.add(enriched);
            }

            request.setAttribute("hospitals", enrichedHospitals);
            request.getRequestDispatcher("/admin/manage-hospital.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu bệnh viện!");
            request.getRequestDispatcher("/admin/manage-hospital.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        String action = request.getParameter("action");
        String userIdStr = request.getParameter("userId");
        
        if ("toggleStatus".equals(action) && userIdStr != null) {
            try {
                Integer userId = Integer.parseInt(userIdStr);
                User targetUser = adminService.getUserById(userId);
                if (targetUser != null) {
                    String newStatus = "active".equals(targetUser.getStatus()) ? "inactive" : "active";
                    if (adminService.updateUserStatus(userId, newStatus)) {
                        session.setAttribute("success", "Đã cập nhật trạng thái tài khoản thành công!");
                    } else {
                        session.setAttribute("error", "Không thể cập nhật trạng thái tài khoản!");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                session.setAttribute("error", "Lỗi khi cập nhật trạng thái!");
            }
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/manage-hospital");
    }
}

