package com.bloodlink.servlet.admin;

import com.bloodlink.model.User;
import com.bloodlink.service.AdminService;
import com.bloodlink.service.NotificationService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {
    private AdminService adminService;
    private NotificationService notificationService;

    @Override
    public void init() throws ServletException {
        super.init();
        adminService = new AdminService();
        notificationService = new NotificationService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get statistics
            List<User> allUsers = adminService.getAllUsers();
            List<com.bloodlink.model.Hospital> allHospitals = adminService.getAllHospitals();
            
            // Count by role
            long totalDonors = allUsers.stream()
                .filter(u -> "donor".equalsIgnoreCase(u.getRoleCode()))
                .count();
            long totalHospitals = allUsers.stream()
                .filter(u -> "hospital".equalsIgnoreCase(u.getRoleCode()))
                .count();
            long activeUsers = allUsers.stream()
                .filter(u -> "active".equalsIgnoreCase(u.getStatus()))
                .count();
            
            // Get notifications
            var notifications = notificationService.getUnreadNotifications(user.getUserId());

            request.setAttribute("totalUsers", allUsers.size());
            request.setAttribute("totalDonors", totalDonors);
            request.setAttribute("totalHospitals", totalHospitals);
            request.setAttribute("activeUsers", activeUsers);
            request.setAttribute("hospitals", allHospitals);
            request.setAttribute("notifications", notifications);

            request.getRequestDispatcher("/admin/dashboard.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu!");
            request.getRequestDispatcher("/admin/dashboard.jsp").forward(request, response);
        }
    }
}

