package com.bloodlink.servlet.admin;

import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.service.AdminService;
import com.bloodlink.service.BloodRequestService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/manage-request")
public class AdminManageRequestServlet extends HttpServlet {
    private AdminService adminService;
    private BloodRequestService bloodRequestService;

    @Override
    public void init() throws ServletException {
        super.init();
        adminService = new AdminService();
        bloodRequestService = new BloodRequestService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get filter parameters
            String statusFilter = request.getParameter("status");
            String bloodGroupFilter = request.getParameter("bloodGroup");
            String hospitalIdStr = request.getParameter("hospitalId");
            
            // Get all requests or filtered
            List<BloodRequest> requests;
            if (statusFilter != null && !statusFilter.isEmpty()) {
                requests = bloodRequestService.getRequestsByStatus(statusFilter);
            } else {
                requests = bloodRequestService.getAllRequests();
            }
            
            // Enrich requests with hospital info
            List<Map<String, Object>> enrichedRequests = new ArrayList<>();
            for (BloodRequest req : requests) {
                // Filter by blood group
                if (bloodGroupFilter != null && !bloodGroupFilter.isEmpty() && 
                    !bloodGroupFilter.equals(req.getBloodGroup())) {
                    continue;
                }
                
                // Filter by hospital
                if (hospitalIdStr != null && !hospitalIdStr.isEmpty()) {
                    try {
                        Integer hospitalId = Integer.parseInt(hospitalIdStr);
                        if (!hospitalId.equals(req.getFromHospitalId()) && 
                            !hospitalId.equals(req.getToHospitalId())) {
                            continue;
                        }
                    } catch (NumberFormatException e) {
                        // Ignore invalid hospital ID
                    }
                }
                
                Map<String, Object> enriched = new HashMap<>();
                enriched.put("requestId", req.getRequestId());
                enriched.put("fromHospitalId", req.getFromHospitalId());
                enriched.put("toHospitalId", req.getToHospitalId());
                enriched.put("bloodGroup", req.getBloodGroup());
                enriched.put("component", req.getComponent());
                enriched.put("quantity", req.getQuantity());
                enriched.put("status", req.getStatus());
                if (req.getCreatedAt() != null) {
                    enriched.put("createdAt", Timestamp.valueOf(req.getCreatedAt()));
                }
                if (req.getUpdatedAt() != null) {
                    enriched.put("updatedAt", Timestamp.valueOf(req.getUpdatedAt()));
                }
                
                // Get from hospital info
                try {
                    Hospital fromHospital = adminService.getHospitalById(req.getFromHospitalId());
                    if (fromHospital != null) {
                        enriched.put("fromHospitalName", fromHospital.getName());
                        enriched.put("fromHospitalRegion", fromHospital.getRegion());
                    } else {
                        enriched.put("fromHospitalName", "Bệnh viện không tồn tại");
                        enriched.put("fromHospitalRegion", "—");
                    }
                } catch (SQLException e) {
                    enriched.put("fromHospitalName", "Lỗi khi tải thông tin");
                    enriched.put("fromHospitalRegion", "—");
                }
                
                // Get to hospital info (if specified)
                if (req.getToHospitalId() != null) {
                    try {
                        Hospital toHospital = adminService.getHospitalById(req.getToHospitalId());
                        if (toHospital != null) {
                            enriched.put("toHospitalName", toHospital.getName());
                            enriched.put("toHospitalRegion", toHospital.getRegion());
                        } else {
                            enriched.put("toHospitalName", "Bệnh viện không tồn tại");
                            enriched.put("toHospitalRegion", "—");
                        }
                    } catch (SQLException e) {
                        enriched.put("toHospitalName", "Lỗi khi tải thông tin");
                        enriched.put("toHospitalRegion", "—");
                    }
                } else {
                    enriched.put("toHospitalName", "Tất cả bệnh viện");
                    enriched.put("toHospitalRegion", "Broadcast");
                }
                
                enrichedRequests.add(enriched);
            }

            // Get all hospitals for filter dropdown
            List<Hospital> allHospitals = adminService.getAllHospitals();

            request.setAttribute("requests", enrichedRequests);
            request.setAttribute("hospitals", allHospitals);
            request.setAttribute("selectedStatus", statusFilter != null ? statusFilter : "");
            request.setAttribute("selectedBloodGroup", bloodGroupFilter != null ? bloodGroupFilter : "");
            request.setAttribute("selectedHospitalId", hospitalIdStr != null ? hospitalIdStr : "");
            
            request.getRequestDispatcher("/admin/manage-request.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu yêu cầu máu!");
            request.getRequestDispatcher("/admin/manage-request.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User adminUser = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(adminUser.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        String action = request.getParameter("action");
        String requestIdStr = request.getParameter("requestId");
        
        if (requestIdStr == null || requestIdStr.isEmpty()) {
            session.setAttribute("error", "Thiếu thông tin request ID!");
            response.sendRedirect(request.getContextPath() + "/admin/manage-request");
            return;
        }
        
        try {
            Integer requestId = Integer.parseInt(requestIdStr);
            BloodRequest bloodRequest = bloodRequestService.getRequestById(requestId);
            
            if (bloodRequest == null) {
                session.setAttribute("error", "Không tìm thấy yêu cầu máu!");
                response.sendRedirect(request.getContextPath() + "/admin/manage-request");
                return;
            }
            
            boolean success = false;
            String message = "";
            
            switch (action) {
                case "approve":
                    if (!"PENDING".equals(bloodRequest.getStatus())) {
                        message = "Chỉ có thể approve yêu cầu đang ở trạng thái PENDING!";
                    } else {
                        bloodRequest.setStatus("ACCEPTED");
                        bloodRequest.setUpdatedAt(LocalDateTime.now());
                        success = bloodRequestService.updateRequest(bloodRequest);
                        message = success ? "Đã approve yêu cầu máu thành công!" : "Không thể approve yêu cầu!";
                    }
                    break;
                    
                case "reject":
                    if (!"PENDING".equals(bloodRequest.getStatus()) && !"ACCEPTED".equals(bloodRequest.getStatus())) {
                        message = "Chỉ có thể reject yêu cầu đang ở trạng thái PENDING hoặc ACCEPTED!";
                    } else {
                        bloodRequest.setStatus("REJECTED");
                        bloodRequest.setUpdatedAt(LocalDateTime.now());
                        success = bloodRequestService.updateRequest(bloodRequest);
                        message = success ? "Đã reject yêu cầu máu thành công!" : "Không thể reject yêu cầu!";
                    }
                    break;
                    
                case "cancel":
                    if ("COMPLETED".equals(bloodRequest.getStatus()) || "CANCELLED".equals(bloodRequest.getStatus())) {
                        message = "Yêu cầu này đã được đóng trước đó!";
                    } else {
                        bloodRequest.setStatus("CANCELLED");
                        bloodRequest.setUpdatedAt(LocalDateTime.now());
                        success = bloodRequestService.updateRequest(bloodRequest);
                        message = success ? "Đã hủy yêu cầu máu thành công!" : "Không thể hủy yêu cầu!";
                    }
                    break;
                    
                case "complete":
                    if (!"ACCEPTED".equals(bloodRequest.getStatus())) {
                        message = "Chỉ có thể complete yêu cầu đang ở trạng thái ACCEPTED!";
                    } else {
                        bloodRequest.setStatus("COMPLETED");
                        bloodRequest.setUpdatedAt(LocalDateTime.now());
                        success = bloodRequestService.updateRequest(bloodRequest);
                        message = success ? "Đã hoàn thành yêu cầu máu thành công!" : "Không thể hoàn thành yêu cầu!";
                    }
                    break;
                    
                default:
                    message = "Hành động không hợp lệ!";
            }
            
            if (success) {
                session.setAttribute("success", message);
            } else {
                session.setAttribute("error", message);
            }
            
        } catch (NumberFormatException e) {
            session.setAttribute("error", "Request ID không hợp lệ!");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Lỗi khi xử lý: " + e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/manage-request");
    }
}

