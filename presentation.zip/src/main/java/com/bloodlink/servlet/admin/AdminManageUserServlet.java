package com.bloodlink.servlet.admin;

import com.bloodlink.model.User;
import com.bloodlink.service.AdminService;
import com.bloodlink.util.BCryptUtil;
import com.bloodlink.util.PasswordUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/manage-user")
public class AdminManageUserServlet extends HttpServlet {
    private AdminService adminService;

    @Override
    public void init() throws ServletException {
        super.init();
        adminService = new AdminService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get filter parameters
            String roleFilter = request.getParameter("role");
            String statusFilter = request.getParameter("status");
            String searchQuery = request.getParameter("search");
            
            // Get all users or filtered
            List<User> users;
            if (roleFilter != null && !roleFilter.isEmpty()) {
                users = adminService.getUsersByRole(roleFilter);
            } else {
                users = adminService.getAllUsers();
            }
            
            // Get current admin user ID to exclude from list
            Integer currentAdminId = user.getUserId();
            
            // Filter by status and search, and exclude admin accounts
            List<Map<String, Object>> enrichedUsers = new ArrayList<>();
            for (User u : users) {
                // Exclude admin accounts from the list (for security)
                if ("admin".equalsIgnoreCase(u.getRoleCode())) {
                    continue;
                }
                
                // Filter by status
                if (statusFilter != null && !statusFilter.isEmpty() && !statusFilter.equals(u.getStatus())) {
                    continue;
                }
                
                // Filter by search query
                if (searchQuery != null && !searchQuery.isEmpty()) {
                    String query = searchQuery.toLowerCase();
                    if (!u.getEmail().toLowerCase().contains(query) &&
                        !u.getUsername().toLowerCase().contains(query) &&
                        !u.getUserId().toString().contains(query)) {
                        continue;
                    }
                }
                
                Map<String, Object> enriched = new HashMap<>();
                enriched.put("userId", u.getUserId());
                enriched.put("username", u.getUsername());
                enriched.put("email", u.getEmail());
                enriched.put("roleCode", u.getRoleCode());
                enriched.put("status", u.getStatus());
                if (u.getCreatedAt() != null) {
                    enriched.put("createdAt", Timestamp.valueOf(u.getCreatedAt()));
                }
                
                // Get additional info based on role
                try {
                    if ("donor".equalsIgnoreCase(u.getRoleCode())) {
                        var donor = adminService.getDonorByUserId(u.getUserId());
                        if (donor != null) {
                            enriched.put("fullName", donor.getFullName());
                            enriched.put("phone", donor.getPhone());
                        }
                    } else if ("hospital".equalsIgnoreCase(u.getRoleCode())) {
                        var hospital = adminService.getHospitalByUserId(u.getUserId());
                        if (hospital != null) {
                            enriched.put("hospitalName", hospital.getName());
                            enriched.put("region", hospital.getRegion());
                        }
                    }
                } catch (SQLException e) {
                    // Ignore errors when fetching additional info
                }
                
                enrichedUsers.add(enriched);
            }

            request.setAttribute("users", enrichedUsers);
            request.setAttribute("selectedRole", roleFilter != null ? roleFilter : "");
            request.setAttribute("selectedStatus", statusFilter != null ? statusFilter : "");
            request.setAttribute("searchQuery", searchQuery != null ? searchQuery : "");
            
            request.getRequestDispatcher("/admin/manage-user.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu người dùng!");
            request.getRequestDispatcher("/admin/manage-user.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User adminUser = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(adminUser.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        String action = request.getParameter("action");
        String userIdStr = request.getParameter("userId");
        
        if (userIdStr == null || userIdStr.isEmpty()) {
            session.setAttribute("error", "Thiếu thông tin user ID!");
            response.sendRedirect(request.getContextPath() + "/admin/manage-user");
            return;
        }
        
        try {
            Integer userId = Integer.parseInt(userIdStr);
            User targetUser = adminService.getUserById(userId);
            
            if (targetUser == null) {
                session.setAttribute("error", "Không tìm thấy người dùng!");
                response.sendRedirect(request.getContextPath() + "/admin/manage-user");
                return;
            }
            
            // Prevent admin from modifying themselves
            if (userId.equals(adminUser.getUserId())) {
                session.setAttribute("error", "Bạn không thể thay đổi tài khoản của chính mình!");
                response.sendRedirect(request.getContextPath() + "/admin/manage-user");
                return;
            }
            
            boolean success = false;
            String message = "";
            
            switch (action) {
                case "toggleStatus":
                    String newStatus = "active".equals(targetUser.getStatus()) ? "inactive" : "active";
                    success = adminService.updateUserStatus(userId, newStatus);
                    message = success ? 
                        "Đã " + (newStatus.equals("active") ? "kích hoạt" : "vô hiệu hóa") + " tài khoản thành công!" :
                        "Không thể cập nhật trạng thái tài khoản!";
                    break;
                    
                case "updateRole":
                    String newRole = request.getParameter("newRole");
                    if (newRole != null && !newRole.isEmpty()) {
                        // Prevent changing role to admin (security)
                        if ("admin".equalsIgnoreCase(newRole)) {
                            message = "Không thể đổi role thành Admin (bảo mật)!";
                        } else if ("admin".equalsIgnoreCase(targetUser.getRoleCode())) {
                            message = "Không thể thay đổi role của tài khoản Admin!";
                        } else {
                            targetUser.setRoleCode(newRole);
                            success = adminService.updateUser(targetUser);
                            message = success ? "Đã cập nhật role thành công!" : "Không thể cập nhật role!";
                        }
                    } else {
                        message = "Thiếu thông tin role mới!";
                    }
                    break;
                    
                case "resetPassword":
                    String newPassword = request.getParameter("newPassword");
                    if (newPassword != null && !newPassword.isEmpty() && newPassword.length() >= 6) {
                        String passwordHash = BCryptUtil.hashPassword(newPassword);
                        success = adminService.updateUserPassword(userId, passwordHash);
                        message = success ? "Đã reset mật khẩu thành công!" : "Không thể reset mật khẩu!";
                    } else {
                        message = "Mật khẩu phải có ít nhất 6 ký tự!";
                    }
                    break;
                    
                default:
                    message = "Hành động không hợp lệ!";
            }
            
            if (success) {
                session.setAttribute("success", message);
            } else {
                session.setAttribute("error", message);
            }
            
        } catch (NumberFormatException e) {
            session.setAttribute("error", "User ID không hợp lệ!");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Lỗi khi xử lý: " + e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/manage-user");
    }
}

