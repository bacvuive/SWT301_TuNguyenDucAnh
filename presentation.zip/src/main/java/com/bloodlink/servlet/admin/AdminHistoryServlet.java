package com.bloodlink.servlet.admin;

import com.bloodlink.model.User;
import com.bloodlink.service.AuditLogService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/history")
public class AdminHistoryServlet extends HttpServlet {
    private AuditLogService auditLogService;

    @Override
    public void init() throws ServletException {
        super.init();
        auditLogService = new AuditLogService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        try {
            // Get filter parameters
            String userIdStr = request.getParameter("userId");
            String action = request.getParameter("action");
            String entityType = request.getParameter("entityType");
            String fromDateStr = request.getParameter("fromDate");
            String toDateStr = request.getParameter("toDate");
            String pageStr = request.getParameter("page");
            String limitStr = request.getParameter("limit");
            
            Integer userId = null;
            if (userIdStr != null && !userIdStr.isEmpty()) {
                try {
                    userId = Integer.parseInt(userIdStr);
                } catch (NumberFormatException e) {
                    // Ignore invalid userId
                }
            }
            
            LocalDateTime fromDate = null;
            if (fromDateStr != null && !fromDateStr.isEmpty()) {
                try {
                    fromDate = LocalDateTime.parse(fromDateStr + "T00:00:00");
                } catch (Exception e) {
                    // Ignore invalid date
                }
            }
            
            LocalDateTime toDate = null;
            if (toDateStr != null && !toDateStr.isEmpty()) {
                try {
                    toDate = LocalDateTime.parse(toDateStr + "T23:59:59");
                } catch (Exception e) {
                    // Ignore invalid date
                }
            }
            
            int page = (pageStr != null && !pageStr.isEmpty()) ? Integer.parseInt(pageStr) : 1;
            int limit = (limitStr != null && !limitStr.isEmpty()) ? Integer.parseInt(limitStr) : 50;
            int offset = (page - 1) * limit;
            
            // Get audit logs
            List<Map<String, Object>> logs = auditLogService.getLogs(
                userId, action, entityType, fromDate, toDate, limit, offset
            );
            
            // Convert timestamps for JSP
            for (Map<String, Object> log : logs) {
                Object createdAt = log.get("createdAt");
                if (createdAt instanceof LocalDateTime) {
                    log.put("createdAt", Timestamp.valueOf((LocalDateTime) createdAt));
                }
            }
            
            // Get total count for pagination
            int totalCount = auditLogService.countLogs(userId, action, entityType, fromDate, toDate);
            int totalPages = (int) Math.ceil((double) totalCount / limit);
            
            request.setAttribute("logs", logs);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("totalCount", totalCount);
            request.setAttribute("selectedUserId", userIdStr != null ? userIdStr : "");
            request.setAttribute("selectedAction", action != null ? action : "");
            request.setAttribute("selectedEntityType", entityType != null ? entityType : "");
            request.setAttribute("selectedFromDate", fromDateStr != null ? fromDateStr : "");
            request.setAttribute("selectedToDate", toDateStr != null ? toDateStr : "");
            
            request.getRequestDispatcher("/admin/history.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải lịch sử hoạt động!");
            request.getRequestDispatcher("/admin/history.jsp").forward(request, response);
        }
    }
}

