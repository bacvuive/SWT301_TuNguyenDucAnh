package com.bloodlink.servlet.common;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.*;
import com.bloodlink.service.HospitalService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/hospital/complete-donation")
public class CompleteDonationServlet extends HttpServlet {
    private HospitalService hospitalService;
    private DonorDAO donorDAO;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        hospitalService = new HospitalService();
        donorDAO = new DonorDAO();
        hospitalDAO = new HospitalDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendRedirect(request.getContextPath() + "/");
            return;
        }

        String appointmentIdStr = request.getParameter("appointmentId");
        if (appointmentIdStr == null) {
            request.setAttribute("error", "Thiếu thông tin lịch hẹn!");
            request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
            return;
        }

        try {
            Integer appointmentId = Integer.parseInt(appointmentIdStr);
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Lấy appointment và verify nó thuộc về hospital này
            var appointments = hospitalService.getAppointments(hospital.getHospitalId());
            Appointment appointment = appointments.stream()
                    .filter(apt -> apt.getAppointmentId().equals(appointmentId))
                    .findFirst()
                    .orElse(null);

            if (appointment == null) {
                request.setAttribute("error", "Lịch hẹn không tồn tại hoặc không thuộc bệnh viện của bạn!");
                request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
                return;
            }

            // Chỉ cho phép complete nếu status là CONFIRMED
            if (!"CONFIRMED".equals(appointment.getStatus())) {
                request.setAttribute("error", "Chỉ có thể hoàn thành lịch hẹn ở trạng thái CONFIRMED!");
                request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
                return;
            }

            // Lấy thông tin donor
            Donor donor = donorDAO.findById(appointment.getDonorId());
            if (donor == null) {
                request.setAttribute("error", "Không tìm thấy thông tin người hiến máu!");
                request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
                return;
            }

            // Prepare data for JSP
            Map<String, Object> appointmentData = new HashMap<>();
            appointmentData.put("appointmentId", appointment.getAppointmentId());
            appointmentData.put("donorName", donor.getFullName());
            appointmentData.put("donorBloodGroup", donor.getBloodGroup());
            appointmentData.put("donorPhone", donor.getPhone());
            if (appointment.getScheduledAt() != null) {
                appointmentData.put("scheduledAt", Timestamp.valueOf(appointment.getScheduledAt()));
            }

            request.setAttribute("appointment", appointmentData);
            request.setAttribute("hospital", hospital);
            request.getRequestDispatcher("/hospital/complete-donation.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            request.setAttribute("error", "ID lịch hẹn không hợp lệ!");
            request.getRequestDispatcher("/hospital/appointments.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        String appointmentIdStr = request.getParameter("appointmentId");
        if (appointmentIdStr == null) {
            session.setAttribute("error", "Thiếu thông tin lịch hẹn!");
            response.sendRedirect(request.getContextPath() + "/hospital/appointments");
            return;
        }

        try {
            Integer appointmentId = Integer.parseInt(appointmentIdStr);
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            // Verify appointment
            var appointments = hospitalService.getAppointments(hospital.getHospitalId());
            Appointment appointment = appointments.stream()
                    .filter(apt -> apt.getAppointmentId().equals(appointmentId))
                    .findFirst()
                    .orElse(null);

            if (appointment == null || !"CONFIRMED".equals(appointment.getStatus())) {
                session.setAttribute("error", "Lịch hẹn không hợp lệ!");
                response.sendRedirect(request.getContextPath() + "/hospital/appointments");
                return;
            }

            Map<String, String[]> paramMap = request.getParameterMap();
            List<BloodBag> bagInputs = new ArrayList<>();

            try {
                paramMap.entrySet().stream()
                    .filter(entry -> entry.getKey().startsWith("bags[") && entry.getKey().endsWith("]"))
                    .map(entry -> entry.getKey().substring(0, entry.getKey().indexOf(']') + 1))
                    .distinct()
                    .forEach(keyPrefix -> {
                        String bloodGroup = request.getParameter(keyPrefix + "[bloodGroup]");
                        String component = request.getParameter(keyPrefix + "[component]");
                        String quantityStr = request.getParameter(keyPrefix + "[quantityMl]");
                        String collectionDateStr = request.getParameter(keyPrefix + "[collectionDate]");

                        if ((bloodGroup != null && !bloodGroup.trim().isEmpty()) ||
                            (component != null && !component.trim().isEmpty()) ||
                            (quantityStr != null && !quantityStr.trim().isEmpty())) {

                            BloodBag bag = new BloodBag();
                            bag.setBloodGroup(bloodGroup != null ? bloodGroup.trim().toUpperCase() : null);
                            bag.setComponent(component != null ? component.trim().toUpperCase() : null);
                            if (quantityStr != null && !quantityStr.trim().isEmpty()) {
                                try {
                                    bag.setVolumeMl(Integer.parseInt(quantityStr.trim()));
                                } catch (NumberFormatException ex) {
                                    throw new IllegalArgumentException("Số lượng túi máu không hợp lệ");
                                }
                            }
                            if (collectionDateStr != null && !collectionDateStr.trim().isEmpty()) {
                                bag.setCollectionDate(LocalDate.parse(collectionDateStr));
                            } else {
                                bag.setCollectionDate(LocalDate.now());
                            }
                            bagInputs.add(bag);
                        }
                    });
            } catch (IllegalArgumentException parseEx) {
                session.setAttribute("error", parseEx.getMessage());
                response.sendRedirect(request.getContextPath() + "/hospital/complete-donation?appointmentId=" + appointmentId);
                return;
            }

            if (bagInputs.isEmpty()) {
                session.setAttribute("error", "Vui lòng nhập ít nhất một túi máu hợp lệ!");
                response.sendRedirect(request.getContextPath() + "/hospital/complete-donation?appointmentId=" + appointmentId);
                return;
            }

            // Tạo donation record
            java.time.LocalDate donationDate = java.time.LocalDate.now();
            var donationRecord = hospitalService.createDonationRecord(
                appointment.getDonorId(),
                hospital.getHospitalId(),
                donationDate,
                bagInputs
            );

            if (donationRecord != null) {
                // Update appointment status to COMPLETED
                appointment.setStatus("COMPLETED");
                appointment.setUpdatedAt(LocalDateTime.now());
                boolean success = hospitalService.updateAppointment(appointment);
                
                if (success) {
                    int totalQuantity = donationRecord.getQuantityMl() != null ? donationRecord.getQuantityMl() : 0;
                    String displayGroup = donationRecord.getMeasuredBloodGroup() != null ? donationRecord.getMeasuredBloodGroup() : "N/A";
                    session.setAttribute("success", String.format("Đã ghi nhận hiến máu thành công! %d ml nhóm máu %s", 
                                                                 totalQuantity, displayGroup));
                } else {
                    session.setAttribute("error", "Đã tạo donation record nhưng không thể cập nhật trạng thái appointment!");
                }
            } else {
                session.setAttribute("error", "Không thể tạo donation record!");
            }

            response.sendRedirect(request.getContextPath() + "/hospital/appointments");
            
        } catch (NumberFormatException e) {
            session.setAttribute("error", "ID lịch hẹn không hợp lệ!");
            response.sendRedirect(request.getContextPath() + "/hospital/appointments");
        } catch (SQLException e) {
            e.printStackTrace();
            session.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/hospital/appointments");
        }
    }
}

