package com.bloodlink.servlet.common;

import com.bloodlink.model.User;
import com.bloodlink.service.NotificationService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servlet để xử lý notification endpoints
 * GET /notifications - Hiển thị trang danh sách notifications
 * POST /notifications/mark-all-read - Đánh dấu tất cả đã đọc
 * PATCH /notifications/:id/read - Đánh dấu notification đã đọc
 */
@WebServlet({"/notifications", "/notifications/*"})
public class NotificationServlet extends HttpServlet {
    private NotificationService notificationService;

    @Override
    public void init() throws ServletException {
        super.init();
        notificationService = new NotificationService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        String pathInfo = request.getPathInfo();
        
        // GET /notifications - Hiển thị trang notifications
        // pathInfo có thể là null (khi request đến /notifications) hoặc "/" (khi request đến /notifications/)
        if (pathInfo == null || pathInfo.equals("/") || pathInfo.isEmpty() || pathInfo.equals("")) {
            try {
                String filter = request.getParameter("filter"); // "all" hoặc "unread"
                List<com.bloodlink.model.Notification> notificationsRaw;
                
                if ("unread".equals(filter)) {
                    notificationsRaw = notificationService.getUnreadNotifications(user.getUserId());
                } else {
                    notificationsRaw = notificationService.getUserNotifications(user.getUserId());
                }
                
                // Enrich notifications với Timestamp cho JSP
                List<Map<String, Object>> notifications = new ArrayList<>();
                if (notificationsRaw != null) {
                    for (var notif : notificationsRaw) {
                        if (notif != null) {
                            Map<String, Object> enriched = new HashMap<>();
                            enriched.put("notificationId", notif.getNotificationId());
                            enriched.put("userId", notif.getUserId());
                            enriched.put("type", notif.getType());
                            enriched.put("subject", notif.getSubject());
                            enriched.put("message", notif.getMessage());
                            enriched.put("link", notif.getLink());
                            enriched.put("isRead", notif.getIsRead());
                            if (notif.getCreatedAt() != null) {
                                enriched.put("createdAt", Timestamp.valueOf(notif.getCreatedAt()));
                            } else {
                                enriched.put("createdAt", null);
                            }
                            notifications.add(enriched);
                        }
                    }
                }
                
                // Đếm số lượng unread
                int unreadCount = notificationService.getUnreadNotifications(user.getUserId()).size();
                
                request.setAttribute("notifications", notifications);
                request.setAttribute("unreadCount", unreadCount);
                request.setAttribute("filter", filter != null ? filter : "all");
                
                request.getRequestDispatcher("/notifications.jsp").forward(request, response);
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Lỗi khi tải thông báo: " + e.getMessage());
                request.getRequestDispatcher("/notifications.jsp").forward(request, response);
            }
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            sendJsonResponse(response, HttpServletResponse.SC_UNAUTHORIZED, 
                "error", "Bạn cần đăng nhập để thực hiện thao tác này");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        String pathInfo = request.getPathInfo();
        
        // POST /notifications/mark-all-read
        if (pathInfo != null && pathInfo.equals("/mark-all-read")) {
            try {
                boolean success = notificationService.markAllAsRead(user.getUserId());
                if (success) {
                    sendJsonResponse(response, HttpServletResponse.SC_OK,
                        "success", "Đã đánh dấu tất cả thông báo là đã đọc");
                } else {
                    sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                        "error", "Không thể đánh dấu tất cả thông báo");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "error", "Lỗi hệ thống: " + e.getMessage());
            }
        } else {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Endpoint không hợp lệ");
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPatch(request, response);
    }

    /**
     * Handle PATCH request (mapped via doPut)
     */
    private void doPatch(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            sendJsonResponse(response, HttpServletResponse.SC_UNAUTHORIZED, 
                "error", "Bạn cần đăng nhập để thực hiện thao tác này");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        String pathInfo = request.getPathInfo();
        
        // PATCH /notifications/:id/read
        if (pathInfo != null && pathInfo.matches("/\\d+/read")) {
            try {
                Long notificationId = Long.parseLong(pathInfo.substring(1, pathInfo.indexOf("/read")));
                
                // Kiểm tra notification có thuộc về user không
                var notification = notificationService.getNotificationById(notificationId);
                if (notification == null) {
                    sendJsonResponse(response, HttpServletResponse.SC_NOT_FOUND,
                        "error", "Không tìm thấy thông báo");
                    return;
                }
                
                if (!notification.getUserId().equals(user.getUserId())) {
                    sendJsonResponse(response, HttpServletResponse.SC_FORBIDDEN,
                        "error", "Bạn không có quyền truy cập thông báo này");
                    return;
                }
                
                // Đánh dấu đã đọc
                boolean success = notificationService.markAsRead(notificationId);
                
                if (success) {
                    sendJsonResponse(response, HttpServletResponse.SC_OK,
                        "success", "Đã đánh dấu thông báo là đã đọc");
                } else {
                    sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                        "error", "Không thể đánh dấu thông báo");
                }
                
            } catch (NumberFormatException e) {
                sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                    "error", "ID thông báo không hợp lệ");
            } catch (SQLException e) {
                e.printStackTrace();
                sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "error", "Lỗi hệ thống: " + e.getMessage());
            }
        } else {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Endpoint không hợp lệ");
        }
    }

    /**
     * Gửi JSON response
     */
    private void sendJsonResponse(HttpServletResponse response, int statusCode, 
                                   String key, String message) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(statusCode);
        PrintWriter out = response.getWriter();
        out.print(String.format("{\"%s\":\"%s\"}", key, escapeJson(message)));
        out.flush();
    }

    /**
     * Escape JSON string
     */
    private String escapeJson(String str) {
        if (str == null) {
            return "";
        }
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}

