package com.bloodlink.servlet.common;

import com.bloodlink.dao.BloodBagDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.Hospital;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * CentersServlet - Handle blood centers map page
 * Loads hospitals from database with inventory statistics
 */
@WebServlet("/centers")
public class CentersServlet extends HttpServlet {
    private HospitalDAO hospitalDAO;
    private BloodBagDAO bloodBagDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        this.hospitalDAO = new HospitalDAO();
        this.bloodBagDAO = new BloodBagDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // Load all hospitals
            List<Hospital> hospitals = hospitalDAO.findAll();
            
            // Enrich hospitals with inventory statistics
            List<Map<String, Object>> enrichedHospitals = new ArrayList<>();
            Map<String, Integer> bloodGroupStats = new HashMap<>();
            
            for (Hospital hospital : hospitals) {
                Map<String, Object> enriched = new HashMap<>();
                enriched.put("hospitalId", hospital.getHospitalId());
                enriched.put("name", hospital.getName());
                enriched.put("address", hospital.getAddress());
                enriched.put("contact", hospital.getContact());
                enriched.put("region", hospital.getRegion());
                enriched.put("latitude", hospital.getLatitude());
                enriched.put("longitude", hospital.getLongitude());
                
                // Get inventory statistics for this hospital
                try {
                    List<com.bloodlink.model.BloodBag> bags = bloodBagDAO.findByHospitalId(hospital.getHospitalId());
                    int totalBags = bags.size();
                    int availableBags = (int) bags.stream()
                        .filter(b -> "AVAILABLE".equals(b.getStatus()))
                        .count();
                    
                    enriched.put("totalBags", totalBags);
                    enriched.put("availableBags", availableBags);
                    
                    // Calculate inventory status
                    String status = "good"; // default
                    if (totalBags == 0) {
                        status = "empty";
                    } else {
                        double availability = (double) availableBags / totalBags;
                        if (availability < 0.3) {
                            status = "critical";
                        } else if (availability < 0.6) {
                            status = "low";
                        }
                    }
                    enriched.put("inventoryStatus", status);
                    
                    // Count by blood group for statistics
                    Map<String, Integer> bgCounts = new HashMap<>();
                    for (com.bloodlink.model.BloodBag bag : bags) {
                        if ("AVAILABLE".equals(bag.getStatus())) {
                            String bg = bag.getBloodGroup();
                            bgCounts.put(bg, bgCounts.getOrDefault(bg, 0) + 1);
                            bloodGroupStats.put(bg, bloodGroupStats.getOrDefault(bg, 0) + 1);
                        }
                    }
                    // Convert Map to format suitable for JSP
                    enriched.put("bloodGroupCounts", bgCounts);
                    // Also store as JSON string for JavaScript
                    StringBuilder bgJson = new StringBuilder("{");
                    boolean first = true;
                    for (Map.Entry<String, Integer> entry : bgCounts.entrySet()) {
                        if (!first) bgJson.append(",");
                        bgJson.append("\"").append(entry.getKey()).append("\":").append(entry.getValue());
                        first = false;
                    }
                    bgJson.append("}");
                    enriched.put("bloodGroupCountsJson", bgJson.length() > 2 ? bgJson.toString() : "{}");
                    
                } catch (SQLException e) {
                    enriched.put("totalBags", 0);
                    enriched.put("availableBags", 0);
                    enriched.put("inventoryStatus", "unknown");
                    enriched.put("bloodGroupCounts", new HashMap<String, Integer>());
                    enriched.put("bloodGroupCountsJson", "{}");
                }
                
                enrichedHospitals.add(enriched);
            }
            
            // Calculate overall statistics
            int totalCenters = hospitals.size();
            int totalBags = bloodGroupStats.values().stream().mapToInt(Integer::intValue).sum();
            
            // Set request attributes
            request.setAttribute("hospitals", enrichedHospitals);
            request.setAttribute("totalCenters", totalCenters);
            request.setAttribute("totalBags", totalBags);
            request.setAttribute("bloodGroupStats", bloodGroupStats);
            
            // Forward to JSP
            request.getRequestDispatcher("/centers.jsp").forward(request, response);
            
        } catch (SQLException e) {
            System.err.println("[CentersServlet] Database error: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu trung tâm hiến máu");
            request.getRequestDispatcher("/centers.jsp").forward(request, response);
        }
    }
}

