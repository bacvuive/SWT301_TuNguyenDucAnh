package com.bloodlink.servlet.common;

import com.bloodlink.model.Hospital;
import com.bloodlink.model.TransferEvent;
import com.bloodlink.model.TransferRequest;
import com.bloodlink.model.User;
import com.bloodlink.service.TransferService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

/**
 * Servlet xử lý điều phối túi máu giữa các bệnh viện
 * Endpoints:
 * - POST /transfers - Tạo transfer request và allocate bags
 * - POST /transfers/:id/events - Xử lý event (PICKED_UP, IN_TRANSIT, DELIVERED, CANCELLED)
 * - GET /transfers/:id - Xem chi tiết transfer với events và bags
 */
@WebServlet("/transfers/*")
public class TransferServlet extends HttpServlet {
    private TransferService transferService;

    @Override
    public void init() throws ServletException {
        super.init();
        transferService = new TransferService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            sendJsonResponse(response, HttpServletResponse.SC_UNAUTHORIZED, 
                "error", "Bạn cần đăng nhập để thực hiện thao tác này");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equalsIgnoreCase(user.getRoleCode()) && 
            !"admin".equalsIgnoreCase(user.getRoleCode())) {
            sendJsonResponse(response, HttpServletResponse.SC_FORBIDDEN,
                "error", "Bạn không có quyền thực hiện thao tác này");
            return;
        }

        // Parse request path: /transfers/:id
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Thiếu ID transfer request");
            return;
        }

        String[] pathParts = pathInfo.split("/");
        if (pathParts.length < 2) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Định dạng URL không hợp lệ");
            return;
        }

        Integer transferId;
        try {
            transferId = Integer.parseInt(pathParts[1]);
        } catch (NumberFormatException e) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "ID transfer request không hợp lệ");
            return;
        }

        try {
            TransferRequest transfer = transferService.getTransferWithDetails(transferId);
            if (transfer == null) {
                sendJsonResponse(response, HttpServletResponse.SC_NOT_FOUND,
                    "error", "Transfer request không tồn tại");
                return;
            }

            // Lấy events và bags
            List<TransferEvent> events = transferService.getTransferEvents(transferId);
            var bags = transferService.getTransferBags(transferId);

            // Build JSON response
            response.setContentType("application/json;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.print(buildTransferJson(transfer, events, bags));
            out.flush();

        } catch (SQLException e) {
            e.printStackTrace();
            sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "error", "Lỗi hệ thống: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            sendJsonResponse(response, HttpServletResponse.SC_UNAUTHORIZED, 
                "error", "Bạn cần đăng nhập để thực hiện thao tác này");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equalsIgnoreCase(user.getRoleCode()) && 
            !"admin".equalsIgnoreCase(user.getRoleCode())) {
            sendJsonResponse(response, HttpServletResponse.SC_FORBIDDEN,
                "error", "Bạn không có quyền thực hiện thao tác này");
            return;
        }

        // Parse request path
        String pathInfo = request.getPathInfo();
        
        if (pathInfo == null || pathInfo.equals("/")) {
            // POST /transfers - Tạo transfer request
            handleCreateTransfer(request, response, user);
        } else {
            // POST /transfers/:id/events - Xử lý event
            handleTransferEvent(request, response, user);
        }
    }

    /**
     * Xử lý tạo transfer request
     */
    private void handleCreateTransfer(HttpServletRequest request, HttpServletResponse response,
                                      User user) throws IOException {
        try {
            // Get hospital info
            Hospital hospital = (Hospital) request.getSession().getAttribute("hospital");
            if (hospital == null) {
                sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                    "error", "Không tìm thấy thông tin bệnh viện");
                return;
            }

            // Parse parameters
            String requestIdStr = request.getParameter("requestId");
            Integer requestId = (requestIdStr != null && !requestIdStr.trim().isEmpty()) 
                ? Integer.parseInt(requestIdStr) : null;
            
            String toHospitalIdStr = request.getParameter("toHospitalId");
            if (toHospitalIdStr == null || toHospitalIdStr.trim().isEmpty()) {
                sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                    "error", "Thiếu thông tin bệnh viện nhận");
                return;
            }
            Integer toHospitalId = Integer.parseInt(toHospitalIdStr);

            String bloodGroup = request.getParameter("bloodGroup");
            String component = request.getParameter("component");
            String unitsStr = request.getParameter("units");

            if (bloodGroup == null || component == null || unitsStr == null) {
                sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                    "error", "Thiếu thông tin: bloodGroup, component, units");
                return;
            }

            Integer units = Integer.parseInt(unitsStr);

            // Tạo transfer request
            TransferRequest transfer = transferService.createTransferWithAllocation(
                requestId,
                hospital.getHospitalId(),
                toHospitalId,
                bloodGroup,
                component,
                units
            );

            response.setContentType("application/json;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.print(String.format(
                "{\"success\":true,\"transferId\":%d,\"message\":\"Tạo transfer request thành công và đã allocate %d túi máu\"}",
                transfer.getTransferId(), units
            ));
            out.flush();

        } catch (NumberFormatException e) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Dữ liệu không hợp lệ: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "error", "Lỗi hệ thống: " + e.getMessage());
        }
    }

    /**
     * Xử lý transfer event
     */
    private void handleTransferEvent(HttpServletRequest request, HttpServletResponse response,
                                     User user) throws IOException {
        String pathInfo = request.getPathInfo();
        String[] pathParts = pathInfo.split("/");
        
        if (pathParts.length < 3 || !"events".equals(pathParts[2])) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Định dạng URL không hợp lệ. Sử dụng: /transfers/:id/events");
            return;
        }

        Integer transferId;
        try {
            transferId = Integer.parseInt(pathParts[1]);
        } catch (NumberFormatException e) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "ID transfer request không hợp lệ");
            return;
        }

        String eventType = request.getParameter("eventType");
        String note = request.getParameter("note");

        if (eventType == null || eventType.trim().isEmpty()) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Thiếu thông tin eventType");
            return;
        }

        try {
            transferService.handleTransferEvent(transferId, eventType, note, user.getUserId());
            sendJsonResponse(response, HttpServletResponse.SC_OK,
                "success", "Xử lý event thành công");
        } catch (IllegalArgumentException e) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "error", "Lỗi hệ thống: " + e.getMessage());
        }
    }

    /**
     * Build JSON response cho transfer details
     */
    private String buildTransferJson(TransferRequest transfer, List<TransferEvent> events,
                                     List<com.bloodlink.model.BloodBag> bags) {
        StringBuilder json = new StringBuilder();
        json.append("{\n");
        json.append("  \"transferId\": ").append(transfer.getTransferId()).append(",\n");
        json.append("  \"requestId\": ").append(transfer.getRequestId() != null ? transfer.getRequestId() : "null").append(",\n");
        json.append("  \"fromHospitalId\": ").append(transfer.getFromHospitalId()).append(",\n");
        json.append("  \"toHospitalId\": ").append(transfer.getToHospitalId()).append(",\n");
        json.append("  \"bloodGroup\": \"").append(transfer.getBloodGroup()).append("\",\n");
        json.append("  \"component\": \"").append(transfer.getComponent()).append("\",\n");
        json.append("  \"units\": ").append(transfer.getUnits()).append(",\n");
        json.append("  \"status\": \"").append(transfer.getStatus()).append("\",\n");
        json.append("  \"createdAt\": \"").append(transfer.getCreatedAt()).append("\",\n");
        json.append("  \"updatedAt\": \"").append(transfer.getUpdatedAt()).append("\",\n");
        
        // Events
        json.append("  \"events\": [\n");
        for (int i = 0; i < events.size(); i++) {
            TransferEvent event = events.get(i);
            json.append("    {\n");
            json.append("      \"eventId\": ").append(event.getEventId()).append(",\n");
            json.append("      \"eventType\": \"").append(event.getEventType()).append("\",\n");
            json.append("      \"bagId\": ").append(event.getBagId() != null ? event.getBagId() : "null").append(",\n");
            json.append("      \"note\": \"").append(escapeJson(event.getNote())).append("\",\n");
            json.append("      \"createdAt\": \"").append(event.getCreatedAt()).append("\"\n");
            json.append("    }");
            if (i < events.size() - 1) json.append(",");
            json.append("\n");
        }
        json.append("  ],\n");
        
        // Bags
        json.append("  \"bags\": [\n");
        for (int i = 0; i < bags.size(); i++) {
            com.bloodlink.model.BloodBag bag = bags.get(i);
            json.append("    {\n");
            json.append("      \"bagId\": ").append(bag.getBagId()).append(",\n");
            json.append("      \"bagCode\": \"").append(bag.getBagCode()).append("\",\n");
            json.append("      \"bloodGroup\": \"").append(bag.getBloodGroup()).append("\",\n");
            json.append("      \"component\": \"").append(bag.getComponent()).append("\",\n");
            json.append("      \"status\": \"").append(bag.getStatus()).append("\",\n");
            json.append("      \"expiryDate\": \"").append(bag.getExpiryDate()).append("\"\n");
            json.append("    }");
            if (i < bags.size() - 1) json.append(",");
            json.append("\n");
        }
        json.append("  ]\n");
        json.append("}");
        
        return json.toString();
    }

    /**
     * Gửi JSON response
     */
    private void sendJsonResponse(HttpServletResponse response, int statusCode, 
                                   String key, String message) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(statusCode);
        PrintWriter out = response.getWriter();
        out.print(String.format("{\"%s\":\"%s\"}", key, escapeJson(message)));
        out.flush();
    }

    /**
     * Escape JSON string
     */
    private String escapeJson(String str) {
        if (str == null) {
            return "";
        }
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}

