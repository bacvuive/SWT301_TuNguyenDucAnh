package com.bloodlink.servlet.common;

import com.bloodlink.model.User;
import com.bloodlink.service.BloodBagStatusService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Servlet xử lý cập nhật status của blood bag
 * Endpoint: PATCH /bags/:id/status
 */
@WebServlet("/bags/*")
public class BloodBagStatusServlet extends HttpServlet {
    private BloodBagStatusService bloodBagStatusService;

    @Override
    public void init() throws ServletException {
        super.init();
        bloodBagStatusService = new BloodBagStatusService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Xử lý POST như PATCH (do HTML forms không hỗ trợ PATCH)
        doPatch(request, response);
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Xử lý PUT như PATCH
        doPatch(request, response);
    }

    /**
     * Xử lý PATCH request
     */
    private void doPatch(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            sendJsonResponse(response, HttpServletResponse.SC_UNAUTHORIZED, 
                "error", "Bạn cần đăng nhập để thực hiện thao tác này");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        
        // Chỉ cho phép hospital và admin thao tác
        if (!"hospital".equalsIgnoreCase(user.getRoleCode()) && 
            !"admin".equalsIgnoreCase(user.getRoleCode())) {
            sendJsonResponse(response, HttpServletResponse.SC_FORBIDDEN,
                "error", "Bạn không có quyền thực hiện thao tác này");
            return;
        }

        // Parse request path: /bags/:id/status
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Thiếu ID blood bag");
            return;
        }

        String[] pathParts = pathInfo.split("/");
        if (pathParts.length < 3 || !"status".equals(pathParts[2])) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Định dạng URL không hợp lệ. Sử dụng: /bags/:id/status");
            return;
        }

        // Parse bag ID
        Integer bagId;
        try {
            bagId = Integer.parseInt(pathParts[1]);
        } catch (NumberFormatException e) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "ID blood bag không hợp lệ");
            return;
        }

        // Parse status
        String newStatus = request.getParameter("status");
        if (newStatus == null || newStatus.trim().isEmpty()) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Thiếu thông tin status");
            return;
        }

        String note = request.getParameter("note");
        Integer actorUserId = user.getUserId();

        try {
            var result = bloodBagStatusService.updateBagStatus(bagId, newStatus, actorUserId, note);
            var updatedBag = result.getBag();
            
            response.setContentType("application/json;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.print(String.format(
                "{\"success\":true,\"bagId\":%d,\"oldStatus\":\"%s\",\"newStatus\":\"%s\",\"message\":\"Cập nhật status thành công\"}",
                updatedBag.getBagId(),
                result.getOldStatus(),
                updatedBag.getStatus()
            ));
            out.flush();

        } catch (IllegalArgumentException e) {
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "error", "Lỗi hệ thống: " + e.getMessage());
        }
    }

    /**
     * Gửi JSON response
     */
    private void sendJsonResponse(HttpServletResponse response, int statusCode, 
                                   String key, String message) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(statusCode);
        PrintWriter out = response.getWriter();
        out.print(String.format("{\"%s\":\"%s\"}", key, escapeJson(message)));
        out.flush();
    }

    /**
     * Escape JSON string
     */
    private String escapeJson(String str) {
        if (str == null) {
            return "";
        }
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}

