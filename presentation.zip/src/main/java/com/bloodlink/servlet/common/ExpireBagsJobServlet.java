package com.bloodlink.servlet.common;

import com.bloodlink.model.User;
import com.bloodlink.service.ExpireBagsService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Servlet để chạy job expire bags
 * Endpoint: POST /jobs/expire-bags
 */
@WebServlet("/jobs/expire-bags")
public class ExpireBagsJobServlet extends HttpServlet {
    private ExpireBagsService expireBagsService;

    @Override
    public void init() throws ServletException {
        super.init();
        expireBagsService = new ExpireBagsService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            sendJsonResponse(response, HttpServletResponse.SC_UNAUTHORIZED, 
                "error", "Bạn cần đăng nhập để thực hiện thao tác này");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        
        // Chỉ cho phép admin chạy job
        if (!"admin".equalsIgnoreCase(user.getRoleCode())) {
            sendJsonResponse(response, HttpServletResponse.SC_FORBIDDEN,
                "error", "Chỉ quản trị viên mới có quyền chạy job này");
            return;
        }

        try {
            var result = expireBagsService.expireExpiredBags();
            
            response.setContentType("application/json;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.print(String.format(
                "{\"success\":true,\"expiredCount\":%d,\"expiredBagIds\":%s,\"message\":\"Đã expire %d túi máu quá hạn\"}",
                result.getExpiredCount(),
                formatBagIdsJson(result.getExpiredBagIds()),
                result.getExpiredCount()
            ));
            out.flush();

        } catch (SQLException e) {
            e.printStackTrace();
            sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                "error", "Lỗi hệ thống: " + e.getMessage());
        }
    }

    /**
     * Format list of bag IDs thành JSON array
     */
    private String formatBagIdsJson(java.util.List<Integer> bagIds) {
        if (bagIds == null || bagIds.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < bagIds.size(); i++) {
            sb.append(bagIds.get(i));
            if (i < bagIds.size() - 1) {
                sb.append(",");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * Gửi JSON response
     */
    private void sendJsonResponse(HttpServletResponse response, int statusCode, 
                                   String key, String message) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(statusCode);
        PrintWriter out = response.getWriter();
        out.print(String.format("{\"%s\":\"%s\"}", key, escapeJson(message)));
        out.flush();
    }

    /**
     * Escape JSON string
     */
    private String escapeJson(String str) {
        if (str == null) {
            return "";
        }
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}

