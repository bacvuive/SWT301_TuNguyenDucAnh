package com.bloodlink.servlet.common;

import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.service.HospitalService;
import com.bloodlink.service.ReportService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * ReportServlet - Handle report generation requests
 * Supports Excel export for inventory, donations, and requests
 */
@WebServlet("/hospital/reports")
public class ReportServlet extends HttpServlet {
    private ReportService reportService;
    private HospitalService hospitalService;

    @Override
    public void init() throws ServletException {
        super.init();
        this.reportService = new ReportService();
        this.hospitalService = new HospitalService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"hospital".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            Hospital hospital = hospitalService.getHospitalByUserId(user.getUserId());
            if (hospital == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            String reportType = request.getParameter("type");
            String format = request.getParameter("format");

            if (reportType == null || format == null) {
                // Show reports page
                request.setAttribute("hospital", hospital);
                request.getRequestDispatcher("/hospital/reports.jsp").forward(request, response);
                return;
            }

            // Generate report
            byte[] reportData = null;
            String fileName = "";

            switch (reportType) {
                case "inventory":
                    reportData = reportService.generateInventoryReport(
                        hospital.getHospitalId(), hospital.getName());
                    fileName = "bao-cao-kho-mau-" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + ".xlsx";
                    break;

                case "donations":
                    LocalDate fromDate = null;
                    LocalDate toDate = null;
                    
                    String fromDateStr = request.getParameter("fromDate");
                    String toDateStr = request.getParameter("toDate");
                    
                    if (fromDateStr != null && !fromDateStr.isEmpty()) {
                        fromDate = LocalDate.parse(fromDateStr);
                    }
                    if (toDateStr != null && !toDateStr.isEmpty()) {
                        toDate = LocalDate.parse(toDateStr);
                    }
                    
                    reportData = reportService.generateDonationReport(
                        hospital.getHospitalId(), hospital.getName(), fromDate, toDate);
                    fileName = "bao-cao-hien-mau-" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + ".xlsx";
                    break;

                case "requests":
                    reportData = reportService.generateRequestReport(
                        hospital.getHospitalId(), hospital.getName());
                    fileName = "bao-cao-yeu-cau-mau-" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + ".xlsx";
                    break;

                default:
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid report type");
                    return;
            }

            if (reportData == null) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to generate report");
                return;
            }

            // Set response headers for file download
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
            response.setContentLength(reportData.length);

            // Write file to response
            response.getOutputStream().write(reportData);
            response.getOutputStream().flush();

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating report: " + e.getMessage());
        }
    }
}

