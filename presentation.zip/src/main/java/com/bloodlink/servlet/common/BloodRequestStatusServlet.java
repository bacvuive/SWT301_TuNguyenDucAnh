package com.bloodlink.servlet.common;

import com.bloodlink.model.User;
import com.bloodlink.service.BloodRequestService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Servlet xử lý cập nhật trạng thái yêu cầu máu
 * Endpoints:
 * - PATCH /requests/:id/accept - Chấp nhận yêu cầu (PENDING → ACCEPTED)
 * - PATCH /requests/:id/reject - Từ chối yêu cầu (PENDING → REJECTED)
 * - PATCH /requests/:id/complete - Hoàn tất yêu cầu (ACCEPTED → COMPLETED)
 */
@WebServlet("/requests/*")
public class BloodRequestStatusServlet extends HttpServlet {
    private BloodRequestService bloodRequestService;

    @Override
    public void init() throws ServletException {
        super.init();
        bloodRequestService = new BloodRequestService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Xử lý POST như PATCH (do HTML forms không hỗ trợ PATCH)
        doPatch(request, response);
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Xử lý PUT như PATCH
        doPatch(request, response);
    }

    /**
     * Xử lý PATCH request (thông qua POST hoặc PUT)
     */
    private void doPatch(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            // Nếu không phải AJAX, redirect về login
            String requestedWith = request.getHeader("X-Requested-With");
            if (!"XMLHttpRequest".equals(requestedWith)) {
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }
            sendJsonResponse(response, HttpServletResponse.SC_UNAUTHORIZED, 
                "error", "Bạn cần đăng nhập để thực hiện thao tác này");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        
        // Chỉ cho phép hospital và admin thao tác
        if (!"hospital".equalsIgnoreCase(user.getRoleCode()) && 
            !"admin".equalsIgnoreCase(user.getRoleCode())) {
            String requestedWith = request.getHeader("X-Requested-With");
            if (!"XMLHttpRequest".equals(requestedWith)) {
                session.setAttribute("error", "Bạn không có quyền thực hiện thao tác này");
                response.sendRedirect(request.getContextPath() + "/hospital/requests");
                return;
            }
            sendJsonResponse(response, HttpServletResponse.SC_FORBIDDEN,
                "error", "Bạn không có quyền thực hiện thao tác này");
            return;
        }

        // Parse request path: /requests/{id}/{action}
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            String requestedWith = request.getHeader("X-Requested-With");
            if (!"XMLHttpRequest".equals(requestedWith)) {
                session.setAttribute("error", "Thiếu thông tin yêu cầu máu");
                response.sendRedirect(request.getContextPath() + "/hospital/requests");
                return;
            }
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Thiếu thông tin yêu cầu máu");
            return;
        }

        String[] pathParts = pathInfo.split("/");
        // pathParts[0] sẽ là "" (empty string) vì split("/") tạo phần tử đầu tiên là rỗng
        // pathParts[1] sẽ là requestId
        // pathParts[2] sẽ là action
        if (pathParts.length < 3) {
            String requestedWith = request.getHeader("X-Requested-With");
            if (!"XMLHttpRequest".equals(requestedWith)) {
                session.setAttribute("error", "Định dạng URL không hợp lệ");
                response.sendRedirect(request.getContextPath() + "/hospital/requests");
                return;
            }
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "Định dạng URL không hợp lệ. Sử dụng: /requests/{id}/{accept|reject|complete}");
            return;
        }

        // Parse request ID
        Integer requestId;
        try {
            requestId = Integer.parseInt(pathParts[1]);
        } catch (NumberFormatException e) {
            String requestedWith = request.getHeader("X-Requested-With");
            if (!"XMLHttpRequest".equals(requestedWith)) {
                session.setAttribute("error", "ID yêu cầu máu không hợp lệ");
                response.sendRedirect(request.getContextPath() + "/hospital/requests");
                return;
            }
            sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                "error", "ID yêu cầu máu không hợp lệ");
            return;
        }

        // Parse action
        String action = pathParts[2].toLowerCase();
        String note = request.getParameter("note");
        if (note == null) {
            note = "";
        }

        // Kiểm tra xem có phải AJAX request không
        String requestedWith = request.getHeader("X-Requested-With");
        boolean isAjax = "XMLHttpRequest".equals(requestedWith);

        try {
            Integer actorUserId = user.getUserId();
            boolean success = false;
            String message = "";

            switch (action) {
                case "accept":
                    success = bloodRequestService.acceptRequest(requestId, actorUserId, note);
                    message = "Chấp nhận yêu cầu máu thành công";
                    break;
                    
                case "reject":
                    success = bloodRequestService.rejectRequest(requestId, actorUserId, note);
                    message = "Từ chối yêu cầu máu thành công";
                    break;
                    
                case "complete":
                    success = bloodRequestService.completeRequest(requestId, actorUserId, note);
                    message = "Hoàn tất yêu cầu máu thành công";
                    break;
                    
                default:
                    if (!isAjax) {
                        session.setAttribute("error", "Thao tác không hợp lệ");
                        response.sendRedirect(request.getContextPath() + "/hospital/requests");
                        return;
                    }
                    sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                        "error", "Thao tác không hợp lệ. Chỉ cho phép: accept, reject, complete");
                    return;
            }

            if (success) {
                if (isAjax) {
                    // AJAX request - trả về JSON
                    sendJsonResponse(response, HttpServletResponse.SC_OK,
                        "success", message);
                } else {
                    // Form POST - redirect về trang requests với message
                    session.setAttribute("success", message);
                    response.sendRedirect(request.getContextPath() + "/hospital/requests");
                }
            } else {
                if (isAjax) {
                    // AJAX request - trả về JSON error
                    sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                        "error", "Không thể cập nhật trạng thái yêu cầu máu");
                } else {
                    // Form POST - redirect với error message
                    session.setAttribute("error", "Không thể cập nhật trạng thái yêu cầu máu");
                    response.sendRedirect(request.getContextPath() + "/hospital/requests");
                }
            }

        } catch (IllegalArgumentException e) {
            if (isAjax) {
                sendJsonResponse(response, HttpServletResponse.SC_BAD_REQUEST,
                    "error", e.getMessage());
            } else {
                session.setAttribute("error", e.getMessage());
                response.sendRedirect(request.getContextPath() + "/hospital/requests");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            String errorMsg = "Lỗi hệ thống: " + e.getMessage();
            if (isAjax) {
                sendJsonResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "error", errorMsg);
            } else {
                session.setAttribute("error", errorMsg);
                response.sendRedirect(request.getContextPath() + "/hospital/requests");
            }
        }
    }

    /**
     * Gửi JSON response
     */
    private void sendJsonResponse(HttpServletResponse response, int statusCode, 
                                   String key, String message) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(statusCode);
        PrintWriter out = response.getWriter();
        out.print(String.format("{\"%s\":\"%s\"}", key, escapeJson(message)));
        out.flush();
    }

    /**
     * Escape JSON string
     */
    private String escapeJson(String str) {
        if (str == null) {
            return "";
        }
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t");
    }
}

