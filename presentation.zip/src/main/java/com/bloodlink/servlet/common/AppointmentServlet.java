package com.bloodlink.servlet.common;

import com.bloodlink.model.User;
import com.bloodlink.service.DonorService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@WebServlet("/donor/appointment")
public class AppointmentServlet extends HttpServlet {
    private DonorService donorService;

    @Override
    public void init() throws ServletException {
        super.init();
        donorService = new DonorService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("authUser") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        User user = (User) session.getAttribute("authUser");
        if (!"donor".equals(user.getRoleCode())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        try {
            var donor = donorService.getDonorByUserId(user.getUserId());
            if (donor == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
                return;
            }

            String hospitalIdStr = request.getParameter("hospitalId");
            String scheduledAtStr = request.getParameter("scheduledAt");
            String note = request.getParameter("note");

            if (hospitalIdStr == null || scheduledAtStr == null) {
                request.setAttribute("error", "Vui lòng điền đầy đủ thông tin!");
                request.getRequestDispatcher("/donor/schedule.jsp").forward(request, response);
                return;
            }

            Integer hospitalId = Integer.parseInt(hospitalIdStr);
            LocalDateTime scheduledAt = LocalDateTime.parse(scheduledAtStr, 
                    DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            var appointment = donorService.createAppointment(
                    donor.getDonorId(), hospitalId, scheduledAt, note);

            if (appointment != null) {
                response.sendRedirect(request.getContextPath() + "/donor/history?success=appointment_created");
            } else {
                request.setAttribute("error", "Không thể tạo lịch hẹn!");
                request.getRequestDispatcher("/donor/schedule.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống!");
            request.getRequestDispatcher("/donor/schedule.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Dữ liệu không hợp lệ!");
            request.getRequestDispatcher("/donor/schedule.jsp").forward(request, response);
        }
    }
}

