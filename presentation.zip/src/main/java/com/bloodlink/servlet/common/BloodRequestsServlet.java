package com.bloodlink.servlet.common;

import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.model.BloodRequest;
import com.bloodlink.model.Hospital;
import com.bloodlink.service.BloodRequestService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/requests")
public class BloodRequestsServlet extends HttpServlet {
    private BloodRequestService bloodRequestService;
    private HospitalDAO hospitalDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        bloodRequestService = new BloodRequestService();
        hospitalDAO = new HospitalDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Lấy tất cả yêu cầu máu đang pending (hoặc có thể lấy tất cả)
            List<BloodRequest> allRequests = bloodRequestService.getPendingRequests();
            
            // Enrich requests with hospital information
            List<Map<String, Object>> enrichedRequests = new ArrayList<>();
            for (BloodRequest req : allRequests) {
                Map<String, Object> enriched = new HashMap<>();
                enriched.put("requestId", req.getRequestId());
                enriched.put("fromHospitalId", req.getFromHospitalId());
                enriched.put("toHospitalId", req.getToHospitalId());
                enriched.put("bloodGroup", req.getBloodGroup());
                enriched.put("component", req.getComponent());
                enriched.put("quantity", req.getQuantity());
                enriched.put("status", req.getStatus());
                enriched.put("createdAt", req.getCreatedAt());
                enriched.put("updatedAt", req.getUpdatedAt());
                
                // Lấy thông tin bệnh viện tạo yêu cầu
                Hospital fromHospital = hospitalDAO.findById(req.getFromHospitalId());
                enriched.put("hospitalName", fromHospital != null ? fromHospital.getName() : "Không xác định");
                enriched.put("hospitalAddress", fromHospital != null ? fromHospital.getAddress() : "");
                enriched.put("hospitalRegion", fromHospital != null ? fromHospital.getRegion() : "");
                enriched.put("hospitalContact", fromHospital != null ? fromHospital.getContact() : "");
                
                // Tính thời gian đã trôi qua và mức độ khẩn cấp
                long hoursAgo = 0;
                if (req.getCreatedAt() != null) {
                    hoursAgo = java.time.Duration.between(
                        req.getCreatedAt(), 
                        java.time.LocalDateTime.now()
                    ).toHours();
                    enriched.put("hoursAgo", hoursAgo);
                    if (hoursAgo < 1) {
                        enriched.put("timeAgo", "Vừa mới tạo");
                    } else if (hoursAgo < 24) {
                        enriched.put("timeAgo", hoursAgo + " giờ trước");
                    } else {
                        long daysAgo = hoursAgo / 24;
                        enriched.put("timeAgo", daysAgo + " ngày trước");
                    }
                } else {
                    enriched.put("hoursAgo", 0L);
                    enriched.put("timeAgo", "Không xác định");
                }
                
                // Xác định mức độ khẩn cấp (dựa vào thời gian tạo)
                if (hoursAgo < 6) {
                    enriched.put("urgency", "Khẩn cấp");
                    enriched.put("urgencyBadge", "danger");
                } else if (hoursAgo < 24) {
                    enriched.put("urgency", "Cần gấp");
                    enriched.put("urgencyBadge", "warning");
                } else {
                    enriched.put("urgency", "Bình thường");
                    enriched.put("urgencyBadge", "primary");
                }
                
                enrichedRequests.add(enriched);
            }
            
            // Thống kê theo nhóm máu
            Map<String, Integer> bloodGroupStats = new HashMap<>();
            for (BloodRequest req : allRequests) {
                String bg = req.getBloodGroup();
                bloodGroupStats.put(bg, bloodGroupStats.getOrDefault(bg, 0) + 1);
            }
            
            request.setAttribute("requests", enrichedRequests);
            request.setAttribute("bloodGroupStats", bloodGroupStats);
            request.setAttribute("totalPending", allRequests.size());
            
            request.getRequestDispatcher("/requests.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải dữ liệu yêu cầu máu!");
            request.getRequestDispatcher("/requests.jsp").forward(request, response);
        }
    }
}

