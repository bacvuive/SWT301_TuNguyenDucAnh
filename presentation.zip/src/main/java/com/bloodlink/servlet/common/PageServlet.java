package com.bloodlink.servlet.common;

import com.bloodlink.model.User;
import com.bloodlink.service.AuthService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;

/**
 * Main page servlet handling routing to various JSP pages.
 * Maps to specific routes and forwards to appropriate JSP files.
 */
@WebServlet(
    name = "PageServlet",
    urlPatterns = {
        "/login", "/register", "/donors",
        "/education", "/community", "/about", "/contact", "/newsletter",
        "/donor", "/admin"
    },
    loadOnStartup = 1
)
public class PageServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private AuthService authService;

    @Override
    public void init() throws ServletException {
        super.init();
        authService = new AuthService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String requestURI = request.getRequestURI();
        String contextPath = request.getContextPath();
        String path = requestURI.substring(contextPath.length());
        
        // Normalize path
        if (path == null || path.isEmpty()) {
            path = "/";
        }
        
        // Debug logging
        System.out.println("[PageServlet] Processing GET request: path=" + path + ", URI=" + requestURI);
        
        // Map paths to JSP pages
        String jspPage = mapPathToJsp(path);
        
        if (jspPage == null) {
            // Path not found - return 404
            System.err.println("[PageServlet] Path not mapped: " + path);
            response.sendError(HttpServletResponse.SC_NOT_FOUND, 
                "The requested resource is not available: " + path);
            return;
        }
        
        System.out.println("[PageServlet] Forwarding to JSP: " + jspPage);
        
        // Forward to JSP page
        try {
            RequestDispatcher dispatcher = request.getRequestDispatcher(jspPage);
            if (dispatcher == null) {
                System.err.println("[PageServlet] RequestDispatcher is null for: " + jspPage);
                response.sendError(HttpServletResponse.SC_NOT_FOUND, 
                    "JSP page not found: " + jspPage);
                return;
            }
            
            dispatcher.forward(request, response);
            System.out.println("[PageServlet] Successfully forwarded to: " + jspPage);
        } catch (ServletException | IOException e) {
            System.err.println("[PageServlet] Error forwarding to JSP: " + jspPage);
            System.err.println("[PageServlet] Error: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                "Error loading page: " + e.getMessage());
        }
    }
    
    /**
     * Maps URL path to corresponding JSP page.
     * @param path The request path
     * @return JSP page path or null if not found
     */
    private String mapPathToJsp(String path) {
        // Note: "/" is handled by welcome-file-list in web.xml, not here
        // Note: /hospital/* is handled by HospitalDashboardServlet and other hospital servlets
        return switch (path) {
            case "/login" -> "/login.jsp";
            case "/register" -> "/register.jsp";
            case "/donor" -> "/donor/dashboard.jsp";
            // Note: /requests is handled by BloodRequestsServlet, not here
            case "/donors" -> "/donors.jsp";
            // Note: /centers is now handled by CentersServlet
            case "/education" -> "/education.jsp";
            case "/community" -> "/community/community.jsp";
            case "/about" -> "/about.jsp";
            case "/contact" -> "/contact.jsp";
            case "/newsletter" -> "/newsletter.jsp";
            case "/admin" -> "/admin/dashboard.jsp";
            // Note: /hospital/* routes are handled by dedicated servlets:
            // - /hospital/dashboard -> HospitalDashboardServlet
            // - /hospital/requests/create -> HospitalCreateRequestServlet
            // etc.
            default -> null;
        };
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String requestURI = request.getRequestURI();
        String contextPath = request.getContextPath();
        String path = requestURI.substring(contextPath.length());
        
        // Normalize path
        if (path == null || path.isEmpty()) {
            path = "/";
        }
        
        // Route POST requests
        switch (path) {
            case "/login":
                handleLogin(request, response);
                break;
            case "/register":
                handleRegister(request, response);
                break;
            case "/contact":
                handleContact(request, response);
                break;
            case "/newsletter":
                handleNewsletter(request, response);
                break;
            default:
                response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED,
                    "POST method not allowed for: " + path);
                break;
        }
    }

    /**
     * Handles user login.
     */
    private void handleLogin(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String next = request.getParameter("next");
        
        // Validate input
        if (email == null || password == null || email.trim().isEmpty() || password.isEmpty()) {
            request.setAttribute("error", "Email và mật khẩu không được để trống!");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }
        
        try {
            User user = authService.login(email, password);
            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("authUser", user);
                session.setAttribute("userId", user.getUserId());
                session.setAttribute("role", user.getRoleCode().toUpperCase());
                
                // Load additional info based on role
                try {
                    if ("donor".equalsIgnoreCase(user.getRoleCode())) {
                        var donor = authService.getDonorByUserId(user.getUserId());
                        if (donor != null) {
                            session.setAttribute("donor", donor);
                        }
                    } else if ("hospital".equalsIgnoreCase(user.getRoleCode())) {
                        var hospital = authService.getHospitalByUserId(user.getUserId());
                        if (hospital != null) {
                            session.setAttribute("hospital", hospital);
                        }
                    }
                } catch (SQLException e) {
                    System.err.println("[PageServlet] Warning: Could not load user profile: " + e.getMessage());
                    // Continue login even if profile loading fails
                }
                
                // Redirect to appropriate dashboard
                String redirectUrl = determineRedirectUrl(user.getRoleCode(), request.getContextPath());
                if (next != null && !next.isEmpty()) {
                    redirectUrl = request.getContextPath() + next;
                }
                response.sendRedirect(redirectUrl);
            } else {
                request.setAttribute("error", "Email hoặc mật khẩu không đúng, hoặc tài khoản đã bị khóa!");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            System.err.println("[PageServlet] SQL Exception in login: " + e.getMessage());
            e.printStackTrace();
            String errorMsg = "Lỗi hệ thống: " + e.getMessage();
            if (e.getMessage() != null && 
                (e.getMessage().contains("connection") || e.getMessage().contains("connect"))) {
                errorMsg = "Không thể kết nối đến database. Vui lòng kiểm tra cấu hình trong DBConnection.java";
            }
            request.setAttribute("error", errorMsg);
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        } catch (Exception e) {
            System.err.println("[PageServlet] Unexpected exception in login: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống: " + e.getClass().getSimpleName());
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }

    /**
     * Determines redirect URL based on user role.
     * Redirects to servlet endpoints, not JSP files directly.
     */
    private String determineRedirectUrl(String roleCode, String contextPath) {
        if (roleCode == null || contextPath == null) {
            return contextPath + "/";
        }
        
        return switch (roleCode.toLowerCase()) {
            case "admin" -> contextPath + "/admin/dashboard";  // Admin dashboard servlet
            case "hospital" -> contextPath + "/hospital/dashboard";  // HospitalDashboardServlet
            case "donor" -> contextPath + "/donor/dashboard";  // DonorDashboardServlet
            default -> contextPath + "/";
        };
    }

    /**
     * Handles user registration.
     */
    private void handleRegister(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        String phone = request.getParameter("phone");
        String role = request.getParameter("role");
        String bloodType = request.getParameter("bloodType");
        String address = request.getParameter("address");
        String gender = request.getParameter("gender");
        String dob = request.getParameter("dob");
        String next = request.getParameter("next");
        
        // Debug logging
        System.out.println("[PageServlet] Register - Role: [" + role + "]");
        
        // Validate required fields
        if (fullName == null || email == null || password == null ||
            fullName.trim().isEmpty() || email.trim().isEmpty() || password.isEmpty()) {
            request.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc!");
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }
        
        // Validate password confirmation
        if (!password.equals(confirmPassword)) {
            request.setAttribute("error", "Mật khẩu xác nhận không khớp!");
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }
        
        // Validate role selection
        if (role == null || role.trim().isEmpty()) {
            request.setAttribute("error", "Vui lòng chọn loại tài khoản!");
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }
        
        try {
            User user;
            String roleLower = role.toLowerCase().trim();
            System.out.println("[PageServlet] Register - Normalized role: [" + roleLower + "]");
            
            if ("donor".equals(roleLower)) {
                // Register as donor
                String username = email.split("@")[0];
                user = authService.registerDonor(username, email, password, fullName,
                                                bloodType, phone, address, gender, dob);
                request.setAttribute("success", "Đăng ký thành công! Vui lòng đăng nhập.");
            } else if ("hospital".equals(roleLower)) {
                // Register as hospital - create new hospital
                String username = email.split("@")[0];
                String hospitalName = request.getParameter("hospitalName");
                String hospitalContact = request.getParameter("hospitalContact");
                String hospitalRegion = request.getParameter("hospitalRegion");
                
                if (hospitalName == null || hospitalName.trim().isEmpty()) {
                    request.setAttribute("error", "Vui lòng nhập tên bệnh viện!");
                    request.getRequestDispatcher("/register.jsp").forward(request, response);
                    return;
                }
                
                if (address == null || address.trim().isEmpty()) {
                    request.setAttribute("error", "Vui lòng nhập địa chỉ bệnh viện!");
                    request.getRequestDispatcher("/register.jsp").forward(request, response);
                    return;
                }
                
                // Create new hospital with provided information
                user = authService.registerHospital(username, email, password,
                        hospitalName.trim(), address.trim(),
                        hospitalContact != null ? hospitalContact.trim() : null,
                        hospitalRegion != null ? hospitalRegion.trim() : null);
                request.setAttribute("success", "Đăng ký thành công! Vui lòng đăng nhập.");
            } else {
                request.setAttribute("error", "Vui lòng chọn loại tài khoản hợp lệ!");
                request.getRequestDispatcher("/register.jsp").forward(request, response);
                return;
            }
            
            // Redirect after successful registration
            if (next != null && !next.isEmpty()) {
                response.sendRedirect(request.getContextPath() + next);
            } else {
                response.sendRedirect(request.getContextPath() + "/login");
            }
        } catch (IllegalArgumentException e) {
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("/register.jsp").forward(request, response);
        } catch (SQLException e) {
            System.err.println("[PageServlet] SQL Exception in register: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống. Vui lòng thử lại sau!");
            request.getRequestDispatcher("/register.jsp").forward(request, response);
        }
    }

    /**
     * Handles contact form submission.
     */
    private void handleContact(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String bloodType = request.getParameter("bloodType");
        String message = request.getParameter("message");
        
        if (fullName != null && email != null && phone != null &&
            !fullName.trim().isEmpty() && !email.trim().isEmpty() && !phone.trim().isEmpty()) {
            request.setAttribute("success", "Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm nhất có thể.");
        } else {
            request.setAttribute("error", "Vui lòng điền đầy đủ thông tin bắt buộc!");
        }
        
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    /**
     * Handles newsletter subscription.
     */
    private void handleNewsletter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        
        if (email != null && !email.trim().isEmpty()) {
            request.setAttribute("success", "Đăng ký nhận tin thành công!");
        } else {
            request.setAttribute("error", "Vui lòng nhập email!");
        }
        
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
