package com.bloodlink.service;

import com.bloodlink.dao.AppointmentDAO;
import com.bloodlink.dao.DonationRecordDAO;
import com.bloodlink.dao.DonorDAO;
import com.bloodlink.model.Appointment;
import com.bloodlink.model.DonationRecord;
import com.bloodlink.model.Donor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DonorServiceTest {

    @Mock
    private DonorDAO donorDAO;

    @Mock
    private DonationRecordDAO donationRecordDAO;

    @Mock
    private AppointmentDAO appointmentDAO;

    private DonorService donorService;

    @BeforeEach
    void setUp() {
        donorService = new DonorService(donorDAO, donationRecordDAO, appointmentDAO);
    }

    @Test
    void createAppointmentPersistsAndReturnsSavedEntity() throws SQLException {
        Appointment saved = new Appointment();
        saved.setAppointmentId(77);
        saved.setDonorId(10);
        saved.setHospitalId(5);

        when(appointmentDAO.create(any(Appointment.class))).thenReturn(77);
        when(appointmentDAO.findById(77)).thenReturn(saved);

        Appointment result = donorService.createAppointment(
                10,
                5,
                LocalDateTime.of(2025, 1, 20, 14, 0),
                "Bring ID"
        );

        assertNotNull(result);
        assertEquals(77, result.getAppointmentId());

        verify(appointmentDAO).create(any(Appointment.class));
        verify(appointmentDAO).findById(77);
        verifyNoMoreInteractions(appointmentDAO, donorDAO, donationRecordDAO);
    }

    @Test
    void getUpcomingAppointmentsFiltersPastAndCancelled() throws SQLException {
        LocalDateTime now = LocalDateTime.now();
        Appointment upcoming = new Appointment();
        upcoming.setScheduledAt(now.plusDays(1));
        upcoming.setStatus("PENDING");

        Appointment past = new Appointment();
        past.setScheduledAt(now.minusDays(1));
        past.setStatus("COMPLETED");

        Appointment cancelled = new Appointment();
        cancelled.setScheduledAt(now.plusDays(2));
        cancelled.setStatus("CANCELLED");

        when(appointmentDAO.findByDonorId(10)).thenReturn(List.of(upcoming, past, cancelled));

        List<Appointment> result = donorService.getUpcomingAppointments(10);

        assertEquals(1, result.size());
        assertSame(upcoming, result.get(0));
        verify(appointmentDAO).findByDonorId(10);
        verifyNoMoreInteractions(appointmentDAO);
        verifyNoMoreInteractions(donorDAO, donationRecordDAO);
    }

    @Test
    void getUpcomingAppointmentsSortsByDateAscending() throws SQLException {
        LocalDateTime now = LocalDateTime.now();
        Appointment later = new Appointment();
        later.setScheduledAt(now.plusDays(5));
        later.setStatus("PENDING");

        Appointment sooner = new Appointment();
        sooner.setScheduledAt(now.plusDays(2));
        sooner.setStatus("PENDING");

        when(appointmentDAO.findByDonorId(20)).thenReturn(List.of(later, sooner));

        List<Appointment> result = donorService.getUpcomingAppointments(20);

        assertEquals(List.of(sooner, later), result);
        verify(appointmentDAO).findByDonorId(20);
        verifyNoMoreInteractions(appointmentDAO);
        verifyNoMoreInteractions(donorDAO, donationRecordDAO);
    }

    @Test
    void getDonorByUserIdDelegatesToDao() throws SQLException {
        Donor donor = new Donor();
        when(donorDAO.findByUserId(12)).thenReturn(donor);

        Donor result = donorService.getDonorByUserId(12);

        assertSame(donor, result);
        verify(donorDAO).findByUserId(12);
        verifyNoMoreInteractions(donorDAO);
        verifyNoMoreInteractions(donationRecordDAO, appointmentDAO);
    }

    @Test
    void getDonorByIdDelegatesToDao() throws SQLException {
        Donor donor = new Donor();
        when(donorDAO.findById(3)).thenReturn(donor);

        assertSame(donor, donorService.getDonorById(3));
        verify(donorDAO).findById(3);
        verifyNoMoreInteractions(donorDAO);
        verifyNoMoreInteractions(donationRecordDAO, appointmentDAO);
    }

    @Test
    void getDonationHistoryDelegatesToDao() throws SQLException {
        List<DonationRecord> history = List.of(new DonationRecord());
        when(donationRecordDAO.findByDonorId(5)).thenReturn(history);

        assertSame(history, donorService.getDonationHistory(5));
        verify(donationRecordDAO).findByDonorId(5);
        verifyNoMoreInteractions(donationRecordDAO);
        verifyNoMoreInteractions(donorDAO, appointmentDAO);
    }

    @Test
    void getDonationCountReturnsListSize() throws SQLException {
        List<DonationRecord> history = List.of(new DonationRecord(), new DonationRecord(), new DonationRecord());
        when(donationRecordDAO.findByDonorId(7)).thenReturn(history);

        assertEquals(3, donorService.getDonationCount(7));
        verify(donationRecordDAO).findByDonorId(7);
        verifyNoMoreInteractions(donationRecordDAO);
        verifyNoMoreInteractions(donorDAO, appointmentDAO);
    }

    @Test
    void getAppointmentsDelegatesToDao() throws SQLException {
        List<Appointment> appointments = List.of(new Appointment(), new Appointment());
        when(appointmentDAO.findByDonorId(9)).thenReturn(appointments);

        assertSame(appointments, donorService.getAppointments(9));
        verify(appointmentDAO).findByDonorId(9);
        verifyNoMoreInteractions(appointmentDAO);
        verifyNoMoreInteractions(donorDAO, donationRecordDAO);
    }

    @Test
    void updateAppointmentSetsUpdatedTimestampAndDelegates() throws SQLException {
        Appointment appointment = new Appointment();
        assertNull(appointment.getUpdatedAt());

        when(appointmentDAO.update(appointment)).thenReturn(true);

        assertTrue(donorService.updateAppointment(appointment));
        assertNotNull(appointment.getUpdatedAt());
        verify(appointmentDAO).update(appointment);
        verifyNoMoreInteractions(appointmentDAO);
        verifyNoMoreInteractions(donorDAO, donationRecordDAO);
    }

    @Test
    void cancelAppointmentUpdatesStatusWhenFound() throws SQLException {
        Appointment existing = new Appointment();
        existing.setStatus("PENDING");

        when(appointmentDAO.findById(44)).thenReturn(existing);
        when(appointmentDAO.update(existing)).thenReturn(true);

        assertTrue(donorService.cancelAppointment(44));
        assertEquals("CANCELLED", existing.getStatus());
        assertNotNull(existing.getUpdatedAt());
        verify(appointmentDAO).findById(44);
        verify(appointmentDAO).update(existing);
        verifyNoMoreInteractions(appointmentDAO);
        verifyNoMoreInteractions(donorDAO, donationRecordDAO);
    }

    @Test
    void cancelAppointmentReturnsFalseWhenNotFound() throws SQLException {
        when(appointmentDAO.findById(55)).thenReturn(null);

        assertFalse(donorService.cancelAppointment(55));
        verify(appointmentDAO).findById(55);
        verify(appointmentDAO, never()).update(any(Appointment.class));
        verifyNoMoreInteractions(appointmentDAO);
        verifyNoMoreInteractions(donorDAO, donationRecordDAO);
    }

    @Test
    void defaultConstructorInitializesDaos() throws Exception {
        DonorService defaultService = new DonorService();

        assertNotNull(getPrivateField(defaultService, "donorDAO"));
        assertNotNull(getPrivateField(defaultService, "donationRecordDAO"));
        assertNotNull(getPrivateField(defaultService, "appointmentDAO"));
    }

    private Object getPrivateField(DonorService service, String fieldName) throws Exception {
        Field field = DonorService.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(service);
    }
}
