package com.bloodlink.service;

import com.bloodlink.dao.DonorDAO;
import com.bloodlink.dao.HospitalDAO;
import com.bloodlink.dao.UserDAO;
import com.bloodlink.model.Donor;
import com.bloodlink.model.Hospital;
import com.bloodlink.model.User;
import com.bloodlink.util.PasswordUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserDAO userDAO;

    @Mock
    private DonorDAO donorDAO;

    @Mock
    private HospitalDAO hospitalDAO;

    private AuthService authService;

    @BeforeEach
    void setUp() {
        authService = new AuthService(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void loginReturnsUserWhenCredentialsValid() throws Exception {
        String email = "donor@example.com";
        String password = "secret123";
        User stored = new User();
        stored.setUserId(5);
        stored.setEmail(email);
        stored.setPasswordHash(PasswordUtil.hashPassword(password));
        stored.setStatus("active");

        when(userDAO.findByEmail(email)).thenReturn(stored);

        User result = authService.login(email, password);

        assertNotNull(result);
        assertEquals(5, result.getUserId());
        verify(userDAO).findByEmail(email);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void registerHospitalCreatesUserAndProfile() throws SQLException {
        String username = "hospital1";
        String email = "hospital@bloodlink.test";
        String password = "AdminPass1";

        when(userDAO.findByEmail(email)).thenReturn(null);
        when(userDAO.findByUsername(username)).thenReturn(null);
        when(userDAO.create(any(User.class))).thenReturn(501);
        when(hospitalDAO.create(any(Hospital.class))).thenReturn(9001);

        User created = authService.registerHospital(
                username,
                email,
                password,
                "Hospital Name",
                "123 Street",
                "0236-111-222",
                "Miền Trung"
        );

        assertNotNull(created);
        assertEquals(501, created.getUserId());

        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(userDAO).create(userCaptor.capture());
        assertEquals("hospital", userCaptor.getValue().getRoleCode());
        assertTrue(PasswordUtil.checkPassword(password, userCaptor.getValue().getPasswordHash()));

        ArgumentCaptor<Hospital> hospitalCaptor = ArgumentCaptor.forClass(Hospital.class);
        verify(hospitalDAO).create(hospitalCaptor.capture());
        Hospital savedHospital = hospitalCaptor.getValue();
        assertEquals(501, savedHospital.getUserId());
        assertEquals("Hospital Name", savedHospital.getName());

        verify(userDAO).findByEmail(email);
        verify(userDAO).findByUsername(username);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void registerHospitalThrowsWhenHospitalMissing() throws SQLException {
        when(userDAO.findByEmail("mail@test")).thenReturn(null);
        when(userDAO.findByUsername("hospUser")).thenReturn(null);
        when(hospitalDAO.findById(123)).thenReturn(null);

        assertThrows(IllegalArgumentException.class, () -> authService.registerHospital(
                "hospUser",
                "mail@test",
                "pass",
                123
        ));

        verify(hospitalDAO).findById(123);
    }

    @Test
    void registerHospitalLinksExistingHospital() throws SQLException {
        Hospital hospital = new Hospital();
        hospital.setHospitalId(55);
        hospital.setUserId(null);

        when(userDAO.findByEmail("mail@test")).thenReturn(null);
        when(userDAO.findByUsername("hospUser")).thenReturn(null);
        when(userDAO.create(any(User.class))).thenReturn(700);
        when(hospitalDAO.findById(55)).thenReturn(hospital);
        when(hospitalDAO.update(any(Hospital.class))).thenReturn(true);

        User created = authService.registerHospital(
                "hospUser",
                "mail@test",
                "pass",
                55
        );

        assertEquals(700, created.getUserId());

        ArgumentCaptor<Hospital> updateCaptor = ArgumentCaptor.forClass(Hospital.class);
        verify(hospitalDAO).update(updateCaptor.capture());
        assertEquals(700, updateCaptor.getValue().getUserId());

        verify(hospitalDAO).findById(55);
    }

    @Test
    void registerHospitalThrowsWhenEmailAlreadyUsed() throws SQLException {
        when(userDAO.findByEmail("dup@mail")).thenReturn(new User());

        assertThrows(IllegalArgumentException.class, () -> authService.registerHospital(
                "hospitalUser",
                "dup@mail",
                "pass",
                "Hospital",
                "Addr",
                "Contact",
                "Region"
        ));

        verify(userDAO).findByEmail("dup@mail");
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void registerHospitalThrowsWhenExistingHospitalAlreadyLinked() throws SQLException {
        Hospital hospital = new Hospital();
        hospital.setHospitalId(88);
        hospital.setUserId(10);

        when(userDAO.findByEmail("mail@test")).thenReturn(null);
        when(userDAO.findByUsername("hospUser")).thenReturn(null);
        when(hospitalDAO.findById(88)).thenReturn(hospital);

        assertThrows(IllegalArgumentException.class, () -> authService.registerHospital(
                "hospUser",
                "mail@test",
                "pass",
                88
        ));

        verify(hospitalDAO).findById(88);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void defaultConstructorInitializesDaos() throws Exception {
        AuthService service = new AuthService();

        Field userField = AuthService.class.getDeclaredField("userDAO");
        Field donorField = AuthService.class.getDeclaredField("donorDAO");
        Field hospitalField = AuthService.class.getDeclaredField("hospitalDAO");

        userField.setAccessible(true);
        donorField.setAccessible(true);
        hospitalField.setAccessible(true);

        assertNotNull(userField.get(service));
        assertNotNull(donorField.get(service));
        assertNotNull(hospitalField.get(service));
    }

    @Test
    void registerHospitalThrowsWhenUserCreationFails() throws SQLException {
        when(userDAO.findByEmail("mail@test")).thenReturn(null);
        when(userDAO.findByUsername("hospUser")).thenReturn(null);
        when(userDAO.create(any(User.class))).thenReturn(null);

        assertThrows(SQLException.class, () -> authService.registerHospital(
                "hospUser",
                "mail@test",
                "pass",
                "Hospital",
                "Addr",
                "Contact",
                "Region"
        ));

        verify(userDAO).findByEmail("mail@test");
        verify(userDAO).findByUsername("hospUser");
        verify(userDAO).create(any(User.class));
    }

    @Test
    void registerHospitalThrowsWhenHospitalCreateFails() throws SQLException {
        when(userDAO.findByEmail("mail@test")).thenReturn(null);
        when(userDAO.findByUsername("hospUser")).thenReturn(null);
        when(userDAO.create(any(User.class))).thenReturn(10);
        when(hospitalDAO.create(any(Hospital.class))).thenReturn(null);

        assertThrows(SQLException.class, () -> authService.registerHospital(
                "hospUser",
                "mail@test",
                "pass",
                "Hospital",
                "Addr",
                "Contact",
                "Region"
        ));

        verify(hospitalDAO).create(any(Hospital.class));
    }

    @Test
    void registerHospitalLinksExistingHospitalThrowsWhenUserCreationFails() throws SQLException {
        Hospital hospital = new Hospital();
        hospital.setHospitalId(55);
        hospital.setUserId(null);

        when(userDAO.findByEmail("mail@test")).thenReturn(null);
        when(userDAO.findByUsername("hospUser")).thenReturn(null);
        when(hospitalDAO.findById(55)).thenReturn(hospital);
        when(userDAO.create(any(User.class))).thenReturn(null);

        assertThrows(SQLException.class, () -> authService.registerHospital(
                "hospUser",
                "mail@test",
                "pass",
                55
        ));

        verify(userDAO).create(any(User.class));
    }

    @Test
    void registerHospitalLinksExistingHospitalThrowsWhenUpdateFails() throws SQLException {
        Hospital hospital = new Hospital();
        hospital.setHospitalId(55);
        hospital.setUserId(null);

        when(userDAO.findByEmail("mail@test")).thenReturn(null);
        when(userDAO.findByUsername("hospUser")).thenReturn(null);
        when(hospitalDAO.findById(55)).thenReturn(hospital);
        when(userDAO.create(any(User.class))).thenReturn(700);
        when(hospitalDAO.update(any(Hospital.class))).thenReturn(false);

        assertThrows(SQLException.class, () -> authService.registerHospital(
                "hospUser",
                "mail@test",
                "pass",
                55
        ));

        verify(hospitalDAO).update(any(Hospital.class));
    }

    @Test
    void getUserByIdDelegatesToDao() throws SQLException {
        User user = new User();
        when(userDAO.findById(3)).thenReturn(user);

        assertSame(user, authService.getUserById(3));
        verify(userDAO).findById(3);
    }

    @Test
    void getDonorByUserIdDelegatesToDao() throws SQLException {
        Donor donor = new Donor();
        when(donorDAO.findByUserId(4)).thenReturn(donor);

        assertSame(donor, authService.getDonorByUserId(4));
        verify(donorDAO).findByUserId(4);
    }

    @Test
    void getHospitalByUserIdDelegatesToDao() throws SQLException {
        Hospital hospital = new Hospital();
        when(hospitalDAO.findByUserId(5)).thenReturn(hospital);

        assertSame(hospital, authService.getHospitalByUserId(5));
        verify(hospitalDAO).findByUserId(5);
    }

    @Test
    void loginReturnsNullWhenPasswordInvalid() throws Exception {
        String email = "donor@example.com";
        User stored = new User();
        stored.setUserId(7);
        stored.setEmail(email);
        stored.setPasswordHash(PasswordUtil.hashPassword("correct"));
        stored.setStatus("active");

        when(userDAO.findByEmail(email)).thenReturn(stored);

        User result = authService.login(email, "wrong");

        assertNull(result);
        verify(userDAO).findByEmail(email);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void loginReturnsNullWhenUserNotFound() throws Exception {
        when(userDAO.findByEmail("missing@example.com")).thenReturn(null);

        User result = authService.login("missing@example.com", "any");

        assertNull(result);
        verify(userDAO).findByEmail("missing@example.com");
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void loginReturnsNullWhenPasswordHashMissing() throws Exception {
        String email = "nohash@example.com";
        User stored = new User();
        stored.setEmail(email);
        stored.setPasswordHash(null);
        stored.setStatus("active");

        when(userDAO.findByEmail(email)).thenReturn(stored);

        User result = authService.login(email, "123");

        assertNull(result);
        verify(userDAO).findByEmail(email);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void loginThrowsSQLExceptionWhenDaoFails() throws SQLException {
        when(userDAO.findByEmail("error@example.com")).thenThrow(new RuntimeException("boom"));

        assertThrows(SQLException.class, () -> authService.login("error@example.com", "pass"));
        verify(userDAO).findByEmail("error@example.com");
    }

    @Test
    void loginReturnsNullWhenUserInactive() throws Exception {
        String email = "inactive@example.com";
        User stored = new User();
        stored.setEmail(email);
        stored.setPasswordHash(PasswordUtil.hashPassword("abc123"));
        stored.setStatus("disabled");

        when(userDAO.findByEmail(email)).thenReturn(stored);

        User result = authService.login(email, "abc123");

        assertNull(result);
        verify(userDAO).findByEmail(email);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void registerDonorCreatesUserAndDonor() throws SQLException {
        String username = "newdonor";
        String email = "new@bloodlink.test";
        String rawPassword = "StrongPa55!";

        when(userDAO.findByEmail(email)).thenReturn(null);
        when(userDAO.findByUsername(username)).thenReturn(null);
        when(userDAO.create(any(User.class))).thenReturn(42);
        when(donorDAO.create(any(Donor.class))).thenReturn(99);

        User created = authService.registerDonor(
                username,
                email,
                rawPassword,
                "Nguyen Van A",
                "O+",
                "0912345678",
                "Da Nang",
                "male",
                "1990-01-01"
        );

        assertNotNull(created);
        assertEquals(42, created.getUserId());

        ArgumentCaptor<User> userCaptor = ArgumentCaptor.forClass(User.class);
        verify(userDAO).create(userCaptor.capture());
        User savedUser = userCaptor.getValue();
        assertEquals(username, savedUser.getUsername());
        assertEquals("donor", savedUser.getRoleCode());
        assertTrue(PasswordUtil.checkPassword(rawPassword, savedUser.getPasswordHash()));

        ArgumentCaptor<Donor> donorCaptor = ArgumentCaptor.forClass(Donor.class);
        verify(donorDAO).create(donorCaptor.capture());
        Donor savedDonor = donorCaptor.getValue();
        assertEquals(42, savedDonor.getUserId());
        assertEquals("Nguyen Van A", savedDonor.getFullName());
        assertEquals("O+", savedDonor.getBloodGroup());

        verify(userDAO).findByEmail(email);
        verify(userDAO).findByUsername(username);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }

    @Test
    void registerDonorThrowsWhenEmailExists() throws SQLException {
        String email = "existing@bloodlink.test";
        when(userDAO.findByEmail(email)).thenReturn(new User());

        assertThrows(IllegalArgumentException.class, () -> authService.registerDonor(
                "username",
                email,
                "pass",
                "Full Name",
                "A+",
                "0900000000",
                "Address",
                "female",
                null
        ));

        verify(userDAO).findByEmail(email);
        verifyNoMoreInteractions(userDAO, donorDAO, hospitalDAO);
    }
}
