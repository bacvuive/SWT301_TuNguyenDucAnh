package com.bloodlink.service;

import com.bloodlink.dao.*;
import com.bloodlink.model.*;
import com.bloodlink.util.AppConfig;
import com.bloodlink.util.DBConnection;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BloodRequestServiceTest {

    @Mock BloodRequestDAO bloodRequestDAO;
    @Mock DonorDAO donorDAO;
    @Mock HospitalDAO hospitalDAO;
    @Mock UserDAO userDAO;
    @Mock NotificationService notificationService;
    @Mock TransferService transferService;
    @Mock BloodBagDAO bloodBagDAO;

    BloodRequestService svc;

    @BeforeEach
    void setUp() {
        svc = new BloodRequestService(
                bloodRequestDAO, donorDAO, hospitalDAO, userDAO,
                notificationService, transferService, bloodBagDAO
        );
    }

    // ---------- Helper for JDBC row ----------

    private void stubRowForRequest(PreparedStatement ps, ResultSet rs,
                                   int requestId, int fromHospitalId, Integer toHospitalId,
                                   String bloodGroup, String component, int qty, String status) throws Exception {
        when(ps.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(true);
        when(rs.getInt("request_id")).thenReturn(requestId);
        when(rs.getInt("from_hospital_id")).thenReturn(fromHospitalId);
        if (toHospitalId == null) {
            when(rs.getInt("to_hospital_id")).thenReturn(0);
            when(rs.wasNull()).thenReturn(true);
        } else {
            when(rs.getInt("to_hospital_id")).thenReturn(toHospitalId);
            when(rs.wasNull()).thenReturn(false);
        }
        when(rs.getString("blood_group")).thenReturn(bloodGroup);
        when(rs.getString("component")).thenReturn(component);
        when(rs.getInt("quantity")).thenReturn(qty);
        when(rs.getString("status")).thenReturn(status);
        when(rs.getTimestamp(anyString())).thenReturn(Timestamp.valueOf(LocalDateTime.now()));
    }

    // ---------- createRequest validations ----------

    @Test
    void createRequest_fail_sameHospital() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () ->
                svc.createRequest(1, 1, "O+", "WB", 2, 100)
        );
        assertTrue(ex.getMessage().contains("chính bệnh viện"));
    }

    @Test
    void createRequest_fail_badQuantity() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () ->
                svc.createRequest(1, 2, "O+", "WB", 0, 100)
        );
        assertTrue(ex.getMessage().contains("Số lượng phải lớn hơn 0"));
    }

    @Test
    void createRequest_fail_emptyBloodGroup() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () ->
                svc.createRequest(1, 2, "  ", "WB", 2, 100)
        );
        assertTrue(ex.getMessage().contains("Nhóm máu"));
    }

    // ---------- createRequest success (targeted) ----------

    @Test
    void createRequest_success_targeted_sendsNotifications() throws Exception {
        when(bloodRequestDAO.create(any())).thenReturn(10);

        Hospital from = new Hospital();
        from.setHospitalId(1);
        from.setName("BV A");
        when(hospitalDAO.findById(1)).thenReturn(from);

        Donor d1 = new Donor(); d1.setDonorId(11); d1.setUserId(1001);
        Donor d2 = new Donor(); d2.setDonorId(12); d2.setUserId(1002);
        when(donorDAO.findByBloodGroup("O+")).thenReturn(List.of(d1, d2));

        User u1 = new User(); u1.setUserId(1001); u1.setStatus("active");
        User u2 = new User(); u2.setUserId(1002); u2.setStatus("inactive");
        when(userDAO.findById(1001)).thenReturn(u1);
        when(userDAO.findById(1002)).thenReturn(u2);

        Hospital target = new Hospital();
        target.setHospitalId(2);
        target.setUserId(2001);
        when(hospitalDAO.findById(2)).thenReturn(target);

        BloodRequest res = svc.createRequest(1, 2, "O+", "WB", 3, 999);

        assertNotNull(res);
        assertEquals(10, res.getRequestId());
        assertEquals("PENDING", res.getStatus());

        // Only active donor gets notified
        verify(notificationService, times(1))
                .createNotification(eq(1001), eq("warning"), contains("Yêu cầu máu khẩn cấp"));

        // Hospital target notified
        verify(notificationService, times(1))
                .createNotification(eq(2001), eq("info"), contains("Yêu cầu máu"));
        verifyNoMoreInteractions(notificationService);
    }

    // ---------- createRequest success (broadcast) ----------

    @Test
    void createRequest_success_broadcast_notifyOtherHospitals() throws Exception {
        when(bloodRequestDAO.create(any())).thenReturn(20);

        Hospital from = new Hospital();
        from.setHospitalId(1);
        from.setName("BV A");
        when(hospitalDAO.findById(1)).thenReturn(from);

        when(donorDAO.findByBloodGroup("A+")).thenReturn(List.of());
        // all hospitals (2,3), exclude creator(1), only notify those having userId
        Hospital h1 = new Hospital(); h1.setHospitalId(1); h1.setUserId(1111);
        Hospital h2 = new Hospital(); h2.setHospitalId(2); h2.setUserId(2222);
        Hospital h3 = new Hospital(); h3.setHospitalId(3); h3.setUserId(null); // no user -> skip
        when(hospitalDAO.findAll()).thenReturn(List.of(h1, h2, h3));

        BloodRequest res = svc.createRequest(1, null, "A+", "RBC", 2, 999);
        assertNotNull(res);
        verify(notificationService, times(1))
                .createNotification(eq(2222), eq("info"), contains("Yêu cầu máu"));
        verifyNoMoreInteractions(notificationService);
    }

    // ---------- DAO delegation getters ----------

    @Test
    void dao_delegations() throws Exception {
        svc.getRequestsByHospital(5);
        verify(bloodRequestDAO).findByToHospitalId(5);

        svc.getPendingRequests();
        verify(bloodRequestDAO).findByStatus("PENDING");

        svc.getRequestById(7);
        verify(bloodRequestDAO).findById(7);

        svc.getAllRequests();
        verify(bloodRequestDAO).findAll();

        svc.getRequestsByStatus("ACCEPTED");
        verify(bloodRequestDAO).findByStatus("ACCEPTED");

        svc.getRequestsCreatedByHospital(9);
        verify(bloodRequestDAO).findByFromHospitalId(9);

        svc.getIncomingRequests(4);
        verify(bloodRequestDAO).findIncomingRequests(4);
    }

    // ---------- acceptRequest happy path + lỗi ----------
    @Test
    void acceptRequest_broadcast_creatorCannotAccept() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            // broadcast: toHospitalId = null, fromHospitalId = 1, status = PENDING
            stubRowForRequest(lockStmt, lockRs, 801, 1, null, "O+", "WB", 1, "PENDING");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            // actor là đúng bệnh viện tạo request -> phải bị chặn
            Hospital actor = new Hospital(); actor.setHospitalId(1);
            when(hospitalDAO.findByUserId(999)).thenReturn(actor);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> svc.acceptRequest(801, 999, "note"));

            assertTrue(ex.getMessage().contains("chấp nhận yêu cầu do chính bạn tạo ra"));
            verify(conn, atLeastOnce()).rollback();
        }
    }

    @Test
    void acceptRequest_targeted_happyPath_sendsNotifications_andAutoLink() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class);
             MockedStatic<AppConfig> mockedCfg = mockStatic(AppConfig.class)) {

            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);
            CallableStatement callStmt = mock(CallableStatement.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            when(conn.prepareCall("{call dbo.sp_update_request_status(?, ?, ?, ?)}")).thenReturn(callStmt);
            // lock row -> PENDING, toHospitalId = 2, fromHospitalId = 1
            stubRowForRequest(lockStmt, lockRs, 101, 1, 2, "O+", "WB", 3, "PENDING");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            // actor hospital: hospitalId = 2
            Hospital actorH = new Hospital(); actorH.setHospitalId(2);
            when(hospitalDAO.findByUserId(9999)).thenReturn(actorH);

            // reload request in same tx
            PreparedStatement reloadStmt = mock(PreparedStatement.class);
            ResultSet reloadRs = mock(ResultSet.class);
            when(conn.prepareStatement("SELECT request_id, from_hospital_id, to_hospital_id, blood_group, component, " +
                    "quantity, status, created_at, updated_at FROM blood_request WHERE request_id = ?"))
                    .thenReturn(reloadStmt);
            stubRowForRequest(reloadStmt, reloadRs, 101, 1, 2, "O+", "WB", 3, "ACCEPTED");

            // hospitals for notification
            Hospital from = new Hospital(); from.setHospitalId(1); from.setUserId(1001);
            Hospital to   = new Hospital(); to.setHospitalId(2); to.setUserId(1002);
            when(hospitalDAO.findById(1)).thenReturn(from);
            when(hospitalDAO.findById(2)).thenReturn(to);

            // auto-link ON
            mockedCfg.when(AppConfig::isAutoLinkEnabled).thenReturn(true);
            when(bloodBagDAO.findAvailable(2, "O+", "WB"))
                    .thenReturn(List.of(new BloodBag(), new BloodBag(), new BloodBag()));
            TransferRequest tr = new TransferRequest(); tr.setTransferId(555);
            when(transferService.createTransferWithAllocation(eq(101), eq(2), eq(1),
                    eq("O+"), eq("WB"), eq(3))).thenReturn(tr);

            boolean ok = svc.acceptRequest(101, 9999, "ok accept");
            assertTrue(ok);

            verify(notificationService).notifyRequestAccepted(eq(1001), eq(101), eq("O+"), eq(3), eq("ok accept"));
            verify(notificationService).notifyRequestAccepted(eq(1002), eq(101), eq("O+"), eq(3), eq("ok accept"));
            verifyNoMoreInteractions(notificationService);

            verify(conn).setAutoCommit(false);
            verify(conn).commit();
            verify(conn).setAutoCommit(true);
            verify(conn).close();
        }
    }

    @Test
    void acceptRequest_fails_whenNotPending() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            stubRowForRequest(lockStmt, lockRs, 501, 1, 2, "O+", "WB", 1, "ACCEPTED");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> svc.acceptRequest(501, 9999, "note"));

            assertTrue(ex.getMessage().contains("Không thể chấp nhận yêu cầu ở trạng thái"));
            verify(conn, atLeastOnce()).rollback();
        }
        

    }

    // ---------- rejectRequest ----------
    @Test
    void rejectRequest_statusNotPending_throws() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            // status = ACCEPTED, không phải PENDING
            stubRowForRequest(lockStmt, lockRs, 902, 1, 2, "A+", "RBC", 1, "ACCEPTED");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);


            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> svc.rejectRequest(902, 777, "no"));

            assertTrue(ex.getMessage().contains("Không thể từ chối yêu cầu ở trạng thái"));
            verify(conn, atLeastOnce()).rollback();
        }
    }


    @Test
    void rejectRequest_broadcast_byOtherHospital_ok() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);
            CallableStatement callStmt = mock(CallableStatement.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            when(conn.prepareCall("{call dbo.sp_update_request_status(?, ?, ?, ?)}")).thenReturn(callStmt);
            stubRowForRequest(lockStmt, lockRs, 202, 1, null, "A+", "RBC", 2, "PENDING");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            Hospital actorH = new Hospital(); actorH.setHospitalId(3);
            when(hospitalDAO.findByUserId(7777)).thenReturn(actorH);

            BloodRequest after = new BloodRequest();
            after.setRequestId(202);
            after.setFromHospitalId(1);
            after.setBloodGroup("A+");
            after.setQuantity(2);
            after.setStatus("REJECTED");
            when(bloodRequestDAO.findById(202)).thenReturn(after);

            Hospital from = new Hospital(); from.setHospitalId(1); from.setUserId(3001);
            when(hospitalDAO.findById(1)).thenReturn(from);

            boolean ok = svc.rejectRequest(202, 7777, "not available");
            assertTrue(ok);

            verify(notificationService).notifyRequestRejected(eq(3001), eq(202),
                    eq("A+"), eq(2), eq("not available"));
            verifyNoMoreInteractions(notificationService);
        }
    }

    @Test
    void rejectRequest_wrongTargetHospital_throws() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            // targeted request to hospital 2
            stubRowForRequest(lockStmt, lockRs, 601, 1, 2, "O+", "WB", 1, "PENDING");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            Hospital actorH = new Hospital(); actorH.setHospitalId(3); // khác 2
            when(hospitalDAO.findByUserId(7777)).thenReturn(actorH);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> svc.rejectRequest(601, 7777, "no"));

            assertTrue(ex.getMessage().contains("không có quyền từ chối"));
            verify(conn, atLeastOnce()).rollback();
        }
    }

    // ---------- completeRequest ----------
    @Test
    void completeRequest_wrongHospital_throws() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            // fromHospitalId = 1, toHospitalId = 2, status = ACCEPTED
            stubRowForRequest(lockStmt, lockRs, 903, 1, 2, "O+", "WB", 1, "ACCEPTED");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            // actor là hospital 9 -> không trùng fromHospitalId
            Hospital actor = new Hospital(); actor.setHospitalId(9);
            when(hospitalDAO.findByUserId(9999)).thenReturn(actor);

            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> svc.completeRequest(903, 9999, "note"));

            assertTrue(ex.getMessage().contains("Chỉ bệnh viện tạo yêu cầu"));
            verify(conn, atLeastOnce()).rollback();
        }
    }

    @Test
    void completeRequest_success_movesBags_andNotifies() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);
            CallableStatement callStmt = mock(CallableStatement.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            when(conn.prepareCall("{call dbo.sp_update_request_status(?, ?, ?, ?)}")).thenReturn(callStmt);
            stubRowForRequest(lockStmt, lockRs, 303, 1, 2, "O+", "WB", 2, "ACCEPTED");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            Hospital actorH = new Hospital(); actorH.setHospitalId(1);
            when(hospitalDAO.findByUserId(5555)).thenReturn(actorH);

            BloodBag b1 = new BloodBag(); b1.setBagId(901);
            BloodBag b2 = new BloodBag(); b2.setBagId(902);
            when(bloodBagDAO.findAvailableForTransfer(eq(conn), eq(2), eq("O+"),
                    eq("WB"), eq(2))).thenReturn(List.of(b1, b2));

            doNothing().when(bloodBagDAO)
                    .moveBagsToHospital(eq(conn), anyList(), eq(1), eq(5555), eq(303));

            BloodRequest after = new BloodRequest();
            after.setRequestId(303);
            after.setFromHospitalId(1);
            after.setToHospitalId(2);
            after.setBloodGroup("O+");
            after.setQuantity(2);
            after.setStatus("COMPLETED");
            when(bloodRequestDAO.findById(303)).thenReturn(after);

            Hospital from = new Hospital(); from.setHospitalId(1); from.setUserId(4001);
            Hospital to = new Hospital(); to.setHospitalId(2); to.setUserId(4002);
            when(hospitalDAO.findById(1)).thenReturn(from);
            when(hospitalDAO.findById(2)).thenReturn(to);

            boolean ok = svc.completeRequest(303, 5555, "done");
            assertTrue(ok);

            verify(bloodBagDAO).moveBagsToHospital(eq(conn),
                    argThat(list -> list.size() == 2), eq(1), eq(5555), eq(303));
            verify(notificationService).notifyRequestCompleted(eq(4001), eq(303),
                    eq("O+"), eq(2), eq("done"));
            verify(notificationService).notifyRequestCompleted(eq(4002), eq(303),
                    eq("O+"), eq(2), eq("done"));
        }
    }

    @Test
    void completeRequest_fail_insufficientStock_throws() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);
            CallableStatement callStmt = mock(CallableStatement.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            when(conn.prepareCall("{call dbo.sp_update_request_status(?, ?, ?, ?)}")).thenReturn(callStmt);
            stubRowForRequest(lockStmt, lockRs, 404, 9, 8, "B+", "PLT", 3, "ACCEPTED");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);

            Hospital actorH = new Hospital(); actorH.setHospitalId(9);
            when(hospitalDAO.findByUserId(1234)).thenReturn(actorH);

            when(bloodBagDAO.findAvailableForTransfer(eq(conn), eq(8),
                    eq("B+"), eq("PLT"), eq(3)))
                    .thenReturn(List.of(new BloodBag())); // only 1

            IllegalStateException ex = assertThrows(IllegalStateException.class,
                    () -> svc.completeRequest(404, 1234, "try complete"));

            assertTrue(ex.getMessage().contains("Không đủ túi máu khả dụng"));
            verify(conn, atLeastOnce()).rollback();
        }
    }

    @Test
    void completeRequest_fails_whenNotAccepted() throws Exception {
        try (MockedStatic<DBConnection> mockedDb = mockStatic(DBConnection.class)) {
            Connection conn = mock(Connection.class);
            PreparedStatement lockStmt = mock(PreparedStatement.class);
            ResultSet lockRs = mock(ResultSet.class);

            when(conn.getAutoCommit()).thenReturn(true);
            when(conn.prepareStatement(startsWith("SELECT request_id"))).thenReturn(lockStmt);
            // status PENDING thay vì ACCEPTED
            stubRowForRequest(lockStmt, lockRs, 701, 1, 2, "O+", "WB", 1, "PENDING");

            mockedDb.when(DBConnection::getConnection).thenReturn(conn);


            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> svc.completeRequest(701, 1234, "note"));

            assertTrue(ex.getMessage().contains("Chỉ cho phép hoàn tất yêu cầu ACCEPTED"));
            verify(conn, atLeastOnce()).rollback();
        }
    }

    // ---------- updateRequest ----------

    @Test
    void updateRequest_updatesTimestampAndDelegates() throws Exception {
        BloodRequest br = new BloodRequest();
        br.setRequestId(1);
        br.setUpdatedAt(null);

        when(bloodRequestDAO.update(any())).thenReturn(true);

        boolean ok = svc.updateRequest(br);
        assertTrue(ok);
        assertNotNull(br.getUpdatedAt());
        verify(bloodRequestDAO).update(br);
    }

    // ---------- closeRequest ----------

    @Test
    void closeRequest_success() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(1);
        req.setFromHospitalId(10);
        req.setStatus("PENDING");

        when(bloodRequestDAO.findById(1)).thenReturn(req);
        when(bloodRequestDAO.update(any())).thenReturn(true);

        boolean ok = svc.closeRequest(1, 10);

        assertTrue(ok);
        assertEquals("COMPLETED", req.getStatus());
        verify(bloodRequestDAO).update(req);
    }

    @Test
    void closeRequest_notFound_throws() throws Exception {
        when(bloodRequestDAO.findById(1)).thenReturn(null);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> svc.closeRequest(1, 10));

        assertTrue(ex.getMessage().contains("không tồn tại"));
    }

    @Test
    void closeRequest_wrongHospital_throws() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(1);
        req.setFromHospitalId(99);
        req.setStatus("PENDING");

        when(bloodRequestDAO.findById(1)).thenReturn(req);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> svc.closeRequest(1, 10));

        assertTrue(ex.getMessage().contains("không có quyền"));
    }

    @Test
    void closeRequest_alreadyClosed_throws() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(1);
        req.setFromHospitalId(10);
        req.setStatus("COMPLETED");

        when(bloodRequestDAO.findById(1)).thenReturn(req);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> svc.closeRequest(1, 10));

        assertTrue(ex.getMessage().contains("đã được đóng"));
    }

    // ---------- cancelRequest ----------

    @Test
    void cancelRequest_success() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(2);
        req.setFromHospitalId(10);
        req.setStatus("PENDING");

        when(bloodRequestDAO.findById(2)).thenReturn(req);
        when(bloodRequestDAO.update(any())).thenReturn(true);

        boolean ok = svc.cancelRequest(2, 10);

        assertTrue(ok);
        assertEquals("CANCELLED", req.getStatus());
        verify(bloodRequestDAO).update(req);
    }

    @Test
    void cancelRequest_wrongHospital_throws() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(2);
        req.setFromHospitalId(99);
        req.setStatus("PENDING");

        when(bloodRequestDAO.findById(2)).thenReturn(req);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> svc.cancelRequest(2, 10));

        assertTrue(ex.getMessage().contains("không có quyền"));
    }

    @Test
    void cancelRequest_alreadyClosed_throws() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(2);
        req.setFromHospitalId(10);
        req.setStatus("CANCELLED");

        when(bloodRequestDAO.findById(2)).thenReturn(req);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> svc.cancelRequest(2, 10));

        assertTrue(ex.getMessage().contains("đã được đóng"));
    }

    // ---------- Private helpers via reflection (để max coverage) ----------

    @Test
    void getComponentName_coversAllBranches() throws Exception {
        Method m = BloodRequestService.class
                .getDeclaredMethod("getComponentName", String.class);
        m.setAccessible(true);

        assertEquals("Máu toàn phần", m.invoke(svc, "WB"));
        assertEquals("Hồng cầu", m.invoke(svc, "RBC"));
        assertEquals("Tiểu cầu", m.invoke(svc, "PLT"));
        assertEquals("Huyết tương tươi đông lạnh", m.invoke(svc, "FFP"));
        assertEquals("Toàn phần", m.invoke(svc, ""));         // null/empty
        assertEquals("XYZ", m.invoke(svc, "XYZ"));             // default branch
    }

    @Test
    void getStatusText_coversAllBranches() throws Exception {
        Method m = BloodRequestService.class
                .getDeclaredMethod("getStatusText", String.class);
        m.setAccessible(true);

        assertEquals("cập nhật", m.invoke(svc, new Object[]{null}));
        assertEquals("chấp nhận", m.invoke(svc, "ACCEPTED"));
        assertEquals("từ chối", m.invoke(svc, "REJECTED"));
        assertEquals("hoàn tất", m.invoke(svc, "COMPLETED"));
        assertEquals("đang chờ", m.invoke(svc, "PENDING"));
        assertEquals("abc", m.invoke(svc, "ABC")); // default: toLowerCase
    }

    @Test
    void getTransferService_lazyInitBranch() throws Exception {
        // khởi tạo service với transferService = null để test lazy init
        BloodRequestService svc2 = new BloodRequestService(
                bloodRequestDAO, donorDAO, hospitalDAO, userDAO,
                notificationService, null, bloodBagDAO
        );
        Method m = BloodRequestService.class
                .getDeclaredMethod("getTransferService");
        m.setAccessible(true);

        Object ts = m.invoke(svc2);
        assertNotNull(ts);
    }

    @Test
    void sendNotificationsToDonors_skipsInactiveAndNullUser() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setBloodGroup("O+");
        req.setComponent("WB");
        req.setQuantity(2);

        Donor d1 = new Donor(); d1.setDonorId(1); d1.setUserId(101);
        Donor d2 = new Donor(); d2.setDonorId(2); d2.setUserId(102);
        Donor d3 = new Donor(); d3.setDonorId(3); d3.setUserId(103);

        when(donorDAO.findByBloodGroup("O+")).thenReturn(List.of(d1, d2, d3));

        User u1 = new User(); u1.setUserId(101); u1.setStatus("active");
        User u2 = new User(); u2.setUserId(102); u2.setStatus("inactive");
        when(userDAO.findById(101)).thenReturn(u1);
        when(userDAO.findById(102)).thenReturn(u2);
        when(userDAO.findById(103)).thenReturn(null);

        Method m = BloodRequestService.class
                .getDeclaredMethod("sendNotificationsToDonors", BloodRequest.class, String.class);
        m.setAccessible(true);

        m.invoke(svc, req, "BV A");

        verify(notificationService, times(1))
                .createNotification(eq(101), eq("warning"), contains("Yêu cầu máu khẩn cấp"));
        verifyNoMoreInteractions(notificationService);
    }

    @Test
    void sendNotificationsToHospitals_broadcast_skipsCreatorAndNullUser() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setFromHospitalId(1);
        req.setToHospitalId(null);
        req.setBloodGroup("A+");
        req.setComponent("RBC");
        req.setQuantity(5);

        Hospital h1 = new Hospital(); h1.setHospitalId(1); h1.setUserId(111); // creator -> skip
        Hospital h2 = new Hospital(); h2.setHospitalId(2); h2.setUserId(222); // notified
        Hospital h3 = new Hospital(); h3.setHospitalId(3); h3.setUserId(null); // skip

        when(hospitalDAO.findAll()).thenReturn(List.of(h1, h2, h3));

        Method m = BloodRequestService.class
                .getDeclaredMethod("sendNotificationsToHospitals", BloodRequest.class, String.class);
        m.setAccessible(true);

        m.invoke(svc, req, "BV A");

        verify(notificationService, times(1))
                .createNotification(eq(222), eq("info"), contains("Yêu cầu máu"));
        verifyNoMoreInteractions(notificationService);
    }

    @Test
    void sendStatusChangeNotifications_handlesNotificationSQLException() throws Exception {
        BloodRequest request = new BloodRequest();
        request.setRequestId(777);
        request.setFromHospitalId(1);
        request.setToHospitalId(2);
        request.setBloodGroup("O+");
        request.setQuantity(4);

        Hospital from = new Hospital(); from.setHospitalId(1); from.setUserId(1001);
        Hospital to   = new Hospital(); to.setHospitalId(2); to.setUserId(1002);
        when(hospitalDAO.findById(1)).thenReturn(from);
        when(hospitalDAO.findById(2)).thenReturn(to);

        doThrow(new SQLException("fail"))
                .when(notificationService)
                .notifyRequestAccepted(eq(1001), eq(777), eq("O+"), eq(4), eq("note"));

        Method m = BloodRequestService.class.getDeclaredMethod(
                "sendStatusChangeNotifications", BloodRequest.class, String.class, Integer.class, String.class);
        m.setAccessible(true);

        assertDoesNotThrow(() -> m.invoke(svc, request, "ACCEPTED", 5000, "note"));

        verify(notificationService).notifyRequestAccepted(eq(1001), eq(777), eq("O+"), eq(4), eq("note"));
        verify(notificationService).notifyRequestAccepted(eq(1002), eq(777), eq("O+"), eq(4), eq("note"));
    }

    @Test
    void sendStatusChangeNotifications_handlesHospitalLookupSQLException() throws Exception {
        BloodRequest request = new BloodRequest();
        request.setRequestId(888);
        request.setFromHospitalId(1);
        request.setToHospitalId(null);

        when(hospitalDAO.findById(1)).thenThrow(new SQLException("db down"));

        Method m = BloodRequestService.class.getDeclaredMethod(
                "sendStatusChangeNotifications", BloodRequest.class, String.class, Integer.class, String.class);
        m.setAccessible(true);

        assertDoesNotThrow(() -> m.invoke(svc, request, "REJECTED", 4000, "note"));

        verifyNoInteractions(notificationService);
    }
    private Object getPrivateField(BloodRequestService target, String fieldName) throws Exception {
        Field f = BloodRequestService.class.getDeclaredField(fieldName);
        f.setAccessible(true);
        return f.get(target);
    }
    @Test
    void defaultConstructor_initializesInternalDependencies() throws Exception {
        // Gọi constructor mặc định (cái JaCoCo đang báo)
        BloodRequestService svcDefault = new BloodRequestService();

        // Các dependency bên trong phải được khởi tạo khác null
        assertNotNull(getPrivateField(svcDefault, "bloodRequestDAO"));
        assertNotNull(getPrivateField(svcDefault, "donorDAO"));
        assertNotNull(getPrivateField(svcDefault, "hospitalDAO"));
        assertNotNull(getPrivateField(svcDefault, "userDAO"));
        assertNotNull(getPrivateField(svcDefault, "notificationService"));
        assertNotNull(getPrivateField(svcDefault, "bloodBagDAO"));
        // transferService được lazy-init, nên có thể null, mình test ở getTransferService() riêng
    }

    @Test
    void createRequest_overloadWithoutActorUserId_delegatesToMainMethod() throws Exception {
        // Khi tạo request phải trả về ID
        when(bloodRequestDAO.create(any())).thenReturn(123);

        // Bệnh viện tạo yêu cầu (fromHospital)
        Hospital from = new Hospital();
        from.setHospitalId(1);
        from.setName("BV A");
        when(hospitalDAO.findById(1)).thenReturn(from);

        // Donor/hospital list rỗng cho đơn giản (không cần verify notify)
        when(donorDAO.findByBloodGroup("O+")).thenReturn(List.of());

        Hospital target = new Hospital();
        target.setHospitalId(2);
        target.setUserId(2001);
        when(hospitalDAO.findById(2)).thenReturn(target);

        // GỌI đúng overload 5 tham số
        BloodRequest result = svc.createRequest(1, 2, "O+", "WB", 1);

        assertNotNull(result);
        assertEquals(123, result.getRequestId());
        assertEquals("PENDING", result.getStatus());

        // Đảm bảo thực sự gọi xuống DAO
        verify(bloodRequestDAO, times(1)).create(any(BloodRequest.class));
    }
//autoCreateTransferForRequest
    @Test
    void autoCreateTransferForRequest_noFromHospital_doesNothing() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(1001);
        req.setFromHospitalId(null); // broadcast / không xác định
        req.setBloodGroup("O+");
        req.setComponent("WB");
        req.setQuantity(2);

        Method m = BloodRequestService.class
                .getDeclaredMethod("autoCreateTransferForRequest",
                        BloodRequest.class, Integer.class, Integer.class);
        m.setAccessible(true);

        m.invoke(svc, req, 111, 5); // actorUserId, actorHospitalId

        verifyNoInteractions(bloodBagDAO);
        verifyNoInteractions(transferService);
    }
    @Test
    void autoCreateTransferForRequest_sameHospital_doesNothing() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(1002);
        req.setFromHospitalId(5); // toHospital = 5
        req.setBloodGroup("O+");
        req.setComponent("WB");
        req.setQuantity(2);

        Method m = BloodRequestService.class
                .getDeclaredMethod("autoCreateTransferForRequest",
                        BloodRequest.class, Integer.class, Integer.class);
        m.setAccessible(true);

        // actorHospitalId cũng = 5
        m.invoke(svc, req, 111, 5);

        verifyNoInteractions(bloodBagDAO);
        verifyNoInteractions(transferService);
    }
    @Test
    void autoCreateTransferForRequest_insufficientStock_noTransferCreated() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(1003);
        req.setFromHospitalId(1); // toHospitalId = 1
        req.setBloodGroup("A+");
        req.setComponent("RBC");
        req.setQuantity(5);

        // actorHospital cung cấp máu = 2
        when(bloodBagDAO.findAvailable(2, "A+", "RBC"))
                .thenReturn(List.of(new BloodBag())); // chỉ 1 túi

        Method m = BloodRequestService.class
                .getDeclaredMethod("autoCreateTransferForRequest",
                        BloodRequest.class, Integer.class, Integer.class);
        m.setAccessible(true);

        m.invoke(svc, req, 111, 2);

        // Đã kiểm tra stock
        verify(bloodBagDAO).findAvailable(2, "A+", "RBC");
        // Nhưng không tạo transfer
        verifyNoInteractions(transferService);
    }
    //---------- sendStatusChangeNotifications ----------
    @Test
    void sendStatusChangeNotifications_pending_doesNotNotify() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(2001);
        req.setFromHospitalId(1);
        req.setToHospitalId(2);

        // vẫn gọi findById nhưng không dùng userId
        when(hospitalDAO.findById(1)).thenReturn(new Hospital());
        when(hospitalDAO.findById(2)).thenReturn(new Hospital());

        Method m = BloodRequestService.class
                .getDeclaredMethod("sendStatusChangeNotifications",
                        BloodRequest.class, String.class, Integer.class, String.class);
        m.setAccessible(true);

        m.invoke(svc, req, "PENDING", 999, "note");

        verifyNoInteractions(notificationService);
    }
    @Test
    void sendStatusChangeNotifications_accepted_withNullUserIds_doesNotNotify() throws Exception {
        BloodRequest req = new BloodRequest();
        req.setRequestId(2002);
        req.setFromHospitalId(1);
        req.setToHospitalId(2);

        Hospital from = new Hospital(); from.setHospitalId(1); from.setUserId(null);
        Hospital to   = new Hospital(); to.setHospitalId(2);   to.setUserId(null);

        when(hospitalDAO.findById(1)).thenReturn(from);
        when(hospitalDAO.findById(2)).thenReturn(to);

        Method m = BloodRequestService.class
                .getDeclaredMethod("sendStatusChangeNotifications",
                        BloodRequest.class, String.class, Integer.class, String.class);
        m.setAccessible(true);

        m.invoke(svc, req, "ACCEPTED", 999, "note");

        verifyNoInteractions(notificationService);
    }


}
