package com.bloodlink.e2e;

import com.bloodlink.e2e.pages.LoginPage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;


public class LoginE2ETest extends BaseE2ETest {

    private static final String BASE_URL = System.getProperty("bloodlink.baseUrl", "http://localhost:8080/bloodlink-web");

    @Test
    @DisplayName("Failed login shows error message")
    void loginWithInvalidCredentials_showsErrorAlert() {
        LoginPage loginPage = new LoginPage(driver).open(BASE_URL)
                .login("unknown@example.com", "invalid");

        driver.findElement(By.tagName("body"));

        Assertions.assertTrue(loginPage.hasError(), "Expected an error state after invalid login");
    }
}
