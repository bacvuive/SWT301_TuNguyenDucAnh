package com.bloodlink.e2e.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Page object for hospital blood request creation page (hospital/requests/create.jsp).
 */
public class HospitalRequestPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private static final By BLOOD_GROUP_SELECT = By.name("bloodGroup");
    private static final By COMPONENT_SELECT = By.name("component");
    private static final By QUANTITY_INPUT = By.name("quantity");
    private static final By TO_HOSPITAL_SELECT = By.id("toHospitalSelect");
    private static final By SUBMIT_BUTTON = By.cssSelector("form#createRequestForm button[type='submit']");
    private static final By ERROR_ALERT = By.cssSelector(".alert.alert-danger");
    private static final By INVALID_FEEDBACK = By.cssSelector(".is-invalid, .invalid-feedback");
    private static final By CLIENT_ERROR = By.id("clientFormError");

    public HospitalRequestPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    }

    public HospitalRequestPage openCreate(String baseUrl) {
        driver.get(baseUrl + "/hospital/requests/create");
        return this;
    }

    /**
     * Fill out and submit blood request form.
     */
    public HospitalRequestPage create(String bloodGroup, String component, String quantity, String toHospitalIdOrName) {
        Select bloodGroupSelect = new Select(wait.until(ExpectedConditions.visibilityOfElementLocated(BLOOD_GROUP_SELECT)));
        if (bloodGroup != null) {
            bloodGroupSelect.selectByValue(bloodGroup);
        }

        Select componentSelect = new Select(driver.findElement(COMPONENT_SELECT));
        componentSelect.selectByValue(component);

        driver.findElement(QUANTITY_INPUT).clear();
        driver.findElement(QUANTITY_INPUT).sendKeys(quantity);

        if (toHospitalIdOrName != null && !toHospitalIdOrName.isBlank()) {
            Select hospitalSelect = new Select(driver.findElement(TO_HOSPITAL_SELECT));
            try {
                hospitalSelect.selectByValue(toHospitalIdOrName);
            } catch (Exception ignore) {
                hospitalSelect.selectByVisibleText(toHospitalIdOrName);
            }
        }

        var submitButton = wait.until(ExpectedConditions.elementToBeClickable(SUBMIT_BUTTON));
        try {
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].scrollIntoView({block: 'center'});", submitButton);
        } catch (Exception ignored) {
            // Ignore if scroll not supported
        }

        try {
            submitButton.click();
        } catch (org.openqa.selenium.ElementClickInterceptedException e) {
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].click();", submitButton);
        }
        return this;
    }

    /**
     * @return true when quantity validation fails (error alert or invalid feedback is present).
     */
    public boolean hasQtyError() {
        try {
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.visibilityOfElementLocated(ERROR_ALERT),
                    ExpectedConditions.visibilityOfElementLocated(INVALID_FEEDBACK),
                    ExpectedConditions.visibilityOfElementLocated(CLIENT_ERROR)));
        } catch (TimeoutException ignored) {
            // No visible validation feedback within wait duration
        }

        if (!driver.findElements(ERROR_ALERT).isEmpty()) {
            String errorText = driver.findElements(ERROR_ALERT).get(0).getText().toLowerCase();
            if (errorText.contains("số lượng") || errorText.contains("must") || errorText.contains("lỗi")) {
                return true;
            }
        }
        if (!driver.findElements(INVALID_FEEDBACK).isEmpty()) {
            return true;
        }
        if (!driver.findElements(CLIENT_ERROR).isEmpty()) {
            var errorElement = driver.findElement(CLIENT_ERROR);
            if (errorElement.isDisplayed() && !errorElement.getText().isBlank()) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return true if an error message is present, optionally matching a keyword.
     */
    public boolean hasErrorContaining(String keyword) {
        String needle = keyword != null ? keyword.toLowerCase() : null;
        try {
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.visibilityOfElementLocated(ERROR_ALERT),
                    ExpectedConditions.visibilityOfElementLocated(INVALID_FEEDBACK),
                    ExpectedConditions.visibilityOfElementLocated(CLIENT_ERROR)));
        } catch (TimeoutException ignored) {
            // fall back to DOM inspection
        }

        if (!driver.findElements(ERROR_ALERT).isEmpty()) {
            String errorText = driver.findElements(ERROR_ALERT).get(0).getText().toLowerCase();
            if (needle == null || needle.isBlank()) {
                return true;
            }
            if (errorText.contains(needle)) {
                return true;
            }
        }

        if (!driver.findElements(INVALID_FEEDBACK).isEmpty()) {
            for (var el : driver.findElements(INVALID_FEEDBACK)) {
                String text = el.getText().toLowerCase();
                if (needle == null || needle.isBlank()) {
                    return true;
                }
                if (text.contains(needle)) {
                    return true;
                }
            }
        }

        if (!driver.findElements(CLIENT_ERROR).isEmpty()) {
            var errorElement = driver.findElement(CLIENT_ERROR);
            if (errorElement.isDisplayed()) {
                String text = errorElement.getText().toLowerCase();
                if (needle == null || needle.isBlank() || text.contains(needle)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * @return captured error text if present, otherwise empty string.
     */
    public String getErrorText() {
        if (!driver.findElements(ERROR_ALERT).isEmpty()) {
            return driver.findElements(ERROR_ALERT).get(0).getText();
        }
        if (!driver.findElements(INVALID_FEEDBACK).isEmpty()) {
            return driver.findElements(INVALID_FEEDBACK).get(0).getText();
        }
        if (!driver.findElements(CLIENT_ERROR).isEmpty()) {
            var errorElement = driver.findElement(CLIENT_ERROR);
            if (errorElement.isDisplayed()) {
                return errorElement.getText();
            }
        }
        return "";
    }

    public String getBloodGroupValidationMessage() {
        var select = driver.findElement(BLOOD_GROUP_SELECT);
        try {
            return (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].validationMessage;", select);
        } catch (Exception ignored) {
            return "";
        }
    }
}
