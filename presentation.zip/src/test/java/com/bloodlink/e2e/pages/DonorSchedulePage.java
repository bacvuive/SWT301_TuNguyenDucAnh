package com.bloodlink.e2e.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Page object for donor schedule page (donor/schedule.jsp).
 */
public class DonorSchedulePage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private static final By HOSPITAL_SELECT = By.name("hospitalId");
    private static final By SCHEDULED_AT_INPUT = By.name("scheduledAt");
    private static final By NOTE_TEXTAREA = By.name("note");
    private static final By SUBMIT_BUTTON = By.cssSelector("form[action$='/donor/schedule'] button[type='submit']");
    private static final By SUCCESS_ALERT = By.cssSelector(".alert.alert-success");
    private static final By ERROR_ALERT = By.cssSelector(".alert.alert-danger");
    private static final By APPOINTMENT_CARD = By.cssSelector(".appointment-card");

    public DonorSchedulePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    }

    public DonorSchedulePage open(String baseUrl) {
        driver.get(baseUrl + "/donor/schedule");
        return this;
    }

    /**
     * Create a new appointment.
     *
     * @param hospitalIdOrName Option value or visible text for hospital select
     * @param dateISO          date in yyyy-MM-dd format
     * @param timeHHmm         time in HH:mm format
     * @return this page object
     */
    public DonorSchedulePage createAppointment(String hospitalIdOrName, String dateISO, String timeHHmm) {
        Select hospitalSelect = new Select(wait.until(ExpectedConditions.visibilityOfElementLocated(HOSPITAL_SELECT)));
        if (hospitalIdOrName != null && !hospitalIdOrName.isBlank()) {
            try {
                hospitalSelect.selectByValue(hospitalIdOrName);
            } catch (Exception ignore) {
                hospitalSelect.selectByVisibleText(hospitalIdOrName);
            }
        }

        String datetimeValue = dateISO + "T" + timeHHmm;
        WebElement datetimeInput = driver.findElement(SCHEDULED_AT_INPUT);
        datetimeInput.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        datetimeInput.sendKeys(datetimeValue);

        driver.findElement(NOTE_TEXTAREA).clear();
        driver.findElement(NOTE_TEXTAREA).sendKeys("Đặt lịch tự động Selenium");

        driver.findElement(SUBMIT_BUTTON).click();
        return this;
    }

    /**
     * @return true if the UI indicates the appointment was created.
     */
    public boolean hasCreated() {
        if (!driver.findElements(SUCCESS_ALERT).isEmpty()) {
            return true;
        }
        String url = driver.getCurrentUrl();
        if (url.contains("/donor/history") && url.contains("success")) {
            return true;
        }
        return !driver.findElements(APPOINTMENT_CARD).isEmpty();
    }

    /**
     * @return true if UI shows validation error for the appointment form.
     */
    public boolean hasValidationError() {
        if (!driver.findElements(ERROR_ALERT).isEmpty()) {
            return true;
        }
        if (!driver.findElements(By.cssSelector(".invalid-feedback")).isEmpty()) {
            return true;
        }
        String currentUrl = driver.getCurrentUrl();
        return currentUrl.contains("error") || currentUrl.contains("/donor/schedule");
    }
}
