package com.bloodlink.e2e.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Selenium Page Object for the BloodLink login page (login.jsp).
 */
public class LoginPage {

    private final WebDriver driver;

    private static final By EMAIL_INPUT = By.id("email");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By SUBMIT_BUTTON = By.cssSelector("form[action$='/login'] button[type='submit']");
    private static final By ALERT_ERROR = By.cssSelector(".card .alert.alert-danger");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public LoginPage open(String baseUrl) {
        driver.get(baseUrl + "/login");
        return this;
    }

    public LoginPage login(String email, String password) {
        WebElement emailInput = driver.findElement(EMAIL_INPUT);
        emailInput.clear();
        emailInput.sendKeys(email);

        WebElement passwordInput = driver.findElement(PASSWORD_INPUT);
        passwordInput.clear();
        passwordInput.sendKeys(password);

        driver.findElement(SUBMIT_BUTTON).click();
        return this;
    }

    public boolean hasError() {
        boolean hasAlert = !driver.findElements(ALERT_ERROR).isEmpty();
        boolean stillOnLogin = driver.getCurrentUrl().endsWith("/login") || driver.getCurrentUrl().contains("/login?");
        return hasAlert || stillOnLogin;
    }
}
