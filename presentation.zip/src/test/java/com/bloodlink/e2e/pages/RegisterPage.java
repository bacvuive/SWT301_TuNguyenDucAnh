package com.bloodlink.e2e.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Page object for donor registration flow on register.jsp.
 */
public class RegisterPage {

    private final WebDriver driver;
    private final WebDriverWait wait;

    private static final By FULL_NAME_INPUT = By.id("fullName");
    private static final By EMAIL_INPUT = By.id("email");
    private static final By PASSWORD_INPUT = By.id("password");
    private static final By CONFIRM_PASSWORD_INPUT = By.id("confirmPassword");
    private static final By PHONE_INPUT = By.id("phone");
    private static final By ROLE_SELECT = By.id("role");
    private static final By BLOOD_TYPE_SELECT = By.id("bloodType");
    private static final By ADDRESS_INPUT = By.id("address");
    private static final By AGREE_CHECKBOX = By.id("agree");
    private static final By SUBMIT_BUTTON = By.cssSelector("form#registerForm button[type='submit']");
    private static final By SUCCESS_ALERT = By.cssSelector(".alert.alert-success");
    private static final By ERROR_ALERT = By.cssSelector(".alert.alert-danger");

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    }

    public RegisterPage open(String baseUrl) {
        driver.get(baseUrl + "/register");
        return this;
    }

    /**
     * Fill in donor registration form with minimal required data and submit.
     *
     * @param fullName  donor full name
     * @param username  optional username hint (mapped to phone/address suffix)
     * @param email     donor email
     * @param password  donor password
     * @param bloodGroup blood group to select (e.g. "O+")
     * @return this page object for chaining
     */
    public RegisterPage registerDonor(String fullName, String username, String email, String password, String bloodGroup) {
        return registerDonor(fullName, username, email, password, password, bloodGroup);
    }

    public RegisterPage registerDonor(String fullName, String username, String email, String password, String confirmPassword, String bloodGroup) {
        driver.findElement(FULL_NAME_INPUT).clear();
        driver.findElement(FULL_NAME_INPUT).sendKeys(fullName);

        driver.findElement(EMAIL_INPUT).clear();
        driver.findElement(EMAIL_INPUT).sendKeys(email);

        driver.findElement(PASSWORD_INPUT).clear();
        driver.findElement(PASSWORD_INPUT).sendKeys(password);

        driver.findElement(CONFIRM_PASSWORD_INPUT).clear();
        driver.findElement(CONFIRM_PASSWORD_INPUT).sendKeys(confirmPassword);

        driver.findElement(PHONE_INPUT).clear();
        driver.findElement(PHONE_INPUT).sendKeys(username != null && !username.isBlank() ? username : "0900000000");

        Select role = new Select(driver.findElement(ROLE_SELECT));
        role.selectByValue("donor");

        wait.until(ExpectedConditions.visibilityOfElementLocated(BLOOD_TYPE_SELECT));
        Select bloodType = new Select(driver.findElement(BLOOD_TYPE_SELECT));
        bloodType.selectByVisibleText(bloodGroup);

        driver.findElement(ADDRESS_INPUT).clear();
        driver.findElement(ADDRESS_INPUT).sendKeys("Địa chỉ " + (username != null ? username : "donor"));

        WebElement agree = wait.until(ExpectedConditions.elementToBeClickable(AGREE_CHECKBOX));
        if (!agree.isSelected()) {
            try {
                ((org.openqa.selenium.JavascriptExecutor) driver)
                        .executeScript("arguments[0].scrollIntoView({block: 'center'});", agree);
            } catch (Exception ignored) {
                // Fallback: ignore scroll issues
            }

            try {
                agree.click();
            } catch (org.openqa.selenium.ElementClickInterceptedException e) {
                ((org.openqa.selenium.JavascriptExecutor) driver)
                        .executeScript("arguments[0].click();", agree);
            }
        }

        var submitButton = wait.until(ExpectedConditions.elementToBeClickable(SUBMIT_BUTTON));
        try {
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].scrollIntoView({block: 'center'});", submitButton);
        } catch (Exception ignored) {
            // Ignore scroll issues
        }

        try {
            submitButton.click();
        } catch (org.openqa.selenium.ElementClickInterceptedException e) {
            ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript("arguments[0].click();", submitButton);
        }
        return this;
    }

    /**
     * @return true if registration succeeded (success alert or redirected to login).
     */
    public boolean isSuccess() {
        try {
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.urlContains("/login"),
                    ExpectedConditions.presenceOfElementLocated(SUCCESS_ALERT)));
        } catch (org.openqa.selenium.TimeoutException ignored) {
            // Ignore timeout, we'll fall back to current DOM state
        }

        boolean successAlert = !driver.findElements(SUCCESS_ALERT).isEmpty();
        String currentUrl = driver.getCurrentUrl();
        boolean redirectedToLogin = currentUrl.contains("/login");
        return successAlert || redirectedToLogin;
    }

    /**
     * @return true if the registration form displays an error or stays on the same page.
     */
    public boolean hasError() {
        try {
            wait.until(ExpectedConditions.or(
                    ExpectedConditions.presenceOfElementLocated(ERROR_ALERT),
                    ExpectedConditions.presenceOfElementLocated(By.cssSelector(".invalid-feedback"))));
        } catch (org.openqa.selenium.TimeoutException ignored) {
            // fall back to checking DOM directly
        }

        if (!driver.findElements(ERROR_ALERT).isEmpty()) {
            return true;
        }
        if (!driver.findElements(By.cssSelector(".invalid-feedback")).isEmpty()) {
            return true;
        }
        // If still on register page after submission, treat as error for validation scenario
        String currentUrl = driver.getCurrentUrl();
        return currentUrl.contains("/register");
    }
}
