package com.bloodlink.e2e;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 * Base class for Selenium end-to-end tests.
 * <p>
 * Responsibilities:
 * <ul>
 *     <li>Install and manage browser driver binaries via WebDriverManager.</li>
 *     <li>Create and tear down a {@link WebDriver} instance for each test.</li>
 *     <li>Expose hook methods for subclasses to customize options.</li>
 * </ul>
 */
public abstract class BaseE2ETest {

    protected WebDriver driver;

    @BeforeAll
    static void setupClass() {
        WebDriverManager.chromedriver().setup();
    }

    @BeforeEach
    void setupDriver() {
        ChromeOptions options = buildChromeOptions();
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
    }

    @AfterEach
    void tearDownDriver() {
        if (driver != null) {
            driver.quit();
        }
    }

    /**
     * Hook for subclasses to customize Chrome options (headless mode, timeouts, etc.).
     */
    protected ChromeOptions buildChromeOptions() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-gpu");
        options.addArguments("--remote-allow-origins=*");
        return options;
    }
}
