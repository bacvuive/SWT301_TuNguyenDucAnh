package tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.bloodlink.e2e.BaseE2ETest;
import com.bloodlink.e2e.pages.HospitalRequestPage;
import com.bloodlink.e2e.pages.LoginPage;

@TestMethodOrder(OrderAnnotation.class)
public class HospitalRequestTests extends BaseE2ETest {

    private static final String BASE_URL = System.getProperty("bloodlink.baseUrl", "http://localhost:8080/bloodlink-web");
    private static final String HOSPITAL_EMAIL = System.getProperty("HOSPITAL_EMAIL", "bv_choray@example.com");
    private static final String HOSPITAL_PASS = System.getProperty("HOSPITAL_PASS", "12345678");

    private WebDriverWait wait;

    @BeforeEach
    void initWait() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    }

    @Test
    @Order(1)
    void createRequest_targeted_success() {
        new LoginPage(driver).open(BASE_URL).login(HOSPITAL_EMAIL, HOSPITAL_PASS);
        wait.until(ExpectedConditions.urlContains("/hospital"));

        HospitalRequestPage requestPage = new HospitalRequestPage(driver).openCreate(BASE_URL);
        // TODO: Adjust component value if select options change (currently expecting option value code)
        requestPage.create("O+", "WB", "5", "2");

        wait.until(ExpectedConditions.or(
                ExpectedConditions.urlContains("/hospital/dashboard"),
                ExpectedConditions.urlContains("/hospital/requests")));

        String currentUrl = driver.getCurrentUrl();
        boolean successRedirect = currentUrl.contains("/hospital/dashboard") || currentUrl.contains("/hospital/requests");
        boolean successMessage = driver.getPageSource().toLowerCase().contains("tạo yêu cầu máu thành công");

        assertTrue(successRedirect || successMessage, "Expected successful creation state");
    }

    @Test
    @Order(2)
    void createRequest_broadcast_success() {
        new LoginPage(driver).open(BASE_URL).login(HOSPITAL_EMAIL, HOSPITAL_PASS);
        wait.until(ExpectedConditions.urlContains("/hospital"));

        HospitalRequestPage requestPage = new HospitalRequestPage(driver).openCreate(BASE_URL);
        requestPage.create("A+", "RBC", "3", "");

        wait.until(ExpectedConditions.or(
                ExpectedConditions.urlContains("/hospital"),
                ExpectedConditions.presenceOfElementLocated(org.openqa.selenium.By.cssSelector(".alert.alert-success"))));

        boolean successAlert = driver.getPageSource().toLowerCase().contains("yêu cầu máu");
        assertTrue(successAlert, "Broadcast request should show success message");
    }

    @Test
    @Order(3)
    void createRequest_quantityZero_validation() {
        new LoginPage(driver).open(BASE_URL).login(HOSPITAL_EMAIL, HOSPITAL_PASS);
        wait.until(ExpectedConditions.urlContains("/hospital"));

        HospitalRequestPage requestPage = new HospitalRequestPage(driver).openCreate(BASE_URL);
        requestPage.create("O+", "WB", "0", "");

        assertTrue(requestPage.hasQtyError(), "Quantity zero should trigger validation error");
    }

    @Test
    @Order(4)
    void createRequest_missingBloodGroup_showsError() {
        new LoginPage(driver).open(BASE_URL).login(HOSPITAL_EMAIL, HOSPITAL_PASS);
        wait.until(ExpectedConditions.urlContains("/hospital"));

        HospitalRequestPage requestPage = new HospitalRequestPage(driver).openCreate(BASE_URL);
        requestPage.create("", "WB", "2", "2");

        String validationMessage = requestPage.getBloodGroupValidationMessage();
        assertTrue(validationMessage != null && !validationMessage.isBlank(),
                () -> "Expected browser validation message on blood group select, but was blank. Error section text: " + requestPage.getErrorText());
    }

    @Test
    @Order(5)
    void unauthorized_redirect_to_login() {
        driver.manage().deleteAllCookies();
        driver.get(BASE_URL + "/hospital/requests/create");
        wait.until(ExpectedConditions.urlContains("/login"));
        assertTrue(driver.getCurrentUrl().contains("/login"), "Unauthenticated hospital access should redirect to login");
    }
}
