package tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.Instant;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.bloodlink.e2e.BaseE2ETest;
import com.bloodlink.e2e.pages.LoginPage;
import com.bloodlink.e2e.pages.RegisterPage;

@TestMethodOrder(OrderAnnotation.class)
public class AuthTests extends BaseE2ETest {

    private static final String BASE_URL = System.getProperty("bloodlink.baseUrl", "http://localhost:8080/bloodlink-web");
    private static final String HOSPITAL_EMAIL = System.getProperty("HOSPITAL_EMAIL", "bv_choray@example.com");
    private static final String HOSPITAL_PASSWORD = System.getProperty("HOSPITAL_PASS", "12345678");
    private static String registeredEmail;
    private static final String REGISTER_PASSWORD = System.getProperty("DONOR_PASS", "12345678");

    private WebDriverWait wait;

    @BeforeEach
    void setUpWait() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    }


    @Test
    @Order(1)
    void registerDonor_success() {
        RegisterPage registerPage = new RegisterPage(driver).open(BASE_URL);

        String timestamp = String.valueOf(Instant.now().toEpochMilli());
        String username = "donor_" + timestamp;
        String desiredEmail = System.getProperty("DONOR_EMAIL", "donor3@example.com");//nhập email mới

        // Ensure unique email per run by appending timestamp when needed
        String emailToUse = desiredEmail;
        if (registeredEmail != null && registeredEmail.equals(desiredEmail)) {
            emailToUse = desiredEmail.replace("@", "+" + timestamp + "@");
        }

        registerPage.registerDonor(
                "Donor1 " + timestamp,
                username,
                emailToUse,
                REGISTER_PASSWORD,
                "O+");

        registeredEmail = emailToUse;
        assertTrue(registerPage.isSuccess(), "Registration should succeed for new donor");
    }

    @Test
    @Order(2)
    void registerDonor_passwordMismatch_showsError() {
        RegisterPage registerPage = new RegisterPage(driver).open(BASE_URL);

        String timestamp = String.valueOf(Instant.now().toEpochMilli());
        String username = "donor_mismatch_" + timestamp;
        String email = "donor_mismatch_" + timestamp + "@example.com";

        registerPage.registerDonor(
                "DonorMismatch " + timestamp,
                username,
                email,
                REGISTER_PASSWORD,
                REGISTER_PASSWORD + "123",
                "A+");

        assertTrue(registerPage.hasError(), "Password mismatch should keep user on form with error");
    }

    @Test
    @Order(3)
    void login_success_donor() {
        String email = registeredEmail != null ? registeredEmail : System.getProperty("DONOR_EMAIL", "trung@gmail.com");
        LoginPage loginPage = new LoginPage(driver).open(BASE_URL)
                .login(email, REGISTER_PASSWORD);

        wait.until(driver -> driver.getCurrentUrl().contains("/dashboard") || driver.getPageSource().toLowerCase().contains("xin chào"));

        String currentUrl = driver.getCurrentUrl();
        boolean urlMatches = currentUrl.contains("/donor/dashboard");
        boolean welcomeVisible = driver.getPageSource().toLowerCase().contains("xin chào"); // TODO adjust text if locale changes

        assertTrue(urlMatches || welcomeVisible, "Should redirect to donor dashboard after successful login");
    }

    @Test
    @Order(4)
    void login_fail_wrongPassword() {
        String email = registeredEmail != null ? registeredEmail : System.getProperty("DONOR_EMAIL", "donor1@example.com");
        LoginPage loginPage = new LoginPage(driver).open(BASE_URL)
                .login(email, REGISTER_PASSWORD + "wrong");

        wait.until(driver -> driver.getCurrentUrl().contains("/login"));
        assertTrue(loginPage.hasError(), "Expected to remain on login with error for wrong password");
    }

    @Test
    @Order(5)
    void login_success_hospital() {
        new LoginPage(driver).open(BASE_URL)
                .login(HOSPITAL_EMAIL, HOSPITAL_PASSWORD);

        wait.until(driver -> driver.getCurrentUrl().contains("/hospital")
                || driver.getPageSource().toLowerCase().contains("bệnh viện"));

        String currentUrl = driver.getCurrentUrl();
        boolean onHospitalPage = currentUrl.contains("/hospital/dashboard") || currentUrl.contains("/hospital/requests");
        assertTrue(onHospitalPage, "Hospital login should navigate to hospital area");
    }

}
