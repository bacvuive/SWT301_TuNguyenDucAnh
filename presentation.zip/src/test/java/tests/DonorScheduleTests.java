package tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Duration;
import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.bloodlink.e2e.BaseE2ETest;
import com.bloodlink.e2e.pages.DonorSchedulePage;
import com.bloodlink.e2e.pages.LoginPage;

@TestMethodOrder(OrderAnnotation.class)
public class DonorScheduleTests extends BaseE2ETest {

    private static final String BASE_URL = System.getProperty("bloodlink.baseUrl", "http://localhost:8080/bloodlink-web");
    private static final String DONOR_EMAIL = System.getProperty("DONOR_EMAIL", "trung@gmail.com");
    private static final String DONOR_PASS = System.getProperty("DONOR_PASS", "12345678");

    private WebDriverWait wait;

    @BeforeEach
    void initWait() {
        wait = new WebDriverWait(driver, Duration.ofSeconds(5));
    }

    @Test
    @Order(1)
    void createAppointment_success() {
        new LoginPage(driver).open(BASE_URL).login(DONOR_EMAIL, DONOR_PASS);

        // Wait until dashboard or schedule link visible before navigating
        wait.until(ExpectedConditions.urlContains("/dashboard"));

        DonorSchedulePage schedulePage = new DonorSchedulePage(driver).open(BASE_URL);
        String futureDate = LocalDate.now().plusDays(2).toString();

        schedulePage.createAppointment("1", futureDate, "09:00");
        assertTrue(schedulePage.hasCreated(), "Appointment creation should show success state");
    }

    @Test
    @Order(2)
    void createAppointment_missingDate_showsValidationError() {
        new LoginPage(driver).open(BASE_URL).login(DONOR_EMAIL, DONOR_PASS);
        wait.until(ExpectedConditions.urlContains("/dashboard"));

        DonorSchedulePage schedulePage = new DonorSchedulePage(driver).open(BASE_URL);

        schedulePage.createAppointment("1", null, null);

        assertTrue(schedulePage.hasValidationError(), "Missing datetime should trigger validation error");
    }

    @Test
    @Order(3)
    void schedule_unauthorized_redirect() {
        driver.manage().deleteAllCookies();
        driver.get(BASE_URL + "/donor/schedule");
        wait.until(ExpectedConditions.urlContains("/login"));
        assertTrue(driver.getCurrentUrl().contains("/login"), "Unauthenticated access should redirect to login");
    }
}
