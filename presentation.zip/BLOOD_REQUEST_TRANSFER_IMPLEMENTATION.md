# Blood Request & Transfer Implementation Guide

## Tổng quan

Đã triển khai hệ thống yêu cầu máu và điều phối (blood request & transfer) theo quy trình nghiệp vụ chi tiết.

## Các thành phần đã triển khai

### 1. Database Layer

#### SQL Migration: `create_request_audit_and_procedures.sql`
- ✅ **request_audit table**: Lưu audit trail cho mọi thay đổi status của request
- ✅ **CHECK constraint**: `from_hospital_id != to_hospital_id`
- ✅ **sp_update_request_status**: Stored procedure với row-level locking và validation
- ✅ **sp_allocate_transfer**: Allocate bags theo FIFO với row-level locking
- ✅ **sp_complete_transfer**: Complete transfer và auto-complete request

### 2. Data Access Layer

#### RequestAuditDAO
- ✅ `create()`: Tạo audit record
- ✅ `findByRequestId()`: Lấy audit history
- ✅ `findById()`: Lấy audit record theo ID

### 3. Service Layer

#### BloodRequestService
- ✅ **createRequest()**: 
  - Validation: `from_hospital_id != to_hospital_id`, `quantity > 0`
  - Tạo audit record khi tạo request
  - Gửi notifications cho donors và hospitals

- ✅ **acceptRequest()**: 
  - Row-level locking (UPDLOCK) để tránh race condition
  - Broadcast logic: First-accept wins
  - Validation: Chỉ to_hospital (hoặc bất kỳ hospital nào với broadcast) mới có thể accept
  - Auto-create transfer nếu enabled và đủ stock

- ✅ **rejectRequest()**: 
  - Row-level locking
  - Validation tương tự acceptRequest
  - Gửi notifications

- ✅ **completeRequest()**: 
  - Chỉ from_hospital (người tạo request) mới có thể complete
  - Validation status transition: ACCEPTED → COMPLETED

#### TransferService
- ✅ **createTransferWithAllocation()**: 
  - Tạo transfer và allocate bags
  - Sử dụng stored procedure `sp_allocate_transfer` nếu có
  - Fallback về Java implementation với row-level locking

- ✅ **handleTransferEvent()**: 
  - Xử lý events: PICKED_UP, IN_TRANSIT, DELIVERED, CANCELLED
  - State machine validation
  - Auto-complete request khi DELIVERED (nếu enabled)

- ✅ **completeTransfer()**: 
  - Sử dụng stored procedure `sp_complete_transfer` nếu có
  - Chuyển bags sang to_hospital và set status = AVAILABLE
  - Auto-complete request nếu có request_id

- ✅ **cancelTransfer()**: 
  - Trả bags về AVAILABLE
  - Update transfer status = CANCELLED

### 4. API Endpoints

#### Đã có sẵn:
- ✅ `POST /hospital/requests/create` - Tạo yêu cầu máu
- ✅ `PATCH /requests/:id/accept` - Chấp nhận yêu cầu
- ✅ `PATCH /requests/:id/reject` - Từ chối yêu cầu
- ✅ `PATCH /requests/:id/complete` - Hoàn tất yêu cầu

#### Cần tạo thêm:
- ⚠️ `POST /transfers` - Tạo transfer request (có thể tự động từ accept request)
- ⚠️ `POST /transfers/:id/events` - Xử lý transfer events (PICKED_UP, IN_TRANSIT, DELIVERED, CANCELLED)

### 5. State Machine

#### Blood Request States:
- `PENDING` → `ACCEPTED` (bởi to_hospital hoặc first hospital với broadcast)
- `PENDING` → `REJECTED` (bởi to_hospital)
- `ACCEPTED` → `COMPLETED` (bởi from_hospital)

#### Transfer States:
- `PENDING` → `ACCEPTED` (khi allocate bags thành công)
- `ACCEPTED` → `IN_TRANSIT` (khi PICKED_UP)
- `IN_TRANSIT` → `COMPLETED` (khi DELIVERED)
- `*` → `CANCELLED` (khi hủy)

## Quy trình nghiệp vụ

### 1. Tạo yêu cầu (Create Request)
```
POST /hospital/requests/create
Body: { bloodGroup, component, quantity, toHospitalId (nullable) }
```

**Validation:**
- `from_hospital_id != to_hospital_id` (CHECK constraint)
- `quantity > 0`
- `bloodGroup` valid

**Actions:**
- Tạo request với status = PENDING
- Tạo audit record
- Gửi notifications cho donors và hospitals

### 2. Duyệt yêu cầu (Review Request)

#### Accept:
```
PATCH /requests/:id/accept
```

**Logic:**
- Lock request row (UPDLOCK)
- Validate: Chỉ to_hospital (hoặc bất kỳ hospital với broadcast) mới có thể accept
- Broadcast: First-accept wins
- Update status: PENDING → ACCEPTED
- Auto-create transfer nếu enabled và đủ stock

#### Reject:
```
PATCH /requests/:id/reject
```

**Logic:**
- Lock request row
- Validate tương tự accept
- Update status: PENDING → REJECTED

### 3. Tạo điều phối & giữ túi (Allocate/Reserve)

**Tự động khi accept request (nếu auto-link enabled):**
- Tạo transfer request
- Gọi `sp_allocate_transfer` để allocate bags theo FIFO
- Set bags status = RESERVED
- Set transfer status = ACCEPTED

### 4. Vận chuyển (Dispatch & In-transit)

**Cần tạo endpoint:**
```
POST /transfers/:id/events
Body: { eventType: 'PICKED_UP' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED', note }
```

**State transitions:**
- `PICKED_UP`: ACCEPTED → IN_TRANSIT
- `IN_TRANSIT`: IN_TRANSIT → IN_TRANSIT (update event)
- `DELIVERED`: IN_TRANSIT → COMPLETED
- `CANCELLED`: * → CANCELLED (trả bags về AVAILABLE)

### 5. Bàn giao & hoàn tất (Delivery & Complete)

**Khi DELIVERED:**
- Gọi `sp_complete_transfer`:
  - Chuyển bags sang to_hospital
  - Set bags status = AVAILABLE
  - Set transfer status = COMPLETED
  - Auto-complete request nếu có request_id

## Broadcast vs. Targeted

### Targeted Request (to_hospital_id != NULL):
- Chỉ 1 bệnh viện nhận được yêu cầu
- Chỉ bệnh viện đó mới có thể accept/reject
- Dễ kiểm soát SLA

### Broadcast Request (to_hospital_id = NULL):
- Tất cả bệnh viện (trừ from_hospital) nhận được yêu cầu
- **First-accept wins**: Bệnh viện đầu tiên accept sẽ win
- Các bệnh viện khác sẽ thấy request đã được accept (status != PENDING)

## Quy tắc nghiệp vụ

1. ✅ **from_hospital_id ≠ to_hospital_id** (CHECK constraint)
2. ✅ **Chỉ to_hospital mới có thể Accept/Reject** (validated trong service)
3. ✅ **Chỉ PENDING mới Accept/Reject; chỉ ACCEPTED mới Complete**
4. ✅ **Túi chỉ chạy: AVAILABLE → RESERVED → IN_USE|TRANSFERRED**
5. ✅ **Alloc FIFO theo expiry_date**
6. ✅ **Tất cả bước thay đổi ghi audit + notification**

## Các bước tiếp theo

### 1. Tạo API endpoints cho transfers

#### Tạo TransferServlet:
```java
@WebServlet("/transfers/*")
public class TransferServlet extends HttpServlet {
    // POST /transfers - Tạo transfer (optional, có thể tự động từ accept)
    // GET /transfers/:id - Lấy transfer details
    // POST /transfers/:id/events - Xử lý transfer events
}
```

#### Tạo TransferEventServlet:
```java
@WebServlet("/transfers/*/events")
public class TransferEventServlet extends HttpServlet {
    // POST /transfers/:id/events
    // Body: { eventType: 'PICKED_UP' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED', note }
}
```

### 2. Cải thiện stored procedure calls

**Vấn đề:** Stored procedures có thể tự commit, nhưng chúng ta đang trong transaction.

**Giải pháp:** 
- Option 1: Không dùng transaction khi gọi stored procedure (stored procedure tự quản lý transaction)
- Option 2: Tạo version của stored procedure không commit (với parameter)

### 3. Re-allocation logic

**Khi bag expire trước khi pickup:**
- Cần job để kiểm tra bags đã RESERVED quá lâu
- Re-allocate nếu cần

### 4. Testing

- Test concurrent accept với broadcast requests
- Test insufficient stock scenarios
- Test state machine transitions
- Test audit logging

## Lưu ý quan trọng

1. **Stored Procedures**: Các stored procedures tự quản lý transaction, nên khi gọi từ Java code trong transaction, cần cẩn thận với nested transactions.

2. **Row-level Locking**: Sử dụng `UPDLOCK, ROWLOCK` để tránh race condition, đặc biệt với broadcast requests.

3. **Broadcast Logic**: First-accept wins - bệnh viện đầu tiên accept sẽ win, các bệnh viện khác sẽ thấy request đã được accept.

4. **Auto-link**: Khi accept request, nếu auto-link enabled và đủ stock, tự động tạo transfer và allocate bags.

5. **Notifications**: Tất cả thay đổi status đều gửi notifications cho các bệnh viện liên quan.

## Kết luận

Đã triển khai đầy đủ các chức năng cốt lõi:
- ✅ Create request với validation
- ✅ Accept/Reject với locking và broadcast logic
- ✅ Auto-create transfer với allocation
- ✅ Transfer events handling
- ✅ Complete transfer và auto-complete request
- ✅ Audit logging
- ✅ Notifications

Cần bổ sung:
- ⚠️ API endpoints cho transfers (optional, có thể tự động từ accept)
- ⚠️ UI để quản lý transfers
- ⚠️ Re-allocation logic cho expired bags
- ⚠️ Testing

